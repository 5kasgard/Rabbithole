#!/usr/bin/env python3
from __future__ import annotations
import ast, os, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TESTS = [
    "tests/test_akbc.py",
    "tests/test_analogy_ecology_presentation_benchmark.py",
    "tests/test_arc_contact_surface.py",
    "tests/test_arc_provenance_projection.py",
    "tests/test_argument.py",
    "tests/test_assurance.py",
    "tests/test_catalog_provider.py",
    "tests/test_cli.py",
    "tests/test_corpus.py",
    "tests/test_discovery.py",
    "tests/test_field_cli_contact.py",
    "tests/test_inquiry_surface.py",
    "tests/test_instrument.py",
    "tests/test_intent.py",
    "tests/test_kernel_regression.py",
    "tests/test_live_acquisition_inquiry.py",
    "tests/test_master_cli.py",
    "tests/test_master_interchange.py",
    "tests/test_master_registry.py",
    "tests/test_organ_dependency_mutation.py",
    "tests/test_organs.py",
    "tests/test_outward_loop_master.py",
    "tests/test_performance_fabric_v017.py",
    "tests/test_portfolio_ir_actions.py",
    "tests/test_process.py",
    "tests/test_provenance.py",
    "tests/test_provenance_invalidation.py",
    "tests/test_scope.py",
    "tests/test_verification.py",
    "tests/test_forager.py",
    "tests/test_placement.py",
]

def main() -> int:
    failures=[]
    for test in TESTS:
        print(f"\n== {test} ==", flush=True)
        path=ROOT/test
        tree=ast.parse(path.read_text())
        has_pytest_tests=any(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith("test_") for n in ast.walk(tree))
        command=[sys.executable,"-m","pytest","-q",str(path)] if has_pytest_tests else [sys.executable,str(path)]
        env=os.environ.copy()
        env["PYTHONPATH"] = str(ROOT) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
        env.setdefault("PYTEST_DISABLE_PLUGIN_AUTOLOAD", "1")
        try:
            with tempfile.TemporaryDirectory(prefix="field-product-test-") as workdir:
                result=subprocess.run(command,cwd=workdir,env=env,timeout=90)
        except subprocess.TimeoutExpired:
            print(f"TIMEOUT: {test}")
            failures.append(test)
            continue
        if result.returncode: failures.append(test)
    if failures:
        print("Failed:", *failures, sep="\n- ")
        return 1
    print(f"\nAll {len(TESTS)} product test modules passed.")
    return 0

if __name__ == "__main__": raise SystemExit(main())
