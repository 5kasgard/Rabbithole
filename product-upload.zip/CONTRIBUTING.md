# Contributing

Keep changes bounded, testable and explicit about authority. A contribution should state the problem, affected invariant, evidence or test, rollback path and any new external claim.

Run `python scripts/run_product_tests.py` before opening a pull request. Do not commit generated runtime state, archives, credentials or benchmark outputs.
