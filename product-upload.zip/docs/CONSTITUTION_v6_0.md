# THE FIELD CONSTITUTION v6.0

## Status and precedence

This constitution governs the 0.18.0rc3 master candidate. It supersedes v5.0 for current development. v5.0 remains immutable in `legacy/normative-v0.17/`.

Evidence receipts outrank status prose. Human or institutional normative authority outranks system-generated preference. External claims remain blocked until the relevant external evidence exists.

## Axioms

### A1 — Reality-bound authority
No claim gains epistemic authority except through an appropriate test, observation or proof whose scope and limitations are recorded.

### A2 — Proposal is not authority
Generation, search, analogy, language models, heuristics and internal agreement may propose. They cannot promote their own outputs.

### A3 — Authority dimensions remain separate
Epistemic support, model applicability, action permission and normative approval are distinct. No dimension may silently substitute for another.

### A4 — Disagreement is state
Rival claims, identities and models remain representable without forced merge. Disagreement alone does not erase authority; failed tests, invalidated sources, scope failure or explicit revocation do.

### A5 — Provenance and dependence are reconstructable
Every load-bearing object identifies its source, transformation, dependency, version, scope and invalidation path.

### A6 — Bounded pluralism
No process, representation, runtime, storage system, network, model or hardware substrate is presumed universal. Allocation follows task shape, risk, contact evidence and total cost.

### A7 — Slow-clock reality priority
Internal coherence is the fast clock; reality contact is the slow clock. No new governance layer may be promoted without a linked external contact, deletion, or measured reduction in operating burden.

### A8 — Human normative sovereignty
Consent, legitimacy, values and irreversible commitments require explicit human or institutional authority. Factual confidence cannot mint normative permission.

### A9 — Historical immutability
Prior releases, tests and audit evidence remain byte-preserved. New versions append new evidence and may invalidate prior claims; they do not rewrite their own history.

### A10 — Decision propagation
Every load-bearing decision must map to affected requirements, components, capabilities, migrations, documents, tests, fallbacks and unresolved external gates.

## Operational invariants

### O1 — Test-bound promotion
Every promotion records the test class, evaluator, evidence identity, authority ceiling, applicability and revocation conditions.

### O2 — Mechanical transport grants no semantic authority
A valid interchange envelope proves only canonical transport and dependency mechanics. Semantic support requires profile-specific tests.

### O3 — Transformations declare loss
Every extraction, mapping, compression, summary, conversion or deletion declares retained structure, loss, reversibility, dependencies and cost.

### O4 — Fallback or abstention
Unknown, shifted, unavailable, unsafe or uncontacted regions must use a contacted fallback or explicitly abstain.

### O5 — Reversible default action
Automated action defaults to dry-run or reversible execution. Irreversible action requires separately identifiable authority and cannot claim rollback.

### O6 — Perpetual profile invariant
A profile may be called perpetual only when it repeatedly acquires, tests, acts within authority, monitors, replans, accounts resources and abstains under a frozen external objective.

### O7 — POSIWID recording
Every promoted mechanism records intended purpose, observed effect, displaced cost, failure behavior, operator burden and rollback fidelity.

### O8 — Resource honesty
Latency, CPU, memory, I/O, network, money, energy, human attention, experiment cost and irreversible risk remain separate dimensions unless a declared conversion model is justified.

### O9 — Independence is evidenced
Labels such as independent, adversarial or external do not establish independence. Identity, organisation, authorship, timing and shared-code relationships must be recorded where independence matters.

### O10 — Readiness does not close reality
Local tests may prove software readiness. They cannot prove external utility, safety, adoption, longitudinal superiority or institutional legitimacy.

## Architecture boundaries

1. The authoritative waist carries identity, version, dependencies, scope, authority ceiling, revocation and resource metadata.
2. Semantic profiles remain plural and may define stronger constraints.
3. Python remains the current reference authority implementation; bounded specialists may accelerate contacted regions.
4. Historical campaign builders and evidence are archival dependencies, not mandatory live runtime dependencies.
5. Local state and policy remain sovereign by default.
6. Federation preserves version and rival claims rather than forcing global consensus.
7. External providers and actuators are capabilities with explicit policy, not ambient powers.

## Amendment process

An amendment must include:

- the wording changed;
- the failure or evidence motivating it;
- affected decisions, components and tests;
- a strongest opposing case;
- migration and rollback;
- whether it changes epistemic, operational or normative authority;
- explicit human approval.

Amendments never retroactively alter historical records.

## Release rule

A master candidate may integrate current architecture and documentation. A canonical release may claim only what its inherited, local and external gates support.

If slow-clock gates remain blocked, experimental mechanisms are published separately or as release candidates. They are not promoted through readiness scores alone.
