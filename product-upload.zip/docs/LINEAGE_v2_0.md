# Lineage v2.0

## Identity rule

A release is identified by version plus SHA-256. A version label without bytes and digest is not a unique artifact.

## Canonical chain

- Rx0 / v0.5.0: complete textual snapshot; original archive absent.
- v0.14.0: canonical archive `40cd8c2267e4f0e3c789cf4d586adea8227cfbc68ff9b43004d8c4d5f3f13ecd`.
- v0.15.0: canonical archive `bdabe625624b68d754f64a95ca3427565ccfde0bf469ca6ff8f9d582a538736d`.
- v0.16.0: canonical hash previously verified as `496a27e7a956f0625aca3c4e7642a947f49f9497ad3a9ef46fc0416088e4572a`; original archive absent; source reconstructed independently by forward and reverse patches.
- v0.17.0: canonical archive `de17deb19cf94172a06faed997f32c2a5d70e17f58f719bf5ac3f87ad66fdca1`.
- v0.18.0rc1–rc2: superseded integrated master candidates; retained as noncanonical build history.
- v0.18.0rc3: current integrated master candidate; not canonical promotion.

## Major reductions

1. Rx0 established the first reality-grounded constraint kernel, disagreement layer, placement problem and thin-waist insight.
2. v0.14 rejected a universal discovery process and introduced a task-proportionate process portfolio.
3. v0.15 rejected substrate preference and retained Python authority with bounded specialists.
4. v0.16 built independent longitudinal-validation machinery while keeping the empirical verdict blocked.
5. v0.17 accelerated bounded regions without replacing authority boundaries.
6. The lineage-and-vision audit found the epistemic spine preserved but the outward organism, exocortex and standard incomplete.
7. 0.18.0rc1–rc2 established the first integrated master, current documents, protocol draft, bounded outward loop, front door and evidence vault.
8. 0.18.0rc3 completes origin-mechanism reuse, master chronology, resident supervision, target profiles, transport, utility accounting, scaling and exhaustive decision propagation while keeping external promotion blocked.

## ARC lineage

The original reasoning gate was:

```text
Expose → invariant-check → adversarial split → smallest real test
```

It evolved into:

```text
contract → concrete → expose → abstract → arena → contact → complete
```

The larger process does not replace the original discipline. Every campaign must still identify the smallest real contact capable of moving belief.

## Preservation and migration

- Historical source, reports and receipts remain immutable.
- New releases may supersede claims but never edit prior evidence.
- A capability may be narrowed, deprecated or removed only with explicit disposition, replacement, migration, replay and rollback evidence.
- Additive accumulation is not preservation if it makes the live organism unmaintainable; decoupling precedes deletion.

## Decision propagation

`master/MASTER_DECISION_REGISTRY.json` is the current closure ledger. Every future release appends or updates current closure state while retaining the previous registry in history.
