# Master Scaling Architecture

## Governing rule

Scale by ownership, coupling and failure domain—not by fashion. The current design is heterogeneous by bounded function and homogeneous at authority boundaries.

## Planes

1. **Authority plane:** single replayable writer for contracts, decisions, permissions, revocation and canonical state. Shard only after a contacted distributed-ownership protocol.
2. **Acquisition plane:** horizontally scalable provider workers; every artifact content-addressed, provenance-bound and hostile-data isolated.
3. **Search/evidence plane:** parallel retrieval and independent lanes; deduplicate by evidence root before authority accounting.
4. **Formal/specialist plane:** CPU/native/GPU/remote specialists admitted by applicability contracts, whole-route break-even, differential reference checks and fallback.
5. **Profile plane:** target-profile views are derived from source-local assertions; identity hypotheses remain rival/versioned.
6. **Coordination plane:** resident scheduler uses one authoritative queue, leases and bounded handlers; workers may scale, scheduling authority remains replayable.
7. **Interchange plane:** FIP provides bounded mechanical envelopes; transports may vary, semantic profiles remain plural and test-bound.
8. **Presentation plane:** derived read models and notifications may scale independently; they never become authority stores.
9. **History plane:** immutable content-addressed lineage vault, physically separable from live packages.

## Scaling sequence

- Eliminate repeated work and duplicate serialization first.
- Batch before concurrency; concurrency before distribution.
- Scale immutable reads and independent acquisition before mutable authority.
- Partition by objective, tenant, privacy domain and failure domain.
- Introduce backpressure, leases, deadlines, idempotency and compensation before higher throughput.
- Keep a contacted conservative reference for every specialist.
- Measure p50/p95/p99, memory, I/O, energy proxy, human burden, recovery and useful outcome together.

## Forbidden shortcuts

- No service mesh merely to make the architecture look distributed.
- No shared mutable state without ownership and replay semantics.
- No summed speedups or epistemic scores.
- No distributed authority from local FIP conformance alone.
- No profile scale that bypasses privacy, lawful basis or deletion controls.
