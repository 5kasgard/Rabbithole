# Field Interchange Protocol — Experimental Draft v1

## Status

Experimental candidate. Not an adopted standard. Same-campaign Python, Node and Go implementations passed 10,000 valid objects and 22 adversarial cases; independent clean-room implementation and deployed compatibility remain missing.

## Purpose

FIP is a minimal mechanical envelope for exchanging authority-relevant objects across heterogeneous components without pairwise canonicalization rules.

It is not a transport and it is not a universal semantic ontology.

## Envelope

A v1 object contains:

- `fip`: protocol identity (`field/1`);
- `profile`: semantic profile name and version;
- `identity`: stable object identity;
- `object_type`: must equal profile name;
- `dependencies`: sorted unique identities;
- `authority`: mechanical ceiling, issuer and scopes;
- `revocation`: active/revoked plus monotonic sequence;
- `payload`: profile-specific content;
- `extensions`: namespaced non-critical data;
- `critical_extensions`: extensions that must be understood;
- `digest`: SHA-256 of canonical material excluding the digest field.

## Canonicalization

- UTF-8 object keys are sorted by byte order.
- Duplicate keys, non-finite numbers and unsafe integers are rejected.
- Integral floats canonicalize as integers.
- Non-integral numbers use profile-defined decimal strings.
- Input size, depth, object, array and dependency limits are enforced.

## Authority boundary

Passing FIP validation yields `semantic_authority: false`. A semantic profile may require additional proofs, measurements, signatures or institutional approvals.

## Promotion gates

- two independent clean-room implementations;
- public vectors and negative cases;
- extension and profile governance;
- compatibility trial;
- real multi-producer/multi-consumer use;
- measured reduction in adapter burden;
- no semantic-authority laundering.
