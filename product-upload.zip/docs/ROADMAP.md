# ROADMAP — Current Master Candidate

## Integrated now

- current normative authority set;
- canonical lineage and content-addressed evidence vault;
- decision, requirement, component, capability and standard registries;
- experimental FIP reference implementation;
- bounded outward-loop operating profile;
- simple normal front door;
- inherited v0.17 authority, validation and performance systems.

## Promotion-critical external contacts

1. Freeze and externally timestamp a reversible real objective.
2. Run the outward profile continuously for 72 hours.
3. Obtain two clean-room FIP implementations by independent actors or organisations.
4. Run the separately approved 14-day continuation against an equal-budget baseline.
5. Measure utility, critical/non-critical error, abstention quality, p50/p95/p99, resource cost, operator burden and rollback fidelity.
6. Test the normal front door with non-developer operators.

## Engineering sequence

- Add real provider, instrument and reversible-action adapters one bounded profile at a time.
- Build the whole-target profile as a versioned, rival-preserving workflow.
- Decouple archive/campaign builders from live runtime imports before deletion.
- Add profile governance and compatibility history for FIP.
- Build local mobile/exocortex presentation only after normal workflow contact identifies the actual user burden.
- Integrate collective federation only after mechanical and semantic boundary trials.

## Prohibited shortcut

Do not promote a canonical v0.18 solely because the integrated candidate passes internal tests.


## 0.18.0rc3 origin recovery and gap closure

The master now includes a persistent resident scheduler/supervisor, versioned whole-target profiles, capability-scoped FIP transports, utility-per-resource receipts, a complete origin reuse registry, origin-to-current changelog, cross-implementation propagation matrix, gap ledger, blind-spot ledger and scaling/subtraction plans. These are bounded internal mechanisms; external promotion gates remain open.
