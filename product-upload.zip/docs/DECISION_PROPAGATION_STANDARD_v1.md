# Decision Propagation Standard v1

A local architectural insight is incomplete until its consequences are evaluated across the whole organism.

For each load-bearing decision, record:

- stable decision ID and origin;
- exact statement and rejected alternatives;
- affected requirements, components and capabilities;
- interfaces, data models, authority owners and resource dimensions;
- documents and examples requiring change;
- migration, compatibility and rollback;
- demonstration and attempted-kill tests;
- local closure, cross-propagation gaps and external blockers.

A release cannot claim whole-system alignment while a mandatory target is absent or unknown. Bounded application is labelled bounded, not silently generalized.

The machine-readable implementation is `master/MASTER_DECISION_REGISTRY.json`; `rabbithole.master_registry.MasterRegistry` enforces referential integrity.
