# Functional Checklist — Current Master 0.18.0rc3

Generated from current machine registries. Receipts and source override this view.

## Requirements

| ID | Requirement | Current state | Basis |
|---|---|---|---|
| R01 | installed_phase | partial_not_lived | Installable and locally owned, but not an immediate ordinary-user phase. |
| R02 | perpetual_catalyst | bounded_runtime_built_external_blocked | Persistent resident scheduler/supervisor and objective-scoped outward loop now exist; 72-hour, 14-day and independent utility evidence remain blocked. |
| R03 | truth_grounded_acceleration | strong_internal_external_unproven | Authority discipline is strong; accelerated useful knowledge outcomes are not independently established. |
| R04 | constraint_pruning_gradient | aligned_bounded | Formal pruning and deterministic-to-epistemic gradient exist with explicit scope. |
| R05 | infrastructure_reach_and_actuation | bounded_transport_and_action_partial | Capability-scoped FIP transport and action contracts exist; broad live connector/device ecosystem remains unbuilt. |
| R06 | whole_target_profile | structural_profile_built_external_quality_blocked | Versioned whole-target profile now preserves rival identities, claims, dependencies, privacy and revocation; longitudinal entity-resolution accuracy is unproven. |
| R07 | task_proportionate_heterogeneity | aligned_bounded | Task-proportionate method and substrate portfolios exist; selection remains authored and locally validated. |
| R08 | operational_anti_closure | strong_internal_partial_operational | Anti-closure is strong internally; external provider and institutional plurality remain weak. |
| R09 | strange_loop_under_external_test | internal_loop_live_external_feedback_blocked | Mutation and amendment gates exist; external beneficiary feedback has not closed the loop. |
| R10 | personal_exocortex_and_sovereignty | partial_installable_not_exocortex | Local sovereignty exists; lived personal exocortex and independent usability evidence do not. |
| R11 | collective_coordination_without_collapse | structural_only_no_deployed_collective | Federation structures exist; no deployed multi-party coordination ecology. |
| R12 | complete_memory_with_resource_honesty | resource_honest_memory_and_utility_partial | Replay, provenance, transformation loss and local utility-per-resource receipts exist; complete memory and cross-domain aggregation remain invalid claims. |
| R13 | domain_and_scale_plurality | partial_plurality_not_universal | Plural representations and methods exist; broad domain and scale competence is unproven. |
| R14 | objective_legibility | structurally_aligned_interface_partial | Claims and limits are explicit, but presentation remains expert-oriented. |
| R15 | external_utility_and_harm | blocked_external | No independent longitudinal utility, harm or equal-budget comparison yet. |

## Capabilities

| ID | Capability | Current disposition | Category | Remaining gap |
|---|---|---|---|---|
| C01 |  | retained as bounded formal/numerical specialist, not universal reasoning engine | preserved_strong_bounded |  |
| C02 |  | partial; arbitrary unstructured intent interpretation is not externally validated | preserved_partial |  |
| C03 |  | live for registered structured objects; general cross-domain entity resolution remains partial | preserved_strong_bounded |  |
| C04 |  | partial; multimodal and abstract carving remain frontier or externally bounded | preserved_partial |  |
| C05 |  | live for structured registered cases; partial-context entity/measurand identity remains unresolved | preserved_strong_bounded |  |
| C06 |  | partial; broad autonomous web/paper/database/sensor acquisition is not a live bundled ecosystem | outward_gap |  |
| C07 |  | registry is live; breadth and actual independence of external oracle ecosystem remain partial | preserved_strong_bounded |  |
| C08 |  | structurally live; calibration and long-horizon decay quality remain externally unproven | preserved_strong_bounded |  |
| C09 |  | strong local integrity/replay; privileged whole-ledger rewrite and arbitrary event-prefix reconstruction remain boundaries | preserved_strong_local |  |
| C10 |  | live process kernel; evidence breadth and real external independence depend on providers and actors | preserved_strong_bounded |  |
| C11 |  | live structural guardrail; role labels do not prove independent actors or complete search | preserved_strong_bounded |  |
| C12 |  | live selector over registered methods; selector criteria can themselves become hidden universal authority | preserved_strong_bounded |  |
| C13 |  | campaign engine and local evidence live; unavailable substrates remain blocked rather than falsified | added_bounded |  |
| C14 |  | experimental local portfolio; no production tail, energy, edge, remote or long-duration proof | added_experimental |  |
| C15 |  | resource dimensions and local uncertainty-reduction-per-resource receipts are represented; cross-domain aggregation and external outcome calibration remain prohibited | preserved_partial_strengthened | independent calibration against real outcomes |
| C16 |  | bounded to registered dialects and explicit probabilistic/empirical assumptions | preserved_narrowed |  |
| C17 |  | transactional action contracts exist; broad live tool/device adapters and long-horizon execution are external/unbuilt | outward_gap |  |
| C18 |  | CLI/report surfaces are live; intended exocortex experience and independent comprehension evidence are absent | operationally_drifted |  |
| C19 |  | local federation structures plus capability-scoped FIP in-process/file-drop transport exist; no deployed collective network | bounded_transport_structural_collective_gap | deployed multi-party interoperability and governance |
| C20 |  | durable resident scheduler/supervisor with leases, priorities, dependencies, retries, restart and telemetry now exists; long-duration autonomous contact remains unproven | newly_built_bounded_external_gap | 72-hour and 14-day live operation |
| C21 |  | versioned whole-target profile with rival identities, assertions, privacy scopes and dependency revocation now exists | newly_built_structural_external_quality_gap | longitudinal false-merge/false-split and useful-profile evaluation |
| C22 |  | strong structural anti-closure internally; external provider diversity and actual independent authorship remain unproven | preserved_strong_internal |  |
| C23 |  | internal recursive process is live; independent external challenge and outcome feedback are not yet completed | preserved_internal_external_gap |  |
| C24 |  | protocol/runtime ready; empirical superiority and real utility remain unproven | runtime_ready_external_blocked |  |
| C25 |  | strong local controls; distributed compromise, privileged custodian and deployed supply-chain threats remain beyond evidence | preserved_strong_local |  |
| C26 |  | goal retained as compositional aspiration; no universal domain competence is claimed or demonstrated | narrowed_aspiration_not_claim |  |

## Components and POSIWID

| ID | Component | Observed effect | Judgement |
|---|---|---|---|
| P01 | goal_and_intent | GoalGate rejects underspecified/high-risk goals; proposal faculties can structure text but require explicit configuration. | withheld |
| P02 | constraint_kernel | Runs a bounded interval/dimensional constraint solver with strong local regression coverage. | withheld |
| P03 | acquisition_search | Provides content-addressed local/catalog/Crossref/OpenAlex mechanisms and campaign structures; a fresh instrument attaches zero provider runtimes by default. | withheld |
| P04 | carving_representation | Supports registered document/quantity/claim extraction and typed IR contracts. | withheld |
| P05 | placement_identity | Precision-first structured mapping with reversible hypotheses and non-merge bias. | withheld |
| P06 | verification_oracles | Ships seven local verifier contracts/implementations and component byte attestations. | withheld |
| P07 | epistemic_disagreement | Maintains argument/provenance/calibration structures and refuses consensus-as-proof. | withheld |
| P08 | memory_replay_invalidation | Hash-chained logs, snapshots, persistence, dependency containment and invalidation; serializes selected structured state. | withheld |
| P09 | actions_actuation | Implements a capability-secured action registry, but a fresh organism registers zero concrete actions and the public CLI has no general action-registration/capability-mint surface. | withheld |
| P10 | process_arc5_arc5a | Creates extensive human-stepped campaign state, frozen lanes, approvals, tests and contact receipts. | withheld |
| P11 | process_portfolio | Registers nine seeded methods and computes hard-valid Pareto frontiers; high-stakes unresolved cases require human choice. | withheld |
| P12 | performance_fabric | Routes among fresh, batched, scoped-warm, transactional and native bounded mechanisms with fallback. | withheld |
| P13 | presentation_interface | Provides a narrow text resolution report; standalone JSX exists but is not integrated into the release workflow or user-tested as the personal phase. | withheld |
| P14 | federation_collective | Provides sealed bundle and conflict-ledger primitives; fresh state has zero bundles and no network transport/deployed collective. | withheld |
| P15 | environment_instrument_contact | Defines registries/contracts and now includes capability-scoped in-process and file-drop FIP transports; broad deployed adapters remain absent. | bounded_new_external_gap |
| P16 | self_improvement_mutation | Ships mutation operators, recursive campaigns and integrity checks; most contact remains local and self-authored. | withheld |
| P17 | longitudinal_validation | Implements a rigorous frozen 180-day study ledger and blocks its verdict with no external data. | withheld |
| P18 | personal_sovereignty_installed_phase | Ships local archives/wheels, a simple master front door, a bounded resident runtime and target profiles; ordinary-user usability remains externally untested. | partial_lived_gap |
| P19 | resident_scheduler_supervisor | Durable priority/dependency queue, leases, retry limits, restart generations, telemetry and exact replay under frozen objective IDs. | bounded_internal_external_duration_blocked |
| P20 | whole_target_profile | Versioned rival identity hypotheses and attributable assertions with dependency revocation, privacy scopes and no self-granted authority. | structural_built_external_resolution_blocked |
| P21 | interchange_transport_registry | Bidirectional in-process and atomic file-drop FIP transport with explicit capability scopes and semantic-authority false. | bounded_local_interoperability |
| P22 | utility_accounting | Metric-contract-local uncertainty reduction, outcome, risk and resource receipts without cross-domain score laundering. | bounded_internal_external_calibration_blocked |

## Gap closure

| ID | Gap | State | Remaining boundary |
|---|---|---|---|
| G01 | perpetual coordination | built_bounded | 72-hour/14-day and independent utility |
| G02 | whole-target profile | built_structural | real longitudinal false-merge/false-split performance |
| G03 | bidirectional transport seam | built_bounded | network/mobile/device adapters and independent interoperability |
| G04 | useful uncertainty reduction per resource | built_local_metric_contract | cross-task calibration and external outcomes |
| G05 | TCP/IP-like standard | experimental_contacted_local | independent implementations, governance, compatibility history |
| G06 | broad acquisition ecosystem | partial | live web/database/sensor connector portfolio |
| G07 | broad actuation ecosystem | partial | live device/tool adapters and institutional approval |
| G08 | personal exocortex | partial | integrated ordinary-user surface and usability evidence |
| G09 | collective coordination | structural | deployed multi-party governance and transport |
| G10 | runtime/archive subtraction | planned | decoupling proof and safe module deletion |
| G11 | external longitudinal validation | runtime_ready_blocked | elapsed time, private tasks, independent evaluators |
| G12 | complete normative propagation | built_machine_checked | future releases must keep matrix closed |

## Release status

- 0.18.0rc3 is an integrated master candidate.
- Canonical v0.18 promotion remains blocked by external slow-clock gates.
- FIP is experimental; same-campaign implementations are not independent.
- Resident runtime and whole-target profiles are structurally built but not externally validated.

