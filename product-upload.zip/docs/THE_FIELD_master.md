# THE FIELD — Current Master Architecture 0.18.0rc3

## Status

This is the current integrated master candidate. It consolidates the canonical v0.17 organism, all retained ARC conclusions, the lineage-and-vision audit, updated normative documents, the experimental Field Interchange Protocol, a bounded outward-loop profile, a simple front door, machine-readable decision propagation and a content-addressed historical vault.

It is not a canonical v0.18 promotion. External promotion gates remain open.

## 1. Architectural statement

The Field is:

> A locally sovereign, truth-grounded computational organism with a thin mechanical authority waist, plural semantic profiles, task-proportionate processes, bounded specialists, reconstructable memory and explicit human normative control.

The implementation is heterogeneous by bounded function and homogeneous at authority boundaries.

## 2. Planes

### 2.1 Goal and normative authority plane

Human-owned objectives, success conditions, budgets, allowed actions, expiry and institutional approval. The system may interpret and propose; it cannot infer consent or legitimacy.

### 2.2 Mechanical interchange plane

FIP provides canonical encoding, digest identity, dependencies, revocation, scopes and extension behavior. It grants no semantic authority.

### 2.3 Semantic and epistemic plane

Typed observations, carvings, mappings, models, claims, uncertainty, provenance, argument, disagreement, applicability and verification contracts.

### 2.4 Formal constraint plane

Dimensions, intervals, registered invariants, proof/refinement loops and specialist numerical kernels reject impossible states within declared scope.

### 2.5 Process plane

Minimal scientific loops, ARC-5, ARC-5A, evidence synthesis, CEGAR, Bayesian experiment selection, adversarial collaboration and design-science cycles are selected by task shape, risk and preconditions.

### 2.6 World-contact plane

Providers, acquisition, parsers, instruments, environments, external experiments and action capabilities. Every connector has policy, source identity, resource accounting and failure behavior.

### 2.7 Perpetual coordination plane

The outward-loop profile freezes an external objective and repeatedly acquires, tests, acts reversibly, monitors and replans or abstains. It is structurally implemented but externally unvalidated.

### 2.8 Memory and history plane

Append-only logs, content stores, contract versions, snapshots, invalidation, federation and the historical lineage vault. Current runtime does not require archival campaign builders.

### 2.9 Presentation and exocortex plane

A small `field-master` front door exposes current status, verification, interchange and outward operation. The advanced `field` surface remains available. A true lived exocortex still requires non-developer contact and richer multimodal presentation.

## 3. Authority flow

```text
human/institution freezes objective and permissions
    ↓
proposers create candidates with zero authority
    ↓
mechanical envelope validates identity and dependencies
    ↓
semantic profile places and scopes the object
    ↓
appropriate tests or proofs support, falsify or leave unresolved
    ↓
applicability gate determines local use
    ↓
capability and approval gate authorizes reversible action
    ↓
monitoring and external outcomes can retain, narrow or revoke authority
```

No lower step may be bypassed by confidence or convenience.

## 4. Current live implementation

The candidate retains the complete v0.17 capability surface and adds:

- `rabbithole.interchange`: experimental FIP reference implementation and contract adapter;
- `rabbithole.outward_loop`: objective-scoped acquire→test→act→monitor→replan runtime;
- `rabbithole.master_registry`: machine verification of standards, decisions, requirements, components, capabilities, documents and history;
- `master_cli.py` / `field-master`: simplified normal operating surface;
- `master/*.json`: current authority and closure registries;
- `history/`: content-addressed releases, ARCs, audits and precursor sources;
- current v2.1 vision, v6.0 constitution, conformance v1.0 and lineage v2.0.

## 5. Operating profiles

### Reference profile

Fresh v0.17-compatible authority path. Strongest isolation and known semantics. Used for fallback and rollback.

### Bounded performance profile

Cold batching, scoped warm execution, transactional auxiliary state and native numerical specialization only inside contacted regions.

### Experimental interchange profile

FIP validation at component boundaries. Semantic authority remains false until profile-specific verification.

### Bounded outward profile

A frozen low-risk reversible objective with explicit budget and adapters. The built-in file-integrity profile is operational; other connectors require registration.

### Validation profile

The Stage 5 longitudinal runtime remains available and empirically blocked until independent evidence matures.

## 6. Current POSIWID

The master candidate's actual present effect is:

> Integrate and govern a strong epistemic organism, expose a coherent current architecture, preserve its complete lineage, provide a mechanically viable interchange candidate, and make one bounded outward loop operational without claiming that the full personal and collective phase has been achieved.

## 7. Missing organism

The following remain material product gaps:

- default long-running provider and instrument ecosystem;
- broad reversible action adapters;
- whole-target profile workflow;
- personal mobile exocortex UI;
- deployed collective federation;
- independent protocol ecosystem;
- real 72-hour and 14-day outward trials;
- independent longitudinal benefit and harm evidence.

These gaps are tracked in machine-readable registries and block canonical promotion where applicable.

## 8. Current commands

```bash
field-master status
field-master verify
field-master fip-seal input.json --profile evidence --identity example
field-master fip-verify envelope.json
field-master phase-init examples/master/file_integrity_loop.json ./state/loop
field-master phase-step examples/master/file_integrity_loop.json ./state/loop
field-master phase-status ./state/loop
```

The expert surface remains:

```bash
field --help
field-performance --help
field-accept
```

## 9. Source of truth

1. `docs/CONSTITUTION_v6_0.md`
2. `docs/GOAL_VISION.md`
3. `docs/CONFORMANCE_v1_0.md`
4. `docs/LINEAGE_v2_0.md`
5. this document
6. `master/*.json`
7. evidence receipts and history

Evidence can narrow prose. Prose cannot broaden evidence.


## 0.18.0rc3 origin recovery and gap closure

The master now includes a persistent resident scheduler/supervisor, versioned whole-target profiles, capability-scoped FIP transports, utility-per-resource receipts, a complete origin reuse registry, origin-to-current changelog, cross-implementation propagation matrix, gap ledger, blind-spot ledger and scaling/subtraction plans. These are bounded internal mechanisms; external promotion gates remain open.
