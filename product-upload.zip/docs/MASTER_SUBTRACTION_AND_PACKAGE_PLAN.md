# Runtime, Archive and Subtraction Plan

The live runtime, experimental mechanisms and historical evidence must be separable.

## Packages

- `the-field-core`: authority, contracts, provenance, replay, verification, goal and bounded formal kernel.
- `the-field-organism`: acquisition, inquiry, process portfolios, resident runtime, profiles, actions and presentation.
- `the-field-fip`: experimental protocol, transports, vectors and conformance.
- `the-field-history`: releases, ARC packages, audit packages and precursor snapshots.
- `the-field-dev`: campaign builders, mutation tools and acceptance runners.

## Deletion rule

A module is deleted only after imports are decoupled, public capability equivalence is proven, historical replay remains possible from the history package, and the normal install/diagnosis burden improves. Archive retention is not live-runtime retention.
