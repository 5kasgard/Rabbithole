# The Field — Master Changelog from Origin to 0.18.0rc3

This is the consolidated change history. It records canonical releases, precursor mechanisms, missing artifacts, rejected universals, surviving functions and present disposition. Source and receipts override prose.

## precursor-rabbithole-0.5-1.1
- **Identity/status:** supplemental AI corpus ddf0eba7…04b2 — supplemental_noncanonical.
- **Changes:** active scheduler and EIG; resident executive and supervisor; capabilities and Byzantine filtering; event log, telemetry and bidirectional transport; whole-surface cleanup catalog
- **What survives now:** Functions recovered or absorbed under current authority rules; obsolete kernels are historical only.

## rx0-v0.5.0
- **Identity/status:** repomix de510a57…ff79 — earliest canonical textual baseline.
- **Changes:** constraint field and topology gating; first ARC discoveries; thin-waist objective; source ledger, WAL and local UI
- **What survives now:** Formal specialist, first-ARC method, truth boundary and thin-waist objective remain load-bearing.

## v0.6.0
- **Identity/status:** historical source/changelog — canonical lineage.
- **Changes:** typed AKBC waist; reversible placement; authority-laundering closure; scoped capabilities and sound routing
- **What survives now:** Current semantic intake and authority separation.

## v0.7.0
- **Identity/status:** historical source/changelog — canonical lineage.
- **Changes:** ARC-5; content-addressed search; verification and IR registries; argument/provenance/action systems; FieldInstrument
- **What survives now:** Persistent discovery and plural contracts.

## v0.8.x
- **Identity/status:** no retained canonical release artifact — lineage_gap_not_invented.
- **Changes:** No recoverable canonical change set; no changes invented.
- **What survives now:** No claims made; later v0.9 diff is accepted only from retained source history.

## v0.9.0
- **Identity/status:** historical source/changelog — canonical lineage.
- **Changes:** universal-field rejection; thin typed evidence/contract waist; goal, component, calibration, causal, ontology, federation and drift gates; bounded task surface
- **What survives now:** Plural dialect architecture and bounded specialist field.

## v0.10.0
- **Identity/status:** historical source/changelog — canonical lineage.
- **Changes:** persistent ARC5 kernel; frozen search/test plans; human approvals and reopening
- **What survives now:** Current ARC-5 process kernel.

## v0.11.0
- **Identity/status:** historical source/changelog — canonical lineage.
- **Changes:** recursive 18-capability campaign; exact lineage passages; claim narrowing and reconstruction queue
- **What survives now:** Whole-system capability reconstruction discipline.

## v0.12.0
- **Identity/status:** historical source/changelog — canonical lineage.
- **Changes:** whole-organism reconstruction; resource-aware portfolios; environments, explanation, mutation, design and scenario mechanisms
- **What survives now:** Broad organism organs and public assurance surface.

## v0.13.0
- **Identity/status:** historical source/changelog — canonical lineage.
- **Changes:** ARC-5A constructive/destructive lanes; dual decompositions/lattices; five-role arena; dual-authored tests and saturation
- **What survives now:** High-stakes adversarial host.

## v0.14.0
- **Identity/status:** 40cd8c22…13ecd — canonical archive verified.
- **Changes:** process-against-process; task-proportionate process portfolio; universal-process rejection
- **What survives now:** Specialist process ownership and no score laundering.

## v0.15.0
- **Identity/status:** bdabe625…736d — canonical archive verified.
- **Changes:** substrate campaign; CPython authority retained; native numerical specialist; reversible migrations
- **What survives now:** Heterogeneous by bounded function, homogeneous authority.

## v0.16.0
- **Identity/status:** 496a27e7…4572a canonical hash; source dual-reconstructed — canonical bytes absent_source exact.
- **Changes:** 180-day independent validation runtime; frozen arms/challenges/evaluators; statistical and anti-contamination hardening
- **What survives now:** External claims remain mechanically blocked until real evidence.

## v0.17.0
- **Identity/status:** de17deb1…dca1 — canonical archive verified_reference.
- **Changes:** performance ARC; cold batching; scoped warm capsule; transactional auxiliary state; specialist/fallback selector
- **What survives now:** Bounded local acceleration without authority migration.

## performance-arc-round-2
- **Identity/status:** seven-stage contract→complete campaign — completed internal campaign.
- **Changes:** content-addressed disk inventory; bottleneck and failure decomposition; authority-aware work-elimination abstraction; five-role arena; contacted warm, batch, transactional and specialist mechanisms; bounded hybrid architecture.
- **What survives now:** v0.17 performance fabric and the rule “heterogeneous by bounded function, homogeneous at authority boundaries.” Production tails, edge, energy and external outcomes remain open.

## lineage-vision-audit-r1
- **Identity/status:** seven-stage contract→complete audit, final synthesis 230/230 — completed internal audit.
- **Changes:** exact Rx0→v0.17 reconstruction; whole/component reverse-POSIWID; first-ARC and TCP/IP-like waist backfill; 76-decision propagation; FIP cross-language and outward-loop contact; constitutional and promotion corrections.
- **What survives now:** current normative authority, drift/gap ledgers, experimental FIP decision, and the rule that external slow-clock evidence controls promotion.

## v0.18.0rc1-rc2
- **Identity/status:** superseded master candidates — noncanonical_build_history.
- **Changes:** normative refresh; lineage vault; FIP prototype; bounded outward loop; master registries and front door
- **What survives now:** Basis for rc3; superseded candidates retained, not promoted.

## v0.18.0rc3
- **Identity/status:** built by current overhaul — integrated master candidate_external gates open.
- **Changes:** origin reuse registry; complete master changelog; resident scheduler/supervisor; whole-target profile; capability-scoped transport; utility accounting; scaling architecture; cross-implementation propagation and gap ledger
- **What survives now:** Most complete internally integrated master; not canonical v0.18.

## Cross-lineage reductions

- The universal constraint field became a bounded formal specialist.
- The universal discovery process became a task-proportionate portfolio.
- The universal representation became plural semantic profiles over a narrow mechanical authority waist.
- The universal substrate became bounded heterogeneous specialists under homogeneous authority/replay.
- “Never compress” became explicit transformation-loss and reversibility accounting.
- “Perpetual” now requires repeated acquisition, testing, reversible action, monitoring, replanning, resource accounting and abstention.

## Current status

0.18.0rc3 is the most complete internally integrated master candidate. External promotion gates remain open; it is not canonical v0.18.0.
