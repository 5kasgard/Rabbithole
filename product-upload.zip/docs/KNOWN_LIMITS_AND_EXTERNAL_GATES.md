# Known Limits and External Gates

The integrated master candidate does not close:

- 72 continuous hours of live outward operation;
- separately approved 14-day continuation;
- equal-budget external baseline;
- independent utility and harm evaluation;
- independent clean-room FIP implementations;
- public FIP governance or adoption;
- production p95/p99 across real providers and networks;
- physical power-loss durability on target hardware;
- edge-device energy and thermal envelopes;
- broad live instruments and actuators;
- non-developer exocortex usability;
- deployed multi-party federation.

These are not documentation tasks. They require elapsed time, external actors, concrete hardware, real objectives or institutions. The master candidate preserves them as blocked promotion gates.
