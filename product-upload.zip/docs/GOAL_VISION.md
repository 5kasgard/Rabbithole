# THE FIELD — Current Goal and Vision v2.1

## Status

This document is the current target state for the master candidate. It replaces literal universal claims that later ARC contact disproved while preserving the original intent: a personal, truth-grounded computational phase that continuously extends a person's ability to understand and act in reality.

The Field is not an oracle, a chatbot, a single model, a single constraint engine, or a single process. It is a **locally sovereign computational organism** whose components cooperate through explicit authority, evidence, scope, resource and revocation contracts.

## 1. The phase

The intended product is a phase a person can enter on their own substrate. It should feel less like operating a research framework and more like extending cognition into a persistent, reality-coupled faculty.

The installed phase begins useful, honest and locally owned. It does not begin omniscient. It ships with:

- a tested epistemic constitution;
- core dimensional and logical checks;
- typed evidence, provenance and disagreement mechanisms;
- a bounded process portfolio;
- safe fallback and abstention;
- local memory, replay and revocation;
- a simple operating surface;
- explicit capability and resource envelopes.

Depth accretes through contact with the user's domains, sources, instruments, projects and objectives. New standing structure enters only with declared origin, scope and authority.

## 2. How it computes

The Field uses a **deterministic-to-epistemic gradient**.

At the hard end, formal invariants, dimensions, types, proof obligations and executable contracts reject impossible states. At the open-world end, search, extraction, statistical models, causal hypotheses, adversarial processes and experiments propose and discriminate possibilities. Generation is permitted to propose. It cannot grant itself authority.

No single representation, process or substrate is universal. The architecture is:

> A thin mechanical authority waist, plural semantic profiles, task-proportionate processes and bounded specialists.

Constraint propagation remains a powerful specialist. It is not the whole organism.

## 3. Authority

No claim gains epistemic authority from fluency, confidence, popularity, repetition, transport validity, internal agreement or source identity.

Authority is separated into at least five independent questions:

1. Was an object proposed or observed?
2. Did an appropriate test support it?
3. Is the supporting model applicable here?
4. Is the actor permitted to act?
5. Is the action normatively approved by the relevant human or institution?

The Field may automate evidence collection and reversible action. It may not infer consent, legitimacy or irreversible authority from factual confidence.

## 4. Memory and information

The Field aims for resource-honest, reconstructable memory—not the impossible claim that finite systems never transform or compress information.

Raw artifacts are retained where lawful and feasible. Every extraction, mapping, summary, compression, conversion and deletion must declare:

- what was retained;
- what was lost;
- whether the change is reversible;
- which source and version it depends on;
- how it may be invalidated;
- what storage, compute, money, energy and human attention it costs.

Historical evidence is append-only and content-addressed. Duplicate copies never count as independent evidence.

## 5. The perpetual operational invariant

A persistent database is not a perpetual catalyst. A valid perpetual profile must repeatedly perform:

```text
freeze external objective and budget
→ acquire from reality
→ place and preserve provenance
→ test or explicitly remain unresolved
→ select a process proportionate to risk and shape
→ act only within permission and reversibility bounds
→ monitor the result
→ repair, replan, escalate or abstain
→ record actual POSIWID and resource cost
```

The loop must survive provider failure, contradictory evidence, stale credentials, partial action, monitoring disagreement, restart, state corruption, goal drift and budget exhaustion without laundering authority.

## 6. Personal exocortex

The core atom is one person and one locally owned phase. The system should:

- run on devices the person controls;
- keep private state local by default;
- expose a small normal front door and a deeper expert surface;
- preserve the user's history and decisions;
- adapt presentation to the user's level without hiding evidence;
- make uncertainty, disagreement and required human decisions visible;
- support offline and degraded operation.

Cloud or remote faculties provide capacity, not sovereignty. Local policy decides what may leave the device and what authority may return.

## 7. World reach

The internal bridge may use web search, databases, code execution, instruments, images, simulations, APIs and physical devices. Every connector is a bounded capability, not a universal trust channel.

The phase should eventually support cross-domain target profiles for people, organisations, technologies, scientific objects, places, products, patents, projects and systems. Such profiles must preserve rival identities, temporal versions, provenance, uncertainty and legal/ethical boundaries.

## 8. Collective phase

A collective Field is a federation of locally sovereign fields, not a central truth vote and not a training-data pool.

The collective layer may exchange mechanically conformant envelopes, semantic profiles, test receipts and revocations. Local fields re-evaluate applicability and authority. Rival models and cultural contexts may coexist where no decisive test exists.

Collective coordination must not collapse semantic plurality into one ontology or one institution.

## 9. Interoperability

The Field requires a TCP/IP-like narrow waist in the limited sense that independently implemented components should exchange authority-bearing objects without pairwise custom reconciliation.

The experimental Field Interchange Protocol currently targets:

- canonical encoding and digest identity;
- version and profile identity;
- dependencies and revocation;
- authority ceilings and scopes;
- critical and non-critical extensions.

Mechanical conformance is not semantic truth. Semantic profiles remain plural and test-bound. FIP is not a standard until independent clean-room implementations, governance, compatibility history and real multi-party use exist.

## 10. Heterogeneity

The Field is heterogeneous by bounded function and homogeneous at authority boundaries.

Different tasks may require formal checking, evidence synthesis, ARC-5A, Bayesian experiment selection, adversarial collaboration, design science, a minimal scientific loop, native numerical code, databases, local models or remote faculties.

Every specialist must have:

- explicit preconditions and contraindications;
- a reference or fallback;
- differential or contact tests;
- a kill condition;
- resource and operator-burden accounting;
- revocation and rollback.

## 11. Resource objective

The target is not universally trivial computation. It is:

> Maximise reliable, useful uncertainty reduction and successful reversible action per unit of total resource.

Total resource includes latency, CPU, memory, storage, network, money, energy, external experiments, human review, maintenance, recovery and irreversible risk. Every operating profile publishes its envelope and degraded modes.

## 12. Self-improvement and the strange loop

The Field may inspect and modify its processes, representations, routing and implementation. It cannot certify itself through self-consistency.

Self-improvement requires:

- an independently frozen objective;
- a retained unchanged comparator;
- adversarial tests not authored solely by the modifier;
- external contact where the claim concerns reality;
- rollback on hard-gate failure;
- decision propagation across every affected component and document.

The strange loop is valid only when it returns through reality, not when the system produces increasingly elaborate evidence about itself.

## 13. Present boundary

The master candidate integrates the strongest current architecture and documents. It does not claim that the full vision is complete.

Still externally blocked are:

- 72-hour and 14-day real outward operation;
- independent longitudinal utility and harm evidence;
- independently authored FIP implementations and adoption;
- broad live provider, instrument and action ecosystems;
- non-developer exocortex usability;
- deployed collective coordination.

The system must say this plainly. Honesty about the missing organism is part of the organism.
