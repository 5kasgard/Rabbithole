# Conformance Standard v1.0

A component or release conforms only if all applicable requirements below are satisfied. File presence is never sufficient.

## 1. Identity and history

- Version and SHA-256 identify every release and frozen artifact.
- Historical artifacts are byte-preserved and indexed by evidence class.
- Reconstructed material is explicitly labelled and never presented as original bytes.

## 2. Authority

- Proposal, verification, applicability, permission and normative approval are separate.
- No transport, model, source or process grants itself authority.
- Authority ceilings and revocation paths are explicit.

## 3. Information

- Raw sources are content-addressed where lawful and feasible.
- Transformations declare retained and lost structure.
- Dependencies and invalidation propagate.
- Duplicate copies do not create evidence independence.

## 4. Process

- Method choice records preconditions, contraindications, risk and overhead.
- High-risk unresolved frontiers remain visible.
- Tests are frozen before decisive contact.
- Failed contact reopens the causally implicated assumption or stage.

## 5. Heterogeneous implementation

- Specialists have bounded scopes and contacted fallbacks.
- Whole-operation benefit includes boundary, verification, recovery and maintenance cost.
- Cross-language or cross-runtime behavior has differential conformance tests.

## 6. Interchange

- Canonical encoding and digest behavior are mechanically testable.
- Critical extensions fail closed.
- Unknown non-critical extensions round-trip without authority gain.
- Dependency cycles, stale revocations, reactivation and revoked dependencies are rejected.
- Semantic authority remains profile-specific.

## 7. Outward operation

- The objective, budget, actors and allowed actions are frozen.
- Acquisition, testing, action, monitoring and replanning produce receipts.
- Automated action is reversible unless explicit external authority says otherwise.
- Failures cause abstention, compensation, escalation or stop—not fabricated completion.

## 8. Decision propagation

Every release includes a machine-readable registry mapping each load-bearing decision to:

- requirements;
- components;
- capabilities;
- source and evidence;
- migrations and documents;
- tests and kill conditions;
- current closure state;
- unresolved external obligations.

Unknown targets or missing closure states fail conformance.

## 9. Documentation

- Current goal, constitution, master architecture, lineage, checklist and roadmap agree.
- Superseded normative documents remain in history.
- Capability status is regenerated from evidence, not copied from old prose.

## 10. Promotion

A canonical promotion requires:

- inherited regressions;
- current source-bound tests;
- clean extraction and integrity replay;
- rollback fidelity;
- all applicable external gates;
- no unsupported whole-vision or standard claim.

The 0.18.0rc3 master candidate is conformant as an integrated candidate only. Its canonical promotion is blocked by the external gates listed in `master/MASTER_PROMOTION_CONTRACT.json`.
