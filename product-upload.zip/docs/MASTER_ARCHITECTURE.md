# Master Architecture and Integration Map

## Design rule

Do not merge every mechanism into every execution path. Apply every load-bearing **standard and decision** to every affected component, while keeping specialist implementations behind bounded interfaces.

## Core live packages

- `core`, `field`, `fast`: formal constraint specialist and reference implementation.
- `akbc`, `ontology`, `mapping_precision`: typed observation, identity and placement.
- `waist`: append-only semantic contract envelope.
- `interchange`: language-neutral mechanical envelope.
- `verification`, `scope`, `assurance`, `argument`, `causal`: authority and applicability.
- `acquisition`, `providers`, `extraction`, `inquiry`: world contact and zero-authority carving.
- `actions`, `capabilities`, `environment`, `instrument`: permissioned execution.
- `arc_kernel`, `arc_adversarial`, `process_portfolio`: task-proportionate discovery and adjudication.
- `substrate_campaign`, `performance_fabric`: bounded implementation selection.
- `outward_loop`: operational continuous profile.
- `master_registry`: cross-lineage conformance and decision propagation.

## Archival packages

Historical campaign builders, stage receipts, prior releases and precursor snapshots are stored under `history/`. They are not imported by the normal runtime.

## Cross-cutting standards

Every affected component is evaluated against `master/MASTER_STANDARD_PROFILE.json`. Not every standard is implemented through one base class; conformance is proven by interfaces, registries and tests appropriate to the component.

## Thin waists

The architecture intentionally retains two layers:

1. **FIP mechanical envelope** for canonical cross-runtime identity and lifecycle mechanics.
2. **Semantic contract waist** for scope, uncertainty, verification, permissions, applicability and resource metadata.

Collapsing them would either make the wire format too rich or make semantic authority too weak.

## Migration strategy

- Preserve v0.17 reference behavior.
- Add current master capabilities without rewriting inherited receipts.
- Migrate boundaries to FIP experimentally, one profile at a time.
- Run outward loops through adapters, not direct core privileges.
- Decouple archive and live runtime before deletion.
- Promote only externally survived slices.


## 0.18.0rc3 origin recovery and gap closure

The master now includes a persistent resident scheduler/supervisor, versioned whole-target profiles, capability-scoped FIP transports, utility-per-resource receipts, a complete origin reuse registry, origin-to-current changelog, cross-implementation propagation matrix, gap ledger, blind-spot ledger and scaling/subtraction plans. These are bounded internal mechanisms; external promotion gates remain open.
