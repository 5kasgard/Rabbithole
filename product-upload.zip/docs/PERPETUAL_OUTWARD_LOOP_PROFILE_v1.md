# Bounded Perpetual Outward-Loop Profile v1

## Status

Implemented as a release-candidate operating profile. It establishes the required mechanics, not the missing 72-hour, 14-day or independent-utility evidence.

## Cycle

```text
frozen objective and budget
→ acquire
→ verify
→ reversible action or abstention
→ monitor
→ replan, escalate or stop
→ persist audit, contract and resource receipts
```

## Hard rules

- no action without supported verification;
- reversible-only by default;
- objective expiry and resource budgets are enforced;
- state is atomically persisted and digest-bound;
- state corruption is detectable;
- every cycle enters the contract waist and audit log;
- external utility claims remain false until independent contact exists.

## Built-in profile

The master candidate includes a local file-integrity profile suitable for release manifests, sensor-export files or downloaded artifacts with an expected digest. It writes a reversible status artifact and monitors it.

Additional providers, instruments and actuators are plugins with separate capability and authority contracts. They are not implied by the core profile.
