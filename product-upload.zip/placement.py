"""Compatibility placement facade.

The production placement model lives in :mod:`rabbithole.akbc`.  This small API
is retained for old demos, but it now obeys the same safety rules:

* dimension can veto but never prove identity;
* an explicit accreted alias may merge;
* a fallible similarity proposer only creates ``unresolved``;
* refused or unresolved carvings get distinct nodes;
* sourced values enter as untested evidence, never tested truth.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable, Optional

from rabbithole.core import unit as unit_lookup


def _norm(s: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", s.lower()))


class Aliases:
    """Union-find equivalence over explicitly accepted aliases."""
    def __init__(self):
        self.parent: dict[str, str] = {}

    def _find(self, x: str) -> str:
        x = _norm(x)
        self.parent.setdefault(x, x)
        if self.parent[x] != x:
            self.parent[x] = self._find(self.parent[x])
        return self.parent[x]

    def same(self, a: str, b: str) -> bool:
        a, b = _norm(a), _norm(b)
        return a == b or (a in self.parent and b in self.parent and self._find(a) == self._find(b))

    def link(self, a: str, b: str) -> None:
        ra, rb = self._find(a), self._find(b)
        if ra != rb:
            self.parent[rb] = ra


@dataclass
class Placement:
    action: str  # exact|merged|new|unresolved|refused_dimension
    target: str
    reason: str = ""


def _distinct_name(field, name: str, unit: str) -> str:
    base = f"{name} [{unit or 'dimensionless'}]"
    if base not in field.variables:
        return base
    i = 2
    while f"{base} #{i}" in field.variables:
        i += 1
    return f"{base} #{i}"


def resolve(field, name: str, unit: str, aliases: Aliases,
            propose_same: Optional[Callable[[str, str], bool]] = None) -> Placement:
    try:
        inc_dim, _ = unit_lookup(unit)
    except KeyError:
        return Placement("new", _distinct_name(field, name, unit),
                         f"unknown unit {unit!r}; kept separate")

    if name in field.variables:
        if field.variables[name].dim == inc_dim:
            return Placement("exact", name, "same label and dimension")
        return Placement("refused_dimension", _distinct_name(field, name, unit),
                         "same label but incompatible dimension; distinct node required")

    proposed = []
    for vname, v in field.variables.items():
        alias = aliases.same(name, vname)
        semantic = bool(propose_same and propose_same(name, vname))
        if not (alias or semantic):
            continue
        if v.dim != inc_dim:
            proposed.append((vname, "dimension_veto"))
            continue
        if alias:
            return Placement("merged", vname,
                             "explicit accepted alias and dimension agree")
        proposed.append((vname, "similarity_only"))

    if any(kind == "similarity_only" for _, kind in proposed):
        return Placement("unresolved", _distinct_name(field, name, unit),
                         "similarity proposed identity, but representation alone has no authority")
    if proposed:
        return Placement("refused_dimension", _distinct_name(field, name, unit),
                         "similarity proposed identity but dimension vetoed it")
    return Placement("new", _distinct_name(field, name, unit) if name in field.variables else name,
                     "no candidate identity")


def place_value(field, name: str, unit: str, value: float, sigma: float, source: str,
                aliases: Aliases, propose_same=None, confidence: float = 0.9) -> Placement:
    p = resolve(field, name, unit, aliases, propose_same)
    target = p.target
    if target not in field.variables:
        field.var(target, unit)
    inc_scale = unit_lookup(unit)[1]
    tgt = field.variables[target]
    value_in_tgt = value * inc_scale / tgt.unit_scale
    sigma_in_tgt = sigma * inc_scale / tgt.unit_scale
    field.add_evidence(target, value_in_tgt, sigma_in_tgt, source=source,
                       confidence=confidence, tested=False, contact="human",
                       statement=f"{name} = {value} ± {sigma} {unit} via {source}")
    return p
