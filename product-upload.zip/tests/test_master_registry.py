from __future__ import annotations

import json
from pathlib import Path

from rabbithole.master_registry import MasterRegistry


def test_master_registry_is_referentially_and_historically_valid():
    root = Path(__file__).resolve().parents[1]
    result = MasterRegistry(root).verify()
    assert result["valid"], result["issues"]
    assert result["requirements"] == 15
    assert result["components"] == 22
    assert result["capabilities"] == 26
    assert result["decisions"] == 88
    assert result["external_claims_closed"] is False


def test_master_status_preserves_reference_and_promotion_boundary():
    root = Path(__file__).resolve().parents[1]
    status = MasterRegistry(root).status()
    assert status["identity"]["reference_version"] == "0.17.0"
    assert status["identity"]["promotion"] == "blocked until external gates"
    assert status["verdict"]["evidence_overlay"] == "blocked_by_missing_evidence"
    assert status["fip"]["standard_achieved"] is False


def test_document_authority_targets_exist():
    root = Path(__file__).resolve().parents[1]
    raw = json.loads((root / "master/MASTER_DOCUMENT_AUTHORITY.json").read_text())
    for row in raw["precedence"]:
        assert (root / row["document"]).exists(), row
