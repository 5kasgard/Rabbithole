import json
import sys
from pathlib import Path

from rabbithole.discovery import DiscoveryArc, POSIWIDContract
from rabbithole.faculties import SubprocessFaculty
from rabbithole.process import ARC5Controller, SearchEnvelope
from rabbithole.search import LocalCorpusProvider


def contract():
    return POSIWIDContract(
        "placement", ("aliases first-match",), ("identity is reversible",),
        ("fixtures compose",), ("unseen carvings compose without contamination",),
    )


def test_seed_queries_are_contrastive():
    q = ARC5Controller.seed_queries(contract())
    assert {x["polarity"] for x in q} >= {"for", "against", "failure", "boundary"}


def test_stage_gate_refuses_narrow_search(tmp_path: Path):
    p = tmp_path / "a.md"
    p.write_text("placement mechanism success")
    arc = DiscoveryArc(contract())
    c = ARC5Controller(arc, SearchEnvelope(("software",), min_independent_groups=2),
                       {"local": LocalCorpusProvider([tmp_path])})
    c.run_search(provider="local", text="placement success", stage="concrete",
                 polarity="for", wave=0, domain_family="software")
    gate = c.concrete_gate()
    assert not gate.passed
    assert any("polarities" in x for x in gate.reasons)


def test_subprocess_faculty_is_propose_only(tmp_path: Path):
    script = tmp_path / "faculty.py"
    script.write_text('''import json,sys\nr=json.load(sys.stdin)\nprint(json.dumps({"distinctions": []}))\n''')
    f = SubprocessFaculty([sys.executable, str(script)])
    receipt = f.propose_json(system="s", user="u", schema={"type":"object"})
    assert receipt.response == {"distinctions": []}
