"""Adversarial gates for the v0.6 AKBC vertical slice."""
from __future__ import annotations

import json
import math
import os
import tempfile
import time
import traceback
import sys
import random
from fractions import Fraction

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rabbithole import (CapabilityIssuer, Carving, Field, FieldSystem,
                        GroundingTest, HeterogeneousRouter, Interval, Measurement, RealityHarness, ingest,
                        metrology_seed)
from forager import LocalSource, forage
from placement import Aliases, place_value


def _density(system: FieldSystem, label: str, unit: str, value: float, sigma: float,
             source: str, sample: str = "water-sample-W", state: str = "25C"):
    return system.ingest(Carving(
        label=label, unit=unit, value=value, sigma=sigma, source=source,
        citation=f"record from {source}", kind_id="mass_density",
        algebraic_type="scalar", phenomenon="material property",
        operational_tags=("mass_per_volume", "additive_mass_over_volume"),
        scope={"sample_id": sample, "state": state},
        relations=("mass", "volume"),
    ))


def test_same_measurand_different_names_and_units_compose_without_erasing_observations():
    s = FieldSystem(kinds=metrology_seed())
    a = _density(s, "mass density", "kg/m^3", 997.0, 1.0, "source-A")
    b = _density(s, "volumic mass", "g/cm^3", 0.997, 0.001, "source-B")
    assert a.action == "new"
    assert b.action == "accepted_existing"
    assert s.canonical(a.local_measurand_id) == s.canonical(b.local_measurand_id)
    assert len(s.observations) == 2                    # provenance not collapsed
    assert len(s.field.evidence) == 2
    vals = sorted(round(e.value, 6) for e in s.field.evidence.values())
    assert vals == [997.0, 997.0]                      # unit conversion at projection
    root = s.canonical(a.local_measurand_id)
    belief = s.field.belief(root)
    assert belief.mean is None                         # testimony has zero authority
    assert all(c[3] == 0.0 for c in belief.contributions)


def test_testimony_only_moves_belief_after_registered_contact():
    h = RealityHarness(predicates={"check-a": lambda: True, "check-b": lambda: True})
    s = FieldSystem(kinds=metrology_seed(), harness=h)
    a = _density(s, "density", "kg/m^3", 997.0, 1.0, "A")
    b = _density(s, "rho", "g/cm^3", 0.998, 0.001, "B")
    root = s.canonical(a.local_measurand_id)
    assert s.field.belief(root).mean is None
    s.ground_observation(a.observation_id, GroundingTest("predicate", "check-a", author="lab"))
    one = s.field.belief(root)
    assert abs(one.mean - 997.0) < 1e-9
    s.ground_observation(b.observation_id, GroundingTest("predicate", "check-b", author="lab"))
    two = s.field.belief(root)
    assert two.mean is not None and 997.0 < two.mean < 998.1
    assert s.ledger.trust("A")["contacts"] == 1


def test_same_dimension_energy_and_torque_refuse_even_when_values_agree():
    s = FieldSystem(kinds=metrology_seed())
    e = s.ingest(Carving(label="energy", unit="J", value=5, sigma=.1,
                         source="A", kind_id="energy", algebraic_type="scalar",
                         scope={"system": "shaft-X", "state": "t0"}))
    t = s.ingest(Carving(label="torque", unit="N*m", value=5, sigma=.1,
                         source="B", kind_id="torque", algebraic_type="pseudovector",
                         scope={"system": "shaft-X", "state": "t0"}))
    assert s.canonical(e.local_measurand_id) != s.canonical(t.local_measurand_id)
    hs = [s.hypotheses[h] for h in t.hypotheses]
    assert any(x.status == "rejected" and
               any(p.name == "quantity_kind" and p.outcome == "fail" for p in x.probes)
               for x in hs)
    assert len(s.field.variables) == 2


def test_frequency_and_activity_refuse_same_dimension_and_scalar_character():
    s = FieldSystem(kinds=metrology_seed())
    f = s.ingest(Carving(label="rate", unit="Hz", value=5, sigma=.1,
                         source="oscilloscope", kind_id="frequency", algebraic_type="scalar",
                         operational_tags=("reciprocal_period",), scope={"device": "osc-1"}))
    a = s.ingest(Carving(label="rate", unit="Bq", value=5, sigma=.1,
                         source="counter", kind_id="activity", algebraic_type="scalar",
                         operational_tags=("decay_count_rate",), scope={"sample": "Cs-137"}))
    assert s.canonical(f.local_measurand_id) != s.canonical(a.local_measurand_id)


def test_speed_and_velocity_refuse_scalar_vector_collapse():
    s = FieldSystem(kinds=metrology_seed())
    sp = s.ingest(Carving(label="speed", unit="m/s", value=10, sigma=.2,
                          source="A", kind_id="speed", algebraic_type="scalar",
                          scope={"object": "car-1", "time": "t0"}))
    ve = s.ingest(Carving(label="velocity", unit="m/s", value=10, sigma=.2,
                          source="B", kind_id="velocity", algebraic_type="vector",
                          scope={"object": "car-1", "time": "t0"}))
    assert s.canonical(sp.local_measurand_id) != s.canonical(ve.local_measurand_id)


def test_same_quantity_kind_different_subjects_remain_distinct():
    s = FieldSystem(kinds=metrology_seed())
    a = _density(s, "density", "kg/m^3", 997, 1, "A", sample="water-A")
    b = _density(s, "density", "kg/m^3", 998, 1, "B", sample="water-B")
    assert s.canonical(a.local_measurand_id) != s.canonical(b.local_measurand_id)


def test_missing_scope_remains_unresolved_then_registered_test_can_merge_and_retract():
    h = RealityHarness()
    h.register("registry_same_sample", lambda spec: True, contact="secondary")
    s = FieldSystem(kinds=metrology_seed(), harness=h)
    a = _density(s, "density", "kg/m^3", 997, 1, "A")
    b = s.ingest(Carving(label="volumic mass", unit="g/cm^3", value=.997, sigma=.001,
                         source="B", kind_id="mass_density", algebraic_type="scalar",
                         phenomenon="material property",
                         operational_tags=("mass_per_volume",)))
    assert b.action == "unresolved"
    hids = [hid for hid in b.hypotheses if s.hypotheses[hid].status == "unresolved"]
    assert hids
    s.test_identity(hids[0], GroundingTest("registry_same_sample", None, author="registry"))
    assert s.canonical(a.local_measurand_id) == s.canonical(b.local_measurand_id)
    s.retract_identity(hids[0], "later sample identifier disproved co-reference")
    assert s.canonical(a.local_measurand_id) != s.canonical(b.local_measurand_id)
    assert len(s.observations) == 2


def test_identity_disagreement_and_value_disagreement_are_separate():
    s = FieldSystem(kinds=metrology_seed())
    a = _density(s, "density", "kg/m^3", 997, .1, "A")
    b = _density(s, "rho", "kg/m^3", 1100, .1, "B")
    d = s.disagreement(a.local_measurand_id)
    assert d["identity_disagreement"] == []
    assert d["value_disagreement"] is True


def test_default_bridge_is_propose_only_and_does_not_mutate():
    f = Field("bridge-safe")
    f.var("x", "m")
    spec = {"variables": [{"name": "t", "unit": "s"}]}
    p = ingest(spec, f)
    assert p.valid is True
    assert list(f.variables) == ["x"]
    ingest(spec, f, mode="declared", source="explicit test model")
    assert "t" in f.variables


def test_constraint_proposal_requires_explicit_promotion_basis():
    s = FieldSystem(kinds=metrology_seed())
    spec = {"variables": [{"name": "x", "unit": "m"}],
            "constraints": [{"type": "bound", "var": "x", "lo": 0, "hi": 10,
                             "statement": "declared model range"}]}
    p = s.propose_constraints(spec, proposer="model")
    assert p.dimensional_status == "valid"
    assert "x" not in s.field.variables
    try:
        s.approve_constraints(p.pid, "because_the_model_said_so", "model")
        raise AssertionError("invalid promotion basis accepted")
    except ValueError:
        pass
    s.approve_constraints(p.pid, "declared_model", "user-scoped scenario")
    assert "x" in s.field.variables


def test_forager_acquires_untested_evidence_not_clamp():
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "source.json")
        json.dump({"rho": {"value": 997, "unit": "kg/m^3", "sigma": 1,
                           "source": "handbook"}}, open(path, "w"))
        f = Field("forage")
        f.var("rho", "kg/m^3")
        r = forage(f, "rho", "rho", LocalSource(path))
        assert r.status == "acquired_untested"
        assert len(f.factors) == 0
        assert len(f.evidence) == 1
        assert f.evidence[r.evidence_id].prov.authority(0) == 0.0


def test_refused_legacy_placement_never_writes_into_incompatible_node():
    f = Field("legacy-safe")
    f.var("current", "m/s")
    p = place_value(f, "current", "A", 12, .2, "ammeter", Aliases())
    assert p.action == "refused_dimension"
    assert p.target != "current"
    assert f.evidence[next(iter(f.evidence))].var == p.target
    assert f.variables["current"].dim != f.variables[p.target].dim


def test_interval_outward_rounding_contains_decimal_result():
    x = Interval.point(0.1) + Interval.point(0.2)
    assert x.contains(0.3)
    y = Interval.point(1) + Interval.point(3)
    assert y == Interval(4, 4)


def test_allocate_and_route_expose_next_contact_not_fake_completion():
    s = FieldSystem(kinds=metrology_seed())
    _density(s, "density", "kg/m^3", 997, 1, "A")
    tasks = s.allocate()
    assert tasks and tasks[0]["type"] == "observation"
    route = s.route(tasks[0])
    assert route["substrate"] == "external contact"


def test_posiwid_reports_observed_effects_and_valid_audit_chain():
    s = FieldSystem(kinds=metrology_seed())
    _density(s, "density", "kg/m^3", 997, 1, "A")
    r = s.posiwid()
    assert r["observed_effects"]["carvings_retained"] == 1
    assert r["observed_effects"]["untested_observations"] == 1
    assert r["audit_valid"]["valid"] is True



def test_correlated_contacts_share_one_fusion_slot():
    h = RealityHarness(predicates={"ok1": lambda: True, "ok2": lambda: True,
                                   "ok3": lambda: True})
    s = FieldSystem(kinds=metrology_seed(), harness=h)
    a = s.ingest(Carving(label="density", unit="kg/m^3", value=997, sigma=1,
                         source="mirror-A", independence_key="dataset-X",
                         kind_id="mass_density", algebraic_type="scalar",
                         scope={"sample_id": "W", "state": "25C"}))
    b = s.ingest(Carving(label="rho", unit="kg/m^3", value=999, sigma=1,
                         source="mirror-B", independence_key="dataset-X",
                         kind_id="mass_density", algebraic_type="scalar",
                         scope={"sample_id": "W", "state": "25C"}))
    c = s.ingest(Carving(label="volumic mass", unit="kg/m^3", value=1003, sigma=1,
                         source="independent-lab", independence_key="lab-Y",
                         kind_id="mass_density", algebraic_type="scalar",
                         scope={"sample_id": "W", "state": "25C"}))
    for d, key in ((a, "ok1"), (b, "ok2"), (c, "ok3")):
        s.ground_observation(d.observation_id, GroundingTest("predicate", key, author="auditor"))
    root = s.canonical(a.local_measurand_id)
    belief = s.field.belief(root)
    # One representative from dataset-X and one from independent lab-Y.
    # Three records do not become three independent votes.
    assert belief.mean is not None
    assert abs(belief.mean - 1000.0) < 2.1
    assert len(belief.contributions) == 3


def test_executor_capability_is_scoped_revocable_and_not_truth_authority():
    issuer = CapabilityIssuer(secret=b"x" * 32)
    h = RealityHarness(predicates={"ok": lambda: True}, capability_issuer=issuer,
                       require_capabilities=True)
    no_cap = h.run(GroundingTest("predicate", "ok", author="lab"))
    assert no_cap.result == "untestable"
    cap = issuer.mint("execute", "executor:predicate", holder="lab")
    yes = h.run(GroundingTest("predicate", "ok", author="lab", capability=cap))
    assert yes.result == "pass"
    forged = dict(cap); forged["resource"] = "executor:shell"
    bad = h.run(GroundingTest("predicate", "ok", author="lab", capability=forged))
    assert bad.result == "untestable"
    issuer.revoke(cap)
    revoked = h.run(GroundingTest("predicate", "ok", author="lab", capability=cap))
    assert revoked.result == "untestable"






def test_registered_identity_test_cannot_override_a_hard_invariant_veto():
    h = RealityHarness(predicates={"always": lambda: True})
    s = FieldSystem(kinds=metrology_seed(), harness=h)
    e = s.ingest(Carving(label="energy", unit="J", value=5, sigma=.1,
                         source="E", kind_id="energy", algebraic_type="scalar",
                         scope={"system": "shaft", "time": "t0"}))
    t = s.ingest(Carving(label="torque", unit="N*m", value=5, sigma=.1,
                         source="T", kind_id="torque", algebraic_type="pseudovector",
                         scope={"system": "shaft", "time": "t0"}))
    rejected = next(s.hypotheses[hid] for hid in t.hypotheses
                    if s.hypotheses[hid].status == "rejected")
    verdict = s.test_identity(rejected.hid, GroundingTest("predicate", "always", author="oracle"))
    assert verdict.result == "fail"
    assert rejected.status == "rejected"
    assert s.canonical(e.local_measurand_id) != s.canonical(t.local_measurand_id)


def test_measurement_units_are_explicitly_converted_and_mismatch_is_untestable():
    h = RealityHarness(predicates={
        "rho_gcc": lambda: Measurement(0.997, 0.001, "g/cm^3"),
        "wrong": lambda: Measurement(5.0, 0.1, "s"),
    })
    s = FieldSystem(kinds=metrology_seed(), harness=h)
    a = _density(s, "density", "kg/m^3", 997.0, 1.0, "lab-A")
    good = s.ground_observation(a.observation_id,
                                GroundingTest("measure", "rho_gcc", author="instrument-X"))
    assert good.result == "pass"
    obs = s.observations[a.observation_id]
    assert obs.grounding_author == "instrument-X"
    assert s.field.belief(s.canonical(a.local_measurand_id)).mean is not None

    b = _density(s, "rho", "kg/m^3", 997.0, 1.0, "lab-B", sample="water-B")
    bad = s.ground_observation(b.observation_id,
                               GroundingTest("measure", "wrong", author="broken-instrument"))
    assert bad.result == "untestable"
    assert s.observations[b.observation_id].grounding_status == "untestable"


def test_identity_retraction_rebuilds_components_instead_of_irreversible_union():
    s = FieldSystem(kinds=metrology_seed())
    a = _density(s, "density", "kg/m^3", 997, 1, "A")
    b = _density(s, "rho", "kg/m^3", 997, 1, "B")
    c = _density(s, "volumic mass", "kg/m^3", 997, 1, "C")
    assert s.canonical(a.local_measurand_id) == s.canonical(b.local_measurand_id)
    assert s.canonical(a.local_measurand_id) == s.canonical(c.local_measurand_id)
    bh = next(h for h in s.hypotheses.values()
              if h.observation_id == b.observation_id and h.status == "accepted")
    s.retract_identity(bh.hid, "adversarial correction")
    assert s.canonical(b.local_measurand_id) != s.canonical(a.local_measurand_id)
    assert s.canonical(c.local_measurand_id) == s.canonical(a.local_measurand_id)


def test_source_receipt_retains_snapshot_digest_and_detects_tamper():
    s = FieldSystem(kinds=metrology_seed())
    d = s.ingest(Carving(
        label="density", unit="kg/m^3", value=997, sigma=1, source="source-A",
        kind_id="mass_density", algebraic_type="scalar",
        scope={"sample_id": "W"}, source_locator="file://record.json",
        source_snapshot='{"value":997,"unit":"kg/m^3"}',
        media_type="application/json", extractor="fixture-parser"))
    receipt = s.receipt_for_observation(d.observation_id)
    assert receipt is not None and receipt.verify()
    assert s.verify_receipts()["snapshots"] == 1
    receipt.snapshot += "tamper"
    assert s.verify_receipts()["valid"] is False


def test_interval_arithmetic_encloses_exact_float_operations():
    rng = random.Random(20260714)
    for _ in range(500):
        a = rng.uniform(-1e6, 1e6)
        b = rng.uniform(-1e6, 1e6)
        ia, ib = Interval.point(a), Interval.point(b)
        exact_add = Fraction.from_float(a) + Fraction.from_float(b)
        exact_sub = Fraction.from_float(a) - Fraction.from_float(b)
        exact_mul = Fraction.from_float(a) * Fraction.from_float(b)
        for iv, exact in ((ia + ib, exact_add), (ia - ib, exact_sub), (ia * ib, exact_mul)):
            assert Fraction.from_float(iv.lo) <= exact <= Fraction.from_float(iv.hi)
        if b != 0.0:
            iv = ia / ib
            exact = Fraction.from_float(a) / Fraction.from_float(b)
            assert Fraction.from_float(iv.lo) <= exact <= Fraction.from_float(iv.hi)
    for x in (0.1, 2.0, 3.0, 1e-200, 1e200):
        for n in (2, 3, 5):
            branches = Interval.point(x).root_branches(n)
            positive = max(branches, key=lambda iv: iv.hi)
            target = Fraction.from_float(x)
            assert Fraction.from_float(positive.lo) ** n <= target
            assert Fraction.from_float(positive.hi) ** n >= target


def test_grounded_belief_projection_is_explicit_reversible_and_computable():
    h = RealityHarness(predicates={"a": lambda: True, "b": lambda: True})
    s = FieldSystem(kinds=metrology_seed(), harness=h)
    a = _density(s, "density", "kg/m^3", 997.0, 1.0, "lab-A")
    b = _density(s, "volumic mass", "g/cm^3", 0.997, 0.001, "lab-B")
    root = s.canonical(a.local_measurand_id)

    spec = {
        "variables": [
            {"name": "sample_volume", "unit": "m^3"},
            {"name": "sample_mass", "unit": "kg"},
        ],
        "constraints": [
            {"type": "product", "a": root, "b": "sample_volume",
             "c": "sample_mass", "statement": "mass density definition"},
        ],
        "clamps": [
            {"var": "sample_volume", "value": 0.002,
             "reason": "declared sample volume"},
        ],
    }
    p = s.propose_constraints(spec, proposer="model proposer")
    s.approve_constraints(p.pid, "definition", "mass density definition")

    try:
        s.field.project_belief(root)
        raise AssertionError("untested testimony became calculable")
    except ValueError:
        pass

    s.ground_observation(a.observation_id, GroundingTest("predicate", "a", author="auditor-A"))
    s.ground_observation(b.observation_id, GroundingTest("predicate", "b", author="auditor-B"))
    projection = s.project_beliefs([root], k_sigma=2.0)
    assert root in projection["projected"]
    fid = projection["projected"][root]
    assert s.field.factors[fid].prov.kind == "projection"
    report, _ = s.settle()
    assert report.status == "settled"
    mass = s.field.variables["sample_mass"].domain
    assert mass.contains(1.994)
    s.field.release(fid)
    report, _ = s.settle()
    assert math.isinf(s.field.variables["sample_mass"].domain.lo)


def test_contested_belief_is_not_projected_by_default():
    h = RealityHarness(predicates={"a": lambda: True, "b": lambda: True})
    s = FieldSystem(kinds=metrology_seed(), harness=h)
    a = _density(s, "density", "kg/m^3", 997.0, 0.1, "lab-A")
    b = _density(s, "rho", "kg/m^3", 1200.0, 0.1, "lab-B")
    s.ground_observation(a.observation_id, GroundingTest("predicate", "a", author="auditor-A"))
    s.ground_observation(b.observation_id, GroundingTest("predicate", "b", author="auditor-B"))
    root = s.canonical(a.local_measurand_id)
    result = s.project_beliefs([root])
    assert root in result["refused"]
    assert root not in result["projected"]


def test_sound_router_never_selects_approximate_native_without_opt_in():
    f = Field("route")
    f.var("x", "m")
    f.clamp("x", value=1)
    router = HeterogeneousRouter(native_factor_threshold=0)
    _, route = router.settle(f)
    assert route.substrate == "Python/CPU"
    assert "sound mode" in route.reason or "below native threshold" in route.reason


def test_field_system_roundtrip_preserves_identity_evidence_and_audit():
    h = RealityHarness(predicates={"ok": lambda: True})
    s = FieldSystem(kinds=metrology_seed(), harness=h)
    a = _density(s, "density", "kg/m^3", 997.0, 1.0, "lab-A")
    s.ground_observation(a.observation_id, GroundingTest("predicate", "ok", author="auditor"))
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "system.json")
        s.save(path)
        loaded = FieldSystem.load(path, harness=h)
    assert len(loaded.observations) == 1
    assert len(loaded.measurands) == 1
    root = loaded.canonical(a.local_measurand_id)
    assert loaded.field.belief(root).mean is not None
    assert loaded.audit.verify()["valid"] is True



def test_contact_types_do_not_collapse_to_equal_epistemic_weight():
    f = Field("contact-quality")
    f.var("x", "m")
    f.add_evidence("x", 0.0, 1.0, "direct-lab", 1.0, tested=True,
                   contact="direct", contact_quality=1.0,
                   independence_key="direct-lineage")
    f.add_evidence("x", 10.0, 1.0, "model-output", 1.0, tested=True,
                   contact="model", contact_quality=0.25,
                   independence_key="model-lineage")
    b = f.belief("x")
    # Equal precision but 4:1 contact quality => weighted mean 2, not 5.
    assert abs(b.mean - 2.0) < 1e-12
    assert abs(b.sigma - math.sqrt(1.0 / 1.25)) < 1e-12


def test_registered_executor_quality_limits_grounded_evidence_authority():
    f = Field("executor-quality")
    f.var("x", "m")
    eid = f.add_evidence("x", 3.0, 1.0, "claim", 1.0,
                         tested=False, independence_key="claim")
    h = RealityHarness(predicates={"ok": lambda: True})
    h.register("model_check", lambda spec: True, contact="model")
    from rabbithole import GroundingLoop
    loop = GroundingLoop(f, h)
    verdict = loop.dispatch(eid, GroundingTest("model_check", None, author="model-auditor"))
    assert verdict.result == "pass" and verdict.quality == 0.25
    assert f.evidence[eid].contact == "model"
    assert f.evidence[eid].author == "model-auditor"
    assert abs(f.evidence[eid].contact_quality - 0.25) < 1e-12
    assert abs(f.evidence[eid].authority(time.time()) - 0.25) < 1e-6


def test_executor_can_be_registered_as_permission_without_truth_weight():
    f = Field("permission-not-truth")
    f.var("x", "m")
    eid = f.add_evidence("x", 3.0, 1.0, "claim", 1.0, tested=False)
    h = RealityHarness()
    h.register("workflow_ack", lambda spec: True, contact="model", epistemic_weight=0.0)
    from rabbithole import GroundingLoop
    verdict = GroundingLoop(f, h).dispatch(
        eid, GroundingTest("workflow_ack", None, author="scheduler"))
    assert verdict.result == "pass" and verdict.quality == 0.0
    assert f.evidence[eid].prov.test_count == 1
    assert f.belief("x").mean is None  # executed successfully, but proves nothing about x


def test_low_quality_model_pass_cannot_decide_identity():
    h = RealityHarness()
    h.register("model_same", lambda spec: True, contact="model")
    s = FieldSystem(kinds=metrology_seed(), harness=h)
    a = _density(s, "density", "kg/m^3", 997, 1, "A")
    b = s.ingest(Carving(label="volumic mass", unit="g/cm^3", value=.997, sigma=.001,
                         source="B", kind_id="mass_density", algebraic_type="scalar",
                         phenomenon="material property",
                         operational_tags=("mass_per_volume",)))
    hid = next(hid for hid in b.hypotheses if s.hypotheses[hid].status == "unresolved")
    verdict = s.test_identity(hid, GroundingTest("model_same", None, author="model"))
    assert verdict.result == "pass" and verdict.quality == 0.25
    assert s.hypotheses[hid].status == "unresolved"
    assert s.canonical(a.local_measurand_id) != s.canonical(b.local_measurand_id)


def test_low_quality_pass_cannot_mint_verified_invariant():
    h = RealityHarness()
    h.register("model_law_check", lambda spec: True, contact="model")
    h.register("instrument_law_check", lambda spec: True, contact="instrument")
    s = FieldSystem(kinds=metrology_seed(), harness=h)
    spec = {"variables": [{"name": "x", "unit": "m"}],
            "constraints": [{"type": "bound", "var": "x", "lo": 0, "hi": 1,
                             "statement": "candidate invariant"}]}
    p = s.propose_constraints(spec, proposer="model")
    try:
        s.approve_constraints(p.pid, "verified_invariant", "model",
                              GroundingTest("model_law_check", None, author="model"))
        raise AssertionError("model-level pass minted a verified invariant")
    except PermissionError:
        pass
    assert "x" not in s.field.variables
    s.approve_constraints(p.pid, "verified_invariant", "calibrated rig",
                          GroundingTest("instrument_law_check", None, author="rig"))
    assert "x" in s.field.variables
    assert any(f.prov.kind == "invariant" for f in s.field.factors.values())


def test_field_roundtrip_preserves_contact_quality():
    f = Field("contact-persistence")
    f.var("x", "m")
    eid = f.add_evidence("x", 3.0, 1.0, "model", 1.0, tested=True,
                         contact="model", contact_quality=0.25)
    g = Field.from_dict(f.to_dict())
    assert abs(g.evidence[eid].contact_quality - 0.25) < 1e-12
    assert abs(g.evidence[eid].authority(time.time()) - 0.25) < 1e-6

def main():
    tests = sorted((name, obj) for name, obj in globals().items()
                   if name.startswith("test_") and callable(obj))
    passed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"PASS  {name}")
            passed += 1
        except Exception:
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\n{passed} passed, {len(tests)-passed} failed")
    raise SystemExit(0 if passed == len(tests) else 1)


if __name__ == "__main__":
    main()
