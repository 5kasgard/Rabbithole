"""RabbitHole test suite. Zero-dependency runner (no pytest needed)."""

import json
import math
import os
import sys
import time
import traceback

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rabbithole import (  # noqa: E402
    BRIDGE_SPEC, DimensionalWall, Dim, Field, Interval, ingest, unit,
)

INF = math.inf


def approx(a, b, tol=1e-9):
    if math.isinf(a) or math.isinf(b):
        return a == b
    return abs(a - b) <= tol * max(1.0, abs(a), abs(b))


# --------------------------------------------------------------------------
# interval + dimension primitives
# --------------------------------------------------------------------------

def test_interval_arithmetic():
    a, b = Interval(1, 2), Interval(3, 4)
    assert (a + b).lo == 4 and (a + b).hi == 6
    assert (b - a).lo == 1 and (b - a).hi == 3
    m = Interval(-2, 3) * Interval(-1, 4)
    assert m.lo == -8 and m.hi == 12
    # infinity handling with 0 * inf = 0 convention
    z = Interval(0, INF) * Interval(0, 5)
    assert z.lo == 0 and z.hi == INF
    # sound division: divisor spanning zero -> full line, never wrong
    d = Interval(1, 2) / Interval(-1, 1)
    assert math.isinf(d.lo) and math.isinf(d.hi)
    d2 = Interval(80000, INF) / Interval(10, 20)
    assert approx(d2.lo, 4000) and d2.hi == INF
    assert Interval(2, 1).is_empty()
    assert Interval(1, 3).intersect(Interval(2, 5)) == Interval(2, 3)


def test_power_and_roots():
    assert Interval(-3, -2).power(2) == Interval(4, 9)
    assert Interval(-2, 3).power(2) == Interval(0, 9)
    br = Interval(4, 9).root_branches(2)
    assert len(br) == 2
    pos = [x for x in br if x.lo >= 0][0]
    assert approx(pos.lo, 2) and approx(pos.hi, 3)
    odd = Interval(-8, 27).root_branches(3)[0]
    assert approx(odd.lo, -2) and approx(odd.hi, 3)


def test_dimensional_algebra():
    N, m_, J = unit("N")[0], unit("m")[0], unit("J")[0]
    assert (N * m_).exps == J.exps
    v2 = unit("m/s")[0].power(2)
    assert v2.power("1/2").exps == unit("m/s")[0].exps  # sqrt stays exact
    assert Dim.none().is_none()


def test_dimensional_wall_at_registration():
    f = Field()
    f.var("d", "m")
    f.var("t", "s")
    f.var("x", "m")
    try:
        f.sum_is(["d", "t"], "x", "distance plus time (nonsense)")
    except DimensionalWall as w:
        assert "Rejected at registration" in str(w)
        return
    raise AssertionError("wall did not fire")


# --------------------------------------------------------------------------
# the same graph, every direction
# --------------------------------------------------------------------------

def energy_field():
    f = Field("energy")
    f.var("m", "kg", lo=0)
    f.var("g", "m/s^2")
    f.var("h", "m")
    f.var("v", "m/s", lo=0, note="speed (non-negative by declaration)")
    f.var("vsq", "m^2/s^2")
    f.var("mg", "N")
    f.var("PE", "J")
    f.var("mv2", "J")
    f.var("half", "")
    f.var("KE", "J")
    f.constant("g", 9.80665, "g = 9.80665 m/s^2", "CGPM 1901")
    f.constant("half", 0.5, "1/2 (kinetic energy coefficient)", "definition")
    f.product_is("m", "g", "mg", "weight = m·g", "Newton II")
    f.product_is("mg", "h", "PE", "PE = m·g·h", "gravitational potential")
    f.power_is("v", 2, "vsq", "v squared")
    f.product_is("m", "vsq", "mv2", "m·v²")
    f.product_is("half", "mv2", "KE", "KE = ½·m·v²", "kinetic energy")
    f.sum_is(["KE"], "PE", "KE = PE (energy conservation, drop from rest)",
             "conservation of energy")
    return f


def test_forward_clamp_cause_read_effect():
    f = energy_field()
    f.clamp("m", 2, reason="given")
    f.clamp("h", 10, reason="given")
    r = f.settle()
    assert r.status == "settled"
    v = f.variables["v"].domain
    want = math.sqrt(2 * 9.80665 * 10)
    assert approx(v.lo, want, 1e-9) and approx(v.hi, want, 1e-9)


def test_inverse_clamp_effect_read_cause():
    f = energy_field()
    f.clamp("m", 2, reason="given")
    f.clamp("v", 20, reason="measured landing speed")
    r = f.settle()
    assert r.status == "settled"
    h = f.variables["h"].domain
    want = 400.0 / (2 * 9.80665)
    assert approx(h.lo, want, 1e-9) and approx(h.hi, want, 1e-9)


def test_polydirectional_both_ends_narrow():
    f = energy_field()
    f.clamp("m", 2, reason="given")
    f.clamp("h", lo=5, hi=15, reason="range")
    f.clamp("v", lo=10, hi=15, reason="range")
    r = f.settle()
    assert r.status == "settled"
    h, v = f.variables["h"].domain, f.variables["v"].domain
    assert approx(h.lo, 100.0 / 19.6133, 1e-6)
    assert approx(h.hi, 225.0 / 19.6133, 1e-6)
    assert approx(v.lo, 10, 1e-9) and approx(v.hi, 15, 1e-9)


def test_release_resettles():
    f = energy_field()
    f.clamp("m", 2, reason="given")
    cid = f.clamp("v", 20, reason="assumption")
    f.settle()
    assert approx(f.variables["h"].domain.mid(), 400.0 / 19.6133, 1e-9)
    f.release(cid)
    f.settle()
    assert math.isinf(f.variables["h"].domain.hi)  # nothing pins h now


# --------------------------------------------------------------------------
# contradiction: minimal conflict + nearest possible
# --------------------------------------------------------------------------

def test_overclamp_minimal_conflict_and_nearest():
    f = Field("flow")
    for n in ("in_A", "out_B", "out_C"):
        f.var(n, "item")
    f.sum_is(["out_B", "out_C"], "in_A", "flow in = flow out", "conservation")
    f.clamp("in_A", 100, reason="supplier contract")
    f.clamp("out_B", 60, reason="committed to B")
    f.clamp("out_C", 55, reason="promised to C")
    r = f.settle()
    assert r.status == "contradiction"
    c = r.conflict
    assert len(c.conflict) == 4  # exactly the three clamps + conservation
    kinds = sorted(x.prov.kind for x in c.conflict)
    assert kinds == ["clamp", "clamp", "clamp", "invariant"]
    near_c = [x for x in c.relaxations if x.var == "out_C"][0]
    assert approx(near_c.nearest, 40.0, 1e-9)
    assert approx(near_c.feasible.lo, 40.0, 1e-9)


def test_conflict_is_minimal_ignores_bystanders():
    f = Field("flow2")
    for n in ("in_A", "out_B", "out_C", "unrelated"):
        f.var(n, "item")
    f.sum_is(["out_B", "out_C"], "in_A", "conservation", "conservation")
    f.clamp("unrelated", 7, reason="noise")
    f.clamp("in_A", 100, reason="supplier")
    f.clamp("out_B", 60, reason="B")
    f.clamp("out_C", 55, reason="C")
    r = f.settle()
    assert r.status == "contradiction"
    names = {x.prov.statement for x in r.conflict.conflict}
    assert not any("unrelated" in s for s in names)
    assert len(r.conflict.conflict) == 4


# --------------------------------------------------------------------------
# weights: evidence fusion, authority decay by abandonment
# --------------------------------------------------------------------------

def test_evidence_fusion_and_decay():
    now = time.time()
    f = Field("bench")
    f.var("R", "ohm", lo=0)
    e1 = f.add_evidence("R", 100, 2, "bench meter (calibrated last week)",
                        0.9, grounded_at=now, tested=True)
    e2 = f.add_evidence("R", 112, 3, "old datasheet (unreplicated)",
                        0.6, grounded_at=now - 400 * 86400, tested=True)
    b = f.belief("R", now=now)
    a2 = f.evidence[e2].prov.authority(now)
    assert a2 < 0.6  # decayed by abandonment
    assert f.evidence[e1].prov.authority(now) == 0.9  # fresh, undecayed
    assert b.contested is True and b.test is not None
    assert abs(b.mean - 100) < abs(b.mean - 112)  # fused belief hugs the grounded source
    m1 = b.mean
    f.ground_evidence(e2, now=now)  # a test touches reality; datasheet value survives
    b2 = f.belief("R", now=now)
    assert b2.mean > m1  # authority restored by grounding, belief shifts
    # disagreement alone never reduced anyone's authority:
    assert f.evidence[e1].prov.authority(now) == 0.9


def test_sybil_immunity_repetition_is_not_testing():
    """T2 / B4: assertion volume confers no authority. Nine ungrounded
    reposts of a claim must not move the fused belief at all; one actual
    test must."""
    now = time.time()
    f = Field("sybil")
    f.var("R", "ohm", lo=0)
    f.add_evidence("R", 100, 2, "measured on the bench", 0.9,
                   grounded_at=now, tested=True)
    m0 = f.belief("R", now=now).mean
    reposts = [f.add_evidence("R", 112, 3, f"blog repost {i}", 0.5,
                              grounded_at=now)          # tested=False
               for i in range(9)]
    b = f.belief("R", now=now)
    assert b.mean == m0                                  # unmoved by repetition
    assert all(f.evidence[e].prov.authority(now) == 0.0 for e in reposts)
    assert b.contested is True and b.test is not None    # but the field asks for a test
    f.ground_evidence(reposts[0], now=now)               # ONE claim survives a test
    b2 = f.belief("R", now=now)
    assert b2.mean > m0                                  # one test moves what nine posts could not


def test_walls_never_decay():
    f = energy_field()
    g = [x for x in f.factors.values() if "9.80665" in x.prov.statement][0]
    assert g.prov.authority(time.time() + 3.15e9) == 1.0  # a century later


# --------------------------------------------------------------------------
# persistence: full form, no compression
# --------------------------------------------------------------------------

def test_save_load_roundtrip(tmp="/tmp/field_roundtrip.json"):
    f = energy_field()
    f.clamp("m", 2, reason="given")
    f.clamp("h", 10, reason="given")
    f.settle()
    v1 = f.variables["v"].domain
    f.save(tmp)
    g = Field.load(tmp)
    r = g.settle()
    assert r.status == "settled"
    v2 = g.variables["v"].domain
    assert approx(v1.lo, v2.lo) and approx(v1.hi, v2.hi)
    d = json.load(open(tmp))
    assert all("statement" in fd["prov"] and "source" in fd["prov"]
               for fd in d["factors"])  # provenance survives whole


# --------------------------------------------------------------------------
# the bridge contract
# --------------------------------------------------------------------------

def test_bridge_ingest_unit_economics():
    spec = {
        "variables": [
            {"name": "price", "unit": "$/item", "lo": 0},
            {"name": "units", "unit": "item", "lo": 0},
            {"name": "revenue", "unit": "$", "lo": 0},
            {"name": "cost", "unit": "$", "lo": 0},
            {"name": "profit", "unit": "$"},
        ],
        "constraints": [
            {"type": "product", "a": "price", "b": "units", "c": "revenue",
             "statement": "revenue = price · units"},
            {"type": "sum", "terms": ["profit", "cost"], "total": "revenue",
             "statement": "revenue = profit + cost"},
        ],
        "clamps": [
            {"var": "profit", "lo": 50000, "reason": "founder's goal"},
            {"var": "cost", "value": 30000, "reason": "known burn"},
            {"var": "price", "lo": 10, "hi": 20, "reason": "market range"},
        ],
    }
    f = ingest(spec, mode="declared")
    r = f.settle()
    assert r.status == "settled"
    u = f.variables["units"].domain
    assert approx(u.lo, 4000, 1e-9) and u.hi == INF
    rev = f.variables["revenue"].domain
    assert approx(rev.lo, 80000, 1e-9)
    assert "STRICT JSON" in BRIDGE_SPEC


def test_bridge_rejects_dimensional_nonsense():
    spec = {
        "variables": [{"name": "d", "unit": "m"}, {"name": "t", "unit": "s"},
                      {"name": "x", "unit": "m"}],
        "constraints": [{"type": "sum", "terms": ["d", "t"], "total": "x",
                         "statement": "meters plus seconds"}],
    }
    try:
        ingest(spec, mode="declared")
    except DimensionalWall:
        return
    raise AssertionError("bridge let dimensional nonsense through")


# --------------------------------------------------------------------------
# linear factors: subtraction, scaling, weighted balances
# --------------------------------------------------------------------------

def test_linear_subtraction_and_scaling():
    f = Field("lin")
    for n in ("revenue", "cost", "profit"):
        f.var(n, "$")
    f.linear_is([(1, "revenue"), (-1, "cost")], "profit",
                "profit = revenue − cost", "accounting")
    f.clamp("revenue", 80000, reason="booked")
    f.clamp("profit", 50000, reason="goal")
    r = f.settle()
    assert r.status == "settled"
    assert approx(f.variables["cost"].domain.lo, 30000, 1e-9)

    g = Field("mix")
    for n in ("x", "y", "z"):
        g.var(n, "")
    g.linear_is([(3, "x"), (2, "y")], "z", "3x + 2y = z", "given")
    g.clamp("z", 12, reason="given")
    g.clamp("y", 1.5, reason="given")
    g.settle()
    assert approx(g.variables["x"].domain.lo, 3.0, 1e-9)
    d = g.to_dict()
    h = Field.from_dict(d)
    h.settle()
    assert approx(h.variables["x"].domain.lo, 3.0, 1e-9)  # linear roundtrips


# --------------------------------------------------------------------------
# the audit spine: WAL gates (ported lessons from the precursor)
# --------------------------------------------------------------------------

def test_wal_chain_and_tamper_evidence():
    from rabbithole.wal import EventLog
    f = energy_field()
    log = f.attach_log()
    f.clamp("m", 2, reason="given")
    f.clamp("h", 10, reason="given")
    f.settle()
    v = log.verify()
    assert v["valid"] and v["events"] >= 4    # snapshot + 2 clamps + settle
    # tamper an event payload -> the chain breaks exactly there
    log.events[1].payload["statement"] = "history, silently edited"
    v2 = log.verify()
    assert v2["valid"] is False and v2["broken_at"] == 1
    assert "tampered" in v2["reason"]


def test_wal_snapshot_state_is_in_the_chain():
    from rabbithole.wal import EventLog
    f = energy_field()
    log = f.attach_log()                      # attach snapshots current state
    f.clamp("m", 2, reason="given")
    log.snapshot(f.to_dict())
    assert log.verify()["valid"]
    # tamper the STORED snapshot state (not the event): still caught
    seq = max(log.snapshots)
    log.snapshots[seq]["name"] = "a past that never existed"
    v = log.verify()
    assert v["valid"] is False and v["reason"] == "snapshot state tampered"


def test_wal_completeness_no_unwired_sin():
    """The precursor's original sin was an unwired WAL. Gate: every mutating
    operation emits — counted, not narrated."""
    f = Field("audited")
    log = f.attach_log()
    f.var("a", "m")                                   # var
    f.var("b", "m")                                   # var
    f.var("c", "m")                                   # var
    f.sum_is(["a", "b"], "c", "a+b=c", "test")        # factor
    cid = f.clamp("a", 1, reason="test")              # factor (clamp)
    f.clamp("b", 2, reason="test")                    # factor (clamp)
    f.settle()                                        # settle
    f.release(cid)                                    # release
    eid = f.add_evidence("c", 3, 0.1, "meter", 0.9, tested=True)   # evidence
    f.ground_evidence(eid)                            # ground
    f.settle()                                        # settle
    types = [e.type for e in log.events]
    assert types.count("var") == 3
    assert types.count("factor") == 3
    assert types.count("settle") == 2
    assert types.count("release") == 1
    assert types.count("evidence") == 1
    assert types.count("ground") == 1
    assert types[0] == "snapshot"                     # attach anchored the record
    assert log.verify()["valid"]


def test_wal_persistence_and_version_binding():
    from rabbithole.wal import EventLog, kernel_version
    f = energy_field()
    log = f.attach_log()
    f.clamp("m", 2, reason="given")
    f.settle()
    d = log.to_dict()
    log2 = EventLog.from_dict(d)
    v = log2.verify()
    assert v["valid"] and v["events"] == len(log.events)
    versions = log.versions_used()
    assert versions == {kernel_version()}
    assert "unknown-version" not in versions          # code-bound, not sentinel


def test_wal_records_native_settles_too():
    from rabbithole.fast import FastEngine, available
    assert available()
    f = energy_field()
    log = f.attach_log()
    f.clamp("m", 2, reason="given")
    f.clamp("h", 10, reason="given")
    FastEngine(f).settle()
    settles = [e for e in log.events if e.type == "settle"]
    assert len(settles) == 1 and settles[0].payload.get("engine") == "native"
    assert log.verify()["valid"]




def _fast():
    from rabbithole.fast import FastEngine, available
    assert available(), "gcc-built native engine expected in this environment"
    return FastEngine


def test_fast_matches_oracle_on_scenarios():
    FastEngine = _fast()
    # forward, inverse, poly on the energy graph: every domain identical
    for clamps in (lambda f: (f.clamp("m", 2), f.clamp("h", 10)),
                   lambda f: (f.clamp("m", 2), f.clamp("v", 20)),
                   lambda f: (f.clamp("m", 2), f.clamp("h", lo=5, hi=15),
                              f.clamp("v", lo=10, hi=15))):
        fa, fb = energy_field(), energy_field()
        clamps(fa); clamps(fb)
        ra, rb = FastEngine(fa).settle(), fb.settle()
        assert ra.status == rb.status == "settled"
        for n in fa.variables:
            da, db = fa.variables[n].domain, fb.variables[n].domain
            assert approx(da.lo, db.lo, 1e-9) and approx(da.hi, db.hi, 1e-9), n
    # contradiction path: same minimal conflict + nearest through native probes
    f = Field("flow")
    for n in ("in_A", "out_B", "out_C", "spare"):
        f.var(n, "item")
    f.sum_is(["out_B", "out_C"], "in_A", "conservation", "conservation")
    f.clamp("spare", 7, reason="bystander")
    f.clamp("in_A", 100, reason="A")
    f.clamp("out_B", 60, reason="B")
    f.clamp("out_C", 55, reason="C")
    r = FastEngine(f).settle()
    assert r.status == "contradiction"
    assert len(r.conflict.conflict) == 4
    assert not any("spare" in x.prov.statement for x in r.conflict.conflict)
    near_c = [x for x in r.conflict.relaxations if x.var == "out_C"][0]
    assert approx(near_c.nearest, 40.0, 1e-9)


def test_fast_fuzz_differential():
    """Random graphs: the native engine must agree with the Python oracle."""
    import random
    FastEngine = _fast()
    COEFFS = [-2.0, -1.0, -0.5, 0.5, 1.0, 2.0]
    for seed in range(150):
        rng = random.Random(seed)
        nv = rng.randint(4, 16)
        names = [f"v{i}" for i in range(nv)]
        f = Field(f"fuzz{seed}")
        for n in names:
            f.var(n, "")
        for _ in range(rng.randint(1, 3)):     # priors
            n = rng.choice(names)
            a = rng.uniform(-40, 40)
            f.var  # no-op; bound via invariant on existing var
            f.invariant_bound(n, lo=a, hi=a + rng.uniform(1, 30))
        for _ in range(rng.randint(nv, 2 * nv)):
            kind = rng.random()
            if kind < 0.5:
                k = rng.randint(2, min(4, nv - 1))
                vs = rng.sample(names, k + 1)
                f.linear_is([(rng.choice(COEFFS), v) for v in vs[:-1]], vs[-1],
                            source="fuzz")
            elif kind < 0.8 and nv >= 3:
                a, b, c = rng.sample(names, 3)
                f.product_is(a, b, c, source="fuzz")
            else:
                a, c = rng.sample(names, 2)
                f.power_is(a, rng.choice([2, 3]), c, source="fuzz")
        for _ in range(rng.randint(1, 3)):     # clamps
            n = rng.choice(names)
            v = rng.uniform(-20, 20)
            f.clamp(n, v)
        fa = Field.from_dict(f.to_dict())      # independent copy for the oracle
        ra = FastEngine(f).settle()
        rb = fa.settle()
        assert ra.status == rb.status, f"seed {seed}: {ra.status} vs {rb.status}"
        if ra.status == "settled":
            for n in names:
                da, db = f.variables[n].domain, fa.variables[n].domain
                ea, eb = da.is_empty(), db.is_empty()
                assert ea == eb, f"seed {seed} var {n} emptiness"
                if not ea:
                    tol = 1e-6
                    for x, y in ((da.lo, db.lo), (da.hi, db.hi)):
                        if math.isinf(x) or math.isinf(y):
                            assert x == y, f"seed {seed} var {n}: {x} vs {y}"
                        else:
                            assert abs(x - y) <= tol * max(1, abs(x), abs(y)), \
                                f"seed {seed} var {n}: {x} vs {y}"


def test_fast_throughput():
    FastEngine = _fast()
    N = 100_000
    f = Field("bigchain")
    f.var("d", "")
    f.clamp("d", 1, reason="step")
    f.var("x0", "")
    f.clamp("x0", 0, reason="origin")
    prev = "x0"
    for i in range(1, N + 1):
        cur = f"x{i}"
        f.var(cur, "")
        f.sum_is([prev, "d"], cur, source="chain")
        prev = cur
    eng = FastEngine(f)
    r = eng.settle()
    assert r.status == "settled"
    assert approx(f.variables[f"x{N}"].domain.lo, N)
    assert r.pops < 3 * N                       # locality holds at scale
    rate = r.contractions / (r.elapsed_ms / 1000.0)
    print(f"    native: {r.contractions:,} contractions in "
          f"{r.elapsed_ms:.1f} ms -> {rate:,.0f}/s", end="  ")
    assert rate > 2_000_000                     # conservative floor; see bench.py




def test_propagation_throughput():
    N = 1500
    f = Field("chain")
    f.var("d", "")
    f.clamp("d", 1, reason="step")
    prev = "x0"
    f.var(prev, "")
    f.clamp(prev, 0, reason="origin")
    for i in range(1, N + 1):
        cur = f"x{i}"
        f.var(cur, "")
        f.sum_is([prev, "d"], cur, source="chain")
        prev = cur
    r = f.settle()
    assert r.status == "settled"
    end = f.variables[f"x{N}"].domain
    assert approx(end.lo, N) and approx(end.hi, N)
    rate = r.contractions / (r.elapsed_ms / 1000.0)
    print(f"    throughput: {r.contractions} contractions in "
          f"{r.elapsed_ms:.1f} ms -> {rate:,.0f}/s over {r.pops} pops", end="  ")
    # Locality: work is linear in graph size (each factor fires ~once).
    # This is the topology claim — no global recomputation, no blowup.
    assert r.pops < 3 * N
    assert rate > 20_000  # pure-Python reference floor; see ROADMAP for the fast port


# --------------------------------------------------------------------------
# the tether: harness, loop, ledger (ported gates)
# --------------------------------------------------------------------------

def test_harness_refuses_unknown_kinds_and_broken_tests_never_forge_fail():
    from rabbithole import GroundingTest, RealityHarness
    h = RealityHarness(predicates={"boom": lambda: 1 / 0})
    v1 = h.run(GroundingTest("no_such_kind", None, author="x"))
    assert v1.result == "untestable" and "no registered executor" in v1.reason
    v2 = h.run(GroundingTest("predicate", "boom", author="x"))
    assert v2.result == "untestable" and "executor error" in v2.reason  # T4
    v3 = h.run(GroundingTest("shell", "echo hi", author="x"))
    assert v3.result == "untestable"          # shell opt-in (T3)


def test_harness_proposer_cannot_assert_truth():
    from rabbithole import RealityHarness
    h = RealityHarness()
    for verdictish in ("PASS", True, {"result": "pass"}, 1.0):
        v = h.run(verdictish)
        assert v.result == "untestable"       # T2: a verdict is not a test
        assert "verdict, not a test" in v.reason


def test_tether_pass_grounds_and_fail_moves_ledger_not_authority():
    from rabbithole import Field, GroundingLoop, GroundingTest, RealityHarness
    now = time.time()
    f = Field("bench")
    f.attach_log()
    f.var("R", "ohm", lo=0)
    eid = f.add_evidence("R", 112, 3, "old datasheet", 0.6,
                         grounded_at=now - 400 * 86400, tested=True)
    assert f.evidence[eid].prov.authority(now) < 0.15          # decayed
    h = RealityHarness(predicates={"datasheet_check": lambda: True,
                                   "spec_check": lambda: False})
    loop = GroundingLoop(f, h)
    v = loop.dispatch(eid, GroundingTest("predicate", "datasheet_check",
                                         author="reviewer"))
    assert v.result == "pass" and v.contact == "derived"
    assert f.evidence[eid].prov.authority(time.time()) > 0.55  # restored by test
    # a FAIL on another claim moves the ledger, not the claim's authority
    e2 = f.add_evidence("R", 90, 3, "rumor mill", 0.5, tested=True)
    a_before = f.evidence[e2].prov.authority(time.time())
    loop.dispatch(e2, GroundingTest("predicate", "spec_check", author="reviewer"))
    a_after = f.evidence[e2].prov.authority(time.time())
    assert abs(a_after - a_before) < 1e-6      # A3: disagreement/failure ≠ decay
    t = loop.ledger.trust("rumor mill")
    assert t["disbelief"] > 0 and t["reputation"] < 1.0
    assert any(e.type == "test" for e in f.log.events)         # tether is in the WAL


def test_tether_measurement_becomes_tested_evidence():
    from rabbithole import Field, GroundingLoop, GroundingTest, RealityHarness
    f = Field("bench2")
    f.var("R", "ohm", lo=0)
    f.add_evidence("R", 112, 3, "old datasheet", 0.6, tested=True)
    h = RealityHarness(predicates={"four_wire": lambda: (100.4, 0.5)})
    loop = GroundingLoop(f, h)
    v = loop.dispatch("R", GroundingTest("measure", "four_wire",
                                         author="bench robot"))
    assert v.result == "pass" and v.value == 100.4
    tested = [e for e in f.evidence.values() if e.prov.test_count > 0
              and e.contact == "instrument"]
    assert len(tested) >= 1
    b = f.belief("R")
    assert abs(b.mean - 100.4) < 2.0           # the measurement dominates


def test_ledger_untestable_counted_not_punished_and_self_authored_visible():
    from rabbithole import SourceLedger
    led = SourceLedger()
    led.record("poet", "c1", "untestable")
    led.record("poet", "c2", "untestable")
    t = led.trust("poet")
    assert t["reputation"] == 1.0              # no contact = no guilt
    assert t["unfalsifiability_rate"] == 1.0   # ...but perfectly visible
    led.record("selfie", "c3", "pass", author="selfie")
    led.record("selfie", "c4", "pass", author="referee")
    t2 = led.trust("selfie")
    assert 0 < t2["self_authored_rate"] < 1    # grading own homework: counted


def test_ledger_direction_preserving_decay():
    from rabbithole import SourceLedger
    led = SourceLedger(half_life=2.0)
    led.record("s", "c", "fail")
    d0 = led.trust("s")["disbelief"]
    led.tick(4)                                 # two half-lives of silence
    d1 = led.trust("s")["disbelief"]
    assert 0 < d1 < d0                          # a stale fail fades…
    assert led.trust("s")["uncertainty"] > 0.5  # …toward uncertainty, not trustAssign
    led2 = SourceLedger.from_dict(led.to_dict())
    assert abs(led2.trust("s")["disbelief"] - d1) < 1e-12


# --------------------------------------------------------------------------
# coverage (G8, Attack-38 composition), allocate (E5), commit (E6/A8)
# --------------------------------------------------------------------------

def test_coverage_walled_and_weakest_link():
    from rabbithole import Field, coverage
    f = Field("cov")
    for n in ("a", "b", "c"):
        f.var(n, "")
    f.sum_is(["a", "b"], "c", "a+b=c", "test")
    f.clamp("a", 1, reason="declared")
    eid = f.add_evidence("b", 2, 0.1, "note on a napkin", 0.8)   # untested
    f.settle()
    cov = coverage(f, "c")
    assert abs(cov.grounded_fraction - 0.25) < 1e-9   # min(1.0 clamp, 0.25 asserted)
    assert cov.status == "asserted"
    assert any("untested" in m for m in cov.missing)
    f.ground_evidence(eid)                             # one test later…
    cov2 = coverage(f, "c")
    assert cov2.grounded_fraction > 0.5                # …the weak link strengthened
    g = Field("wall")
    g.var("k", "J/K")
    g.constant("k", 1.380649e-23, "k_B", "SI")
    assert coverage(g, "k").grounded_fraction == 1.0
    assert coverage(g, "k").status == "walled"


def test_allocate_ranks_and_drops():
    from rabbithole import Field, allocate
    now = time.time()
    f = Field("alloc")
    f.var("X", "ohm", lo=0)
    f.var("Y", "ohm", lo=0)
    f.add_evidence("X", 100, 2, "m1", 0.9, grounded_at=now, tested=True)
    f.add_evidence("X", 130, 2, "m2", 0.9, grounded_at=now, tested=True)  # contested
    ey = f.add_evidence("Y", 50, 5, "blog", 0.5)                          # untested
    ranked = allocate(f, top_k=3, now=now)
    assert ranked[0]["var"] == "X"             # live disagreement outranks
    assert any(r["var"] == "Y" for r in ranked)
    f.ground_evidence(ey, now=now)
    ranked2 = allocate(f, top_k=3, now=now)
    assert not any(r["var"] == "Y" for r in ranked2)   # grounding drops it


def test_commit_integrity_refuse_force_and_roundtrip():
    from rabbithole import (CommitmentIntegrityError, Field, GroundingLoop,
                            GroundingTest, RealityHarness, commit,
                            resolve_commitment)
    f = Field("decide")
    f.attach_log()
    f.var("supply", "item", lo=0)
    eid = f.add_evidence("supply", 500, 20, "warehouse email", 0.7)  # untested
    f.settle()
    try:
        commit(f, "promise 400 units to B", "sign contract", ["supply"],
               reversibility="cancellation clause, 7 days",
               test_plan=["physical stock count"])
        raise AssertionError("under-covered commitment was not refused")
    except CommitmentIntegrityError as e:
        assert "coverage" in str(e) and "untested" in str(e)       # A8
    forced = commit(f, "promise anyway", "sign", ["supply"],
                    reversibility="none", test_plan=[], force=True)
    assert forced.forced is True                                   # flagged forever
    h = RealityHarness()
    h.register("physical_stock_count", lambda spec: True, contact="instrument")
    GroundingLoop(f, h).dispatch(eid, GroundingTest("physical_stock_count", None,
                                                    author="auditor"))
    ok = commit(f, "promise 400 units to B", "sign contract", ["supply"],
                reversibility="cancellation clause, 7 days",
                test_plan=["quarterly recount"])
    assert ok.min_coverage > 0.5 and ok.forced is False
    resolve_commitment(f, ok.cid, "kept", "delivered in full")
    types = [e.type for e in f.log.events]
    assert types.count("commit") == 2 and "commit_resolved" in types
    g = Field.from_dict(f.to_dict())                                # survives disk
    assert g.commitments[ok.cid].status == "kept"


# --------------------------------------------------------------------------
# bug-fix gates
# --------------------------------------------------------------------------

def test_bridge_ingest_is_transactional():
    f = Field("tx")
    f.var("x", "m")
    bad = {"variables": [{"name": "t", "unit": "s"}],
           "constraints": [{"type": "sum", "terms": ["x", "t"], "total": "x",
                            "statement": "meters plus seconds"}]}
    try:
        ingest(bad, f, mode="declared")
        raise AssertionError("wall did not fire")
    except DimensionalWall:
        pass
    assert list(f.variables) == ["x"]          # no half-ingested 't'
    assert len(f.factors) == 0                 # nothing leaked before the wall


def test_evidence_sigma_must_be_positive():
    f = Field("sig")
    f.var("R", "ohm")
    try:
        f.add_evidence("R", 100, 0, "meter", 0.9)
        raise AssertionError("sigma=0 accepted")
    except ValueError as e:
        assert "wall, not evidence" in str(e)


def test_wall_release_requires_force():
    f = Field("wallrel")
    f.attach_log()
    f.var("g", "m/s^2")
    fid = f.constant("g", 9.80665, "g", "CGPM")
    try:
        f.release(fid)
        raise AssertionError("wall released without force")
    except PermissionError:
        pass
    f.release(fid, force=True)
    rel = [e for e in f.log.events if e.type == "release"]
    assert rel and rel[0].payload["forced"] is True


def test_power_exponent_must_be_positive():
    f = Field("pow0")
    f.var("a", "")
    f.var("c", "")
    try:
        f.power_is("a", 0, "c")
        raise AssertionError("n=0 accepted")
    except ValueError:
        pass


def test_fast_engine_survives_field_mutation():
    from rabbithole.fast import FastEngine
    f = Field("mut")
    for n in ("a", "b", "c"):
        f.var(n, "")
    f.sum_is(["a", "b"], "c", "a+b=c", "test")
    f.clamp("a", 1, reason="t")
    eng = FastEngine(f)
    eng.settle()
    assert math.isinf(f.variables["c"].domain.hi)      # b free -> c open
    f.clamp("b", 2, reason="t")                        # mutate AFTER packing
    r = eng.settle()                                   # must auto-repack
    assert r.status == "settled"
    assert approx(f.variables["c"].domain.lo, 3.0, 1e-9)


# --------------------------------------------------------------------------
# runner
# --------------------------------------------------------------------------

def main():
    tests = [(k, v) for k, v in sorted(globals().items())
             if k.startswith("test_") and callable(v)]
    passed = failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"PASS  {name}")
            passed += 1
        except Exception:
            print(f"FAIL  {name}")
            traceback.print_exc()
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    # ctypes-loaded native libraries can occasionally stall CPython finalization
    # after a prior acceptance process has exercised the same shared object.
    # The runner has no cleanup contract beyond flushing its report, so terminate
    # without interpreter teardown.  This makes a completed gate reliably
    # observable instead of allowing a false aggregate hang after 40/40 passed.
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(1 if failed else 0)


if __name__ == "__main__":
    main()