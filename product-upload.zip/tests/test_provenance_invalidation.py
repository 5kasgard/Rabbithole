from rabbithole.provenance import ProvActivity, ProvAgent, ProvEntity, ProvenanceGraph


def test_invalidation_cascades_without_deleting_history():
    g = ProvenanceGraph()
    agent = g.add_agent(ProvAgent("source", "software"))
    root = g.add_entity(ProvEntity("raw", content_sha256="a", attributed_to=(agent,)))
    act = g.add_activity(ProvActivity("transform", (root,), (agent,), 1.0, 2.0))
    child = g.add_entity(ProvEntity("summary", generated_by=act, derived_from=(root,), attributed_to=(agent,)))
    act2 = g.add_activity(ProvActivity("render", (child,), (agent,), 2.0, 3.0))
    grandchild = g.add_entity(ProvEntity("report", generated_by=act2, derived_from=(child,), attributed_to=(agent,)))
    receipt = g.invalidate_cascade(root, "source retracted")
    assert receipt["count"] == 3
    assert {root, child, grandchild} == set(receipt["newly_invalidated"])
    assert all(g.entities[x].invalidated_at for x in (root, child, grandchild))
    assert len(g.entities) == 3
    assert g.verify()["valid"]
