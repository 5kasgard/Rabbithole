"""Executable adversarial gates for quantity placement."""
from __future__ import annotations

from rabbithole import Carving, FieldSystem, metrology_seed


def check(ok: bool, label: str, detail: str = "") -> bool:
    print(f"[{' ok ' if ok else 'FAIL'}] {label:72s} {detail}")
    return ok


def main() -> None:
    s = FieldSystem(kinds=metrology_seed())
    passed = []
    a = s.ingest(Carving(
        label="mass density", unit="kg/m^3", value=997, sigma=1,
        source="A", kind_id="mass_density", algebraic_type="scalar",
        phenomenon="material property", operational_tags=("mass_per_volume",),
        scope={"sample_id": "W", "state": "25C"}))
    b = s.ingest(Carving(
        label="volumic mass", unit="g/cm^3", value=.997, sigma=.001,
        source="B", kind_id="mass_density", algebraic_type="scalar",
        phenomenon="material property", operational_tags=("mass_per_volume",),
        scope={"sample_id": "W", "state": "25C"}))
    passed.append(check(b.action == "accepted_existing",
                        "same measurand under different names/units composes", b.action))
    passed.append(check(len(s.observations) == 2,
                        "composition retains both provenance-bearing observations"))
    passed.append(check(s.field.belief(s.canonical(a.local_measurand_id)).mean is None,
                        "composition does not grant untested values authority"))

    e = s.ingest(Carving(label="energy", unit="J", value=5, sigma=.1,
                         source="E", kind_id="energy", algebraic_type="scalar",
                         scope={"system": "shaft", "time": "t0"}))
    t = s.ingest(Carving(label="torque", unit="N*m", value=5, sigma=.1,
                         source="T", kind_id="torque", algebraic_type="pseudovector",
                         scope={"system": "shaft", "time": "t0"}))
    passed.append(check(s.canonical(e.local_measurand_id) != s.canonical(t.local_measurand_id),
                        "same dimension and value do not collapse energy into torque"))

    sp = s.ingest(Carving(label="speed", unit="m/s", value=10, sigma=.2,
                          source="S", kind_id="speed", algebraic_type="scalar",
                          scope={"object": "car", "time": "t0"}))
    ve = s.ingest(Carving(label="velocity", unit="m/s", value=10, sigma=.2,
                          source="V", kind_id="velocity", algebraic_type="vector",
                          scope={"object": "car", "time": "t0"}))
    passed.append(check(s.canonical(sp.local_measurand_id) != s.canonical(ve.local_measurand_id),
                        "scalar speed does not collapse into vector velocity"))

    other = s.ingest(Carving(
        label="density", unit="kg/m^3", value=998, sigma=1,
        source="C", kind_id="mass_density", algebraic_type="scalar",
        phenomenon="material property", operational_tags=("mass_per_volume",),
        scope={"sample_id": "OTHER", "state": "25C"}))
    passed.append(check(s.canonical(a.local_measurand_id) != s.canonical(other.local_measurand_id),
                        "same quantity kind on a different subject stays distinct"))

    print("-" * 82)
    print(f"{sum(passed)}/{len(passed)} passed")
    raise SystemExit(0 if all(passed) else 1)


if __name__ == "__main__":
    main()
