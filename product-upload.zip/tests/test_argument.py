from rabbithole.argument import ArgumentClaim, ArgumentEvidence, ArgumentGraph, ClaimRelation


def test_correlated_support_is_one_group_and_disagreement_remains_explicit():
    g = ArgumentGraph()
    c = g.add_claim(ArgumentClaim("mechanism M is necessary", "design_claim"))
    for i in range(10):
        g.add_evidence(ArgumentEvidence(c, "supports", f"copy-{i}", "same-paper",
                                        "document", 0.8, True, "same source repeated"))
    r = g.report(c)
    assert r.independent_support_groups == 1
    g.add_evidence(ArgumentEvidence(c, "attacks", "replication", "independent-lab",
                                    "experiment", 0.9, True, "counterexample"))
    assert g.report(c).state == "contested"


def test_dependencies_block_support_until_resolved():
    g = ArgumentGraph()
    a = g.add_claim(ArgumentClaim("A", "claim"))
    b = g.add_claim(ArgumentClaim("B", "claim"))
    g.add_evidence(ArgumentEvidence(a, "supports", "x", "x", "test", 1, True, "supports"))
    g.relate(ClaimRelation(a, b, "depends_on"))
    assert g.report(a).state == "unresolved"
    g.add_evidence(ArgumentEvidence(b, "supports", "y", "y", "test", 1, True, "supports"))
    assert g.report(a).state == "supported"


def test_retraction_recomputes_without_deleting_history():
    g = ArgumentGraph()
    c = g.add_claim(ArgumentClaim("C", "claim"))
    e = g.add_evidence(ArgumentEvidence(c, "supports", "x", "x", "test", 1, True, "yes"))
    assert g.report(c).state == "supported"
    g.retract_evidence(e, "artifact invalidated")
    assert g.report(c).state == "unresolved"
    assert e in g.evidence and not g.evidence[e].active
