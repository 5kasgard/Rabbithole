"""Executable acceptance gates for the corrected forager authority boundary."""
from __future__ import annotations

import json
import os
import tempfile
import time

from forager import LocalSource, forage
from rabbithole import Field, GroundingLoop, GroundingTest, Measurement, RealityHarness


def check(ok: bool, label: str, detail: str = "") -> bool:
    print(f"[{' ok ' if ok else 'FAIL'}] {label:68s} {detail}")
    return ok


def main() -> None:
    passed = []
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "source.json")
        with open(path, "w") as fh:
            json.dump({
                "rho": {"value": 997.0, "unit": "kg/m^3", "sigma": 1.0,
                        "source": "handbook", "citation": "controlled fixture"},
                "bad": {"value": 997.0, "unit": "kg", "sigma": 1.0,
                        "source": "bad-source"},
            }, fh)
        f = Field("forager-boundary")
        f.var("density", "kg/m^3")
        f.var("volume", "m^3")
        f.var("mass", "kg")
        f.product_is("density", "volume", "mass", "mass = density × volume",
                     source="definition", kind="definition")
        f.clamp("volume", value=0.002, reason="declared scenario")

        r = forage(f, "density", "rho", LocalSource(path))
        passed.append(check(r.status == "acquired_untested", "source record enters as untested evidence", r.status))
        passed.append(check(len(f.factors) == 2, "foraging does not add a clamp or structural wall"))
        f.settle()
        passed.append(check(f.variables["mass"].domain.hi == float("inf"),
                            "untested testimony cannot drive calculation"))

        h = RealityHarness(predicates={"rho_measure": lambda: Measurement(997.0, 1.0, "kg/m^3")})
        loop = GroundingLoop(f, h)
        v = loop.dispatch(r.evidence_id, GroundingTest("measure", "rho_measure", author="instrument-A"))
        passed.append(check(v.result == "pass", "registered contact grounds the evidence"))
        pfid = f.project_belief("density")
        f.settle()
        passed.append(check(f.variables["mass"].domain.contains(1.994),
                            "explicit grounded-belief projection drives interval calculation",
                            repr(f.variables["mass"].domain)))
        f.release(pfid)
        f.settle()
        passed.append(check(f.variables["mass"].domain.hi == float("inf"),
                            "working projection is reversible"))

        bad = forage(f, "density", "bad", LocalSource(path))
        passed.append(check(bad.status == "rejected_dimension",
                            "dimension wall refuses incompatible sourced quantity", bad.status))
        missing = forage(f, "density", "missing", LocalSource(path))
        passed.append(check(missing.status == "not_found",
                            "missing acquisition fails loudly", missing.status))

    print("-" * 78)
    print(f"{sum(passed)}/{len(passed)} passed")
    raise SystemExit(0 if all(passed) else 1)


if __name__ == "__main__":
    main()
