"""Expose the original zero-dependency kernel gates to the unified pytest surface.

The legacy runner remains useful on systems without pytest, but release
acceptance must not depend on running the same native library in a second
interpreter after the full suite. Importing the test functions here makes the
40 original gates first-class members of the public release suite.
"""
from tests.run_tests import *  # noqa: F401,F403
