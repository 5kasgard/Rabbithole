import json, sys
from pathlib import Path
from rabbithole.faculties import SubprocessFaculty
from rabbithole.intent import IntentInterpreter


def test_intent_is_falsifiable_zero_authority_proposal(tmp_path: Path):
    script = tmp_path / "f.py"
    script.write_text('''import json,sys\nr=json.load(sys.stdin)\nout={
"target":"placement", "local_current":["first-match aliases"],
"local_goal":["reversible identity"], "whole_current":["duplicates accumulate"],
"whole_goal":["independent knowledge composes without contamination"],
"constraints":["preserve provenance"], "anti_goals":["false merge"],
"success_observations":["held-out aliases compose"],
"failure_observations":["lookalikes merge"], "scope":"scientific quantities",
"ambiguities":["same kind or same measurand"],
"inferred_assumptions":["structured input"],
"candidate_claim_classes":["identity claim"],
"search_seed_terms":["entity alignment"], "user_decisions_required":[]}
print(json.dumps(out))''')
    interpreter = IntentInterpreter(SubprocessFaculty([sys.executable, str(script)]))
    p = interpreter.interpret("make placement work")
    assert p.authority == 0.0
    assert p.contract.success_observations
    assert p.ambiguities
    assert interpreter.audit.verify()["valid"]
