from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

from rabbithole.discovery import DiscoveryArc, POSIWIDContract, TestObligation

ROOT = Path(__file__).resolve().parents[1]


def _run(*args: str) -> dict:
    proc = subprocess.run(
        [sys.executable, "field_cli.py", *args], cwd=ROOT,
        text=True, capture_output=True, timeout=60,
    )
    assert proc.returncode == 0, proc.stderr
    return json.loads(proc.stdout)


def test_cli_import_contact_and_exact_source_invalidation(tmp_path: Path):
    arc = DiscoveryArc(POSIWIDContract(
        target="public contact loop",
        local_current=("untested",), local_goal=("tested",),
        whole_current=("static report",), whole_goal=("contact-updated process",),
        success_observations=("contact recorded",),
        failure_observations=("no update",),
    ))
    tid = arc.add_test(TestObligation(
        "goal", arc.contract.cid, "does contact update the arc?",
        "run independent check", "yes", "no", "execution",
        "independent-check", .8, .8, .8, {"compute": 1},
        public_surface="field_cli.py contact-record",
    ))
    arc_file = tmp_path / "arc.json"
    arc.save(arc_file)
    state = tmp_path / "state"

    imported = _run("arc-import", str(arc_file), str(state))
    assert imported["capability"] == "arc-import"
    recorded = _run(
        "contact-record", str(state), arc.arc_id, tid,
        json.dumps({
            "state": "passed",
            "observed": "independent check returned expected result",
            "result": "supported",
        }),
    )
    assert recorded["result"]["test"]["state"] == "passed"
    shown = _run("arc", str(state), arc.arc_id)
    assert shown["posiwid"]["observed_effects"]["tests_with_contact"] == 1

    source = tmp_path / "sample.txt"
    source.write_text("Material report for sample W17. Density: 997.0 ± 0.5 kg/m3.")
    inquiry = _run("investigate", "density of W17", str(state), "--source", source.as_uri())
    artifact = inquiry["result"]["artifacts"][0]["artifact"]
    assert artifact["content_sha256"] == hashlib.sha256(source.read_bytes()).hexdigest()

    invalidated = _run(
        "invalidate", str(state), artifact["locator"], artifact["content_sha256"],
        "captured source version retracted",
    )
    assert invalidated["result"]["affected"]
    verified = _run("verify", str(state))
    assert verified["valid"] is True
