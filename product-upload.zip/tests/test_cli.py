from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        state = os.path.join(td, "field.json")
        ingest = subprocess.run(
            [sys.executable, "akbc_cli.py", "ingest", "examples/density_carvings.json", state],
            cwd=ROOT, capture_output=True, text=True)
        assert ingest.returncode == 0, ingest.stderr
        data = json.loads(ingest.stdout)
        assert [x["action"] for x in data["decisions"]] == ["new", "accepted_existing"]
        assert data["posiwid"]["observed_effects"]["untested_observations"] == 2
        verify = subprocess.run([sys.executable, "akbc_cli.py", "verify", state],
                                cwd=ROOT, capture_output=True, text=True)
        assert verify.returncode == 0, verify.stderr
        report = json.loads(verify.stdout)
        assert report["valid"] is True
        assert report["receipts"]["snapshots"] == 2
    print("PASS  structured CLI intake, persistence, and verification")


if __name__ == "__main__":
    main()
