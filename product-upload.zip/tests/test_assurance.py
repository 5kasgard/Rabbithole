from rabbithole.assurance import AssuranceRegistry, CapabilityRequirement
from rabbithole.organs import OrganRegistry, OrganSpec


def test_capability_case_requires_trace_and_kills_claimed_organs():
    organs = OrganRegistry()
    organs.register(OrganSpec("search", "retrieve", ("source receipt",),
                              public_capabilities=("discover",)))
    assurance = AssuranceRegistry()
    req = CapabilityRequirement(
        "discover", "instrument.discover", ("sources retrieved",),
        ("candidate field broadened",), ("search",),
        ("source receipt",), ("search unavailable",),
    )
    assurance.register(req)
    def invoke():
        with organs.operation("R", "search", "discover", "query"):
            return {"sources": 1}
    case = assurance.evaluate(req.rid, organs, invoke,
                              lambda result: {"passed": result["sources"] == 1,
                                              "effects": ["source receipt"]})
    assert case.passed
    assert assurance.coverage()["passing_cases"] == [case.cid]


def test_external_contact_requirement_cannot_be_satisfied_by_internal_effect():
    organs = OrganRegistry()
    organs.register(OrganSpec("verify", "verify", ("verdict",),
                              public_capabilities=("verify",)))
    assurance = AssuranceRegistry()
    req = CapabilityRequirement("verify", "instrument.verify", ("claim evaluated",),
                                ("reality constrains claim",), ("verify",),
                                ("verdict",), ("no contact",), external_contact_required=True)
    assurance.register(req)
    def invoke():
        with organs.operation("R", "verify", "verify", "internal"):
            return {"state": "supported"}
    case = assurance.evaluate(req.rid, organs, invoke,
                              lambda result: {"passed": True, "effects": ["verdict"]})
    assert not case.passed
    assert "no external contact" in case.baseline.reason
