from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
from dataclasses import asdict
from pathlib import Path

import pytest

from rabbithole.performance_fabric import (HybridPerformancePortfolio, PerformanceLedger,
                                           PerformanceOutcome, PerformanceTask,
                                           architecture_posiwid_report, release_source_digest)
from rabbithole.performance_runtime import BoundedPerformanceExecutor
from rabbithole.performance_store import TransactionalKeySetStore


def task(**kw):
    raw = {"operation": "verify", "risk_level": "low", **kw}
    return PerformanceTask.from_dict(raw)


def test_architecture_comparison_includes_homogeneous_hybrid_and_heterogeneous():
    report = architecture_posiwid_report()
    structures = {x["structure"] for x in report["profiles"].values()}
    assert {"homogeneous", "hybrid", "heterogeneous", "hybrid_heterogeneous"} <= structures
    assert report["selected_architecture"] == "adaptive_bounded_portfolio"
    assert report["universal_winner"] is None


def test_high_risk_retains_fresh_reference():
    d = HybridPerformancePortfolio().select(task(risk_level="critical", repetitions=20,
                                                 actor_scope="a", contract_scope="c"))
    assert d.mode == "fresh_reference"


def test_remote_edge_energy_and_longitudinal_surfaces_abstain():
    for field in ("network_required", "edge_target", "energy_claim", "longitudinal_outcome_claim"):
        d = HybridPerformancePortfolio().select(task(**{field: True}))
        assert d.mode == "abstain"


def test_release_identity_mismatch_abstains():
    d = HybridPerformancePortfolio().select(task(expected_release_source_digest="0" * 64))
    assert d.mode == "abstain"
    assert "identity mismatch" in d.reason


def test_warm_capsule_requires_repetition_scope_and_no_credentials():
    p = HybridPerformancePortfolio()
    assert p.select(task(repetitions=3, actor_scope="a", contract_scope="c")).mode == "warm_capsule"
    assert p.select(task(repetitions=3, actor_scope="a", contract_scope="c",
                         credential_bearing=True)).mode != "warm_capsule"


def test_cold_batch_is_fresh_domain_simplifier():
    d = HybridPerformancePortfolio().select(task(repetitions=2, batchable=True))
    assert d.mode == "cold_batch"
    assert "fresh per-operation" in " ".join(d.mechanisms)


def test_transactional_slice_requires_contacted_mutation_algebra():
    p = HybridPerformancePortfolio()
    ok = p.select(task(state_bytes=2_000_000, mutation_algebra="idempotent_key_set"))
    bad = p.select(task(state_bytes=2_000_000, mutation_algebra="increment"))
    assert ok.mode == "transactional_state"
    assert bad.mode == "fresh_reference"


def test_native_slice_requires_exact_regular_shape_and_reference():
    d = HybridPerformancePortfolio().select(task(numeric_shape="sum", integer_exact=True, regular_graph=True))
    assert d.mode == "native_specialist"
    assert any("reference" in x.lower() for x in d.mechanisms)


def test_mechanisms_are_not_unproven_stacked_speedups():
    d = HybridPerformancePortfolio().select(task(
        repetitions=10, actor_scope="a", contract_scope="c",
        state_bytes=2_000_000, mutation_algebra="idempotent_key_set",
        numeric_shape="sum", integer_exact=True, regular_graph=True,
    ))
    assert d.mode == "native_specialist"
    assert "warm" not in " ".join(d.mechanisms).lower()
    assert "sqlite" not in " ".join(d.mechanisms).lower()


def test_transactional_store_round_trip_idempotency_and_replay(tmp_path):
    db = TransactionalKeySetStore(tmp_path / "state.sqlite")
    try:
        first = db.set_many({"a": 1, "b": {"x": 2}}, "op-1")
        duplicate = db.set_many({"a": 1, "b": {"x": 2}}, "op-1")
        assert not first["duplicate"] and duplicate["duplicate"]
        assert db.get("b") == {"x": 2}
        assert db.verify()["valid"]
    finally:
        db.close()


def test_transactional_store_rejects_idempotency_collision(tmp_path):
    db = TransactionalKeySetStore(tmp_path / "state.sqlite")
    try:
        db.set_many({"a": 1}, "same")
        with pytest.raises(ValueError):
            db.set_many({"a": 2}, "same")
    finally:
        db.close()


def test_transactional_store_detects_materialized_tamper(tmp_path):
    path = tmp_path / "state.sqlite"
    db = TransactionalKeySetStore(path)
    db.set_many({"a": 1}, "op")
    db.db.execute("UPDATE materialized SET value_json='2' WHERE key='a'")
    assert not db.verify()["valid"]
    db.close()


def test_ledger_records_actual_posiwid_and_round_trips(tmp_path):
    path = tmp_path / "ledger.json"
    ledger = PerformanceLedger(path)
    d = HybridPerformancePortfolio().select(task())
    ledger.register(d)
    verdict = ledger.record(PerformanceOutcome(d.decision_id, True, True, False, 1.0, 0.0))
    assert verdict == {"hard_valid": True, "rollback_required": False}
    loaded = PerformanceLedger(path)
    assert loaded.verify()["valid"]
    assert loaded.posiwid()["observed_effects"]["hard_valid_outcomes"] == 1


def test_ledger_requires_rollback_on_semantic_or_audit_failure(tmp_path):
    ledger = PerformanceLedger(tmp_path / "ledger.json")
    d = HybridPerformancePortfolio().select(task())
    ledger.register(d)
    result = ledger.record(PerformanceOutcome(d.decision_id, False, True, False, 1.0, 0.1))
    assert result["rollback_required"]


def test_ledger_detects_serialized_state_tamper(tmp_path):
    path = tmp_path / "ledger.json"
    ledger = PerformanceLedger(path)
    d = HybridPerformancePortfolio().select(task())
    ledger.register(d)
    raw = json.loads(path.read_text())
    raw["decisions"][0]["reason"] = "tampered"
    path.write_text(json.dumps(raw))
    with pytest.raises(ValueError):
        PerformanceLedger(path)


def test_warm_executor_reuses_exact_scope_and_restarts_on_scope_change(tmp_path):
    state = tmp_path / "state"
    ex = BoundedPerformanceExecutor(max_warm_operations=10, max_warm_age_s=60)
    a = task(repetitions=3, actor_scope="actor", contract_scope="contract-a")
    b = task(repetitions=3, actor_scope="actor", contract_scope="contract-b")
    first = ex.execute(a, {"state": str(state)})
    restarts_after_first = ex.restarts
    second = ex.execute(a, {"state": str(state)})
    assert first["verdict"]["hard_valid"] and second["verdict"]["hard_valid"]
    assert ex.restarts == restarts_after_first
    ex.execute(b, {"state": str(state)})
    assert ex.restarts == restarts_after_first + 1


def test_executor_transactional_route_records_hard_valid_outcome(tmp_path):
    ex = BoundedPerformanceExecutor()
    t = task(state_bytes=2_000_000, mutation_algebra="idempotent_key_set")
    out = ex.execute(t, {"store": str(tmp_path / "x.sqlite"), "action": "set",
                         "changes": {"a": 1}, "idempotency_key": "one"})
    assert out["decision"]["mode"] == "transactional_state"
    assert out["verdict"]["hard_valid"]


def test_lazy_performance_cli_identity_and_plan(tmp_path):
    root = Path(__file__).resolve().parents[1]
    identity = subprocess.run([sys.executable, "performance_cli.py", "identity"], cwd=root,
                              text=True, capture_output=True, timeout=30)
    assert identity.returncode == 0
    assert json.loads(identity.stdout)["source_digest"] == release_source_digest(root)
    spec = tmp_path / "task.json"
    spec.write_text(json.dumps(asdict(task(repetitions=2, batchable=True))))
    plan = subprocess.run([sys.executable, "performance_cli.py", "plan", str(spec)], cwd=root,
                          text=True, capture_output=True, timeout=30)
    assert plan.returncode == 0
    assert json.loads(plan.stdout)["mode"] == "cold_batch"


def test_general_cli_exposes_performance_status():
    root = Path(__file__).resolve().parents[1]
    p = subprocess.run([sys.executable, "field_cli.py", "performance-status"], cwd=root,
                       text=True, capture_output=True, timeout=40)
    assert p.returncode == 0
    assert json.loads(p.stdout)["architecture"]["selected_architecture"] == "adaptive_bounded_portfolio"
