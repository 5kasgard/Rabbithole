from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path


def run(root: Path, *args: str):
    env = {**os.environ, "PYTHONPATH": str(root)}
    return subprocess.run(
        [sys.executable, str(root / "master_cli.py"), *args],
        cwd=root,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=30,
    )


def test_master_status_and_verify_cli():
    root = Path(__file__).resolve().parents[1]
    status = run(root, "status")
    assert status.returncode == 0, status.stderr
    assert json.loads(status.stdout)["identity"]["version"] == "0.18.0rc3"
    verify = run(root, "verify")
    assert verify.returncode == 0, verify.stderr
    assert json.loads(verify.stdout)["valid"] is True


def test_fip_cli_seal_and_verify(tmp_path):
    root = Path(__file__).resolve().parents[1]
    payload = tmp_path / "payload.json"
    payload.write_text('{"value":1}')
    out = tmp_path / "fip.json"
    sealed = run(
        root, "fip-seal", str(payload), "--profile", "evidence", "--identity", "cli-1",
        "--issuer", "test", "--scope", "demo", "--output", str(out),
    )
    assert sealed.returncode == 0, sealed.stderr
    checked = run(root, "fip-verify", str(out))
    assert checked.returncode == 0, checked.stderr
    assert json.loads(checked.stdout)["semantic_authority"] is False


def test_phase_cli_round_trip(tmp_path):
    root = Path(__file__).resolve().parents[1]
    source = tmp_path / "source.json"
    source.write_text('{"ok":true}\n')
    output = tmp_path / "status.json"
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    config = tmp_path / "config.json"
    config.write_text(json.dumps({
        "objective": {
            "objective_id": "cli-loop",
            "statement": "verify test source",
            "success_conditions": ["digest matches"],
            "allowed_actions": ["write-status"],
            "resource_budget": {"wall_seconds": 10, "io_bytes": 100000},
            "actor": "tester",
            "risk_tier": "low",
            "reversible_only": True,
        },
        "profile": {
            "kind": "file-integrity",
            "source": str(source),
            "expected_sha256": digest,
            "output": str(output),
        },
    }))
    state = tmp_path / "state"
    init = run(root, "phase-init", str(config), str(state))
    assert init.returncode == 0, init.stderr
    step = run(root, "phase-step", str(config), str(state))
    assert step.returncode == 0, step.stderr
    assert json.loads(step.stdout)["receipt"]["status"] == "completed"
    status = run(root, "phase-status", str(state))
    assert status.returncode == 0, status.stderr
    assert json.loads(status.stdout)["cycles"] == 1
