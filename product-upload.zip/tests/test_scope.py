from rabbithole.scope import ModelContract, ModelRegistry, ScopeCondition


def model():
    return ModelContract("free-fall", "constant-g no-drag free fall", ("height",), ("speed",),
                         (ScopeCondition("drag", "eq", False),
                          ScopeCondition("height_m", "range", (0, 1000))),
                         ("constant gravitational field",), ("high drag",),
                         contact_quality=.4, authority_ceiling=.4)


def test_model_scope_refuses_unknown_and_failed_context():
    r=ModelRegistry(); r.register(model())
    assert r.evaluate("free-fall", {"height_m": 10}).state == "unresolved"
    assert r.evaluate("free-fall", {"height_m": 10, "drag": True}).state == "inapplicable"
    d=r.evaluate("free-fall", {"height_m": 10, "drag": False})
    assert d.state == "applicable" and d.authority_ceiling == .4


def test_model_invalidation_revokes_applicability():
    r=ModelRegistry(); r.register(model()); r.invalidate("free-fall", "superseded")
    assert r.evaluate("free-fall", {"height_m": 10, "drag": False}).state == "invalidated"
