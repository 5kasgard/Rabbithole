from rabbithole.organs import OrganRegistry, OrganSpec, OrganUnavailable


def registry():
    r = OrganRegistry()
    r.register(OrganSpec("search", "retrieve source artifacts", ("source receipt exists",),
                         public_capabilities=("research",), failure_signature="search unavailable"))
    r.register(OrganSpec("reduce", "eliminate unsupported mechanisms", ("candidate set contracts",),
                         dependencies=("search",), public_capabilities=("research",)))
    return r


def test_trace_and_coverage():
    r = registry()
    with r.operation("R1", "search", "research", "query"):
        pass
    assert r.coverage("research")["uninvoked"] == ["reduce"]
    assert r.audit.verify()["valid"]


def test_mutation_proves_load_bearing():
    r = registry()
    def public():
        with r.operation("R2", "search", "research", "query"):
            return {"sources": 1}
    result = r.mutation_test("search", "research", public)
    assert result.load_bearing
    assert "predicted" in result.reason


def test_dependent_organ_fails_when_dependency_disabled():
    r = registry()
    with r.disabled("search"):
        try:
            r.require("reduce", "research")
        except OrganUnavailable as exc:
            assert "dependencies" in exc.reason
        else:
            raise AssertionError("dependency failure was not enforced")
