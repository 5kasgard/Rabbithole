from pathlib import Path

from rabbithole.discovery import DiscoveryArc, POSIWIDContract, TestObligation
from rabbithole.instrument import FieldInstrument


def test_import_and_record_contact_through_public_surface(tmp_path: Path):
    arc = DiscoveryArc(POSIWIDContract(
        target="contact loop", local_current=("untested",), local_goal=("tested",),
        whole_current=("static report",), whole_goal=("contact-updated process",),
        success_observations=("contact recorded",), failure_observations=("no update",),
    ))
    tid = arc.add_test(TestObligation(
        "goal", arc.contract.cid, "does contact update?", "run check", "yes", "no",
        "execution", "independent-check", .8, .8, .8, {"compute": 1},
        public_surface="FieldInstrument.record_arc_test"))
    source = tmp_path / "arc.json"
    arc.save(source)
    inst = FieldInstrument(tmp_path / "state")
    imported = inst.import_arc(source)
    assert imported.audit_valid
    recorded = inst.record_arc_test(arc.arc_id, tid, state="passed",
                                    observed="check returned expected result", result="supported")
    assert recorded.result["test"]["state"] == "passed"
    reloaded = inst.load_arc(arc.arc_id)
    assert reloaded.tests[tid].state == "passed"
    assert reloaded.posiwid()["observed_effects"]["tests_with_contact"] == 1
