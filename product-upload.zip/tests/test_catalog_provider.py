import json
from pathlib import Path
from rabbithole.search import CatalogProvider


def test_catalog_provider_replays_captured_sources(tmp_path: Path):
    p=tmp_path/'catalog.json'
    p.write_text(json.dumps({'records':[{'title':'CEGAR','locator':'doi:x','snapshot':'counterexample guided abstraction refinement','summary':'refine abstraction from counterexamples','independence_group':'doi:x'}]}))
    r=CatalogProvider(p).search('counterexample abstraction')
    assert len(r)==1 and r[0].locator=='doi:x'
