from rabbithole.actions import ActionRegistry, ActionSpec
from rabbithole.capabilities import CapabilityIssuer
from rabbithole.ir import IRRegistry, IRRequirement, core_irs
from rabbithole.portfolio import MechanismPortfolio, MechanismProfile, PerformanceRecord, TaskShape


def test_portfolio_respects_contract_then_learns_instance_performance():
    p = MechanismPortfolio()
    p.register(MechanismProfile("symbolic", ("solve",), ("sound",), "CPU", 0.0, True,
                                prior_success=.7, prior_latency_ms=100, prior_fuel=1))
    p.register(MechanismProfile("neural", ("solve",), (), "GPU", 0.0, False,
                                prior_success=.9, prior_latency_ms=10, prior_fuel=2))
    task = TaskShape("solve", {"size": 1}, required_properties=("sound",))
    assert p.select(task).mechanism_id == "symbolic"
    # Repeated failures lower local prediction but cannot route to an incompatible unsound mechanism.
    for _ in range(4):
        p.record(PerformanceRecord("symbolic", "solve", {"size": 1}, False, 100, 1, "test"))
    assert p.select(task).mechanism_id == "symbolic"


def test_ir_selection_refuses_loss_of_required_distinction():
    r = IRRegistry()
    for c in core_irs(): r.register(c)
    s = r.select(IRRequirement("empirical_quantity",
                               ("physical_dimension", "uncertainty_interval"),
                               ("constraint_propagation",),
                               ("dimensional_checker",)))
    assert s.ir_id == "interval-field"
    try:
        r.select(IRRequirement("empirical_quantity", ("natural_language_pragmatics",),
                               ("constraint_propagation",)))
    except LookupError:
        pass
    else:
        raise AssertionError("lossy IR was accepted")


def test_irreversible_action_requires_real_approval_and_capability():
    issuer = CapabilityIssuer(b"x" * 32)
    r = ActionRegistry(issuer)
    r.register(ActionSpec("delete", "file:/tmp/x", False, True, "user",
                          lambda req, dry: {"would_delete": True} if dry else {"deleted": True}))
    cap = issuer.mint("execute_action", "file:/tmp/x", "alex")
    assert r.run("delete", {}, holder="alex", capability=cap, dry_run=True).status == "dry_run"
    try:
        r.run("delete", {}, holder="alex", capability=cap, dry_run=False)
    except PermissionError:
        pass
    else:
        raise AssertionError("irreversible action ran without approval")
