from pathlib import Path

from rabbithole.instrument import FieldInstrument
from rabbithole.process import SearchEnvelope
from rabbithole.search import LocalCorpusProvider


def test_literal_inquiry_searches_and_stops_without_fabricated_answer(tmp_path: Path):
    corpus = tmp_path / "corpus"
    corpus.mkdir()
    (corpus / "source.md").write_text(
        "Source revocation requires derivation-aware provenance and cascading invalidation."
    )
    inst = FieldInstrument(tmp_path / "state")
    result = inst.inquire(
        "How should source revocation work?",
        SearchEnvelope(domain_families=("test",), min_search_waves=1,
                       min_independent_groups=1, per_query_limit=5),
        {"local": LocalCorpusProvider([corpus])}, concrete_provider="local",
    )
    assert result.audit_valid
    assert result.result["terminal_state"] == "insufficient-contact"
    assert result.result["evidence_count"] >= 1
    assert result.result["report"]["authority_ceiling"] == 0.0
    assert "No grounded substantive answer" in result.result["report"]["body"]["answer"]
