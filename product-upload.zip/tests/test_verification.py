from rabbithole.verification import (
    Claim, RegisteredVerifier, VerificationRegistry, VerificationRequest,
    core_contracts,
)


def registry():
    r = VerificationRegistry()
    for c in core_contracts():
        r.register_contract(c)
    return r


def test_executor_success_is_not_automatically_truth():
    r = registry()
    r.register_verifier(RegisteredVerifier(
        "sim", "measurement_protocol", "model", 0.4, "model-author",
        lambda claim, inputs: {"state": "supported", "observed": {"x": 1}},
    ))
    claim = Claim("density is 1", "empirical_quantity", source_ids=("source",))
    try:
        r.verify(VerificationRequest(claim, "empirical-measurement", "sim", {
            "measurand": "density", "procedure": "simulation"}, "user"))
    except ValueError as exc:
        assert "contact type" in str(exc)
    else:
        raise AssertionError("model contact should not satisfy instrument contract")


def test_independent_quality_contact_can_earn_bounded_authority():
    r = registry()
    r.register_verifier(RegisteredVerifier(
        "sensor", "instrument", "instrument", 0.8, "lab-B",
        lambda claim, inputs: {"state": "supported", "observed": {"value": 1.0},
                               "artifacts": ["sha256:receipt"]},
    ))
    claim = Claim("sample density is 1", "empirical_quantity", source_ids=("lab-A",))
    result = r.verify(VerificationRequest(claim, "empirical-measurement", "sensor", {
        "measurand": "sample density", "procedure": "calibrated pycnometer"}, "user"))
    assert result.state == "supported"
    assert result.independent
    assert result.earned_authority == 0.8


def test_normative_contact_never_mints_truth_authority():
    r = registry()
    r.register_verifier(RegisteredVerifier(
        "board", "human_decision", "human", 1.0, "board",
        lambda claim, inputs: {"state": "supported", "observed": {"decision": "approve"}},
    ))
    claim = Claim("we should approve", "normative_claim")
    result = r.verify(VerificationRequest(claim, "normative-judgment", "board", {
        "decision_owner": "board", "values": ["safety"], "jurisdiction": "internal"}, "user"))
    assert result.earned_authority == 0.0


def test_required_verifier_output_is_enforced():
    r = registry()
    r.register_verifier(RegisteredVerifier(
        "checker", "proof_checker", "formal", 1.0, "checker-author",
        lambda claim, inputs: {"state": "supported", "observed": {"valid": True}},
    ))
    claim = Claim("P implies P", "mathematical_proposition")
    result = r.verify(VerificationRequest(claim, "math-proof", "checker", {
        "formal_statement": "P -> P"}, "user"))
    assert result.state == "inconclusive"
    assert result.earned_authority == 0.0
    assert "checker_receipt" in result.reason
