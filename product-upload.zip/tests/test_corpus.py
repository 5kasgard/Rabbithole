from pathlib import Path
from rabbithole.corpus import extract_repomix, iter_repomix_files


def test_repomix_recovers_numbered_files_safely(tmp_path: Path):
    bundle = tmp_path / "x.md"
    bundle.write_text('''# x\n## File: repo/a.py\n````python\n1: print("a")\n2: x=1\n````\n## File: ../escape.txt\n```\n1: no\n```\n''')
    files = extract_repomix(bundle, tmp_path / "out", prefix="repo")
    assert len(files) == 1
    assert (tmp_path / "out/a.py").read_text() == 'print("a")\nx=1\n'
    assert not (tmp_path / "escape.txt").exists()
