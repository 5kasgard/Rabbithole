from pathlib import Path

from rabbithole.discovery import (
    AbstractionNode, DiscoveryArc, EvidenceItem, ExampleCase, FunctionalDistinction,
    MechanismHypothesis, POSIWIDContract, SearchQuery, SystemHypothesis, TestObligation,
)
from rabbithole.instrument import FieldInstrument


def test_arc_provenance_links_sources_to_test_and_cascade_invalidates(tmp_path: Path):
    inst = FieldInstrument(tmp_path / "state")
    arc = DiscoveryArc(POSIWIDContract(
        target="test derivation", local_current=("unknown",), local_goal=("trace",),
        whole_current=("untraced",), whole_goal=("auditable",),
        success_observations=("trace exists",), failure_observations=("trace absent",),
    ))
    qid = arc.add_query(SearchQuery("q", "concrete", "for", "local", 0))
    evidence = EvidenceItem(qid, "source", "file:///source", "local", "source bytes",
                            independence_group="root-source")
    evid = arc.add_evidence(evidence)
    did = arc.add_distinction(FunctionalDistinction(
        "collapsed", ("function",), ("trace",), evidence_ids=(evid,)))
    aid = arc.add_abstraction(AbstractionNode(
        "preserve derivation", 0, retained_function="trace", translation_back="trace target",
        failure_if_mistranslated="source no longer reaches result"))
    xid = arc.add_example(ExampleCase(aid, "case", "success", ("ctx",), ("trace",), (evid,)))
    mid = arc.add_mechanism(MechanismHypothesis(
        "trace", "derivation graph", ("ctx",), ("audit",), evidence_for=(evid,),
        evidence_against=(evid,), positive_cases=(xid,), negative_cases=(xid,),
        work_relocated_to=("lineage recording",), local_posiwid_effect=("trace",),
        whole_posiwid_effect=("audit",), falsifier="source revocation does not reach conclusion"))
    sid = arc.add_system_hypothesis(SystemHypothesis(
        "system", (mid,), ("compose",), ("local",), ("whole",)))
    tid = arc.add_test(TestObligation(
        "system", sid, "does it trace?", "delete source", "yes", "no", "execution",
        "group", .5, .5, .5, {"compute": 1}, public_surface="instrument"))

    inst._sync_arc_provenance(arc)
    source_entity = next(e for e in inst.provenance.entities.values() if e.locator == "file:///source")
    test_entity = next(e for e in inst.provenance.entities.values()
                       if e.locator.endswith(f"/test-obligation/{tid}"))
    assert test_entity.eid in inst.provenance.descendants(source_entity.eid)
    receipt = inst.provenance.invalidate_cascade(source_entity.eid, "withdrawn")
    assert test_entity.eid in receipt["newly_invalidated"]
    assert inst.provenance.verify()["valid"]
