from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

import pytest

from rabbithole.outward_loop import ExternalObjective, FileIntegrityProfile, OutwardLoopEngine


def objective(**changes):
    raw = dict(
        objective_id="test-loop",
        statement="verify file and publish reversible status",
        success_conditions=("digest matches", "status monitored"),
        allowed_actions=("write-status",),
        resource_budget={"wall_seconds": 10.0, "io_bytes": 100000.0},
        actor="tester",
        risk_tier="low",
        reversible_only=True,
        expires_at=time.time() + 300,
    )
    raw.update(changes)
    return ExternalObjective(**raw)


def engine(tmp_path: Path, *, expected: str | None = None):
    source = tmp_path / "source.txt"
    source.write_text("hello")
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    output = tmp_path / "status.json"
    profile = FileIntegrityProfile(source, expected or digest, output)
    loop = OutwardLoopEngine(
        tmp_path / "state",
        objective(),
        acquire=profile.acquire,
        verify=profile.verify,
        act=profile.act,
        monitor=profile.monitor,
        replan=profile.replan,
    )
    return loop, profile, source, output


def test_successful_cycle_acquires_tests_acts_monitors_and_replans(tmp_path):
    loop, _, _, output = engine(tmp_path)
    receipt = loop.step()
    assert receipt.status == "completed"
    assert receipt.verification.state == "supported"
    assert receipt.action.state == "executed"
    assert receipt.action.reversible is True
    assert receipt.monitor.state == "confirmed"
    assert receipt.replan.next_state == "continue"
    assert output.exists()
    assert loop.verify_integrity()["valid"]
    assert loop.to_dict()["external_claims"]["72_hour_live_loop"] == "blocked_not_elapsed"


def test_digest_mismatch_abstains_and_requires_human(tmp_path):
    loop, _, _, output = engine(tmp_path, expected="0" * 64)
    receipt = loop.step()
    assert receipt.status == "abstained"
    assert receipt.verification.state == "falsified"
    assert receipt.action.state == "abstained"
    assert not output.exists()
    assert loop.stopped is True
    assert receipt.replan.next_state == "human_required"


def test_state_is_digest_bound_and_loadable(tmp_path):
    loop, _, source, output = engine(tmp_path)
    loop.step()
    profile = FileIntegrityProfile(source, hashlib.sha256(source.read_bytes()).hexdigest(), output)
    loaded = OutwardLoopEngine.load(
        tmp_path / "state",
        acquire=profile.acquire,
        verify=profile.verify,
        act=profile.act,
        monitor=profile.monitor,
        replan=profile.replan,
    )
    assert len(loaded.cycles) == 1
    assert loaded.verify_integrity()["valid"]
    loaded.step()
    assert len(loaded.cycles) == 2


def test_state_tampering_is_detected(tmp_path):
    loop, _, _, _ = engine(tmp_path)
    loop.step()
    state = tmp_path / "state/outward_loop_state.json"
    state.write_text(state.read_text().replace('"cycles":', '"tampered":true,"cycles":', 1))
    assert not loop.verify_integrity()["valid"]


def test_resource_budget_causes_explicit_abstention(tmp_path):
    source = tmp_path / "source.txt"
    source.write_text("hello")
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    output = tmp_path / "status.json"
    profile = FileIntegrityProfile(source, digest, output)
    loop = OutwardLoopEngine(
        tmp_path / "state",
        objective(resource_budget={"io_bytes": 1.0}),
        acquire=profile.acquire,
        verify=profile.verify,
        act=profile.act,
        monitor=profile.monitor,
        replan=profile.replan,
    )
    receipt = loop.step()
    assert receipt.status == "abstained"
    assert receipt.action.state == "abstained"
    assert receipt.replan.next_state == "stop"


def test_high_risk_irreversible_objective_rejected():
    with pytest.raises(ValueError, match="irreversible high-risk"):
        objective(risk_tier="high", reversible_only=False).validate()
