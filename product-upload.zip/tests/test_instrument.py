from pathlib import Path

from rabbithole.discovery import POSIWIDContract
from rabbithole.instrument import FieldInstrument
from rabbithole.process import SearchEnvelope
from rabbithole.search import LocalCorpusProvider


def contract():
    return POSIWIDContract(
        "placement", ("first-match alias routing",),
        ("reversible identity under evidence",),
        ("controlled fixtures compose",),
        ("unseen representations compose without false merge",),
    )


def test_public_discovery_stops_honestly_without_faculty(tmp_path: Path):
    corpus = tmp_path / "corpus"
    corpus.mkdir()
    docs = {
        "for.md": "placement mechanisms empirical evaluation success",
        "against.md": "alternatives critique counterexample placement",
        "failure.md": "placement failures limitations negative results",
        "boundary.md": "placement impossibility lower bounds boundary conditions",
        "current.md": "first match alias routing fixtures compose",
        "goal.md": "reversible identity evidence unseen representations false merge",
    }
    for name, text in docs.items():
        (corpus / name).write_text(text)
    instrument = FieldInstrument(tmp_path / "state")
    result = instrument.discover(
        contract(), SearchEnvelope(("software",), min_independent_groups=3, min_search_waves=1),
        {"local": LocalCorpusProvider([corpus])}, concrete_provider="local")
    assert result.audit_valid
    status = result.result["status"]
    assert status["gates"][0]["passed"]
    assert not status["ready"]
    assert any("no functional distinctions" in r for r in status["gates"][1]["reasons"])
    assert instrument.organs.coverage("discover")["invoked"] >= 3  # goal/search/audit


def test_search_is_load_bearing_for_public_discovery(tmp_path: Path):
    corpus = tmp_path / "corpus"
    corpus.mkdir()
    (corpus / "x.md").write_text("placement failures alternatives success boundary")
    instrument = FieldInstrument(tmp_path / "state")
    provider = LocalCorpusProvider([corpus])
    def invoke():
        return instrument.discover(contract(), SearchEnvelope(("software",), min_independent_groups=1),
                                   {"local": provider}, concrete_provider="local").result["arc_id"]
    mutation = instrument.organs.mutation_test("search", "discover", invoke)
    assert mutation.load_bearing
