from __future__ import annotations

import json
import tempfile
from pathlib import Path

from rabbithole.discovery import (
    AbstractionNode, DiscoveryArc, EvidenceItem, MechanismHypothesis,
    POSIWIDContract, SearchQuery, TestObligation,
)
from rabbithole.search import (
    ContentStore, CrossrefProvider, LocalCorpusProvider, OpenAlexProvider,
    search_into_arc,
)


def contract() -> POSIWIDContract:
    return POSIWIDContract(
        target="coverage control",
        local_current=("examples are selected from memory",),
        local_goal=("positive and negative search paths are auditable",),
        whole_current=("the architecture can converge inside a biased sample",),
        whole_goal=("the surviving mechanism remains after broad independent search",),
        success_observations=("query lineage and source snapshots survive restart",),
        failure_observations=("duplicate sources count as independent corroboration",),
    )


def test_arc_persistence_and_dedup(tmp_path: Path) -> None:
    arc = DiscoveryArc(contract(), "coverage")
    q1 = arc.add_query(SearchQuery("foo", "concrete", "for", "test", 0))
    q2 = arc.add_query(SearchQuery("foo failure", "concrete", "against", "test", 1,
                                   parent_query_id=q1))
    e1 = EvidenceItem(q1, "A", "urn:a", "test", "same bytes", polarity="for")
    e2 = EvidenceItem(q2, "A copy", "urn:b", "test", "same bytes", polarity="against")
    id1 = arc.add_evidence(e1)
    id2 = arc.add_evidence(e2)
    assert id1 != id2
    assert arc.evidence[id2].duplicate_of == id1
    assert len({e.independence_group for e in arc.evidence.values()}) == 2
    assert len(arc.evidence) == 2
    path = tmp_path / "arc.json"
    arc.save(str(path))
    restored = DiscoveryArc.load(str(path))
    assert restored.arc_id == arc.arc_id
    assert restored.audit.verify()["valid"]
    assert len(restored.queries) == 2
    assert len(restored.evidence) == 2


def test_test_ranking_prefers_discrimination_per_cost() -> None:
    arc = DiscoveryArc(contract())
    a = arc.add_abstraction(AbstractionNode(
        "independently produced representations interoperate", 1,
        retained_function="remove pairwise reconciliation while preserving distinctions",
    ))
    cheap = TestObligation("abstraction", a, "cheap decisive?", "mutation",
                           "A", "B", "execution", "independent-a",
                           0.8, 0.8, 0.9, {"compute": 1.0})
    expensive = TestObligation("abstraction", a, "expensive weak?", "survey",
                               "A", "B", "human", "independent-b",
                               0.2, 0.5, 0.6, {"attention": 20.0})
    arc.add_test(expensive)
    arc.add_test(cheap)
    assert arc.ranked_tests()[0].tid == cheap.tid


def test_local_corpus_is_real_search_and_store_verifies(tmp_path: Path) -> None:
    corpus = tmp_path / "corpus"
    corpus.mkdir()
    (corpus / "positive.md").write_text("Thin protocols enable local conformance and interoperability.")
    (corpus / "negative.md").write_text("Pairwise adapters cause quadratic reconciliation costs.")
    arc = DiscoveryArc(contract())
    provider = LocalCorpusProvider([corpus])
    store = ContentStore(tmp_path / "store")
    out = search_into_arc(arc, provider, text="local conformance interoperability",
                          stage="abstract", polarity="analogue", wave=1, store=store)
    assert out["results"] == 1
    assert len(arc.evidence) == 1
    assert store.verify()["valid"]
    evidence = next(iter(arc.evidence.values()))
    assert evidence.snapshot.startswith("Thin protocols")


def _fake_crossref(url, headers, timeout):
    return json.dumps({"message": {"items": [{
        "DOI": "10.1/example", "title": ["Mechanism"],
        "author": [{"given": "A", "family": "B"}],
        "issued": {"date-parts": [[2025, 1, 2]]}, "type": "journal-article",
        "URL": "https://doi.org/10.1/example", "score": 42.0,
    }]}}).encode()


def _fake_openalex(url, headers, timeout):
    return json.dumps({"results": [{
        "id": "https://openalex.org/W1", "doi": "https://doi.org/10.1/example",
        "display_name": "Mechanism", "publication_date": "2025-01-02",
        "type": "article", "authorships": [{"author": {"display_name": "A B"}}],
        "abstract_inverted_index": {"works": [0], "here": [1]},
        "primary_location": {"source": {"display_name": "Journal"}},
        "relevance_score": 9.0,
    }]}).encode()


def test_external_adapters_parse_real_api_shapes_without_claiming_contact() -> None:
    c = CrossrefProvider(http_get=_fake_crossref).search("mechanism", limit=1)[0]
    o = OpenAlexProvider(http_get=_fake_openalex).search("mechanism", limit=1)[0]
    assert c.independence_group == o.independence_group == "doi:10.1/example"
    assert c.title == o.title == "Mechanism"
    assert "query" not in json.loads(c.snapshot)
    assert "retrieved_at" not in json.loads(o.snapshot)
