from __future__ import annotations

import json

import pytest

from rabbithole.interchange import (
    FIPError,
    canonical,
    contract_to_fip,
    graph_validate,
    make_envelope,
    parse_json,
    seal,
    validate_shape,
)
from rabbithole.waist import ContractStore


def envelope(identity: str = "e1", **kw):
    return make_envelope(
        profile=kw.pop("profile", "evidence"),
        identity=identity,
        payload=kw.pop("payload", {"value": 1.0, "text": "café"}),
        dependencies=kw.pop("dependencies", ()),
        authority_ceiling=kw.pop("authority_ceiling", 0),
        issuer=kw.pop("issuer", "test"),
        scopes=kw.pop("scopes", ("test",)),
        **kw,
    )


def test_integral_float_and_integer_have_same_canonical_form():
    assert canonical({"x": 1.0}) == canonical({"x": 1})


def test_nonintegral_number_requires_decimal_string():
    with pytest.raises(FIPError, match="nonintegral_number"):
        canonical({"x": 1.25})
    assert canonical({"x": "1.25"}) == '{"x":"1.25"}'


def test_duplicate_keys_rejected():
    with pytest.raises(FIPError, match="duplicate_key"):
        parse_json('{"x":1,"x":2}')


def test_seal_and_verify_never_grant_semantic_authority():
    obj = envelope()
    result = validate_shape(obj)
    assert result["transport_valid"] is True
    assert result["semantic_authority"] is False
    assert result["profile_status"] == "contacted_local"


def test_unknown_critical_extension_fails_closed():
    obj = envelope()
    obj["critical_extensions"] = ["x-unknown"]
    with pytest.raises(FIPError, match="unsupported_critical_extension"):
        seal(obj)


def test_unknown_noncritical_extension_roundtrips():
    obj = envelope()
    obj.pop("digest")
    obj["extensions"]["x-vendor-private"] = {"opaque": True}
    obj = seal(obj)
    assert validate_shape(obj)["transport_valid"]
    assert obj["extensions"]["x-vendor-private"] == {"opaque": True}


def test_digest_substitution_rejected():
    obj = envelope()
    obj["digest"] = "0" * 64
    with pytest.raises(FIPError, match="digest_mismatch"):
        validate_shape(obj)


def test_dependency_cycle_rejected():
    a = envelope("a", dependencies=("b",))
    b = envelope("b", dependencies=("a",))
    with pytest.raises(FIPError, match="dependency_cycle"):
        graph_validate([a, b])


def test_revocation_reactivation_rejected():
    active = envelope("x")
    revoked = envelope("x", revocation_status="revoked", revocation_sequence=1)
    reactivated = envelope("x", revocation_status="active", revocation_sequence=2)
    with pytest.raises(FIPError, match="revocation_reactivation"):
        graph_validate([active, revoked, reactivated])


def test_revoked_dependency_rejected():
    revoked = envelope("source", revocation_status="revoked", revocation_sequence=1)
    derived = envelope("derived", dependencies=("source",))
    with pytest.raises(FIPError, match="revoked_dependency"):
        graph_validate([revoked, derived])


def test_contract_adapter_preserves_contract_payload_without_authority_laundering():
    store = ContractStore()
    contract = store.append(
        "claim",
        {"value": 1.25},
        scope={"domain": "test"},
        status="supported",
        authority_ceiling=0.5,
    )
    obj = contract_to_fip(contract)
    assert obj["profile"]["name"] == "contract"
    assert obj["payload"]["payload"]["value"] == "1.25"
    assert validate_shape(obj)["semantic_authority"] is False


def test_json_mapping_order_does_not_change_digest():
    obj = envelope()
    material = {k: v for k, v in obj.items() if k != "digest"}
    reversed_obj = dict(reversed(list(material.items())))
    assert seal(material)["digest"] == seal(reversed_obj)["digest"]
