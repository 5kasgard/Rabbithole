import time
from rabbithole.provenance import ProvActivity, ProvAgent, ProvEntity, ProvenanceGraph


def test_derived_summaries_are_not_independent_and_invalidation_has_impact():
    g=ProvenanceGraph()
    a=g.add_agent(ProvAgent("lab","organization"))
    root=g.add_entity(ProvEntity("paper", attributed_to=(a,)))
    act=g.add_activity(ProvActivity("summarise",(root,),(a,),time.time(),time.time()))
    s1=g.add_entity(ProvEntity("summary-1",generated_by=act,derived_from=(root,)))
    s2=g.add_entity(ProvEntity("summary-2",generated_by=act,derived_from=(root,)))
    other=g.add_entity(ProvEntity("independent paper"))
    assert not g.independent(s1,s2)
    assert g.independent(s1,other)
    g.invalidate(root,"retracted")
    assert g.invalidation_impact(root)["count"] == 2
    assert g.verify()["valid"]
