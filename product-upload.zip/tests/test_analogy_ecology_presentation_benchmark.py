from pathlib import Path

from rabbithole.analogy import AnalogyGate, AnalogyHypothesis
from rabbithole.benchmark import ARC5MethodBenchmark
from rabbithole.ecology import EcologyMember, OrganEcology
from rabbithole.organs import OrganRegistry, OrganSpec
from rabbithole.presentation import PresentationInput, Presenter
from rabbithole.search import LocalCorpusProvider


def test_local_corpus_excludes(tmp_path):
    (tmp_path / "keep.md").write_text("constraint forager")
    (tmp_path / "skip_arc.md").write_text("constraint forager")
    p = LocalCorpusProvider([tmp_path], exclude_patterns=("skip_arc",))
    assert len(p._docs) == 1
    assert p.search("forager")[0].title == "keep.md"


def test_analogy_is_zero_authority_and_requires_negative_cases():
    h = AnalogyHypothesis("market", "truth", "aggregation", "price", ("trade",),
                          "price equals truth", ("participants aggregate",), (),
                          ("liquid market",), (), (), (), (), "")
    a = AnalogyGate.assess(h)
    assert not a.admissible
    assert a.authority == 0.0


def test_ecology_detects_monoculture_and_dormancy():
    r = OrganRegistry()
    for n in ("a", "b"):
        r.register(OrganSpec(n, "search", ("retrieves",), public_capabilities=("discover",)))
    e = OrganEcology()
    e.register(EcologyMember("a", ("discover",), ("same-model",)))
    e.register(EcologyMember("b", ("discover",), ("same-model",)))
    report = e.assess(r, "discover")
    assert "same-model" in report.single_points_of_failure
    assert not report.healthy


def test_presentation_never_changes_authority():
    i = PresentationInput("x", "answer", "supported", authority_ceiling=.4,
                          unknowns=("scope",))
    assert Presenter.render(i, "brief").authority_ceiling == .4
    assert Presenter.render(i, "audit").authority_ceiling == .4


def test_lineage_recovery_and_analogy_controls():
    root = Path("/mnt/data/lineage_extracted")
    if not root.exists():
        return
    report = ARC5MethodBenchmark(root).run()
    assert report.recovery_rate >= .875
    assert report.invalid_analogies_rejected == report.invalid_analogies_total
    assert report.valid_analogy_admitted


def test_unresolved_presentation_cannot_launder_authority():
    from rabbithole.presentation import PresentationInput, Presenter
    try:
        Presenter.render(PresentationInput(
            title="unknown", answer="maybe", status="insufficient-contact",
            authority_ceiling=0.4,
        ))
    except ValueError as exc:
        assert "cannot carry truth authority" in str(exc)
    else:
        raise AssertionError("insufficient contact must not carry authority")
