from rabbithole.organs import OrganRegistry, OrganSpec


def test_dependency_removal_is_load_bearing_when_root_refuses():
    organs = OrganRegistry()
    organs.register(OrganSpec(
        name="provenance", function="retain derivation", observed_effects=("receipt",),
        public_capabilities=("report",),
    ))
    organs.register(OrganSpec(
        name="presentation", function="render report", observed_effects=("report",),
        dependencies=("provenance",), public_capabilities=("report",),
    ))

    def invoke():
        with organs.operation("r", "presentation", "report", "render"):
            return {"ok": True}

    result = organs.mutation_test("provenance", "report", invoke)
    assert result.load_bearing
    assert result.expected_failure_observed
