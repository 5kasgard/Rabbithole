# Historical Lineage Vault

This directory is the content-addressed evidence vault for the current master candidate. It contains canonical releases where bytes are available, a clearly labelled reconstructed v0.16 source archive, the complete retained performance ARC, the complete lineage-and-vision audit, and the Rx0/AI precursor textual snapshots.

Historical artifacts are evidence, not live runtime dependencies. Nothing here may be silently rewritten, promoted, or counted as independent evidence merely because duplicate copies exist elsewhere. `MASTER_LINEAGE_INDEX.json` is the authoritative path/hash/evidence-class index.
