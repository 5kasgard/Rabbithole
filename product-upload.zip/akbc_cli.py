"""Small operational CLI for the v0.6 structured AKBC waist.

The CLI deliberately cannot mark an observation grounded. Reality contact needs
registered executable code/capabilities, not a JSON boolean supplied by the same
source whose claim is being checked.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import asdict
from pathlib import Path

from rabbithole import Carving, FieldSystem, metrology_seed


def _load_state(path: str) -> FieldSystem:
    p = Path(path)
    return FieldSystem.load(str(p)) if p.exists() else FieldSystem(p.stem, kinds=metrology_seed())


def cmd_ingest(args: argparse.Namespace) -> int:
    system = _load_state(args.state)
    payload = json.loads(Path(args.input).read_text())
    records = payload.get("carvings", payload) if isinstance(payload, dict) else payload
    if not isinstance(records, list):
        raise ValueError("input must be a JSON list or {'carvings': [...]} object")
    decisions = []
    for raw in records:
        if not isinstance(raw, dict):
            raise ValueError("every carving must be an object")
        # JSON arrays become the tuple-valued structural signatures expected by
        # the API. Scope remains a mapping.
        data = dict(raw)
        for key in ("operational_tags", "relations"):
            if key in data:
                data[key] = tuple(data[key])
        decision = system.ingest(Carving(**data))
        decisions.append(asdict(decision))
    system.save(args.state)
    result = {
        "state": os.path.abspath(args.state),
        "decisions": decisions,
        "posiwid": system.posiwid(),
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    system = FieldSystem.load(args.state)
    out = {
        "posiwid": system.posiwid(),
        "receipts": system.verify_receipts(),
        "audit": system.audit.verify(),
        "canonical_groups": {
            root: [m.mid for m in members]
            for root, members in system._canonical_groups().items()
        },
    }
    print(json.dumps(out, indent=2, sort_keys=True))
    return 0 if out["receipts"]["valid"] and out["audit"]["valid"] else 1


def cmd_verify(args: argparse.Namespace) -> int:
    system = FieldSystem.load(args.state)
    out = {"audit": system.audit.verify(), "receipts": system.verify_receipts()}
    out["valid"] = out["audit"].get("valid", False) and out["receipts"]["valid"]
    print(json.dumps(out, indent=2, sort_keys=True))
    return 0 if out["valid"] else 1


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="The Field structured AKBC intake")
    sub = p.add_subparsers(dest="command", required=True)
    i = sub.add_parser("ingest", help="ingest a JSON batch of untested carvings")
    i.add_argument("input")
    i.add_argument("state")
    i.set_defaults(func=cmd_ingest)
    s = sub.add_parser("status", help="show observed system effects and unresolved tests")
    s.add_argument("state")
    s.set_defaults(func=cmd_status)
    v = sub.add_parser("verify", help="verify audit chain and captured source receipts")
    v.add_argument("state")
    v.set_defaults(func=cmd_verify)
    return p


def main() -> None:
    try:
        code = parser().parse_args()
        raise SystemExit(code.func(code))
    except (ValueError, KeyError, TypeError) as exc:
        print(f"error: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(2)


if __name__ == "__main__":
    main()
