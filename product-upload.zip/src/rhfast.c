/* rhfast.c — RabbitHole native settle engine.
 *
 * Semantics are an exact port of the pure-Python reference in
 * rabbithole/field.py, which remains the specification and oracle:
 *   empty interval        := lo > hi
 *   0 · ∞                 := 0            (mulT convention)
 *   division spanning 0   := full line    (sound: never removes a value)
 *   even-power backward   := hull of both root branches ∩ prior domain
 *   narrowing test        := same absolute/relative epsilons
 *   scheduling            := FIFO worklist, enqueue-if-not-queued,
 *                            full domain reset per run
 *
 * Factor types: 0 = bound, 2 = product, 3 = power, 4 = linear.
 * Plain sums are compiled by the Python packer as linears with unit
 * coefficients, so conservation and weighted balances share one path.
 *
 * Build:  gcc -O3 -fPIC -shared -o librhfast.so rhfast.c -lm
 */

#include <math.h>
#include <stdlib.h>
#include <string.h>

typedef struct { double lo, hi; } IV;

#define IS_EMPTY(a) ((a).lo > (a).hi)

static inline IV mk(double lo, double hi) { IV r; r.lo = lo; r.hi = hi; return r; }
static const IV FULLV  = { -INFINITY, INFINITY };
static const IV EMPTYV = { 1.0, -1.0 };

static inline double mulT(double x, double y) {
    if (x == 0.0 || y == 0.0) return 0.0;      /* 0·∞ = 0 */
    return x * y;
}

static inline IV iAdd(IV a, IV b) {
    if (IS_EMPTY(a) || IS_EMPTY(b)) return EMPTYV;
    return mk(a.lo + b.lo, a.hi + b.hi);
}
static inline IV iSub(IV a, IV b) {
    if (IS_EMPTY(a) || IS_EMPTY(b)) return EMPTYV;
    return mk(a.lo - b.hi, a.hi - b.lo);
}
static inline IV iMul(IV a, IV b) {
    if (IS_EMPTY(a) || IS_EMPTY(b)) return EMPTYV;
    double c1 = mulT(a.lo, b.lo), c2 = mulT(a.lo, b.hi);
    double c3 = mulT(a.hi, b.lo), c4 = mulT(a.hi, b.hi);
    double lo = c1, hi = c1;
    if (c2 < lo) lo = c2; if (c2 > hi) hi = c2;
    if (c3 < lo) lo = c3; if (c3 > hi) hi = c3;
    if (c4 < lo) lo = c4; if (c4 > hi) hi = c4;
    return mk(lo, hi);
}
static inline IV iDiv(IV a, IV b) {
    if (IS_EMPTY(a) || IS_EMPTY(b)) return EMPTYV;
    if (b.lo <= 0.0 && 0.0 <= b.hi) return FULLV;   /* sound over-approximation */
    return iMul(a, mk(1.0 / b.hi, 1.0 / b.lo));
}
static inline IV iSect(IV a, IV b) {
    if (IS_EMPTY(a) || IS_EMPTY(b)) return EMPTYV;
    double lo = a.lo > b.lo ? a.lo : b.lo;
    double hi = a.hi < b.hi ? a.hi : b.hi;
    return lo <= hi ? mk(lo, hi) : EMPTYV;
}
static inline IV iHull(IV a, IV b) {
    if (IS_EMPTY(a)) return b;
    if (IS_EMPTY(b)) return a;
    return mk(a.lo < b.lo ? a.lo : b.lo, a.hi > b.hi ? a.hi : b.hi);
}
static inline IV iScale(double c, IV x) {           /* scalar multiple */
    if (IS_EMPTY(x)) return x;
    if (c == 0.0) return mk(0.0, 0.0);
    double a = c * x.lo, b = c * x.hi;
    return c > 0.0 ? mk(a, b) : mk(b, a);
}
static inline IV iPow(IV a, int n) {
    if (IS_EMPTY(a) || n == 1) return a;
    if (n & 1) return mk(pow(a.lo, (double)n), pow(a.hi, (double)n));
    if (a.lo >= 0.0) return mk(pow(a.lo, (double)n), pow(a.hi, (double)n));
    if (a.hi <= 0.0) return mk(pow(a.hi, (double)n), pow(a.lo, (double)n));
    double p1 = pow(a.lo, (double)n), p2 = pow(a.hi, (double)n);
    return mk(0.0, p1 > p2 ? p1 : p2);
}
static inline double sroot(double x, int n) {       /* signed n-th root */
    if (x == INFINITY)  return INFINITY;
    if (x == -INFINITY) return (n & 1) ? -INFINITY : 0.0; /* unreachable for even */
    double r = pow(fabs(x), 1.0 / (double)n);
    return x < 0.0 ? -r : r;
}
/* backward through a^n = c: hull of root branches of c, intersected with a */
static inline IV iRootBack(IV c, int n, IV a) {
    if (IS_EMPTY(c)) return EMPTYV;
    if (n & 1) {
        IV br = mk(sroot(c.lo, n), sroot(c.hi, n));
        return iSect(br, a);
    }
    if (c.hi < 0.0) return EMPTYV;
    double lo = c.lo > 0.0 ? c.lo : 0.0;
    double rl = sroot(lo, n), rh = sroot(c.hi, n);
    IV pos = iSect(mk(rl, rh), a);
    IV neg = iSect(mk(-rh, -rl), a);
    return iHull(pos, neg);
}

/* identical narrowing significance test */
static inline int narrowed(IV o, IV nu) {
    int oe = IS_EMPTY(o), ne = IS_EMPTY(nu);
    if (ne) return !oe;
    double tl = 1e-12 + 1e-9 * (isfinite(o.lo) ? fabs(o.lo) : 1.0);
    double th = 1e-12 + 1e-9 * (isfinite(o.hi) ? fabs(o.hi) : 1.0);
    if (nu.lo > o.lo + tl) return 1;
    if (nu.hi < o.hi - th) return 1;
    if (!isfinite(o.lo) && isfinite(nu.lo)) return 1;
    if (!isfinite(o.hi) && isfinite(nu.hi)) return 1;
    return 0;
}

/* ------------------------------------------------------------------ */

int rh_run(int nv, int nf,
           const int *ftype, const int *fptr, const int *vidx,
           const int *pptr, const double *pdata,
           const int *aptr, const int *adata,
           const unsigned char *excl,
           long max_pops,
           double *lo, double *hi,
           long *out_pops, long *out_contr, int *out_emptied)
{
    IV *dom = (IV *)malloc((size_t)nv * sizeof(IV));
    int *q  = (int *)malloc((size_t)(nf > 0 ? nf : 1) * sizeof(int));
    unsigned char *inq = (unsigned char *)calloc((size_t)(nf > 0 ? nf : 1), 1);
    if (!dom || !q || !inq) { free(dom); free(q); free(inq); return -1; }

    for (int v = 0; v < nv; v++) dom[v] = FULLV;

    int head = 0, tail = 0, count = 0;
    for (int f = 0; f < nf; f++)
        if (!excl || !excl[f]) { q[tail] = f; tail = (tail + 1) % nf; count++; inq[f] = 1; }

    /* scratch for linear factors */
    int max_terms = 1;
    for (int f = 0; f < nf; f++) {
        int span = fptr[f + 1] - fptr[f];
        if (ftype[f] == 4 && span - 1 > max_terms) max_terms = span - 1;
    }
    IV *sc = (IV *)malloc((size_t)max_terms * sizeof(IV));
    /* proposal buffers (largest arity: linear = terms + total) */
    int cap = max_terms + 1; if (cap < 3) cap = 3;
    int    *pv  = (int *)malloc((size_t)cap * sizeof(int));
    IV     *pnu = (IV  *)malloc((size_t)cap * sizeof(IV));
    if (!sc || !pv || !pnu) { free(dom); free(q); free(inq); free(sc); free(pv); free(pnu); return -1; }

    long pops = 0, contr = 0;
    int emptied = -1;

    while (count > 0) {
        int f = q[head]; head = (head + 1) % nf; count--; inq[f] = 0;
        pops++;
        if (pops > max_pops) break;

        int s = fptr[f], e = fptr[f + 1];
        int np = 0;

        switch (ftype[f]) {
        case 0: { /* bound: vidx=[v], pdata=[lo,hi] */
            int v = vidx[s];
            IV b = mk(pdata[pptr[f]], pdata[pptr[f] + 1]);
            pv[np] = v; pnu[np] = iSect(dom[v], b); np++;
        } break;
        case 2: { /* product: vidx=[a,b,c] */
            int va = vidx[s], vb = vidx[s + 1], vc = vidx[s + 2];
            IV a = dom[va], b = dom[vb], c = dom[vc];
            pv[np] = vc; pnu[np] = iSect(c, iMul(a, b)); np++;
            pv[np] = va; pnu[np] = iSect(a, iDiv(c, b)); np++;
            pv[np] = vb; pnu[np] = iSect(b, iDiv(c, a)); np++;
        } break;
        case 3: { /* power: vidx=[a,c], pdata=[n] */
            int va = vidx[s], vc = vidx[s + 1];
            int n = (int)pdata[pptr[f]];
            IV a = dom[va], c = dom[vc];
            IV nc = iSect(c, iPow(a, n));
            pv[np] = vc; pnu[np] = nc; np++;
            pv[np] = va; pnu[np] = iRootBack(nc, n, a); np++;
        } break;
        case 4: { /* linear: vidx=[x1..xn,total], pdata=[c1..cn] */
            int nterm = e - s - 1;
            int vt = vidx[e - 1];
            const double *cf = pdata + pptr[f];
            IV sum = mk(0.0, 0.0);
            for (int i = 0; i < nterm; i++) {
                sc[i] = iScale(cf[i], dom[vidx[s + i]]);
                sum = iAdd(sum, sc[i]);
            }
            IV tot = dom[vt];
            pv[np] = vt; pnu[np] = iSect(tot, sum); np++;
            for (int i = 0; i < nterm; i++) {
                double ci = cf[i];
                if (ci == 0.0) continue;
                IV rest = mk(0.0, 0.0);
                for (int j = 0; j < nterm; j++)
                    if (j != i) rest = iAdd(rest, sc[j]);
                IV xi = dom[vidx[s + i]];
                pv[np] = vidx[s + i];
                pnu[np] = iSect(xi, iScale(1.0 / ci, iSub(tot, rest)));
                np++;
            }
        } break;
        default: break;
        }

        for (int k = 0; k < np; k++) {
            int v = pv[k];
            IV old = dom[v], nu = pnu[k];
            if (!narrowed(old, nu)) continue;
            dom[v] = nu;
            contr++;
            if (IS_EMPTY(nu)) { emptied = v; count = 0; break; }
            for (int j = aptr[v]; j < aptr[v + 1]; j++) {
                int nf2 = adata[j];
                if ((excl && excl[nf2]) || inq[nf2]) continue;
                q[tail] = nf2; tail = (tail + 1) % nf; count++; inq[nf2] = 1;
            }
        }
        if (emptied >= 0) break;
    }

    for (int v = 0; v < nv; v++) { lo[v] = dom[v].lo; hi[v] = dom[v].hi; }
    *out_pops = pops; *out_contr = contr; *out_emptied = emptied;

    free(dom); free(q); free(inq); free(sc); free(pv); free(pnu);
    return 0;
}