from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
FIP = ROOT

spec = importlib.util.spec_from_file_location("fip_python", FIP / "fip_python.py")
if spec is None or spec.loader is None:
    raise RuntimeError("cannot load fip_python.py")
fp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fp)

COMMANDS = {
    "python": [sys.executable, str(FIP / "fip_python.py")],
    "node": ["node", str(FIP / "fip_node.js")],
    "go": [str(FIP / "fip_go")],
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def ensure_go_binary() -> None:
    binary = FIP / "fip_go"
    source = FIP / "fip_go.go"
    if not binary.exists() or binary.stat().st_mtime_ns < source.stat().st_mtime_ns:
        subprocess.run(
            ["go", "build", "-o", str(binary), str(source)],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=30,
        )


def obj_for(i: int) -> dict[str, Any]:
    profile = ["evidence", "akbc", "action", "federation"][i % 4]
    payload: dict[str, Any] = {
        "index": i,
        "integral_float": float(i % 17),
        "text": ["plain", "café", "cafe\u0301", "emoji-🚀"][i % 4],
        "flag": bool(i % 2),
        "nested": {"z": i % 5, "a": [i % 3, None, True]},
    }
    if profile == "action":
        payload |= {"reversible": True, "approval_required": True}
    if profile == "federation":
        payload |= {"dialect": f"d-{i % 7}", "preserve_rivals": True}
    if profile == "akbc":
        payload |= {"identity_hypothesis": f"h-{i % 11}", "merge_authority": False}
    if profile == "evidence":
        payload |= {"source": f"source-{i % 13}", "claim_authority": 0}
    return fp.seal(
        {
            "fip": "field/1",
            "profile": {"name": profile, "version": 1},
            "identity": f"obj-{i:05d}",
            "object_type": profile,
            "dependencies": []
            if i < 3
            else sorted({f"obj-{i - 1:05d}", f"obj-{max(0, i - 3):05d}"}),
            "authority": {
                "ceiling": i % 5,
                "issuer": f"issuer-{i % 9}",
                "scopes": sorted({f"scope-{i % 4}", f"scope-{(i + 1) % 4}"}),
            },
            "revocation": {"status": "active", "sequence": 0},
            "payload": payload,
            "extensions": {
                "x-vendor-demo": {"participant": i % 16, "opaque": f"opaque-{i}"}
            },
            "critical_extensions": ["x-field-revocation-v1"] if i % 97 == 0 else [],
        }
    )


def call(implementation: str, raw_text: str, mode: str = "one") -> dict[str, Any]:
    completed = subprocess.run(
        COMMANDS[implementation] + [mode],
        input=raw_text.encode("utf-8"),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=15,
    )
    lines = completed.stdout.decode("utf-8", errors="replace").strip().splitlines()
    if not lines:
        return {
            "ok": False,
            "error": "no_output",
            "returncode": completed.returncode,
            "stderr": completed.stderr.decode("utf-8", errors="replace")[:500],
        }
    try:
        return json.loads(lines[-1])
    except json.JSONDecodeError as exc:
        return {
            "ok": False,
            "error": f"invalid_json_output:{exc}",
            "returncode": completed.returncode,
            "stdout_tail": lines[-1][-500:],
            "stderr": completed.stderr.decode("utf-8", errors="replace")[:500],
        }


def compact(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def reseal(value: dict[str, Any]) -> dict[str, Any]:
    return fp.seal({key: item for key, item in value.items() if key != "digest"})


def build_cases() -> list[dict[str, Any]]:
    base = obj_for(42)
    float_raw = compact(base)
    integer_raw = float_raw.replace('"integral_float":8.0', '"integral_float":8')
    cases: list[dict[str, Any]] = []

    def add(
        name: str,
        input_text: str,
        expect_ok: bool,
        mode: str = "one",
        relation: str | None = None,
    ) -> None:
        cases.append(
            {
                "index": len(cases) + 1,
                "name": name,
                "input": input_text,
                "expect_ok": expect_ok,
                "mode": mode,
                "relation": relation,
            }
        )

    add("numeric_integer_spelling_1", integer_raw, True)
    add(
        "numeric_integer_spelling_1_point_0",
        float_raw,
        True,
        relation="same:numeric_integer_spelling_1",
    )
    add(
        "map_order_reversed",
        compact(dict(reversed(list(base.items())))),
        True,
        relation="same:numeric_integer_spelling_1",
    )

    unicode_composed = obj_for(44)
    unicode_composed["payload"]["text"] = "café"
    unicode_composed = reseal(unicode_composed)
    unicode_decomposed = obj_for(44)
    unicode_decomposed["payload"]["text"] = "cafe\u0301"
    unicode_decomposed = reseal(unicode_decomposed)
    add("unicode_composed", compact(unicode_composed), True)
    add(
        "unicode_decomposed",
        compact(unicode_decomposed),
        True,
        relation="different:unicode_composed",
    )

    add("duplicate_root_key", integer_raw[:-1] + ',"fip":"field/1"}', False)
    add(
        "duplicate_extension_key",
        integer_raw.replace(
            '"extensions":{"x-vendor-demo":',
            '"extensions":{"x-vendor-demo":0,"x-vendor-demo":',
        ),
        False,
    )
    add("nan", integer_raw.replace('"integral_float":8', '"integral_float":NaN'), False)
    add(
        "infinity",
        integer_raw.replace('"integral_float":8', '"integral_float":Infinity'),
        False,
    )
    add(
        "nonintegral_number",
        integer_raw.replace('"integral_float":8', '"integral_float":8.5'),
        False,
    )

    changed = json.loads(integer_raw)
    changed["fip"] = "field/0"
    add("protocol_downgrade", compact(changed), False)
    changed = json.loads(integer_raw)
    changed["object_type"] = "evidence"
    add("profile_collision", compact(changed), False)
    changed = json.loads(integer_raw)
    changed["critical_extensions"] = ["x-unknown-critical"]
    add("unknown_critical_extension", compact(changed), False)
    changed = json.loads(integer_raw)
    changed["digest"] = "0" * 64
    add("digest_substitution", compact(changed), False)
    changed = json.loads(integer_raw)
    changed["extensions"]["x-new-opaque"] = {"unread": True}
    changed = reseal(changed)
    add("unknown_noncritical_roundtrip", compact(changed), True)
    changed = json.loads(integer_raw)
    changed["dependencies"] = [f"d{i:03d}" for i in range(257)]
    add("oversized_dependency_list", compact(changed), False)
    add("oversized_input", '{"x":"' + "a" * 1_000_001 + '"}', False)

    left = obj_for(100)
    right = obj_for(101)
    left["dependencies"] = ["obj-00101"]
    right["dependencies"] = ["obj-00100"]
    add("dependency_cycle", compact([reseal(left), reseal(right)]), False, "batch")

    revoked = obj_for(200)
    revoked["identity"] = "race"
    revoked["revocation"] = {"status": "revoked", "sequence": 2}
    revoked = reseal(revoked)
    stale = obj_for(201)
    stale["identity"] = "race"
    stale["revocation"] = {"status": "active", "sequence": 1}
    add("stale_revocation", compact([revoked, reseal(stale)]), False, "batch")

    reactivated = obj_for(202)
    reactivated["identity"] = "race"
    reactivated["revocation"] = {"status": "active", "sequence": 3}
    add("revocation_reactivation", compact([revoked, reseal(reactivated)]), False, "batch")

    revoked_dependency = obj_for(300)
    revoked_dependency["identity"] = "revoked-dep"
    revoked_dependency["revocation"] = {"status": "revoked", "sequence": 1}
    revoked_dependency = reseal(revoked_dependency)
    derived = obj_for(301)
    derived["identity"] = "active-derived"
    derived["dependencies"] = ["revoked-dep"]
    add(
        "revoked_dependency",
        compact([revoked_dependency, reseal(derived)]),
        False,
        "batch",
    )

    graph_one = obj_for(400)
    graph_one["identity"] = "g1"
    graph_one["dependencies"] = []
    graph_one = reseal(graph_one)
    graph_two = obj_for(401)
    graph_two["identity"] = "g2"
    graph_two["dependencies"] = ["g1"]
    add("valid_acyclic_graph", compact([graph_one, reseal(graph_two)]), True, "batch")
    return cases


def run_group(start: int, end: int, output: Path) -> dict[str, Any]:
    ensure_go_binary()
    cases = build_cases()
    selected = [case for case in cases if start <= case["index"] <= end]
    if not selected:
        raise ValueError(f"empty case range {start}:{end}")
    results = []
    for case in selected:
        print(f"{case['index']} {case['name']}", flush=True)
        implementation_results: dict[str, Any] = {}
        for implementation in COMMANDS:
            started = time.perf_counter()
            try:
                result = call(implementation, case["input"], case["mode"])
            except Exception as exc:  # receipt must preserve the failure
                result = {"ok": False, "error": f"{type(exc).__name__}:{exc}"}
            result["elapsed_s"] = time.perf_counter() - started
            implementation_results[implementation] = result
        passed = all(
            bool(result.get("ok")) == case["expect_ok"]
            for result in implementation_results.values()
        )
        if case["expect_ok"] and case["mode"] == "one":
            equivalence = {
                (
                    result.get("canonical_sha256"),
                    result.get("digest"),
                    result.get("semantic_authority", False),
                )
                for result in implementation_results.values()
            }
            passed = passed and len(equivalence) == 1
        elif case["expect_ok"] and case["mode"] == "batch":
            counts = {result.get("objects") for result in implementation_results.values()}
            valid = all(bool(result.get("valid")) for result in implementation_results.values())
            no_semantic_authority = not any(
                result.get("semantic_authority") is True
                for result in implementation_results.values()
            )
            passed = passed and len(counts) == 1 and valid and no_semantic_authority
        results.append(
            {
                "index": case["index"],
                "name": case["name"],
                "expect_ok": case["expect_ok"],
                "mode": case["mode"],
                "relation": case["relation"],
                "passed": passed,
                "results": implementation_results,
            }
        )
    receipt = {
        "receipt_type": "fip_attack_group_v1",
        "generated_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "range": {"start": start, "end": end},
        "implementation_sources": {
            "python": sha256_file(FIP / "fip_python.py"),
            "node": sha256_file(FIP / "fip_node.js"),
            "go": sha256_file(FIP / "fip_go.go"),
        },
        "cases": results,
        "all_case_expectations_met": all(item["passed"] for item in results),
    }
    output.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + "\n")
    return receipt


def merge_groups(inputs: list[Path], output: Path) -> dict[str, Any]:
    groups = [json.loads(path.read_text()) for path in inputs]
    cases_by_index: dict[int, dict[str, Any]] = {}
    sources = None
    for group in groups:
        if group.get("receipt_type") != "fip_attack_group_v1":
            raise ValueError("unexpected group receipt type")
        if sources is None:
            sources = group["implementation_sources"]
        elif sources != group["implementation_sources"]:
            raise ValueError("implementation source hashes changed between groups")
        for case in group["cases"]:
            index = int(case["index"])
            if index in cases_by_index:
                raise ValueError(f"duplicate case {index}")
            cases_by_index[index] = case
    cases = [cases_by_index[index] for index in sorted(cases_by_index)]
    expected_count = len(build_cases())
    if [item["index"] for item in cases] != list(range(1, expected_count + 1)):
        raise ValueError("groups do not cover every attack exactly once")

    by_name = {case["name"]: case["results"] for case in cases}
    relations: dict[str, bool] = {}
    for case in cases:
        relation = case.get("relation")
        if not relation:
            continue
        operation, other = relation.split(":", 1)
        outcomes = []
        for implementation in COMMANDS:
            left = case["results"][implementation].get("canonical_sha256")
            right = by_name[other][implementation].get("canonical_sha256")
            outcomes.append(left == right if operation == "same" else left != right)
        relations[f"{case['name']}_{operation}_{other}"] = all(outcomes)

    receipt = {
        "receipt_type": "fip_attack_receipt_v1",
        "generated_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "implementation_sources": sources,
        "case_count": len(cases),
        "cases": cases,
        "relations": relations,
        "semantic_authority": False,
        "independence_claim": "none; implementations are project-authored contact implementations",
        "all_expectations_met": all(item["passed"] for item in cases)
        and all(relations.values()),
    }
    output.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + "\n")
    return receipt


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=int)
    parser.add_argument("--end", type=int)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--merge", nargs="*", type=Path)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.merge:
        output = args.output or (ROOT / "FIP_ATTACK_RECEIPT_CURRENT.json")
        receipt = merge_groups(args.merge, output)
        print(
            json.dumps(
                {
                    "all": receipt["all_expectations_met"],
                    "cases": receipt["case_count"],
                    "failed": [case["name"] for case in receipt["cases"] if not case["passed"]],
                    "relations": receipt["relations"],
                    "output": str(output),
                },
                indent=2,
            )
        )
        return 0 if receipt["all_expectations_met"] else 1
    if args.start is None or args.end is None:
        args.start, args.end = 1, len(build_cases())
    output = args.output or ROOT / f"FIP_ATTACK_GROUP_{args.start:02d}_{args.end:02d}.json"
    receipt = run_group(args.start, args.end, output)
    print(
        json.dumps(
            {
                "all": receipt["all_case_expectations_met"],
                "range": receipt["range"],
                "failed": [case["name"] for case in receipt["cases"] if not case["passed"]],
                "output": str(output),
            },
            indent=2,
        )
    )
    return 0 if receipt["all_case_expectations_met"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
