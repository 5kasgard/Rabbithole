from __future__ import annotations
import hashlib, importlib.util, json, subprocess, sys, time
from pathlib import Path
ROOT=Path('/mnt/data/lineage-vision-audit/stage5-contact');FIP=ROOT/'fip'
spec=importlib.util.spec_from_file_location('fip_python',FIP/'fip_python.py');fp=importlib.util.module_from_spec(spec);spec.loader.exec_module(fp)
commands={'python':[sys.executable,str(FIP/'fip_python.py')],'node':['node',str(FIP/'fip_node.js')],'go':[str(FIP/'fip_go')]}
def obj_for(i:int):
 p=['evidence','akbc','action','federation'][i%4]
 payload={'index':i,'integral_float':float(i%17),'text':['plain','caf\u00e9','cafe\u0301','emoji-\U0001f680'][i%4],'flag':bool(i%2),'nested':{'z':i%5,'a':[i%3,None,True]}}
 if p=='action':payload|={'reversible':True,'approval_required':True}
 if p=='federation':payload|={'dialect':f'd-{i%7}','preserve_rivals':True}
 if p=='akbc':payload|={'identity_hypothesis':f'h-{i%11}','merge_authority':False}
 if p=='evidence':payload|={'source':f'source-{i%13}','claim_authority':0}
 return fp.seal({'fip':'field/1','profile':{'name':p,'version':1},'identity':f'obj-{i:05d}','object_type':p,'dependencies':[] if i<3 else sorted({f'obj-{i-1:05d}',f'obj-{max(0,i-3):05d}'}),'authority':{'ceiling':i%5,'issuer':f'issuer-{i%9}','scopes':sorted({f'scope-{i%4}',f'scope-{(i+1)%4}'})},'revocation':{'status':'active','sequence':0},'payload':payload,'extensions':{'x-vendor-demo':{'participant':i%16,'opaque':f'opaque-{i}'}},'critical_extensions':['x-field-revocation-v1'] if i%97==0 else []})
def call(name,raw,mode='one'):
 cp=subprocess.run(commands[name]+[mode],input=raw.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=12)
 ls=cp.stdout.decode().strip().splitlines();return json.loads(ls[-1]) if ls else {'ok':False,'error':'no_output','stderr':cp.stderr.decode()[:500]}
def raw(o):return json.dumps(o,ensure_ascii=False,separators=(',',':'))
def reseal(o):return fp.seal({k:v for k,v in o.items() if k!='digest'})
base=obj_for(42); rfloat=raw(base); rint=rfloat.replace('"integral_float":8.0','"integral_float":8')
cases=[]
def C(name,s,expect,mode='one',rel=None):cases.append((name,s,expect,mode,rel))
C('numeric_integer_spelling_1',rint,True)
C('numeric_integer_spelling_1_point_0',rfloat,True,rel='same:numeric_integer_spelling_1')
C('map_order_reversed',raw(dict(reversed(list(base.items())))),True,rel='same:numeric_integer_spelling_1')
u1=obj_for(44);u1['payload']['text']='caf\u00e9';u1=reseal(u1);u2=obj_for(44);u2['payload']['text']='cafe\u0301';u2=reseal(u2)
C('unicode_composed',raw(u1),True);C('unicode_decomposed',raw(u2),True,rel='different:unicode_composed')
C('duplicate_root_key',rint[:-1]+',"fip":"field/1"}',False)
C('duplicate_extension_key',rint.replace('"extensions":{"x-vendor-demo":','"extensions":{"x-vendor-demo":0,"x-vendor-demo":'),False)
C('nan',rint.replace('"integral_float":8','"integral_float":NaN'),False)
C('infinity',rint.replace('"integral_float":8','"integral_float":Infinity'),False)
C('nonintegral_number',rint.replace('"integral_float":8','"integral_float":8.5'),False)
d=json.loads(rint);d['fip']='field/0';C('protocol_downgrade',raw(d),False)
d=json.loads(rint);d['object_type']='evidence';C('profile_collision',raw(d),False)
d=json.loads(rint);d['critical_extensions']=['x-unknown-critical'];C('unknown_critical_extension',raw(d),False)
d=json.loads(rint);d['digest']='0'*64;C('digest_substitution',raw(d),False)
d=json.loads(rint);d['extensions']['x-new-opaque']={'unread':True};d=reseal(d);C('unknown_noncritical_roundtrip',raw(d),True)
d=json.loads(rint);d['dependencies']=[f'd{i:03d}' for i in range(257)];C('oversized_dependency_list',raw(d),False)
C('oversized_input','{"x":"'+'a'*1000001+'"}',False)
a=obj_for(100);b=obj_for(101);a['dependencies']=['obj-00101'];b['dependencies']=['obj-00100'];C('dependency_cycle',json.dumps([reseal(a),reseal(b)],separators=(',',':')),False,'batch')
old=obj_for(200);old['identity']='race';old['revocation']={'status':'revoked','sequence':2};old=reseal(old)
stale=obj_for(201);stale['identity']='race';stale['revocation']={'status':'active','sequence':1};C('stale_revocation',json.dumps([old,reseal(stale)],separators=(',',':')),False,'batch')
react=obj_for(202);react['identity']='race';react['revocation']={'status':'active','sequence':3};C('revocation_reactivation',json.dumps([old,reseal(react)],separators=(',',':')),False,'batch')
rev=obj_for(300);rev['identity']='revoked-dep';rev['revocation']={'status':'revoked','sequence':1};rev=reseal(rev);drv=obj_for(301);drv['identity']='active-derived';drv['dependencies']=['revoked-dep'];C('revoked_dependency',json.dumps([rev,reseal(drv)],separators=(',',':')),False,'batch')
g1=obj_for(400);g1['identity']='g1';g1['dependencies']=[];g1=reseal(g1);g2=obj_for(401);g2['identity']='g2';g2['dependencies']=['g1'];C('valid_acyclic_graph',json.dumps([g1,reseal(g2)],separators=(',',':')),True,'batch')
results=[];by={}
for idx,(name,s,expect,mode,rel) in enumerate(cases,1):
 print(idx,name,flush=True); rr={}
 for impl in commands:
  t=time.perf_counter()
  try:r=call(impl,s,mode)
  except Exception as e:r={'ok':False,'error':type(e).__name__+':'+str(e)}
  r['elapsed_s']=time.perf_counter()-t;rr[impl]=r
 ok=all(bool(x.get('ok'))==expect for x in rr.values())
 if expect:
  vals={(x.get('canonical_sha256'),x.get('digest'),x.get('semantic_authority')) for x in rr.values()};ok=ok and len(vals)==1
 results.append({'name':name,'expect_ok':expect,'mode':mode,'relation':rel,'passed':ok,'results':rr});by[name]=rr
relations={}
for name,s,expect,mode,rel in cases:
 if not rel:continue
 op,other=rel.split(':',1)
 vals=[]
 for impl in commands:
  a=by[name][impl].get('canonical_sha256');b=by[other][impl].get('canonical_sha256');vals.append(a==b if op=='same' else a!=b)
 relations[f'{name}_{op}_{other}']=all(vals)
receipt={'generated_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'cases':results,'relations':relations,'all_expectations_met':all(x['passed'] for x in results) and all(relations.values())}
(ROOT/'FIP_ATTACK_RECEIPT.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'all':receipt['all_expectations_met'],'failed':[x['name'] for x in results if not x['passed']],'relations':relations},indent=2))
