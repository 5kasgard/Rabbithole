#!/usr/bin/env python3
from __future__ import annotations
import gzip, hashlib, json, os, subprocess, sys, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
FIP=Path(__file__).resolve().parent

def sha(path:Path)->str:
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def run(cmd,input_path,output_path,timeout=180):
 with input_path.open('rb') as inp, output_path.open('wb') as out:
  p=subprocess.run(cmd,stdin=inp,stdout=out,stderr=subprocess.PIPE,timeout=timeout,cwd=ROOT,env={**os.environ,'PYTHONPATH':str(ROOT)})
 if p.returncode: raise RuntimeError(f'{cmd}: {p.stderr.decode()[-1000:]}')

def parsed_equal(a:Path,b:Path):
 count=0
 with a.open() as fa,b.open() as fb:
  for la,lb in zip(fa,fb):
   count+=1
   if json.loads(la)!=json.loads(lb): return False,count
  if fa.readline() or fb.readline(): return False,count
 return True,count

def main():
 started=time.time()
 with tempfile.TemporaryDirectory(prefix='fip-current-') as td:
  td=Path(td); corpus=td/'corpus.ndjson'; expected=td/'expected.ndjson'
  with gzip.open(FIP/'FIP_VALID_CORPUS.ndjson.gz','rb') as src, corpus.open('wb') as dst: dst.write(src.read())
  with gzip.open(FIP/'FIP_PYTHON_EXPECTED.ndjson.gz','rb') as src, expected.open('wb') as dst: dst.write(src.read())
  go=td/'fip_go'; subprocess.run(['go','build','-o',str(go),str(FIP/'fip_go.go')],check=True,cwd=ROOT)
  impls={'python':[sys.executable,str(FIP/'fip_python.py'),'lines'],'node':['node',str(FIP/'fip_node.js'),'lines'],'go':[str(go),'lines']}
  outputs={}
  for name,cmd in impls.items():
   out=td/f'{name}.ndjson';run(cmd,corpus,out);ok,count=parsed_equal(expected,out);outputs[name]={'matches_expected':ok,'objects':count,'sha256':sha(out)}
  passed=all(x['matches_expected'] and x['objects']==10000 for x in outputs.values())
  receipt={
   'receipt_type':'fip_conformance_receipt_v1',
   'generated_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
   'passed':passed,
   'objects':10000,
   'implementations':outputs,
   'implementation_sources':{
    'python':sha(FIP/'fip_python.py'),
    'node':sha(FIP/'fip_node.js'),
    'go':sha(FIP/'fip_go.go'),
   },
   'runner_sha256':sha(Path(__file__)),
   'corpus_sha256':sha(corpus),
   'expected_sha256':sha(expected),
   'semantic_authority':False,
   'independence_claim':'none; same-project implementations',
  }
  (FIP/'FIP_CONFORMANCE_CURRENT.json').write_text(json.dumps(receipt,indent=2)+'\n')
  print(json.dumps(receipt,indent=2));return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
