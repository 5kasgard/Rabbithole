# Experimental FIP package

This package preserves the locally contacted Node and Go reference sources, the 10,000-object corpus, expected Python results and attack receipts from the lineage audit. The authoritative Python candidate now lives in `rabbithole/interchange.py`.

These implementations were produced inside one campaign and are not independent clean-room implementations. Passing them demonstrates cross-language feasibility, not protocol adoption or semantic authority.
