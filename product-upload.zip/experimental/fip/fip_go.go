package main

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"sort"
	"strconv"
	"strings"
)

const MaxBytes = 1000000
const MaxDepth = 32
const MaxKeys = 256
const MaxArray = 1024
const MaxDeps = 256
const Safe = 9007199254740991

var known = map[string]bool{"x-field-revocation-v1": true}
var profiles = map[string]bool{"evidence": true, "akbc": true, "action": true, "federation": true}

type FErr struct{ S string }

func (e FErr) Error() string { return e.S }
func parse(raw []byte) (any, error) {
	if len(raw) > MaxBytes {
		return nil, FErr{"oversized"}
	}
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber()
	v, e := parseValue(d)
	if e != nil {
		return nil, e
	}
	if t, e := d.Token(); e != io.EOF || t != nil {
		return nil, FErr{"trailing"}
	}
	return v, nil
}
func parseValue(d *json.Decoder) (any, error) {
	t, e := d.Token()
	if e != nil {
		return nil, e
	}
	if q, ok := t.(json.Delim); ok {
		switch q {
		case '{':
			m := map[string]any{}
			for d.More() {
				kt, e := d.Token()
				if e != nil {
					return nil, e
				}
				k, ok := kt.(string)
				if !ok {
					return nil, FErr{"key"}
				}
				if _, x := m[k]; x {
					return nil, FErr{"duplicate_key"}
				}
				v, e := parseValue(d)
				if e != nil {
					return nil, e
				}
				m[k] = v
			}
			end, e := d.Token()
			if e != nil || end != json.Delim('}') {
				return nil, FErr{"object"}
			}
			return m, nil
		case '[':
			a := []any{}
			for d.More() {
				v, e := parseValue(d)
				if e != nil {
					return nil, e
				}
				a = append(a, v)
			}
			end, e := d.Token()
			if e != nil || end != json.Delim(']') {
				return nil, FErr{"array"}
			}
			return a, nil
		}
	}
	if n, ok := t.(json.Number); ok {
		f, e := strconv.ParseFloat(n.String(), 64)
		if e != nil || f != float64(int64(f)) || f > Safe || f < -Safe {
			return nil, FErr{"nonintegral_number_requires_decimal_string"}
		}
		return int64(f), nil
	}
	return t, nil
}
func esc(s string) string {
	var b strings.Builder
	b.WriteByte('"')
	for _, r := range s {
		switch r {
		case '"':
			b.WriteString("\\\"")
		case '\\':
			b.WriteString("\\\\")
		case '\b':
			b.WriteString("\\b")
		case '\f':
			b.WriteString("\\f")
		case '\n':
			b.WriteString("\\n")
		case '\r':
			b.WriteString("\\r")
		case '\t':
			b.WriteString("\\t")
		default:
			if r >= 0x20 && r <= 0x7e {
				b.WriteRune(r)
			} else if r <= 0xffff {
				fmt.Fprintf(&b, "\\u%04x", r)
			} else {
				x := r - 0x10000
				fmt.Fprintf(&b, "\\u%04x\\u%04x", 0xd800+(x>>10), 0xdc00+(x&0x3ff))
			}
		}
	}
	b.WriteByte('"')
	return b.String()
}
func canon(v any, d int) (string, error) {
	if d > MaxDepth {
		return "", FErr{"depth"}
	}
	switch x := v.(type) {
	case nil:
		return "null", nil
	case bool:
		if x {
			return "true", nil
		}
		return "false", nil
	case int64:
		return strconv.FormatInt(x, 10), nil
	case string:
		return esc(x), nil
	case []any:
		if len(x) > MaxArray {
			return "", FErr{"array_too_large"}
		}
		a := make([]string, len(x))
		for i, z := range x {
			s, e := canon(z, d+1)
			if e != nil {
				return "", e
			}
			a[i] = s
		}
		return "[" + strings.Join(a, ",") + "]", nil
	case map[string]any:
		if len(x) > MaxKeys {
			return "", FErr{"object_too_large"}
		}
		ks := make([]string, 0, len(x))
		for k := range x {
			ks = append(ks, k)
		}
		sort.Slice(ks, func(i, j int) bool { return bytes.Compare([]byte(ks[i]), []byte(ks[j])) < 0 })
		a := make([]string, len(ks))
		for i, k := range ks {
			s, e := canon(x[k], d+1)
			if e != nil {
				return "", e
			}
			a[i] = esc(k) + ":" + s
		}
		return "{" + strings.Join(a, ",") + "}", nil
	default:
		return "", FErr{"unsupported_type"}
	}
}
func material(o map[string]any) map[string]any {
	d := map[string]any{}
	for k, v := range o {
		if k != "digest" {
			d[k] = v
		}
	}
	return d
}
func arrStr(v any) ([]string, bool) {
	a, ok := v.([]any)
	if !ok {
		return nil, false
	}
	r := make([]string, len(a))
	for i, x := range a {
		s, ok := x.(string)
		if !ok {
			return nil, false
		}
		r[i] = s
	}
	return r, true
}
func sortedUnique(a []string) bool {
	for i := 1; i < len(a); i++ {
		if bytes.Compare([]byte(a[i-1]), []byte(a[i])) >= 0 {
			return false
		}
	}
	return true
}
func validate(v any, vd bool) (string, error) {
	o, ok := v.(map[string]any)
	if !ok {
		return "", FErr{"missing_fields"}
	}
	req := []string{"fip", "profile", "identity", "object_type", "dependencies", "authority", "revocation", "payload", "extensions", "critical_extensions"}
	for _, k := range req {
		if _, ok := o[k]; !ok {
			return "", FErr{"missing_fields"}
		}
	}
	if o["fip"] != "field/1" {
		return "", FErr{"unsupported_protocol"}
	}
	p, ok := o["profile"].(map[string]any)
	if !ok {
		return "", FErr{"unsupported_profile"}
	}
	pn, _ := p["name"].(string)
	pv, _ := p["version"].(int64)
	if !profiles[pn] || pv != 1 {
		return "", FErr{"unsupported_profile"}
	}
	if o["object_type"] != pn {
		return "", FErr{"profile_type_mismatch"}
	}
	id, ok := o["identity"].(string)
	if !ok || id == "" {
		return "", FErr{"identity"}
	}
	deps, ok := arrStr(o["dependencies"])
	if !ok || len(deps) > MaxDeps || !sortedUnique(deps) {
		return "", FErr{"dependencies"}
	}
	a, ok := o["authority"].(map[string]any)
	if !ok {
		return "", FErr{"authority"}
	}
	ceil, ok := a["ceiling"].(int64)
	issuer, iok := a["issuer"].(string)
	sc, ok2 := arrStr(a["scopes"])
	if !ok || !iok || issuer == "" || ceil < 0 || ceil > 4 || !ok2 || !sortedUnique(sc) {
		return "", FErr{"authority"}
	}
	r, ok := o["revocation"].(map[string]any)
	if !ok {
		return "", FErr{"revocation"}
	}
	st, _ := r["status"].(string)
	seq, sok := r["sequence"].(int64)
	if !sok || seq < 0 || (st != "active" && st != "revoked") {
		return "", FErr{"revocation"}
	}
	ex, ok := o["extensions"].(map[string]any)
	if !ok {
		return "", FErr{"extensions"}
	}
	for k := range ex {
		if !strings.HasPrefix(k, "x-") {
			return "", FErr{"extensions"}
		}
	}
	crit, ok := arrStr(o["critical_extensions"])
	if !ok || !sortedUnique(crit) {
		return "", FErr{"critical_extensions"}
	}
	for _, x := range crit {
		if !known[x] {
			return "", FErr{"unsupported_critical_extension"}
		}
	}
	c, e := canon(material(o), 0)
	if e != nil {
		return "", e
	}
	sum := sha256.Sum256([]byte(c))
	dig := hex.EncodeToString(sum[:])
	if vd {
		got, ok := o["digest"].(string)
		if !ok || got != dig {
			return "", FErr{"digest_mismatch"}
		}
	}
	return dig, nil
}
func graphValidate(a []any) error {
	latest := map[string]map[string]any{}
	for _, v := range a {
		if _, e := validate(v, true); e != nil {
			return e
		}
		o := v.(map[string]any)
		id := o["identity"].(string)
		seq := o["revocation"].(map[string]any)["sequence"].(int64)
		if old, ok := latest[id]; ok {
			os := old["revocation"].(map[string]any)["sequence"].(int64)
			if seq <= os {
				return FErr{"stale_revocation"}
			}
			ost := old["revocation"].(map[string]any)["status"].(string)
			if ost == "revoked" && o["revocation"].(map[string]any)["status"].(string) == "active" {
				return FErr{"revocation_reactivation"}
			}
		}
		latest[id] = o
	}
	g := map[string][]string{}
	for id, o := range latest {
		deps, _ := arrStr(o["dependencies"])
		for _, d := range deps {
			if _, ok := latest[d]; ok {
				g[id] = append(g[id], d)
			}
		}
	}
	for id, o := range latest {
		if o["revocation"].(map[string]any)["status"].(string) == "active" {
			for _, d := range g[id] {
				if latest[d]["revocation"].(map[string]any)["status"].(string) == "revoked" {
					return FErr{"revoked_dependency"}
				}
			}
		}
	}
	vis := map[string]bool{}
	done := map[string]bool{}
	var dfs func(string) error
	dfs = func(n string) error {
		if vis[n] {
			return FErr{"dependency_cycle"}
		}
		if done[n] {
			return nil
		}
		vis[n] = true
		for _, m := range g[n] {
			if e := dfs(m); e != nil {
				return e
			}
		}
		delete(vis, n)
		done[n] = true
		return nil
	}
	for n := range latest {
		if e := dfs(n); e != nil {
			return e
		}
	}
	return nil
}
func emit(v any) { b, _ := json.Marshal(v); fmt.Println(string(b)) }
func process(raw []byte, mode string) {
	v, e := parse(raw)
	if e != nil {
		emit(map[string]any{"ok": false, "error": e.Error()})
		return
	}
	if mode == "batch" {
		a, ok := v.([]any)
		if !ok {
			emit(map[string]any{"ok": false, "error": "batch_not_array"})
			return
		}
		if e := graphValidate(a); e != nil {
			emit(map[string]any{"ok": false, "error": e.Error()})
			return
		}
		emit(map[string]any{"ok": true, "valid": true, "objects": len(a)})
		return
	}
	dig, e := validate(v, true)
	if e != nil {
		emit(map[string]any{"ok": false, "error": e.Error()})
		return
	}
	c, _ := canon(v, 0)
	sum := sha256.Sum256([]byte(c))
	m := map[string]any{"ok": true, "canonical_sha256": hex.EncodeToString(sum[:]), "digest": dig, "semantic_authority": false}
	if mode == "one" {
		m["canonical"] = c
	}
	emit(m)
}
func main() {
	mode := "lines"
	if len(os.Args) > 1 {
		mode = os.Args[1]
	}
	if mode == "lines" {
		s := bufio.NewScanner(os.Stdin)
		buf := make([]byte, 1024)
		s.Buffer(buf, MaxBytes+100)
		for s.Scan() {
			process(s.Bytes(), mode)
		}
		return
	}
	raw, e := io.ReadAll(io.LimitReader(os.Stdin, MaxBytes+1))
	if e != nil {
		panic(e)
	}
	process(raw, mode)
}

var _ = errors.New
