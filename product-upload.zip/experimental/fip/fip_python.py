#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from rabbithole.interchange import canonical, graph_validate, parse_json, seal, validate_shape


def main() -> int:
    mode = sys.argv[1] if len(sys.argv) > 1 else "lines"
    if mode == "lines":
        for line in sys.stdin:
            try:
                obj = parse_json(line)
                result = validate_shape(obj)
                encoded = canonical(obj).encode()
                print(json.dumps({
                    "ok": True,
                    "canonical_sha256": hashlib.sha256(encoded).hexdigest(),
                    "digest": result["digest"],
                    "semantic_authority": False,
                }, separators=(",", ":")))
            except Exception as exc:
                print(json.dumps({"ok": False, "error": str(exc)}, separators=(",", ":")))
        return 0
    raw = sys.stdin.read()
    try:
        obj = parse_json(raw)
        if mode == "batch":
            if not isinstance(obj, list):
                raise ValueError("batch_not_array")
            print(json.dumps({"ok": True, **graph_validate(obj)}, separators=(",", ":")))
        elif mode == "one":
            result = validate_shape(obj)
            encoded = canonical(obj).encode()
            print(json.dumps({
                "ok": True,
                "canonical": encoded.decode(),
                "canonical_sha256": hashlib.sha256(encoded).hexdigest(),
                "digest": result["digest"],
                "semantic_authority": False,
            }, separators=(",", ":")))
        else:
            return 2
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    import os
    code=main(); sys.stdout.flush(); sys.stderr.flush(); os._exit(code)
