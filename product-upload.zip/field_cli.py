"""Public CLI for The Field master candidate v0.18.0rc3.

No command marks an organ complete.  Commands execute the normal public surface
and print the resulting POSIWID, integrity checks and unresolved gates.
"""
from __future__ import annotations

import argparse
import json
import os
import shlex
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Mapping

from rabbithole.akbc import Carving
from rabbithole.discovery import DiscoveryArc, POSIWIDContract
from rabbithole.faculties import OllamaFaculty, OpenAICompatibleFaculty, SubprocessFaculty
from rabbithole.instrument import FieldInstrument
from rabbithole.inquiry import InquiryRequest
from rabbithole.executors import HTTPJSONMeasurement
from rabbithole.acquisition import FetchPolicy
from rabbithole.goal import GoalRequest
from rabbithole.task import TaskAction, TaskRequest, TaskVerification
from rabbithole.verification import Claim
from rabbithole.tether import GroundingTest
from rabbithole.process import SearchEnvelope
from rabbithole.arc_kernel import EligibilityContract
from rabbithole.arc_adversarial import HostileInterpretation
from rabbithole.benchmark import ARC5MethodBenchmark
from rabbithole.presentation import PresentationInput
from rabbithole.ir import IRRequirement
from rabbithole.scope import ModelContract, ScopeCondition
from rabbithole.search import CompositeProvider, CrossrefProvider, LocalCorpusProvider, OpenAlexProvider
from rabbithole.substrate_campaign import SubstrateCampaign
from rabbithole.longitudinal_validation import (
    ArmCommitment, ArmPrediction, ChallengeCommitment, ChallengeOutcome,
    EvaluatorAttestation, ExternalReviewAttestation, LongitudinalValidationStudy,
    MaintenanceEvent, ValidationProtocol,
)


def _json(value: str):
    """Read JSON from a file path or an inline JSON object/array.

    Inline JSON keeps small public contact records usable without creating a
    temporary file; larger specifications remain content-addressable files.
    """
    stripped = value.lstrip()
    if stripped.startswith(("{", "[")):
        return json.loads(value)
    return json.loads(Path(value).read_text())


def _contract(raw: Mapping[str, object]) -> POSIWIDContract:
    data = dict(raw)
    for key in ("local_current", "local_goal", "whole_current", "whole_goal",
                "constraints", "anti_goals", "success_observations", "failure_observations"):
        data[key] = tuple(data.get(key, ()))
    return POSIWIDContract(**data)


def _envelope(raw: Mapping[str, object]) -> SearchEnvelope:
    data = dict(raw)
    for key in ("domain_families", "concrete_polarities", "abstract_polarities", "required_followup_categories"):
        if key in data:
            data[key] = tuple(data[key])
    return SearchEnvelope(**data)


def _eligibility(raw: Mapping[str, object]) -> EligibilityContract:
    data = dict(raw)
    for key in ("inclusion_rules", "exclusion_rules", "source_classes", "languages"):
        data[key] = tuple(data.get(key, ()))
    return EligibilityContract(**data)


def _hostile(raw: Mapping[str, object]) -> HostileInterpretation:
    data = dict(raw)
    for key in ("target_may_be_unreal", "alternative_goals", "impossibility_or_unnecessity",
                "whole_system_harms", "simpler_problem_substitutes", "disconfirming_observations"):
        data[key] = tuple(data.get(key, ()))
    return HostileInterpretation(**data)


def _providers(args) -> dict:
    providers = {}
    if args.corpus:
        providers["local"] = LocalCorpusProvider(args.corpus)
    providers["crossref"] = CrossrefProvider(mailto=args.mailto or "")
    providers["openalex"] = OpenAlexProvider(mailto=args.mailto or "")
    selected = [providers[x] for x in args.composite.split(",") if x in providers]
    if selected:
        providers["all"] = CompositeProvider(selected)
    return providers


def _faculty(args):
    if args.faculty == "none":
        return None
    if args.faculty == "openai":
        if not args.model:
            raise ValueError("--model is required for OpenAI-compatible faculty")
        return OpenAICompatibleFaculty(args.model, base_url=args.base_url or "https://api.openai.com/v1")
    if args.faculty == "ollama":
        if not args.model:
            raise ValueError("--model is required for Ollama faculty")
        return OllamaFaculty(args.model, base_url=args.base_url or "http://127.0.0.1:11434")
    if args.faculty == "subprocess":
        if not args.command:
            raise ValueError("--command is required for subprocess faculty")
        return SubprocessFaculty(shlex.split(args.command), model=args.model or "subprocess")
    raise ValueError(f"unknown faculty {args.faculty!r}")


def _text_argument(value: str) -> str:
    path = Path(value)
    return path.read_text() if path.exists() and path.is_file() else value



def cmd_inquire(args) -> int:
    providers = _providers(args)
    if args.provider not in providers:
        raise ValueError(f"provider {args.provider!r} is unavailable; add --corpus for local")
    whole = tuple(_json(args.whole_goal)) if args.whole_goal else ()
    mapping = {"*": args.abstract_provider} if args.abstract_provider else {}
    result = FieldInstrument(args.state).inquire(
        _text_argument(args.input), _envelope(_json(args.envelope)), providers,
        concrete_provider=args.provider, faculty=_faculty(args),
        execute_abstract_with=mapping, whole_goal_context=whole)
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1

def cmd_interpret(args) -> int:
    faculty = _faculty(args)
    if faculty is None:
        raise ValueError("interpret requires a configured proposal faculty")
    whole = tuple(_json(args.whole_goal)) if args.whole_goal else ()
    constraints = tuple(_json(args.constraints)) if args.constraints else ()
    result = FieldInstrument(args.state).interpret(
        _text_argument(args.input), faculty, whole_goal_context=whole,
        known_constraints=constraints)
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1


def cmd_discover_text(args) -> int:
    providers = _providers(args)
    if args.provider not in providers:
        raise ValueError(f"provider {args.provider!r} is unavailable; add --corpus for local")
    faculty = _faculty(args)
    if faculty is None:
        raise ValueError("discover-text requires a configured proposal faculty")
    whole = tuple(_json(args.whole_goal)) if args.whole_goal else ()
    constraints = tuple(_json(args.constraints)) if args.constraints else ()
    envelope = _envelope(_json(args.envelope))
    mapping = {"*": args.abstract_provider} if args.abstract_provider else {}
    result = FieldInstrument(args.state).discover_text(
        _text_argument(args.input), envelope, providers,
        concrete_provider=args.provider, faculty=faculty,
        execute_abstract_with=mapping, whole_goal_context=whole,
        known_constraints=constraints)
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1


def cmd_discover(args) -> int:
    spec = _json(args.spec)
    contract = _contract(spec["contract"])
    envelope = _envelope(spec["search_envelope"])
    providers = _providers(args)
    if args.provider not in providers:
        raise ValueError(f"provider {args.provider!r} is unavailable; add --corpus for local")
    mapping = {"*": args.abstract_provider} if args.abstract_provider else {}
    instrument = FieldInstrument(args.state)
    result = instrument.discover(contract, envelope, providers,
                                 concrete_provider=args.provider,
                                 faculty=_faculty(args),
                                 execute_abstract_with=mapping)
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1



def cmd_arc_start(args) -> int:
    raw = _json(args.spec)
    result = FieldInstrument(args.state).start_arc_kernel(
        _contract(raw["contract"]), _envelope(raw["search_envelope"]),
        _eligibility(raw["eligibility"]), name=str(raw.get("name", "")))
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_arc_step(args) -> int:
    result = FieldInstrument(args.state).apply_arc_operation(args.arc_id, _json(args.operation))
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_arc_search(args) -> int:
    providers = _providers(args)
    mapping = _json(args.provider_map) if args.provider_map else {"*": args.provider}
    result = FieldInstrument(args.state).execute_arc_search(
        args.arc_id, args.track, providers, provider_map=mapping)
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_arc_kernel_status(args) -> int:
    result = FieldInstrument(args.state).arc_kernel_status(args.arc_id)
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_arc_campaign_status(args) -> int:
    result = FieldInstrument(args.state).arc_campaign_status(args.campaign_id)
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_arc5a_start(args) -> int:
    raw = _json(args.spec)
    result = FieldInstrument(args.state).start_arc5a_kernel(
        _contract(raw["contract"]), _envelope(raw["search_envelope"]),
        _eligibility(raw["eligibility"]), _hostile(raw["hostile_interpretation"]),
        name=str(raw.get("name", "")))
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_arc5a_step(args) -> int:
    result = FieldInstrument(args.state).apply_arc5a_operation(args.arc_id, _json(args.operation))
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_arc5a_search(args) -> int:
    providers = _providers(args)
    mapping = _json(args.provider_map) if args.provider_map else {"*": args.provider}
    result = FieldInstrument(args.state).execute_arc5a_search(
        args.arc_id, args.lane, providers, provider_map=mapping)
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_arc5a_status(args) -> int:
    result = FieldInstrument(args.state).arc5a_status(args.arc_id)
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_process_task(args) -> int:
    result = FieldInstrument(args.state).register_process_task(_json(args.task))
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_process_select(args) -> int:
    result = FieldInstrument(args.state).select_process(args.task_id, actor=args.actor)
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_process_status(args) -> int:
    result = FieldInstrument(args.state).process_status()
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def _state_artifact(state: str, family: str, artifact_id: str) -> Path:
    safe = artifact_id.replace("/", "_").replace("\\", "_")
    return Path(state) / family / f"{safe}.json"


def cmd_substrate_import(args) -> int:
    campaign = SubstrateCampaign.load(args.input)
    integrity = campaign.verify()
    if not integrity["valid"]:
        raise ValueError(f"substrate campaign integrity invalid: {integrity['problems']}")
    target = _state_artifact(args.state, "substrate", campaign.campaign_id)
    campaign.save(target)
    out = {"campaign_id": campaign.campaign_id, "stored_at": str(target),
           "status": campaign.status()}
    print(json.dumps(out, indent=2, sort_keys=True, default=str))
    return 0


def cmd_substrate_status(args) -> int:
    campaign = SubstrateCampaign.load(_state_artifact(args.state, "substrate", args.campaign_id))
    out = campaign.status()
    print(json.dumps(out, indent=2, sort_keys=True, default=str))
    return 0 if out["integrity"]["valid"] else 1


def cmd_substrate_verify(args) -> int:
    campaign = SubstrateCampaign.load(_state_artifact(args.state, "substrate", args.campaign_id))
    out = campaign.verify()
    print(json.dumps(out, indent=2, sort_keys=True, default=str))
    return 0 if out["valid"] else 1


def _protocol(raw: Mapping[str, object]) -> ValidationProtocol:
    data = dict(raw)
    data.pop("protocol_digest", None)
    for key in ("arms", "comparator_arms", "primary_endpoints", "secondary_endpoints",
                "domains", "required_external_reviews", "exclusion_rules",
                "stopping_rules", "developer_ids"):
        data[key] = tuple(data.get(key, ()))
    return ValidationProtocol(**data)


def _load_study(state: str, study_id: str) -> tuple[LongitudinalValidationStudy, Path]:
    path = _state_artifact(state, "validation", study_id)
    return LongitudinalValidationStudy.load(path), path


def cmd_validation_init(args) -> int:
    raw = _json(args.protocol)
    protocol_raw = dict(raw.get("protocol", raw))
    study = LongitudinalValidationStudy(_protocol(protocol_raw))
    target = _state_artifact(args.state, "validation", study.protocol.study_id)
    study.save(target)
    out = {"study_id": study.protocol.study_id, "stored_at": str(target),
           "status": study.status()}
    print(json.dumps(out, indent=2, sort_keys=True, default=str))
    return 0


def cmd_validation_arm(args) -> int:
    study, path = _load_study(args.state, args.study_id)
    digest = study.register_arm(ArmCommitment(**dict(_json(args.input)))); study.save(path)
    print(json.dumps({"arm_commitment_digest": digest, "integrity": study.verify()}, indent=2, sort_keys=True))
    return 0


def cmd_validation_review(args) -> int:
    study, path = _load_study(args.state, args.study_id)
    raw = dict(_json(args.input)); raw.pop("review_digest", None)
    rid = study.register_external_review(ExternalReviewAttestation(**raw)); study.save(path)
    print(json.dumps({"review_id": rid, "integrity": study.verify()}, indent=2, sort_keys=True))
    return 0


def cmd_validation_evaluator(args) -> int:
    study, path = _load_study(args.state, args.study_id)
    raw = dict(_json(args.input)); raw.pop("attestation_digest", None)
    raw["competent_for_domains"] = tuple(raw.get("competent_for_domains", ()))
    eid = study.register_evaluator(EvaluatorAttestation(**raw)); study.save(path)
    print(json.dumps({"evaluator_id": eid, "integrity": study.verify()}, indent=2, sort_keys=True))
    return 0


def cmd_validation_challenge(args) -> int:
    study, path = _load_study(args.state, args.study_id)
    cid = study.commit_challenge(ChallengeCommitment(**dict(_json(args.input)))); study.save(path)
    print(json.dumps({"commitment_id": cid, "integrity": study.verify()}, indent=2, sort_keys=True))
    return 0


def cmd_validation_predict(args) -> int:
    study, path = _load_study(args.state, args.study_id)
    pid = study.record_prediction(ArmPrediction(**dict(_json(args.input)))); study.save(path)
    print(json.dumps({"prediction_id": pid, "integrity": study.verify()}, indent=2, sort_keys=True))
    return 0


def cmd_validation_outcome(args) -> int:
    study, path = _load_study(args.state, args.study_id)
    raw = dict(_json(args.input)); raw["external_review_tags"] = tuple(raw.get("external_review_tags", ()))
    oid = study.record_outcome(ChallengeOutcome(**raw)); study.save(path)
    print(json.dumps({"outcome_id": oid, "integrity": study.verify()}, indent=2, sort_keys=True))
    return 0


def cmd_validation_maintenance(args) -> int:
    study, path = _load_study(args.state, args.study_id)
    mid = study.record_maintenance(MaintenanceEvent(**dict(_json(args.input)))); study.save(path)
    print(json.dumps({"event_id": mid, "integrity": study.verify()}, indent=2, sort_keys=True))
    return 0


def cmd_validation_status(args) -> int:
    study, _ = _load_study(args.state, args.study_id)
    out = study.status(now=args.now)
    print(json.dumps(out, indent=2, sort_keys=True, default=str))
    return 0 if out["integrity"]["valid"] else 1


def cmd_validation_analyse(args) -> int:
    study, path = _load_study(args.state, args.study_id)
    result = study.analyse(now=args.now, record=True); study.save(path)
    out = asdict(result)
    print(json.dumps(out, indent=2, sort_keys=True, default=str))
    return 0 if result.status != "stopped" else 1


def cmd_status(args) -> int:
    out = FieldInstrument(args.state).status()
    print(json.dumps(out, indent=2, sort_keys=True))
    return 0 if out["integrity"]["valid"] else 1


def cmd_arc(args) -> int:
    instrument = FieldInstrument(args.state)
    arc = instrument.load_arc(args.arc_id)
    out = {"arc_id": arc.arc_id, "name": arc.name,
           "posiwid": arc.posiwid(), "audit": arc.audit.verify(),
           "saturation": asdict(arc.saturation(
               required_domain_families=tuple(args.required_domain or ()),
               min_independent_groups=args.min_independent_groups)),
           "ranked_tests": [asdict(x) | {"priority": x.priority()} for x in arc.ranked_tests()]}
    print(json.dumps(out, indent=2, sort_keys=True))
    return 0 if out["audit"]["valid"] else 1


def cmd_export(args) -> int:
    arc = FieldInstrument(args.state).load_arc(args.arc_id)
    payload = arc.export_prov_jsonld() if args.format == "prov" else arc.to_dict()
    text = json.dumps(payload, indent=2, sort_keys=True)
    if args.output:
        Path(args.output).write_text(text)
    else:
        print(text)
    return 0



def cmd_import_arc(args) -> int:
    result = FieldInstrument(args.state).import_arc(args.input)
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1


def cmd_contact_record(args) -> int:
    raw = _json(args.input)
    result = FieldInstrument(args.state).record_arc_test(
        args.arc_id, args.test_id, state=str(raw["state"]),
        observed=str(raw["observed"]), result=str(raw.get("result", "")),
        failure_layer=str(raw.get("failure_layer", "")),
        evidence_ids=tuple(raw.get("evidence_ids", ())),
    )
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1


def cmd_invalidate(args) -> int:
    result = FieldInstrument(args.state).invalidate_source(
        locator=args.locator, content_sha256=args.sha256, reason=args.reason)
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1

def cmd_investigate(args) -> int:
    faculty = _faculty(args)
    labels = _json(args.labels) if args.labels else {}
    request = InquiryRequest(
        args.question, tuple(args.source), labels,
        allow_private_network=args.allow_private_network,
        use_faculty_extraction=args.use_faculty_extraction,
    )
    result = FieldInstrument(args.state).investigate(request, faculty)
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1


def cmd_ground_json(args) -> int:
    policy = FetchPolicy(
        allowed_schemes=("file", "http", "https") if args.allow_private_network else ("file", "https"),
        allow_private_network=args.allow_private_network,
        allowed_file_roots=tuple(args.file_root or ()),
    )
    instrument = FieldInstrument(args.state)
    kind = args.kind or f"json-measurement-{args.observation_id}"
    instrument.register_grounding_executor(
        kind, HTTPJSONMeasurement(instrument.acquisition, policy),
        contact=args.contact, quality=args.quality,
    )
    spec = {
        "locator": args.locator,
        "json_path": args.value_path,
        "sigma_path": args.sigma_path,
        "unit_path": args.unit_path,
    }
    result = instrument.ground_observation(
        args.observation_id, GroundingTest(kind, spec, author=args.author),
    )
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1


def cmd_ingest(args) -> int:
    instrument = FieldInstrument(args.state)
    payload = _json(args.input)
    rows = payload.get("carvings", payload) if isinstance(payload, dict) else payload
    if not isinstance(rows, list):
        raise ValueError("input must be a list or {'carvings': [...]} object")
    out = []
    for raw in rows:
        data = dict(raw)
        for key in ("operational_tags", "relations"):
            if key in data:
                data[key] = tuple(data[key])
        out.append(asdict(instrument.ingest(Carving(**data))))
    print(json.dumps({"results": out, "status": instrument.status()}, indent=2, sort_keys=True))
    return 0


def cmd_contracts(args) -> int:
    coverage = FieldInstrument(args.state).verification.coverage()
    print(json.dumps(coverage, indent=2, sort_keys=True))
    return 0


def cmd_method_benchmark(args) -> int:
    report = ARC5MethodBenchmark(args.corpus).save(args.output) if args.output else ARC5MethodBenchmark(args.corpus).run()
    payload = asdict(report)
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if report.passed else 1


def cmd_report(args) -> int:
    raw = _json(args.input)
    for key in ("supported_by", "contested_by", "unknowns", "assumptions", "scope", "next_tests", "provenance"):
        raw[key] = tuple(raw.get(key, ()))
    result = FieldInstrument(args.state).present(PresentationInput(**raw), args.resolution)
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1


def cmd_ecology(args) -> int:
    result = FieldInstrument(args.state).ecology_report(args.capability)
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1


def cmd_represent(args) -> int:
    raw = _json(args.input)
    for key in ("required_structures", "forbidden_losses", "preferred_operations"):
        if key in raw:
            raw[key] = tuple(raw[key])
    result = FieldInstrument(args.state).select_ir(IRRequirement(**raw))
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1


def cmd_model_register(args) -> int:
    raw = _json(args.input)
    raw["conditions"] = tuple(ScopeCondition(**x) for x in raw.get("conditions", ()))
    for key in ("declared_outputs", "invalidators"):
        raw[key] = tuple(raw.get(key, ()))
    inst = FieldInstrument(args.state)
    inst.register_model(ModelContract(**raw))
    print(json.dumps({"registered": raw["model_id"], "status": inst.status()}, indent=2, sort_keys=True))
    return 0


def cmd_scope(args) -> int:
    result = FieldInstrument(args.state).check_model(args.model_id, _json(args.context))
    print(json.dumps(asdict(result), indent=2, sort_keys=True))
    return 0 if result.audit_valid else 1


def cmd_task(args) -> int:
    raw = _json(args.input)
    goal_raw = dict(raw.get("goal", {}))
    for key in ("success_conditions", "constraints", "stakeholders", "requested_actions"):
        goal_raw[key] = tuple(goal_raw.get(key, ()))
    goal = GoalRequest(**goal_raw)
    policy_raw = dict(raw.get("fetch_policy", {}))
    for key in ("allowed_schemes", "allowed_file_roots", "allowed_media_prefixes"):
        if key in policy_raw:
            policy_raw[key] = tuple(policy_raw[key])
    policy = FetchPolicy(**policy_raw) if policy_raw else FetchPolicy()
    jobs = []
    for row in raw.get("verifications", ()):
        data = dict(row)
        claim_raw = dict(data.pop("claim"))
        claim_raw["source_ids"] = tuple(claim_raw.get("source_ids", ()))
        jobs.append(TaskVerification(Claim(**claim_raw),
                                     str(data["contract_id"]), str(data["verifier_id"]),
                                     dict(data.get("inputs", {}))))
    action = None
    if raw.get("action"):
        a = dict(raw["action"])
        action = TaskAction(str(a["action_id"]), dict(a.get("request", {})),
                            str(a["holder"]), dict(a["capability"]),
                            bool(a.get("dry_run", True)), str(a.get("approval", "none")),
                            str(a.get("idempotency_key", "")))
    request = TaskRequest(goal, str(raw.get("question", goal.text)),
                          tuple(raw.get("source_locators", ())), policy,
                          str(raw.get("extraction_mode", "quantity")), tuple(jobs), action,
                          str(raw.get("task_id", "")) or TaskRequest(goal, "x").task_id)
    result = FieldInstrument(args.state).execute_task(request)
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_organism(args) -> int:
    raw = _json(args.input)
    operation = str(raw.get("operation", ""))
    if not operation:
        raise ValueError("organism input requires operation")
    result = FieldInstrument(args.state).stage4c_operation(operation, dict(raw.get("payload", {})))
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0 if result.audit_valid else 1


def cmd_gates(args) -> int:
    out = FieldInstrument(args.state).gate_plan.summary()
    print(json.dumps(out, indent=2, sort_keys=True))
    return 0


def cmd_verify(args) -> int:
    out = FieldInstrument(args.state).verify_integrity()
    print(json.dumps(out, indent=2, sort_keys=True))
    return 0 if out["valid"] else 1


def cmd_performance_plan(args) -> int:
    from rabbithole.performance_fabric import HybridPerformancePortfolio, PerformanceLedger, PerformanceTask
    task = PerformanceTask.from_dict(_json(args.task))
    decision = HybridPerformancePortfolio().select(task)
    if args.ledger:
        PerformanceLedger(args.ledger).register(decision, actor=args.actor)
    print(json.dumps(asdict(decision), indent=2, sort_keys=True))
    return 0


def cmd_performance_run(args) -> int:
    from rabbithole.performance_fabric import PerformanceLedger, PerformanceTask
    from rabbithole.performance_runtime import BoundedPerformanceExecutor
    raw = _json(args.input)
    ledger = PerformanceLedger(args.ledger) if args.ledger else None
    executor = BoundedPerformanceExecutor(max_warm_operations=args.max_warm_operations,
                                          max_warm_age_s=args.max_warm_age)
    if isinstance(raw, list):
        tasks = [PerformanceTask.from_dict(x["task"]) for x in raw]
        requests = [dict(x["request"]) for x in raw]
        out = executor.execute_batch(tasks, requests, ledger=ledger)
    else:
        out = executor.execute(PerformanceTask.from_dict(raw["task"]), dict(raw["request"]), ledger=ledger)
    print(json.dumps(out, indent=2, sort_keys=True, default=str))
    return 0


def cmd_performance_status(args) -> int:
    from rabbithole.performance_fabric import PerformanceLedger, architecture_posiwid_report
    out = {"architecture": architecture_posiwid_report()}
    if args.ledger:
        ledger = PerformanceLedger(args.ledger)
        out.update({"ledger": ledger.verify(), "posiwid": ledger.posiwid()})
    print(json.dumps(out, indent=2, sort_keys=True))
    return 0


def _add_faculty_args(p):
    p.add_argument("--faculty", default="none", choices=("none", "openai", "ollama", "subprocess"))
    p.add_argument("--model", default="")
    p.add_argument("--base-url", default="")
    p.add_argument("--command", default="")


def _add_search_args(p):
    p.add_argument("--corpus", action="append", default=[], help="local corpus root (repeatable)")
    p.add_argument("--provider", default="all", choices=("local", "crossref", "openalex", "all"))
    p.add_argument("--composite", default="local,crossref,openalex",
                   help="comma-separated providers included in 'all'")
    p.add_argument("--abstract-provider", choices=("local", "crossref", "openalex", "all"))
    p.add_argument("--mailto", default="", help="contact address for scholarly APIs")


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="field", description="The Field public capability surface")
    sub = p.add_subparsers(dest="command_name", required=True)


    iq = sub.add_parser("inquire", help="run one raw request as far as configured organs and contacts permit")
    iq.add_argument("input", help="raw text or path to a text file")
    iq.add_argument("envelope", help="JSON SearchEnvelope")
    iq.add_argument("state")
    iq.add_argument("--whole-goal", help="JSON array of whole-system goal effects")
    _add_search_args(iq)
    _add_faculty_args(iq)
    iq.set_defaults(func=cmd_inquire)

    it = sub.add_parser("interpret", help="propose a falsifiable dual-POSIWID contract from raw input")
    it.add_argument("input", help="raw text or path to a text file")
    it.add_argument("state")
    it.add_argument("--whole-goal", help="JSON array of whole-system goal effects")
    it.add_argument("--constraints", help="JSON array of known constraints")
    _add_faculty_args(it)
    it.set_defaults(func=cmd_interpret)

    dt = sub.add_parser("discover-text", help="interpret raw input then execute ARC-5")
    dt.add_argument("input", help="raw text or path to a text file")
    dt.add_argument("envelope", help="JSON SearchEnvelope")
    dt.add_argument("state")
    dt.add_argument("--whole-goal", help="JSON array of whole-system goal effects")
    dt.add_argument("--constraints", help="JSON array of known constraints")
    _add_search_args(dt)
    _add_faculty_args(dt)
    dt.set_defaults(func=cmd_discover_text)


    astart = sub.add_parser("arc-start", help="create a human-gated ARC-5 process kernel without advancing it")
    astart.add_argument("spec", help="JSON with contract, search_envelope and eligibility")
    astart.add_argument("state")
    astart.set_defaults(func=cmd_arc_start)

    astep = sub.add_parser("arc-step", help="apply one explicit operation to an ARC-5 process kernel")
    astep.add_argument("state")
    astep.add_argument("arc_id")
    astep.add_argument("operation", help="JSON operation or path")
    astep.set_defaults(func=cmd_arc_step)

    asearch = sub.add_parser("arc-search", help="execute one frozen concrete or abstract search plan")
    asearch.add_argument("state")
    asearch.add_argument("arc_id")
    asearch.add_argument("track", choices=("concrete", "abstract"))
    asearch.add_argument("--provider-map", help="JSON domain-family to provider mapping")
    _add_search_args(asearch)
    asearch.set_defaults(func=cmd_arc_search)

    akstatus = sub.add_parser("arc-status", help="show the human queue, gates and integrity of one ARC-5 kernel")
    akstatus.add_argument("state")
    akstatus.add_argument("arc_id")
    akstatus.set_defaults(func=cmd_arc_kernel_status)

    acstatus = sub.add_parser("arc-campaign-status", help="show a frozen multi-arc campaign, dispositions, dependencies and human gate")
    acstatus.add_argument("state")
    acstatus.add_argument("campaign_id")
    acstatus.set_defaults(func=cmd_arc_campaign_status)

    a5start = sub.add_parser("arc5a-start", help="create an independently bifurcated adversarial ARC-5A process")
    a5start.add_argument("spec", help="JSON with contract, hostile_interpretation, search_envelope and eligibility")
    a5start.add_argument("state")
    a5start.set_defaults(func=cmd_arc5a_start)

    a5step = sub.add_parser("arc5a-step", help="apply one human-gated ARC-5A operation")
    a5step.add_argument("state")
    a5step.add_argument("arc_id")
    a5step.add_argument("operation", help="JSON operation or path")
    a5step.set_defaults(func=cmd_arc5a_step)

    a5search = sub.add_parser("arc5a-search", help="execute one independently frozen ARC-5A search lane")
    a5search.add_argument("state")
    a5search.add_argument("arc_id")
    a5search.add_argument("lane", choices=("concrete_constructive", "concrete_destructive", "abstract_function", "abstract_counterfactual"))
    a5search.add_argument("--provider-map", help="JSON domain-family to provider mapping")
    _add_search_args(a5search)
    a5search.set_defaults(func=cmd_arc5a_search)

    a5status = sub.add_parser("arc5a-status", help="show ARC-5A lanes, arena, Pareto frontier and integrity")
    a5status.add_argument("state")
    a5status.add_argument("arc_id")
    a5status.set_defaults(func=cmd_arc5a_status)

    ptask = sub.add_parser("process-task", help="register a task for process-against-process selection")
    ptask.add_argument("task", help="JSON task profile or path")
    ptask.add_argument("state")
    ptask.set_defaults(func=cmd_process_task)

    pselect = sub.add_parser("process-select", help="assess the strongest process candidates and preserve the Pareto frontier")
    pselect.add_argument("state")
    pselect.add_argument("task_id")
    pselect.add_argument("--actor", default="human-process-selector")
    pselect.set_defaults(func=cmd_process_select)

    pstatus = sub.add_parser("process-status", help="show process methods, tasks, frontiers and integrity")
    pstatus.add_argument("state")
    pstatus.set_defaults(func=cmd_process_status)

    simp = sub.add_parser("substrate-import", help="import an integrity-valid Stage 4D-C substrate campaign")
    simp.add_argument("input")
    simp.add_argument("state")
    simp.set_defaults(func=cmd_substrate_import)

    sstat = sub.add_parser("substrate-status", help="show layer frontiers, decisions, slices and integrity")
    sstat.add_argument("state")
    sstat.add_argument("campaign_id")
    sstat.set_defaults(func=cmd_substrate_status)

    sver = sub.add_parser("substrate-verify", help="replay and verify a persisted substrate campaign")
    sver.add_argument("state")
    sver.add_argument("campaign_id")
    sver.set_defaults(func=cmd_substrate_verify)

    vini = sub.add_parser("validation-init", help="freeze a Stage 5 longitudinal validation protocol")
    vini.add_argument("protocol")
    vini.add_argument("state")
    vini.set_defaults(func=cmd_validation_init)

    var = sub.add_parser("validation-arm", help="freeze one arm artifact, runtime profile and resource policy")
    var.add_argument("state"); var.add_argument("study_id"); var.add_argument("input")
    var.set_defaults(func=cmd_validation_arm)

    vr = sub.add_parser("validation-review", help="register an independent methods or security review attestation")
    vr.add_argument("state"); vr.add_argument("study_id"); vr.add_argument("input")
    vr.set_defaults(func=cmd_validation_review)

    ve = sub.add_parser("validation-evaluator", help="register an independent evaluator attestation")
    ve.add_argument("state"); ve.add_argument("study_id"); ve.add_argument("input")
    ve.set_defaults(func=cmd_validation_evaluator)

    vc = sub.add_parser("validation-challenge", help="commit a private held-out challenge before release")
    vc.add_argument("state"); vc.add_argument("study_id"); vc.add_argument("input")
    vc.set_defaults(func=cmd_validation_challenge)

    vp = sub.add_parser("validation-predict", help="record one arm prediction before challenge release")
    vp.add_argument("state"); vp.add_argument("study_id"); vp.add_argument("input")
    vp.set_defaults(func=cmd_validation_predict)

    vo = sub.add_parser("validation-outcome", help="record an independently scored challenge outcome")
    vo.add_argument("state"); vo.add_argument("study_id"); vo.add_argument("input")
    vo.set_defaults(func=cmd_validation_outcome)

    vm = sub.add_parser("validation-maintenance", help="record maintenance, recovery or harm evidence")
    vm.add_argument("state"); vm.add_argument("study_id"); vm.add_argument("input")
    vm.set_defaults(func=cmd_validation_maintenance)

    vs = sub.add_parser("validation-status", help="show Stage 5 maturity gates without mutating the ledger")
    vs.add_argument("state"); vs.add_argument("study_id"); vs.add_argument("--now", type=float)
    vs.set_defaults(func=cmd_validation_status)

    va = sub.add_parser("validation-analyse", help="persist one frozen-plan Stage 5 analysis")
    va.add_argument("state"); va.add_argument("study_id"); va.add_argument("--now", type=float)
    va.set_defaults(func=cmd_validation_analyse)

    pfplan = sub.add_parser("performance-plan", help="select a bounded contacted performance mechanism or abstain")
    pfplan.add_argument("task", help="JSON PerformanceTask or path")
    pfplan.add_argument("--ledger")
    pfplan.add_argument("--actor", default="performance-selector")
    pfplan.set_defaults(func=cmd_performance_plan)

    pfrun = sub.add_parser("performance-run", help="execute bounded local performance tasks with fallback")
    pfrun.add_argument("input", help="JSON task/request object or list")
    pfrun.add_argument("--ledger")
    pfrun.add_argument("--max-warm-operations", type=int, default=100)
    pfrun.add_argument("--max-warm-age", type=float, default=300.0)
    pfrun.set_defaults(func=cmd_performance_run)

    pfstatus = sub.add_parser("performance-status", help="show hybrid/heterogeneous architecture and actual POSIWID")
    pfstatus.add_argument("--ledger")
    pfstatus.set_defaults(func=cmd_performance_status)


    d = sub.add_parser("discover", help="execute ARC-5 mechanism discovery")
    d.add_argument("spec", help="JSON containing contract and search_envelope")
    d.add_argument("state", help="persistent instrument state directory")
    _add_search_args(d)
    _add_faculty_args(d)
    d.set_defaults(func=cmd_discover)

    s = sub.add_parser("status", help="show observed capabilities and integrity")
    s.add_argument("state")
    s.set_defaults(func=cmd_status)

    a = sub.add_parser("arc", help="show one discovery arc")
    a.add_argument("state")
    a.add_argument("arc_id")
    a.add_argument("--required-domain", action="append", default=[])
    a.add_argument("--min-independent-groups", type=int, default=3)
    a.set_defaults(func=cmd_arc)

    e = sub.add_parser("export", help="export an arc as native JSON or PROV-shaped JSON-LD")
    e.add_argument("state")
    e.add_argument("arc_id")
    e.add_argument("--format", choices=("native", "prov"), default="native")
    e.add_argument("--output")
    e.set_defaults(func=cmd_export)


    ia = sub.add_parser("arc-import", help="import an audit-valid completed discovery arc")
    ia.add_argument("input")
    ia.add_argument("state")
    ia.set_defaults(func=cmd_import_arc)

    cr = sub.add_parser("contact-record", help="record a real result against an ARC test obligation")
    cr.add_argument("state")
    cr.add_argument("arc_id")
    cr.add_argument("test_id")
    cr.add_argument("input", help="JSON containing state, observed, result and optional evidence_ids")
    cr.set_defaults(func=cmd_contact_record)

    inv = sub.add_parser("invalidate", help="invalidate one captured source version and all derived artifacts")
    inv.add_argument("state")
    inv.add_argument("locator")
    inv.add_argument("sha256")
    inv.add_argument("reason")
    inv.set_defaults(func=cmd_invalidate)

    q = sub.add_parser("investigate", help="acquire real artifacts, carve, place, and stop at the first ungated boundary")
    q.add_argument("question")
    q.add_argument("state")
    q.add_argument("--source", action="append", required=True,
                   help="file/http/https artifact locator; repeatable")
    q.add_argument("--labels", help="JSON mapping locator to source label")
    q.add_argument("--allow-private-network", action="store_true")
    q.add_argument("--use-faculty-extraction", action="store_true")
    _add_faculty_args(q)
    q.set_defaults(func=cmd_investigate)

    gj = sub.add_parser("ground-json", help="ground one existing observation from a replayable JSON measurement")
    gj.add_argument("state")
    gj.add_argument("observation_id")
    gj.add_argument("locator")
    gj.add_argument("--kind", default="")
    gj.add_argument("--author", default="external-json-measurement")
    gj.add_argument("--contact", default="instrument")
    gj.add_argument("--quality", type=float, default=0.9)
    gj.add_argument("--value-path", default="value")
    gj.add_argument("--sigma-path", default="sigma")
    gj.add_argument("--unit-path", default="unit")
    gj.add_argument("--allow-private-network", action="store_true")
    gj.add_argument("--file-root", action="append", default=[])
    gj.set_defaults(func=cmd_ground_json)

    i = sub.add_parser("ingest", help="ingest structured carvings through the public AKBC path")
    i.add_argument("input")
    i.add_argument("state")
    i.set_defaults(func=cmd_ingest)

    c = sub.add_parser("contracts", help="list verification contracts and live executors")
    c.add_argument("state")
    c.set_defaults(func=cmd_contracts)

    mb = sub.add_parser("method-benchmark", help="run the blind lineage and invalid-analogy ARC-5 benchmark")
    mb.add_argument("corpus")
    mb.add_argument("--output")
    mb.set_defaults(func=cmd_method_benchmark)

    rp = sub.add_parser("report", help="render one authority-preserving report at a requested resolution")
    rp.add_argument("input")
    rp.add_argument("state")
    rp.add_argument("--resolution", choices=("brief", "standard", "technical", "audit"), default="standard")
    rp.set_defaults(func=cmd_report)

    eco = sub.add_parser("ecology", help="report failure-root diversity and deletion evidence for a capability")
    eco.add_argument("state")
    eco.add_argument("capability")
    eco.set_defaults(func=cmd_ecology)

    ir = sub.add_parser("represent", help="select an IR using explicit retained/lost structure requirements")
    ir.add_argument("input")
    ir.add_argument("state")
    ir.set_defaults(func=cmd_represent)

    mr = sub.add_parser("model-register", help="register a scoped model contract")
    mr.add_argument("input")
    mr.add_argument("state")
    mr.set_defaults(func=cmd_model_register)

    sc = sub.add_parser("scope", help="evaluate a model applicability contract")
    sc.add_argument("state")
    sc.add_argument("model_id")
    sc.add_argument("context")
    sc.set_defaults(func=cmd_scope)

    task = sub.add_parser("task", help="execute one bounded mixed-domain task through the public surface")
    task.add_argument("input", help="JSON task specification")
    task.add_argument("state")
    task.set_defaults(func=cmd_task)

    organism = sub.add_parser("organism", help="execute one Stage 4C whole-organism operation through the public surface")
    organism.add_argument("input", help="JSON with operation and payload")
    organism.add_argument("state")
    organism.set_defaults(func=cmd_organism)

    gates = sub.add_parser("gates", help="show the frozen Stage 3 reality-gate plan and outcomes")
    gates.add_argument("state")
    gates.set_defaults(func=cmd_gates)

    v = sub.add_parser("verify", help="verify all persistent audit and content receipts")
    v.add_argument("state")
    v.set_defaults(func=cmd_verify)
    return p


def main() -> None:
    try:
        args = parser().parse_args()
        code = int(args.func(args) or 0)
    except (ValueError, KeyError, TypeError, RuntimeError) as exc:
        print(f"error: {type(exc).__name__}: {exc}", file=sys.stderr)
        code = 2
    # The optional native accelerator can stall interpreter finalization after
    # a command has already emitted and persisted its complete result.  The CLI
    # is a process boundary, so terminate after explicitly flushing output.
    sys.stdout.flush(); sys.stderr.flush()
    os._exit(code)


if __name__ == "__main__":
    main()
