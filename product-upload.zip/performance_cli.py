"""Lazy public surface for The Field bounded performance portfolio."""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path


def _json(value: str):
    stripped = value.lstrip()
    return json.loads(value) if stripped.startswith(("{", "[")) else json.loads(Path(value).read_text())


def cmd_identity(_args) -> int:
    from rabbithole.performance_fabric import (BASELINE_V015_SHA256, CONTACT_PAYLOAD_SHA256,
                                               PARENT_V016_SHA256, release_source_digest)
    print(json.dumps({"release": "0.17.0", "source_digest": release_source_digest(),
                      "parent_v0.16_sha256": PARENT_V016_SHA256,
                      "contact_baseline_v0.15_sha256": BASELINE_V015_SHA256,
                      "contact_payload_sha256": CONTACT_PAYLOAD_SHA256}, indent=2, sort_keys=True))
    return 0


def cmd_plan(args) -> int:
    from rabbithole.performance_fabric import HybridPerformancePortfolio, PerformanceLedger, PerformanceTask
    task = PerformanceTask.from_dict(_json(args.task))
    decision = HybridPerformancePortfolio().select(task)
    if args.ledger:
        PerformanceLedger(args.ledger).register(decision, actor=args.actor)
    print(json.dumps(asdict(decision), indent=2, sort_keys=True))
    return 0


def cmd_run(args) -> int:
    from rabbithole.performance_fabric import PerformanceLedger, PerformanceTask
    from rabbithole.performance_runtime import BoundedPerformanceExecutor
    raw = _json(args.input)
    ledger = PerformanceLedger(args.ledger) if args.ledger else None
    executor = BoundedPerformanceExecutor(max_warm_operations=args.max_warm_operations,
                                          max_warm_age_s=args.max_warm_age)
    if isinstance(raw, list):
        tasks = [PerformanceTask.from_dict(x["task"]) for x in raw]
        requests = [dict(x["request"]) for x in raw]
        out = executor.execute_batch(tasks, requests, ledger=ledger)
    else:
        out = executor.execute(PerformanceTask.from_dict(raw["task"]), dict(raw["request"]), ledger=ledger)
    print(json.dumps(out, indent=2, sort_keys=True, default=str))
    return 0


def cmd_status(args) -> int:
    from rabbithole.performance_fabric import PerformanceLedger, architecture_posiwid_report
    if args.ledger:
        ledger = PerformanceLedger(args.ledger)
        out = {"ledger": ledger.verify(), "posiwid": ledger.posiwid(),
               "architecture": architecture_posiwid_report()}
    else:
        out = architecture_posiwid_report()
    print(json.dumps(out, indent=2, sort_keys=True))
    return 0


def cmd_store(args) -> int:
    from rabbithole.performance_store import TransactionalKeySetStore
    raw = _json(args.action)
    db = TransactionalKeySetStore(args.store)
    try:
        action = raw.get("action", "status")
        if action == "set": out = db.set_many(raw["changes"], raw["idempotency_key"])
        elif action == "get": out = {"value": db.get(raw["key"])}
        elif action == "verify": out = db.verify()
        elif action == "status": out = db.status()
        else: raise ValueError("unknown store action")
    finally:
        db.close()
    print(json.dumps(out, indent=2, sort_keys=True))
    return 0


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="field-performance")
    sub = p.add_subparsers(dest="command", required=True)
    i = sub.add_parser("identity"); i.set_defaults(func=cmd_identity)
    q = sub.add_parser("plan"); q.add_argument("task"); q.add_argument("--ledger"); q.add_argument("--actor", default="performance-selector"); q.set_defaults(func=cmd_plan)
    r = sub.add_parser("run"); r.add_argument("input"); r.add_argument("--ledger"); r.add_argument("--max-warm-operations", type=int, default=100); r.add_argument("--max-warm-age", type=float, default=300.0); r.set_defaults(func=cmd_run)
    s = sub.add_parser("status"); s.add_argument("--ledger"); s.set_defaults(func=cmd_status)
    t = sub.add_parser("store"); t.add_argument("store"); t.add_argument("action"); t.set_defaults(func=cmd_store)
    return p


def main() -> None:
    args = parser().parse_args()
    raise SystemExit(int(args.func(args) or 0))


if __name__ == "__main__":
    main()
