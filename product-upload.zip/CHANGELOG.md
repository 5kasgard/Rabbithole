# Changelog

This file consolidates the retained release notes. Historical details remain attributable to their original versioned records.

## GitHub product cut — 2026-07-16

- Published the supported 0.18.0rc3 master as a compact product repository.
- Removed nested archives, raw campaign state, generated evidence and compiled artifacts from Git.
- Preserved the authoritative registries, changelog, runtime, examples, public tests and compact lineage index.
- Added Stage 6 external-contact obligations without implying external promotion.


# Changelog — 0.18.0rc3 Integrated Master Candidate

## Origin-to-current consolidation

- Added the complete master changelog and machine-readable change registry from precursor RabbitHole and Rx0 through every retained release, ARC and audit.
- Added a 24-mechanism origin reuse registry and explicit no-invention record for missing v0.8 canonical evidence.
- Added an 88-decision closure registry and exhaustive decision×component applicability matrix.
- Added gap-closure and blind-spot registries, scaling architecture and runtime/archive subtraction plan.

## Recovered and current implementations

- Added a persistent resident scheduler/supervisor with priorities, dependencies, leases, bounded retries, restart generations, telemetry, state digests and audit replay.
- Added versioned whole-target profiles with rival identity hypotheses, attributable assertions, privacy/access scopes, dependencies and cascading revocation.
- Added capability-scoped bidirectional FIP transport with in-process and atomic file-drop adapters; transport grants no semantic authority.
- Added metric-contract-local uncertainty-reduction/outcome/risk/resource receipts; cross-domain score aggregation remains prohibited.

## Standards and packaging

- Added origin-reuse, single-state-owner, record-don’t-swallow, ownership-aware-scaling, normal-surface-complexity and external-independence standards.
- Preserved v0.17 as rollback and all lineage evidence by digest.
- Remains a release candidate: external 72-hour, 14-day, independent utility, FIP independence, usability and deployed federation gates are open.


# Changelog — 0.18.0rc1 Master Candidate

## Integrated master reconstruction

- Adopted current Goal and Vision v2.1.
- Added Constitution v6.0, Conformance v1.0 and Lineage v2.0.
- Regenerated the Functional Checklist from current evidence registries.
- Added machine-readable standards, decisions, requirements, components, capabilities, drift, FIP, development and promotion registries.
- Added content-addressed history containing canonical releases, reconstructed v0.16 source, precursor snapshots, all retained performance ARC stages and all lineage-audit stages.
- Added `rabbithole.interchange`, the experimental FIP Python reference and contract adapter.
- Preserved Node and Go candidate implementations, vectors and attacks under `experimental/fip/`.
- Added `rabbithole.outward_loop`, an objective-scoped reversible acquire→test→act→monitor→replan runtime.
- Added `rabbithole.master_registry` and `field-master` normal front door.
- Preserved v0.17 as the reference and rollback target.

## Not promoted

- FIP remains experimental.
- External 72-hour, 14-day, independent utility, safety, adoption and usability gates remain blocked.
- The version is a release candidate, not canonical v0.18.0.


# Changelog — v0.17.0

## ARC Round 2 performance completion

- Completed the seven-stage ARC-5A performance campaign against the frozen v0.15.0 target while preserving v0.16.0 as the separate Stage 5 validation runtime lineage.
- Compared the current homogeneous cold monolith, homogeneous warm Python, hybrid cold batching, bounded heterogeneous specialists, a fully distributed heterogeneous alternative, and an adaptive hybrid/heterogeneous portfolio by local and whole-system POSIWID.
- Rejected both a universal homogeneous implementation and a universal heterogeneous rewrite.
- Selected **heterogeneous by bounded function, homogeneous at authority boundaries**:
  - Python remains the contract, selector, audit, replay and fallback authority;
  - cold batching amortises imports while retaining fresh operation state;
  - a release-, actor-, contract- and plugin-scoped warm capsule serves only repeated bounded local work;
  - SQLite WAL/FULL owns only an idempotent key-set mutation slice;
  - existing native numerical code remains limited to admitted integer-exact regular graphs under differential reference checking;
  - unsupported, shifted, remote, edge, energy and longitudinal regimes fall back or abstain.
- Added `rabbithole.performance_fabric`, `performance_runtime` and `performance_store`.
- Added an append-only performance decision/outcome ledger whose actual POSIWID cannot raise epistemic authority and whose hard-gate failure requires rollback.
- Added the lazy `field-performance` executable plus `field performance-plan`, `field performance-run` and `field performance-status` compatibility commands.
- Forbid adding or multiplying correlated mechanism speedups and forbid untested mechanism stacking.
- Preserved every inherited v0.16 acceptance and campaign artifact byte-for-byte; v0.17 evidence is stored under new versioned names.
- Added source-, test- and acceptance-script-bound segmented regression receipts and content-bound benchmark replay, with `FIELD_STAGE6_FORCE_REBUILD=1` retained for direct remeasurement.
- Prevented aggregate acceptance from mutating historical state or hanging on native teardown after valid receipts were already written.


# Changelog — v0.16.0

## Stage 5 validation runtime and preregistration

- Added a frozen 180-day, 120-challenge longitudinal protocol around the separate v0.15.0 primary artifact.
- Added frozen arm artifact/runtime/resource commitments and developer exclusion from arm custody.
- Added independent evaluator and external-review attestations with cross-organisation separation.
- Added private challenge, scoring-contract, blinded-arm-map and external timestamp commitments.
- Added prediction execution receipts, process traces, resource accounting and timestamp receipts.
- Added scoring-contract reveal matching, arm-blinding attestation and different-organisation cross-scoring.
- Replaced degenerate zero-event safety bootstrap behaviour with a conservative paired Wilson risk-difference interval and a preregistered 0.05 absolute noninferiority margin.
- Corrected the paired safety interval to use the actual Bonferroni two-interval critical value.
- Rejected string-valued critical-error flags, missing evaluator signing keys and record-ID collisions that could otherwise overwrite unrelated predictions, outcomes or maintenance events.
- Defined zero-resource comparison semantics so `0/0` means parity rather than artificial superiority and non-zero/zero is unbounded.
- Increased the minimum study size to 120 challenges, 20 owned/scored contacts per counted evaluator, 12 per counted domain and 30% shifted tasks.
- Added administrator and statistical runbooks, frozen artifact digest references and public validation lifecycle commands.
- Made the trust boundary explicit: the local hash chain requires independent anchoring to resist whole-ledger rewrite by a privileged custodian.
- The empirical verdict remains `blocked`; no evaluator, challenge, outcome or elapsed-time evidence is fabricated.


# Changelog — v0.15.0

## Stage 4D-C: heterogeneous substrate campaign

- Added an ARC-5A-hosted persistent campaign over language, runtime, storage, networking and hardware.
- Added 18 candidates, six frozen workload contracts, six role-separated benchmark commitments, five formal contracts, 48 measured observations, raw receipt binding and five hard-valid Pareto decisions.
- Retained CPython as control-plane authority and native C only as a differentially checked numerical specialist.
- Preserved persistent workers, SQLite indexing and Unix sockets as reversible slices; rejected wholesale migration.
- Marked Rust, free-threaded CPython, PostgreSQL, QUIC and GPU paths blocked where the required environment was absent.
- Added public `substrate-import`, `substrate-status` and `substrate-verify` commands.
- Replaced the inherited quadratic wide-sum contractor with a linear outward-rounded prefix/suffix implementation while retaining fast 0/1/2-term paths.
- Bounded persistent-worker and socket benchmark operations so campaign reconstruction cannot wedge indefinitely.

## Acceptance

- Stage 4D-C acceptance: 20/20.
- Stage 4D-C kernel tests: 10 passed.
- Inherited numerical, acquisition, placement, stress and Stage 4C/4D-A/4D-B regressions remain part of `run_all.py`.


# Changelog — v0.14.0

## Stage 4D-B: process-against-process campaign

### Added

- `rabbithole/process_portfolio.py` with a persistent task-proportionate process registry and Pareto selector.
- Nine bounded process families: ARC-5, ARC-5A, systematic evidence synthesis, CEGAR, Bayesian experimental design, multiple working hypotheses/adversarial collaboration, design science, a minimal scientific loop, and an ad-hoc null baseline.
- Process preconditions, contraindications, capabilities, evidence roots, failure modes, overhead and human-burden contracts.
- Five-role process arenas for champion, challenger, simplifier, portfolio and null.
- Hard-valid task-specific Pareto frontiers without one universal score.
- Public commands: `process-task`, `process-select`, and `process-status`.
- Seven representative process-comparison tasks.
- Frozen Stage 4D-C process profile for the language/runtime/storage/network/hardware campaign.
- Stage 4D-B acceptance and process-campaign artifacts.

### Reduction

- Rejected one universal discovery process.
- Retained ARC-5A as a high-stakes open-world meta-orchestrator rather than universal executor.
- Retained ARC-5 as a lower-overhead bounded profile.
- Retained specialist process ownership for evidence synthesis, formal refinement, experimental design, adversarial disputes, artifact engineering and small empirical questions.
- Structural process stacking cannot manufacture epistemic quality.

### Boundaries

- No longitudinal superiority claim.
- No external process-author independence claim.
- No language or hardware migration in this release.


# Changelog — v0.13.0

## Stage 4D-A: ARC-5A adversarial bifurcated discovery

### Added

- `rabbithole/arc_adversarial.py` with a persistent ARC-5A state machine.
- Independent constructive and destructive concrete search plans.
- Independent function-preserving and counterfactual abstraction lattices and search plans.
- Independently authored goal-backward and failure-forward decomposition passes.
- First-class decomposition disagreements with discriminating observations.
- Strongest-selection arena roles: champion, challenger, simplifier, portfolio and null.
- Multi-dimensional Pareto assessments without an early universal score.
- Independently authored champion and adversarial tests for every active candidate.
- Decision saturation based on mechanism classes, abstraction lattices, failure modes, resource relocation, challengers, simplifiers, whole-system harms and Pareto changes.
- Recursive stage reopening when contact invalidates framing, decomposition, abstraction, arena or implementation.
- Public commands: `arc5a-start`, `arc5a-step`, `arc5a-search`, `arc5a-status`.
- Persistent integrity scanning and status reporting for ARC-5A kernels.
- Language/hardware ARC-5A example specification.

### Adversarial corrections

- A missing destructive field model blocks the concrete gate.
- One author cannot define both concrete field models.
- One decomposition cannot stand in for both goal-backward and failure-forward analysis.
- One abstraction lattice cannot stand in for function and counterfactual search.
- A favoured candidate cannot enter contact without champion, challenger, simplifier, portfolio and null competitors.
- A single test author cannot define both demonstration and attempted-kill tests.
- Document novelty alone cannot satisfy saturation.
- Mutating a frozen search or test plan is detected.

### Boundaries

This release implements the stronger process kernel only. It does not yet:

- compare ARC-5A longitudinally against ARC-5 or other discovery methods;
- apply ARC-5A to language/runtime/storage/network/hardware allocation;
- prove independence or competence of external authors and search providers;
- guarantee that the strongest candidate or abstraction was found;
- migrate the v0.12 implementation to a new language or hardware substrate.


# Changelog — v0.12.0

## Stage 4C: whole-organism reconstruction

- Consumed the frozen 18-arc Stage 4B campaign under explicit human approval.
- Rebuilt unresolved capabilities in eleven dependency waves instead of adding
  eighteen modules indiscriminately.
- Preserved external-infrastructure and independent-validation boundaries;
  removed unsupported universal claims.
- Added evaluator commitments, provider contracts, study grouping, opposition
  search, document IR, transformation-loss contracts, reversible mapping,
  empirical calibration interfaces, registered design dialects, allocation and
  solver benchmarks, specialist ecology, declared shift monitors, environment
  protocols, explanation studies, architectural mutation, resource accounting,
  and scenario assurance.
- Extended the normal `FieldInstrument` public surface and persistence for all
  retained mechanisms.
- Added `field organism` / `field_cli.py organism` as the public Stage 4C
  operation path.
- Added resource-aware portfolio selection without collapsing money, human
  attention, energy, latency, or risk into one stored authority score.
- Fixed allocation oracle/regret alignment.
- Expanded code-version hashing to all new load-bearing modules.
- Projected frozen gate outcomes into the goal-derived capability graph through
  the public assurance surface: 9 live and 12 partial capabilities; no invalid
  live claims.
- Updated `run_all.py` and packaging with a working `field-accept` entry point.

## Acceptance

- Stage 4C acceptance: 21/21 checks.
- Frozen reality gates: 17 pass, 13 partial, 1 blocked, 0 fail, 0 unrun.
- 174 pytest tests in the release corpus: 155 inherited, 19 new Stage 4C.
- Final targeted post-synchronization rerun: 42 passed.
- Kernel 40/40; forager 8/8; placement 6/6; stress 9/9.
- Stage 4A lifecycle/CLI and Stage 4B 13/13 campaign regressions pass.

## Claim reductions retained

- Inverse design is only claimed for registered dialects with independent
  validators.
- Distribution-shift response is only claimed for declared monitor families.
- Whole-goal assurance is profile-based and maintained; no universal terminal
  certificate is emitted.
- Physical empirical authority, independent anti-contamination, future
  calibration, long-horizon environments, user comprehension, and deployed
  whole-goal assurance remain external contacts.


# Changelog — v0.11.0

## Stage 4B recursive application

- Added `rabbithole.arc_campaign` for frozen multi-arc target plans,
  dependency waves, portable arc attachments, capability dispositions and a
  human gate before reconstruction.
- Applied ARC-5 separately to all 18 Stage 3 partial/blocked gates.
- Added exact full-lineage passage capture with source digests and byte ranges;
  all project passages share one conservative causal root.
- Added a bounded external evidence catalog and target-specific retrieval
  aliases that explicitly add no evidence or independence.
- Produced nine internal-mechanism dispositions, three external-infrastructure
  boundaries, three independent-validation boundaries and three narrowed
  claims.
- Added the dependency-ordered Stage 4C reconstruction queue.
- Added public `arc-campaign-status` CLI support.
- Added campaign integrity, dependency-cycle, arc-digest, disposition and
  human-gate tests.
- Made campaign arc paths portable relative to the campaign file.
- Added machine-readable Stage 4B acceptance and segmented regression evidence.

## Corrections

- Separated implementation dependencies from coupled validation relationships,
  removing a solver-routing/distribution-shift queue cycle.
- Replaced whole-document lineage embedding with bounded exact passages to
  prevent persistence cost from dominating discovery.
- Preserved external infrastructure and independent validation as real
  boundaries instead of converting them into fixtures.
- Narrowed universal inverse-design, universal drift-detection and terminal
  whole-goal-completion claims.

## Acceptance

- 18/18 capability arcs valid and held at preregistered contact.
- 13/13 Stage 4B campaign checks passed.
- 155 pytest tests passed in isolated batches.
- Forager boundary 8/8; placement boundary 6/6; stress 9/9.
- Stage 4A lifecycle and CLI acceptance rerun successfully.


# Changelog — v0.10.0 / Stage 4A

## Added

- Persistent `ARC5Kernel` state machine implementing the improved subtractive-discovery process.
- Frozen dual-POSIWID and eligibility contracts.
- Separately frozen concrete and abstraction search plans.
- Deterministic positive, negative, alternative, boundary and POSIWID seed searches plus compounded follow-up waves.
- Evidence screening and conservative multi-root independence clustering.
- Causal transfer/anti-analogy records with mismatches, predictions and falsifiers.
- Contrastive mechanism-case matrices and conservative necessity/sufficiency inference.
- Competing system hypotheses and preregistered test definitions.
- Recursive failure diagnosis, downstream invalidation and queue cancellation.
- Persistent human work queue, approvals and append-only amendments.
- Public commands: `arc-start`, `arc-step`, `arc-search`, `arc-status`.
- ARC kernel integrity verification and instrument organ traces.
- Stage 4A lifecycle and CLI acceptance programs.

## Changed

- Freezing a contract or test plan no longer advances the process.
- Only explicit accountable approval advances a stage.
- Public operations and search execution are restricted to the current stage.
- Re-freezing unchanged plans is idempotent; mutation of a frozen plan fails.
- Failed upstream contact clears dependent test preregistration and cancels downstream queued work.
- Package and instrument version advanced to `0.10.0`.

## Preserved boundaries

- Search, analogy, mechanism recurrence and LLM proposals have zero verdict authority.
- The numerical RabbitHole kernel remains a bounded specialist.
- Stage 4B recursive application and Stage 5 longitudinal external validation remain unbuilt.


# Changelog — v0.9.0

- Replaced the universal-field architecture assumption with a thin typed
  evidence/contract waist and plural domain dialects.
- Added goal/authority gate, executable-component attestation, calibration,
  causal identification, experiment allocation, ontology evolution, federation,
  dependency containment, drift monitoring and frozen gate plan.
- Added independently executable built-in verification contracts for formal,
  software, empirical JSON, statistical, causal, documentary and normative
  claims.
- Upgraded acquisition to preserve PDF page/block/table structure and image
  metadata; hostile source content remains data, not instruction authority.
- Upgraded actions with preconditions, idempotency, monitoring and compensation.
- Added one bounded mixed-domain `field task` public surface.
- Added 21 Stage 3 adversarial/integration tests and an isolated-process acceptance
  runner.
- Preserved RabbitHole interval propagation as a bounded specialist rather than
  claiming it is the universal organism.
- Recorded all 31 predeclared gates: 13 pass, 17 partial, one blocked.


# v0.7.0

## Purpose

Replace the narrow “vertical slice proves architecture” standard with a real,
auditable mechanism-discovery and capability-assurance layer.

## Added

- ARC-5 persistent discovery arcs with dual POSIWID.
- Concrete and abstraction-level query lineage.
- Positive, negative, failure, boundary, analogue, anti-analogue, and
  counterexample search polarities.
- Content-addressed local corpus, Crossref, and OpenAlex providers.
- Independence groups and duplicate tracking.
- Functional distinctions, abstraction lattice, example cases, mechanism and
  system hypotheses, test obligations, saturation reports.
- Proposal-faculty receipts; faculty output remains propose-only.
- Verification-contract registry for heterogeneous claim classes.
- Representation-contract registry with explicit retained/lost structure.
- Argument graph that preserves support, attack, dependency, and correlation.
- Empirical mechanism portfolio and task-shape routing.
- Capability-scoped external action registry.
- PROV-shaped provenance graph.
- Runtime organ traces, dependency checks, and architectural mutation tests.
- Capability assurance cases tied to public surfaces and whole-system effects.
- Persistent `FieldInstrument` and public `field` CLI.

## Corrected

- Search breadth and saturation are now first-class rather than implicit.
- Analogy is explicitly zero-authority and must be searched contrastively.
- “Abstract grounding” is replaced by typed verification contracts.
- Provenance, independence, trust, and authority remain separate.
- Representation choice is treated as a mechanism, not neutral serialization.
- Holobiont diversity is measured by independent failure modes, not component count.
- Capability claims require deletion sensitivity rather than file presence or demos.

## Still unbuilt

- validated blind reconstruction of the v5 discoveries;
- autonomous general-purpose multimodal carving;
- broad external verifier and action ecosystems;
- calibrated authority, routing, and decay policies;
- comprehensive field arcs across every goal capability;
- the final user-facing universal instrument.


# Changelog — v0.6.0

## Built from Rx0 plus recovered lineage mechanisms

- Added a typed AKBC waist separating quantity kind, measurand, observation,
  source receipt, identity hypothesis and constraint proposal.
- Replaced destructive aliases with reversible canonical projections.
- Added precision-first placement with dimension, kind, algebraic, phenomenon,
  scope, operational and graph-neighbourhood probes.
- Closed testimony-to-clamp and LLM-to-invariant authority laundering paths.
- Added registered reality executors, source survival ledger, scoped capabilities
  and explicit contact-quality limits.
- Added reversible projection of tested beliefs into interval calculations.
- Added outward-rounded Python interval operations and sound-by-default routing;
  native C remains explicit approximate opt-in.
- Added source snapshot/digest receipts, expanded code-bound WAL, persistence,
  structured CLI intake and machine-readable POSIWID acceptance.
- Added adversarial gates for same-dimension false merges, scope mismatch,
  low-quality identity/invariant tests, correlated sources, unit conversion,
  tampering, persistence and interval enclosure.

## Deliberately not claimed

- autonomous arbitrary-source parsing;
- general ontology induction;
- live bundled web/sensor/database adapters;
- optimal experimental design;
- distributed civilisation-scale coordination;
- full IEEE 1788 interval compliance.
