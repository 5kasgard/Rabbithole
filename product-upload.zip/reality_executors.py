"""Phase-A reality-contact executors — the real replacement for the thin
slice's [STAND-IN] wire.

The stand-in returned the field's own answer (a lie dressed as a measurement).
A real executor grounds a variable by a method that does NOT know the field's
answer and does NOT reuse the field's constraint, then reports (value, sigma)
with an HONEST contact type fixed at registration. A test can never claim a
stronger contact than its executor provides — so a computation registers as
'derived', a person as 'human', a sensor as 'instrument'. Swapping one executor
for another (integration -> sensor -> web) changes nothing in the spine around
it. That is the whole point: the last stand-in comes out, the architecture holds.
"""
from __future__ import annotations
import math


# --- 1. DERIVED contact: an independent computation ------------------------
def impact_speed_by_integration(spec: dict):
    """Ground impact speed by numerically integrating free fall — a DIFFERENT
    method than the energy identity (1/2 m v^2 = m g h) the field settled with.
    Agreement is genuine cross-validation, not tautology, because this route
    never touches the field's v: it uses only g and h and kinematics.

    sigma is EARNED, not invented: Richardson-style, the gap between a coarse
    and a fine integration is a real estimate of the method's numerical error.

    Contact: 'derived' — a computation is not an instrument. Registered as such.
    """
    g = float(spec["g"])
    h = float(spec["h"])

    def integrate(dt: float) -> float:
        # semi-implicit Euler on y'' = -g, from rest at height h
        y, vel = h, 0.0
        while y > 0.0:
            vel += g * dt
            y -= vel * dt
        return vel  # speed at ground crossing

    v_coarse = integrate(1e-3)
    v_fine = integrate(1e-4)
    sigma = abs(v_coarse - v_fine) + 1e-9
    return (v_fine, sigma)


# --- 2. HUMAN contact: a person reads an instrument ------------------------
def manual_reading(spec: dict):
    """The true Phase-A: a human enters a measured value and its uncertainty.
    spec = {"value": float, "sigma": float}. Contact: 'human'. This is the
    honest floor — you, in Brisbane, with a stopwatch or a tape measure, are a
    valid reality contact. Nothing about the spine requires more than this.
    """
    return (float(spec["value"]), float(spec["sigma"]))


# --- 3. INSTRUMENT/derived contact: a sourced/web measurement (network) -----
def web_measurement(spec: dict):
    """Placeholder for the network faculty: fetch a measured value from a
    sourced dataset or API. Same (value, sigma) shape; contact fixed at
    registration by where it comes from. Left unimplemented ON PURPOSE — this
    is the one wire that genuinely needs the outside world, and it should fail
    loudly rather than pretend. When network exists, implement the fetch here
    and register with the source-appropriate contact; the slice does not change.
    """
    raise NotImplementedError(
        "web_measurement needs network access; register a real fetch here."
    )


# Registration recipe (kept next to the executors so the trust boundary is
# visible): kind -> (executor, honest contact type).
REGISTRY = {
    "measure_v_integration": (impact_speed_by_integration, "derived"),
    "measure_v_manual":      (manual_reading,              "human"),
    "measure_v_web":         (web_measurement,             "instrument"),
}


def install(harness):
    """Register every real executor on a RealityHarness at its honest contact."""
    for kind, (executor, contact) in REGISTRY.items():
        harness.register(kind, executor, contact=contact)
    return harness