"""Forager: acquire testimony without laundering it into a wall.

A source lookup is an acquisition event, not a test.  Dimensionally compatible
records enter as untested evidence with zero authority.  Exact constants may
become walls only when the source record explicitly identifies them as a
``definition`` or ``convention``; the caller cannot infer that from sigma=0.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Optional

from rabbithole.core import unit as unit_lookup


class LocalSource:
    def __init__(self, path: str):
        with open(path) as f:
            self.data = {k: v for k, v in json.load(f).items() if not k.startswith("_")}
        self.name = f"local:{path.rsplit('/', 1)[-1]}"

    def lookup(self, key: str) -> Optional[dict]:
        rec = self.data.get(key)
        return None if rec is None else dict(rec)


class WebSource:
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.name = f"web:{base_url}"

    def lookup(self, key: str) -> Optional[dict]:
        raise NotImplementedError(
            "WebSource needs a registered fetch/parser adapter; refusing to fabricate contact."
        )


@dataclass
class ForageResult:
    status: str  # acquired_untested|defined|not_found|rejected_dimension|rejected_unit|rejected_uncertainty
    var: str
    key: str
    value: Optional[float] = None
    sigma: Optional[float] = None
    unit: Optional[str] = None
    citation: Optional[str] = None
    contact: str = "secondary"
    evidence_id: Optional[str] = None
    factor_id: Optional[str] = None
    reason: str = ""

    def ok(self) -> bool:
        return self.status in {"acquired_untested", "defined"}


def forage(field, var: str, key: str, source) -> ForageResult:
    if var not in field.variables:
        return ForageResult("not_found", var, key, reason=f"no variable {var!r} in the field")

    rec = source.lookup(key)
    if rec is None:
        return ForageResult("not_found", var, key,
                            reason=f"{key!r} not found in {getattr(source, 'name', 'source')}")

    src_unit = rec.get("unit", "")
    citation = rec.get("source", "unattributed source")
    try:
        src_dim, src_scale = unit_lookup(src_unit)
    except KeyError:
        return ForageResult("rejected_unit", var, key, unit=src_unit, citation=citation,
                            reason=f"source unit {src_unit!r} is unknown")

    target = field.variables[var]
    if src_dim != target.dim:
        return ForageResult(
            "rejected_dimension", var, key, unit=src_unit, citation=citation,
            reason=(f"{key!r} has dimension {src_dim}; {var!r} requires {target.dim}. "
                    "Rejected before graph mutation."),
        )

    value = float(rec["value"])
    sigma = float(rec.get("sigma", 0.0))
    value_target = value * src_scale / target.unit_scale
    sigma_target = sigma * src_scale / target.unit_scale
    authority_class = rec.get("authority_class", "testimony")

    if authority_class in {"definition", "convention"}:
        fid = field.constant(var, value_target,
                             f"{key}: {value} {src_unit}",
                             f"{authority_class}: {citation}")
        return ForageResult("defined", var, key, value_target, 0.0, target.unit_name,
                            citation, "derived", factor_id=fid,
                            reason=f"explicit {authority_class}; admitted as scoped structure")

    if sigma_target <= 0:
        return ForageResult(
            "rejected_uncertainty", var, key, value_target, sigma_target,
            target.unit_name, citation,
            reason=("testimony with sigma<=0 is not an exact wall; source must provide "
                    "uncertainty or explicit authority_class=definition|convention"),
        )

    eid = field.add_evidence(
        var, value_target, sigma_target, source=citation,
        confidence=float(rec.get("confidence", 0.5)), tested=False,
        contact=rec.get("contact", "human"), author=rec.get("author", citation),
        statement=f"{key} = {value} ± {sigma} {src_unit} via {source.name}",
    )
    return ForageResult(
        "acquired_untested", var, key, value_target, sigma_target, target.unit_name,
        citation, rec.get("contact", "human"), evidence_id=eid,
        reason="admitted as testimony with zero authority until a registered test survives",
    )
