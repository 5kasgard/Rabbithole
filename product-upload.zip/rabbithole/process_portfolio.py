"""Process-against-process portfolio for ARC-5A Stage 4D-B.

The registry does not crown one universal method.  It records the operating
preconditions, causal strengths, failure modes and resource costs of discovery
process families, then composes a task-specific process profile.  Capability
coverage is set-union over declared mechanisms; epistemic quality dimensions use
maxima rather than additive votes so that stacking correlated methods cannot
manufacture authority.

This module supplies structural mechanism-fit evidence only.  It does not prove
longitudinal superiority, external author independence, or semantic correctness
of any method contract.
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Sequence, Tuple

from .wal import EventLog


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


def _canon(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, default=str).encode("utf-8")


def _digest(value: object) -> str:
    return hashlib.sha256(_canon(value)).hexdigest()


DIRECTIONS = {
    "requirement_coverage": "max",
    "field_coverage": "max",
    "falsification_strength": "max",
    "formal_soundness": "max",
    "contact_efficiency": "max",
    "artifact_feedback": "max",
    "adversarial_independence": "max",
    "whole_system_fit": "max",
    "overhead": "min",
    "human_burden": "min",
    "self_sealing_risk": "min",
}


@dataclass(frozen=True)
class ProcessMethod:
    method_id: str
    name: str
    family: str
    capabilities: Tuple[str, ...]
    preconditions: Tuple[str, ...]
    contraindications: Tuple[str, ...]
    strengths: Tuple[str, ...]
    failure_modes: Tuple[str, ...]
    evidence_roots: Tuple[str, ...]
    dimensions: Mapping[str, float]
    overhead: float
    human_burden: float
    author: str
    version: str = "1"

    def validate(self) -> None:
        if not self.method_id.strip() or not self.name.strip() or not self.author.strip():
            raise ValueError("process method requires id, name and author")
        if not self.capabilities or not self.strengths or not self.failure_modes:
            raise ValueError("process method requires capabilities, strengths and failures")
        if self.overhead < 0 or self.human_burden < 0:
            raise ValueError("process costs cannot be negative")
        unknown = set(self.dimensions) - set(DIRECTIONS)
        if unknown:
            raise ValueError(f"unknown process dimensions: {sorted(unknown)}")
        if any(not 0.0 <= float(v) <= 1.0 for v in self.dimensions.values()):
            raise ValueError("process quality dimensions must be in [0,1]")


@dataclass(frozen=True)
class ProcessTaskProfile:
    task_id: str
    name: str
    required_capabilities: Tuple[str, ...]
    mandatory_capabilities: Tuple[str, ...]
    context_flags: Mapping[str, bool]
    risk_level: str
    resource_budget: float
    success_observations: Tuple[str, ...]
    failure_observations: Tuple[str, ...]
    author: str
    created_at: float = field(default_factory=time.time)

    def validate(self) -> None:
        if self.risk_level not in {"low", "medium", "high", "critical"}:
            raise ValueError("invalid process task risk")
        if not self.task_id.strip() or not self.name.strip() or not self.author.strip():
            raise ValueError("task profile requires id, name and author")
        if not self.required_capabilities or not self.success_observations or not self.failure_observations:
            raise ValueError("task profile requires capabilities and observations")
        if not set(self.mandatory_capabilities).issubset(set(self.required_capabilities)):
            raise ValueError("mandatory capabilities must be required capabilities")
        if self.resource_budget <= 0:
            raise ValueError("resource budget must be positive")


@dataclass(frozen=True)
class ProcessCandidate:
    role: str
    task_id: str
    method_ids: Tuple[str, ...]
    rationale: str
    author: str
    candidate_id: str = field(default_factory=lambda: _id("PCM"))

    def validate(self) -> None:
        if self.role not in {"champion", "challenger", "simplifier", "portfolio", "null"}:
            raise ValueError("invalid process candidate role")
        if not self.method_ids or not self.rationale.strip() or not self.author.strip():
            raise ValueError("process candidate requires methods, rationale and author")


@dataclass(frozen=True)
class ProcessAssessment:
    candidate_id: str
    task_id: str
    method_ids: Tuple[str, ...]
    metrics: Mapping[str, float]
    satisfied_capabilities: Tuple[str, ...]
    missing_capabilities: Tuple[str, ...]
    missing_mandatory: Tuple[str, ...]
    invalid_preconditions: Tuple[str, ...]
    evidence_roots: Tuple[str, ...]
    hard_valid: bool
    evaluator: str
    assessment_id: str = field(default_factory=lambda: _id("PAS"))


@dataclass(frozen=True)
class ProcessDecision:
    task_id: str
    candidate_ids: Tuple[str, ...]
    frontier_ids: Tuple[str, ...]
    execution_profile_ids: Tuple[str, ...]
    unresolved: bool
    rationale: str
    decision_id: str = field(default_factory=lambda: _id("PDC"))
    created_at: float = field(default_factory=time.time)


class ProcessPortfolio:
    """Versioned process-method registry and task-specific Pareto selector."""

    def __init__(self) -> None:
        self.methods: Dict[str, ProcessMethod] = {}
        self.tasks: Dict[str, ProcessTaskProfile] = {}
        self.candidates: Dict[str, ProcessCandidate] = {}
        self.assessments: Dict[str, ProcessAssessment] = {}
        self.decisions: Dict[str, ProcessDecision] = {}
        self.audit = EventLog()

    def register_method(self, method: ProcessMethod) -> str:
        method.validate()
        prior = self.methods.get(method.method_id)
        if prior and _digest(asdict(prior)) != _digest(asdict(method)):
            raise ValueError(f"process method {method.method_id!r} already registered differently")
        self.methods[method.method_id] = method
        self.audit.append("process_method_registered", {"method_id": method.method_id,
                                                         "digest": _digest(asdict(method))})
        return method.method_id

    def register_task(self, task: ProcessTaskProfile) -> str:
        task.validate()
        prior = self.tasks.get(task.task_id)
        if prior and _digest(asdict(prior)) != _digest(asdict(task)):
            raise ValueError(f"process task {task.task_id!r} already registered differently")
        self.tasks[task.task_id] = task
        self.audit.append("process_task_registered", {"task_id": task.task_id,
                                                       "digest": _digest(asdict(task))})
        return task.task_id

    def seed_task_candidates(self, task_id: str, author: str) -> Tuple[str, ...]:
        """Create the mandatory strongest-selection arena for one process task.

        The challenger is the strongest domain-native specialist indicated by
        the task flags.  The portfolio composes only applicable specialists;
        it does not activate every method by default.
        """
        if task_id not in self.tasks:
            raise KeyError(task_id)
        task = self.tasks[task_id]
        flags = task.context_flags
        specialists = []
        if flags.get("retrievable_evidence") or flags.get("evidence_synthesis"):
            specialists.append("systematic_evidence")
        if flags.get("formal_model_available"):
            specialists.append("cegar")
        if flags.get("experimentable") and flags.get("probabilistic_model_available"):
            specialists.append("bayesian_design")
        if flags.get("rival_camps_available"):
            specialists.append("mwh_adversarial")
        if flags.get("artifact_buildable") and flags.get("evaluation_environment_available"):
            specialists.append("design_science")
        if flags.get("formal_model_available"):
            challenger = "cegar"
        elif flags.get("experimentable") and flags.get("probabilistic_model_available"):
            challenger = "bayesian_design"
        elif flags.get("rival_camps_available"):
            challenger = "mwh_adversarial"
        elif flags.get("artifact_buildable") and flags.get("evaluation_environment_available"):
            challenger = "design_science"
        elif flags.get("retrievable_evidence") or flags.get("evidence_synthesis"):
            challenger = "systematic_evidence"
        else:
            challenger = "minimal_scientific"
        simplifier = "arc5" if flags.get("broad_open_world") else "minimal_scientific"
        portfolio = []
        if task.risk_level in {"high", "critical"} or flags.get("broad_open_world"):
            portfolio.append("arc5a")
        elif flags.get("moderate_discovery"):
            portfolio.append("arc5")
        portfolio.extend(specialists)
        if not portfolio:
            portfolio.append("minimal_scientific")
        # Stable deduplication.
        portfolio = list(dict.fromkeys(portfolio))
        rows = (
            ProcessCandidate("champion", task_id, ("arc5a",),
                             "strongest general adversarial discovery process", author),
            ProcessCandidate("challenger", task_id, (challenger,),
                             "strongest applicable domain-native process", f"{author}:challenger"),
            ProcessCandidate("simplifier", task_id, (simplifier,),
                             "smallest general process plausibly sufficient", f"{author}:simplifier"),
            ProcessCandidate("portfolio", task_id, tuple(portfolio),
                             "task-proportionate host plus applicable specialists", f"{author}:portfolio"),
            ProcessCandidate("null", task_id, ("domain_native",),
                             "no fixed process beyond local expertise", f"{author}:null"),
        )
        return tuple(self.add_candidate(row) for row in rows)

    def add_candidate(self, candidate: ProcessCandidate) -> str:
        candidate.validate()
        if candidate.task_id not in self.tasks:
            raise KeyError(candidate.task_id)
        missing = [mid for mid in candidate.method_ids if mid not in self.methods]
        if missing:
            raise KeyError(f"unknown process methods: {missing}")
        self.candidates[candidate.candidate_id] = candidate
        self.audit.append("process_candidate_added", asdict(candidate))
        return candidate.candidate_id

    @staticmethod
    def _condition_ok(condition: str, flags: Mapping[str, bool]) -> bool:
        condition = condition.strip()
        if not condition:
            return True
        if condition.startswith("not:"):
            return not bool(flags.get(condition[4:], False))
        return bool(flags.get(condition, False))

    def assess(self, candidate_id: str, evaluator: str) -> ProcessAssessment:
        if not evaluator.strip():
            raise ValueError("process assessment requires evaluator")
        candidate = self.candidates[candidate_id]
        task = self.tasks[candidate.task_id]
        methods = [self.methods[mid] for mid in candidate.method_ids]
        capabilities = set().union(*(set(m.capabilities) for m in methods))
        required = set(task.required_capabilities)
        mandatory = set(task.mandatory_capabilities)
        missing = tuple(sorted(required - capabilities))
        missing_mandatory = tuple(sorted(mandatory - capabilities))
        invalid = []
        for method in methods:
            for condition in method.preconditions:
                if not self._condition_ok(condition, task.context_flags):
                    invalid.append(f"{method.method_id}:missing:{condition}")
            for condition in method.contraindications:
                if self._condition_ok(condition, task.context_flags):
                    invalid.append(f"{method.method_id}:contraindicated:{condition}")
        roots = tuple(sorted(set().union(*(set(m.evidence_roots) for m in methods))))
        metrics = {}
        for dimension in DIRECTIONS:
            if dimension == "requirement_coverage":
                metrics[dimension] = len(required & capabilities) / max(1, len(required))
            elif dimension == "overhead":
                metrics[dimension] = sum(m.overhead for m in methods) + max(0, len(methods)-1) * 0.08
            elif dimension == "human_burden":
                metrics[dimension] = sum(m.human_burden for m in methods)
            else:
                # Max, not sum: adding correlated methods cannot manufacture
                # epistemic quality.  A later empirical campaign may replace
                # this structural estimate with observed outcomes.
                metrics[dimension] = max((float(m.dimensions.get(dimension, 0.0)) for m in methods), default=0.0)
        hard_valid = not missing_mandatory and not invalid and metrics["overhead"] <= task.resource_budget
        row = ProcessAssessment(candidate_id, task.task_id, candidate.method_ids, metrics,
                                tuple(sorted(required & capabilities)), missing,
                                missing_mandatory, tuple(sorted(invalid)), roots,
                                hard_valid, evaluator)
        self.assessments[row.assessment_id] = row
        self.audit.append("process_candidate_assessed", asdict(row))
        return row

    def task_assessments(self, task_id: str) -> Tuple[ProcessAssessment, ...]:
        return tuple(x for x in self.assessments.values() if x.task_id == task_id)

    @staticmethod
    def _dominates(a: ProcessAssessment, b: ProcessAssessment) -> bool:
        if not a.hard_valid:
            return False
        if not b.hard_valid:
            return True
        weak = True
        strict = False
        for name, direction in DIRECTIONS.items():
            av, bv = float(a.metrics[name]), float(b.metrics[name])
            if direction == "max":
                weak &= av >= bv
                strict |= av > bv
            else:
                weak &= av <= bv
                strict |= av < bv
        return weak and strict

    def pareto_frontier(self, task_id: str) -> Tuple[str, ...]:
        rows = list(self.task_assessments(task_id))
        frontier = []
        for row in rows:
            if row.hard_valid and not any(self._dominates(other, row) for other in rows if other.assessment_id != row.assessment_id):
                frontier.append(row.candidate_id)
        return tuple(sorted(set(frontier)))

    def decide(self, task_id: str, author: str) -> ProcessDecision:
        if not author.strip():
            raise ValueError("process decision requires author")
        candidates = [c for c in self.candidates.values() if c.task_id == task_id]
        if not candidates:
            raise ValueError("task has no candidates")
        if not self.task_assessments(task_id):
            for c in candidates:
                self.assess(c.candidate_id, evaluator=f"structural:{author}")
        frontier = self.pareto_frontier(task_id)
        task = self.tasks[task_id]
        unresolved = len(frontier) != 1
        execution: Tuple[str, ...] = ()
        rationale = "multiple non-dominated process profiles remain; retain the frontier"
        if frontier:
            # For high/critical risk, do not collapse a multi-candidate frontier.
            # For lower risk, the least-overhead hard-valid frontier profile is
            # an execution choice, not an epistemic declaration of superiority.
            if len(frontier) == 1:
                execution = self.candidates[frontier[0]].method_ids
                unresolved = False
                rationale = "one hard-valid process candidate remains non-dominated"
            elif task.risk_level in {"low", "medium"}:
                by_candidate = {a.candidate_id: a for a in self.task_assessments(task_id)}
                chosen = min(frontier, key=lambda cid: (by_candidate[cid].metrics["overhead"], cid))
                execution = self.candidates[chosen].method_ids
                rationale = "frontier unresolved; least-overhead frontier profile selected for bounded execution only"
            else:
                rationale = "high-stakes frontier unresolved; human must select or run multiple profiles"
        row = ProcessDecision(task_id, tuple(sorted(c.candidate_id for c in candidates)),
                              frontier, execution, unresolved, rationale)
        self.decisions[row.decision_id] = row
        self.audit.append("process_decision_recorded", asdict(row))
        return row

    def verify(self) -> dict:
        errors = []
        for m in self.methods.values():
            try: m.validate()
            except Exception as exc: errors.append(f"method:{m.method_id}:{exc}")
        for t in self.tasks.values():
            try: t.validate()
            except Exception as exc: errors.append(f"task:{t.task_id}:{exc}")
        for c in self.candidates.values():
            try: c.validate()
            except Exception as exc: errors.append(f"candidate:{c.candidate_id}:{exc}")
        audit = self.audit.verify()
        return {"valid": not errors and audit.get("valid", False), "errors": errors,
                "methods": len(self.methods), "tasks": len(self.tasks),
                "candidates": len(self.candidates), "assessments": len(self.assessments),
                "decisions": len(self.decisions), "audit": audit}

    def to_dict(self) -> dict:
        return {
            "methods": [asdict(x) for x in self.methods.values()],
            "tasks": [asdict(x) for x in self.tasks.values()],
            "candidates": [asdict(x) for x in self.candidates.values()],
            "assessments": [asdict(x) for x in self.assessments.values()],
            "decisions": [asdict(x) for x in self.decisions.values()],
            "audit": self.audit.to_dict(),
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "ProcessPortfolio":
        obj = cls()
        for x in raw.get("methods", []):
            d = dict(x)
            for key in ("capabilities", "preconditions", "contraindications", "strengths", "failure_modes", "evidence_roots"):
                d[key] = tuple(d.get(key, ()))
            row = ProcessMethod(**d); obj.methods[row.method_id] = row
        for x in raw.get("tasks", []):
            d = dict(x)
            for key in ("required_capabilities", "mandatory_capabilities", "success_observations", "failure_observations"):
                d[key] = tuple(d.get(key, ()))
            row = ProcessTaskProfile(**d); obj.tasks[row.task_id] = row
        for x in raw.get("candidates", []):
            d = dict(x); d["method_ids"] = tuple(d.get("method_ids", ()))
            row = ProcessCandidate(**d); obj.candidates[row.candidate_id] = row
        for x in raw.get("assessments", []):
            d = dict(x)
            for key in ("method_ids", "satisfied_capabilities", "missing_capabilities", "missing_mandatory", "invalid_preconditions", "evidence_roots"):
                d[key] = tuple(d.get(key, ()))
            row = ProcessAssessment(**d); obj.assessments[row.assessment_id] = row
        for x in raw.get("decisions", []):
            d = dict(x)
            for key in ("candidate_ids", "frontier_ids", "execution_profile_ids"):
                d[key] = tuple(d.get(key, ()))
            row = ProcessDecision(**d); obj.decisions[row.decision_id] = row
        obj.audit = EventLog.from_dict(raw.get("audit", {}))
        return obj


def default_process_methods() -> Tuple[ProcessMethod, ...]:
    """Mechanism contracts from the Stage 4D-B process comparison.

    Values are structural priors used to expose trade-offs, not empirical
    performance estimates.  Stage 5 must replace them with externally observed
    outcomes where possible.
    """
    return (
        ProcessMethod(
            "arc5", "ARC-5 subtractive discovery", "field-lineage",
            ("dual_posiwid", "broad_search", "functional_decomposition", "abstraction_search",
             "multiple_hypotheses", "preregistered_contact", "recursive_revision"),
            (), (),
            ("broad mechanism discovery", "low-to-medium process overhead", "reopens failed layers"),
            ("common framing can weaken opposition", "single abstraction lattice can hide alternatives"),
            ("field-lineage",),
            {"field_coverage": .78, "falsification_strength": .72, "formal_soundness": .35,
             "contact_efficiency": .58, "artifact_feedback": .55, "adversarial_independence": .42,
             "whole_system_fit": .78, "self_sealing_risk": .38}, .48, .42, "stage4d-b"),
        ProcessMethod(
            "arc5a", "ARC-5A adversarial bifurcated discovery", "field-lineage",
            ("dual_posiwid", "broad_search", "independent_field_models", "dual_decomposition",
             "dual_abstraction", "multiple_hypotheses", "pareto_frontier", "dual_test_authorship",
             "decision_saturation", "preregistered_contact", "recursive_revision"),
            (), (),
            ("ill-structured open-world discovery", "strong structural opposition", "whole-system effects"),
            ("high overhead", "independence can be nominal", "does not supply domain verifier or experiment model"),
            ("field-lineage", "adversarial-process"),
            {"field_coverage": .92, "falsification_strength": .88, "formal_soundness": .45,
             "contact_efficiency": .58, "artifact_feedback": .60, "adversarial_independence": .82,
             "whole_system_fit": .92, "self_sealing_risk": .18}, .88, .82, "stage4d-b"),
        ProcessMethod(
            "systematic_evidence", "Systematic evidence synthesis", "evidence-synthesis",
            ("broad_search", "eligibility_contract", "study_deduplication", "bias_assessment",
             "reproducible_search", "evidence_synthesis"),
            ("retrievable_evidence",), (),
            ("high-recall evidence field", "report/study separation", "reproducible screening"),
            ("does not by itself design artifacts", "published evidence can be biased or inapplicable"),
            ("cochrane", "prisma"),
            {"field_coverage": .95, "falsification_strength": .55, "formal_soundness": .45,
             "contact_efficiency": .42, "artifact_feedback": .20, "adversarial_independence": .70,
             "whole_system_fit": .60, "self_sealing_risk": .22}, .72, .78, "stage4d-b"),
        ProcessMethod(
            "cegar", "Counterexample-guided abstraction refinement", "formal-verification",
            ("formal_abstraction", "independent_checker", "counterexample_refinement",
             "spurious_counterexample_test", "formal_termination_condition"),
            ("formal_model_available",), (),
            ("sound property-directed refinement", "precise failure localization", "automatable loop"),
            ("requires formal semantics", "state explosion", "poor fit for open-world evidence acquisition"),
            ("cegar",),
            {"field_coverage": .18, "falsification_strength": .93, "formal_soundness": .98,
             "contact_efficiency": .78, "artifact_feedback": .68, "adversarial_independence": .72,
             "whole_system_fit": .38, "self_sealing_risk": .12}, .46, .18, "stage4d-b"),
        ProcessMethod(
            "bayesian_design", "Bayesian experimental design", "experimental-design",
            ("probabilistic_hypotheses", "expected_information_gain", "adaptive_experiment_selection",
             "posterior_update", "cost_sensitive_contact"),
            ("experimentable", "probabilistic_model_available"), (),
            ("efficient expensive-contact allocation", "uncertainty-aware adaptation"),
            ("prior/model misspecification", "information gain may not match decision value"),
            ("lindley", "bayesian-design"),
            {"field_coverage": .20, "falsification_strength": .72, "formal_soundness": .62,
             "contact_efficiency": .97, "artifact_feedback": .42, "adversarial_independence": .48,
             "whole_system_fit": .52, "self_sealing_risk": .30}, .50, .32, "stage4d-b"),
        ProcessMethod(
            "mwh_adversarial", "Multiple working hypotheses + adversarial collaboration", "empirical-dispute",
            ("multiple_hypotheses", "rival_authorship", "joint_test_design", "neutral_moderation",
             "preregistered_contact"),
            ("rival_camps_available",), (),
            ("reduces parental attachment", "strongest opponent participates", "jointly acceptable decisive tests"),
            ("high human coordination cost", "strategic behavior", "no guarantee rivals span the field"),
            ("chamberlin", "adversarial-collaboration"),
            {"field_coverage": .52, "falsification_strength": .92, "formal_soundness": .38,
             "contact_efficiency": .66, "artifact_feedback": .35, "adversarial_independence": .96,
             "whole_system_fit": .64, "self_sealing_risk": .14}, .76, .98, "stage4d-b"),
        ProcessMethod(
            "design_science", "Design science build-evaluate cycles", "artifact-design",
            ("artifact_build", "relevance_cycle", "rigor_cycle", "build_evaluate", "operational_validation"),
            ("artifact_buildable", "evaluation_environment_available"), (),
            ("direct artifact improvement", "iterative relevance and evaluation", "operational utility"),
            ("can overfit local setting", "evaluation criteria can be self-authored"),
            ("design-science", "systems-engineering"),
            {"field_coverage": .46, "falsification_strength": .65, "formal_soundness": .48,
             "contact_efficiency": .62, "artifact_feedback": .96, "adversarial_independence": .42,
             "whole_system_fit": .75, "self_sealing_risk": .34}, .68, .50, "stage4d-b"),
        ProcessMethod(
            "minimal_scientific", "Preregistered minimal scientific loop", "scientific-method",
            ("hypothesis", "prediction", "experiment", "revision", "preregistered_contact"),
            (), (),
            ("low overhead", "clear empirical falsifier", "widely applicable bounded loop"),
            ("weak field coverage", "single-hypothesis attachment", "poor support for architecture search"),
            ("scientific-method",),
            {"field_coverage": .24, "falsification_strength": .74, "formal_soundness": .35,
             "contact_efficiency": .64, "artifact_feedback": .35, "adversarial_independence": .30,
             "whole_system_fit": .38, "self_sealing_risk": .40}, .18, .15, "stage4d-b"),
        ProcessMethod(
            "domain_native", "Unconstrained domain-native/ad hoc process", "null",
            ("domain_expertise",), (), (),
            ("minimal coordination overhead", "may exploit tacit expertise"),
            ("unreproducible", "high framing bias", "no guaranteed opposition or audit"),
            ("null-baseline",),
            {"field_coverage": .20, "falsification_strength": .25, "formal_soundness": .20,
             "contact_efficiency": .45, "artifact_feedback": .50, "adversarial_independence": .12,
             "whole_system_fit": .28, "self_sealing_risk": .82}, .08, .08, "stage4d-b"),
    )


def seeded_process_portfolio() -> ProcessPortfolio:
    obj = ProcessPortfolio()
    for method in default_process_methods():
        obj.register_method(method)
    return obj
