"""Secure, replayable acquisition and parsing.

This organ retrieves actual artifacts, stores immutable bytes, and parses them
without granting truth authority.  Acquisition proves only what bytes were
obtained and how they were transformed.
"""
from __future__ import annotations

import csv
import hashlib
import io
import ipaddress
import json
import mimetypes
import os
import re
import socket
import time
import urllib.parse
import urllib.request
import uuid
from dataclasses import asdict, dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from typing import Dict, Mapping, Optional, Protocol, Sequence, Tuple


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


class AcquisitionError(RuntimeError):
    pass


@dataclass(frozen=True)
class FetchPolicy:
    allowed_schemes: Tuple[str, ...] = ("file", "https")
    max_bytes: int = 20_000_000
    timeout_seconds: float = 20.0
    allow_private_network: bool = False
    allowed_file_roots: Tuple[str, ...] = ()
    max_redirects: int = 5
    allowed_media_prefixes: Tuple[str, ...] = (
        "text/", "application/json", "application/xml", "application/pdf",
        "application/xhtml+xml", "text/csv", "image/",
    )


@dataclass
class ArtifactReceipt:
    artifact_id: str
    locator: str
    content_sha256: str
    size_bytes: int
    media_type: str
    retrieved_at: float
    transport: str
    store_path: str
    status: str = "acquired"
    warnings: Tuple[str, ...] = ()
    headers: Mapping[str, str] = field(default_factory=dict)


@dataclass
class ParseReceipt:
    parse_id: str
    artifact_id: str
    parser: str
    parser_version: str
    text_sha256: str
    text_length: int
    status: str
    warnings: Tuple[str, ...] = ()
    metadata: Mapping[str, object] = field(default_factory=dict)


@dataclass
class ParsedArtifact:
    artifact: ArtifactReceipt
    parse: ParseReceipt
    text: str


class BytesStore:
    def __init__(self, root: str | os.PathLike[str]):
        self.root = Path(root)
        self.blobs = self.root / "blobs"
        self.meta = self.root / "metadata"
        self.blobs.mkdir(parents=True, exist_ok=True)
        self.meta.mkdir(parents=True, exist_ok=True)

    def put(self, data: bytes, metadata: Mapping[str, object]) -> tuple[str, Path]:
        digest = hashlib.sha256(data).hexdigest()
        path = self.blobs / digest
        if path.exists() and path.read_bytes() != data:
            raise AcquisitionError("SHA-256 collision or corrupted store")
        if not path.exists():
            tmp = path.with_suffix(".tmp")
            tmp.write_bytes(data)
            os.replace(tmp, path)
        mp = self.meta / f"{digest}.json"
        records = json.loads(mp.read_text()) if mp.exists() else []
        record = dict(metadata)
        if record not in records:
            records.append(record)
            mp.write_text(json.dumps(records, indent=2, sort_keys=True))
        return digest, path

    def get(self, digest: str) -> bytes:
        path = self.blobs / digest
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != digest:
            raise AcquisitionError("stored artifact digest mismatch")
        return data

    def verify(self) -> dict:
        invalid = []
        for p in self.blobs.glob("*"):
            if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() != p.name:
                invalid.append(p.name)
        return {"valid": not invalid, "blobs": len(list(self.blobs.glob('*'))), "invalid": invalid}


class _HTMLText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self.links: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style", "noscript"}:
            self._skip += 1
        if tag == "a":
            for k, v in attrs:
                if k == "href" and v:
                    self.links.append(v)

    def handle_endtag(self, tag):
        if tag in {"script", "style", "noscript"} and self._skip:
            self._skip -= 1

    def handle_data(self, data):
        if not self._skip and data.strip():
            self.parts.append(data.strip())


class ArtifactParser(Protocol):
    name: str
    version: str
    def supports(self, media_type: str, locator: str) -> bool: ...
    def parse(self, data: bytes, media_type: str, locator: str) -> tuple[str, Mapping[str, object], Sequence[str]]: ...


class TextParser:
    name, version = "text", "1"
    def supports(self, media_type, locator): return media_type.startswith("text/") and "html" not in media_type and "csv" not in media_type
    def parse(self, data, media_type, locator): return data.decode("utf-8", errors="replace"), {}, ()


class JSONParser:
    name, version = "json", "1"
    def supports(self, media_type, locator): return "json" in media_type or locator.lower().endswith((".json", ".jsonl"))
    def parse(self, data, media_type, locator):
        text = data.decode("utf-8", errors="replace")
        try:
            obj = json.loads(text)
            return json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False), {"root_type": type(obj).__name__}, ()
        except json.JSONDecodeError:
            rows = []
            for i, line in enumerate(text.splitlines(), 1):
                if line.strip(): rows.append(json.loads(line))
            return "\n".join(json.dumps(x, sort_keys=True, ensure_ascii=False) for x in rows), {"records": len(rows)}, ("parsed as JSON Lines",)


class CSVParser:
    name, version = "csv", "1"
    def supports(self, media_type, locator): return "csv" in media_type or locator.lower().endswith((".csv", ".tsv"))
    def parse(self, data, media_type, locator):
        text = data.decode("utf-8", errors="replace")
        dialect = csv.excel_tab if locator.lower().endswith(".tsv") else csv.excel
        rows = list(csv.reader(io.StringIO(text), dialect=dialect))
        normalized = "\n".join(" | ".join(cell.strip() for cell in row) for row in rows)
        return normalized, {"rows": len(rows), "columns_max": max((len(r) for r in rows), default=0)}, ()


class HTMLArtifactParser:
    name, version = "html", "2"
    def supports(self, media_type, locator): return "html" in media_type or locator.lower().endswith((".html", ".htm"))
    def parse(self, data, media_type, locator):
        raw = data.decode("utf-8", errors="replace")
        p = _HTMLText(); p.feed(raw)
        headings, tables = [], []
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(raw, "html.parser")
            headings = [{"level": int(x.name[1]), "text": x.get_text(" ", strip=True)}
                        for x in soup.find_all(["h1", "h2", "h3", "h4", "h5", "h6"])]
            for table in soup.find_all("table")[:200]:
                rows = []
                for tr in table.find_all("tr"):
                    cells = [c.get_text(" ", strip=True) for c in tr.find_all(["th", "td"])]
                    if cells: rows.append(cells)
                if rows: tables.append(rows)
        except Exception:
            pass
        return "\n".join(p.parts), {"links": tuple(p.links), "headings": headings, "tables": tables}, ()


class XMLParser:
    name, version = "xml", "2"
    def supports(self, media_type, locator): return "xml" in media_type or locator.lower().endswith(".xml")
    def parse(self, data, media_type, locator):
        # ElementTree does not fetch external entities, but reject declarations
        # anyway so entity-expansion and format ambiguity never become a hidden
        # parser capability.
        upper = data[:200_000].upper()
        if b"<!DOCTYPE" in upper or b"<!ENTITY" in upper:
            raise AcquisitionError("DTD/entity declarations are forbidden")
        from xml.etree import ElementTree as ET
        root = ET.fromstring(data)
        parts = [x.strip() for x in root.itertext() if x and x.strip()]
        return "\n".join(parts), {"root_tag": root.tag}, ()


class PDFParser:
    name, version = "pymupdf+pypdf", "3"
    def supports(self, media_type, locator): return media_type == "application/pdf" or locator.lower().endswith(".pdf")
    def parse(self, data, media_type, locator):
        warnings = []
        try:
            import fitz
            doc = fitz.open(stream=data, filetype="pdf")
            if doc.page_count > 500:
                raise AcquisitionError("PDF page count exceeds parser limit")
            pages, total = [], 0
            for index, page in enumerate(doc):
                text = page.get_text("text") or ""
                total += len(text)
                if total > 5_000_000:
                    raise AcquisitionError("PDF extracted text exceeds parser limit")
                blocks = []
                for b in page.get_text("blocks")[:5000]:
                    blocks.append({"bbox": [round(float(x), 3) for x in b[:4]],
                                   "text": str(b[4]), "block_no": int(b[5]), "block_type": int(b[6])})
                tables = []
                try:
                    finder = page.find_tables()
                    for table in finder.tables[:100]:
                        extracted = table.extract()
                        if extracted: tables.append(extracted)
                except Exception as exc:
                    warnings.append(f"page {index+1} table extraction: {type(exc).__name__}")
                pages.append({"page": index + 1, "width": float(page.rect.width),
                              "height": float(page.rect.height), "text": text,
                              "blocks": blocks, "tables": tables,
                              "images": len(page.get_images(full=True))})
            return "\n\n".join(x["text"] for x in pages), {"page_count": doc.page_count, "pages": pages}, tuple(warnings)
        except ImportError:
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(data), strict=False)
            if len(reader.pages) > 500:
                raise AcquisitionError("PDF page count exceeds parser limit")
            pages, total = [], 0
            for i, page in enumerate(reader.pages):
                try:
                    text = page.extract_text() or ""; total += len(text)
                    if total > 5_000_000: raise AcquisitionError("PDF extracted text exceeds parser limit")
                    pages.append({"page": i+1, "text": text, "blocks": [], "tables": [], "images": 0})
                except Exception as exc: warnings.append(f"page {i+1}: {type(exc).__name__}")
            return "\n\n".join(x["text"] for x in pages), {"page_count": len(reader.pages), "pages": pages}, tuple(warnings)


class ImageParser:
    name, version = "pillow-metadata", "1"
    def supports(self, media_type, locator):
        return media_type.startswith("image/") or locator.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff"))
    def parse(self, data, media_type, locator):
        from PIL import Image
        image = Image.open(io.BytesIO(data))
        image.verify()
        image = Image.open(io.BytesIO(data))
        exif = {}
        try:
            exif = {str(k): str(v) for k, v in image.getexif().items()}
        except Exception:
            pass
        meta = {"width": image.width, "height": image.height, "mode": image.mode,
                "format": image.format, "frames": getattr(image, "n_frames", 1), "exif": exif}
        return "", meta, ("image pixels preserved; no OCR or semantic extraction was performed",)


class _PolicyRedirectHandler(urllib.request.HTTPRedirectHandler):
    def __init__(self, engine, policy):
        super().__init__()
        self.engine = engine
        self.policy = policy
        self.redirects = 0

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        self.redirects += 1
        if self.redirects > self.policy.max_redirects:
            raise AcquisitionError("redirect limit exceeded")
        self.engine._check_remote_url(newurl, self.policy)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class AcquisitionEngine:
    def __init__(self, root: str | os.PathLike[str]):
        self.root = Path(root); self.root.mkdir(parents=True, exist_ok=True)
        self.store = BytesStore(self.root / "artifacts")
        self.receipts: Dict[str, ArtifactReceipt] = {}
        self.parses: Dict[str, ParseReceipt] = {}
        self.parsers: list[ArtifactParser] = [JSONParser(), CSVParser(), HTMLArtifactParser(), XMLParser(), PDFParser(), ImageParser(), TextParser()]

    @staticmethod
    def _media(headers: Mapping[str, str], locator: str) -> str:
        raw = headers.get("content-type", "").split(";", 1)[0].strip().lower()
        return raw or mimetypes.guess_type(locator)[0] or "application/octet-stream"

    @staticmethod
    def _check_host(host: str, allow_private: bool) -> None:
        if not host:
            raise AcquisitionError("remote locator has no host")
        if allow_private:
            return
        try:
            infos = socket.getaddrinfo(host, None)
        except socket.gaierror as exc:
            raise AcquisitionError(f"cannot resolve host {host!r}") from exc
        for info in infos:
            ip = ipaddress.ip_address(info[4][0])
            if (ip.is_private or ip.is_loopback or ip.is_link_local or
                    ip.is_reserved or ip.is_multicast or ip.is_unspecified):
                raise AcquisitionError("private/non-routable network access denied by policy")

    @classmethod
    def _check_remote_url(cls, locator: str, policy: FetchPolicy) -> None:
        parsed = urllib.parse.urlparse(locator)
        if parsed.scheme.lower() not in policy.allowed_schemes:
            raise AcquisitionError(f"redirect scheme {parsed.scheme!r} is not allowed")
        if parsed.username or parsed.password:
            raise AcquisitionError("credentials in artifact URL are forbidden")
        cls._check_host(parsed.hostname or "", policy.allow_private_network)

    def acquire(self, locator: str, policy: FetchPolicy = FetchPolicy()) -> ParsedArtifact:
        parsed = urllib.parse.urlparse(locator)
        scheme = parsed.scheme.lower() or "file"
        if scheme not in policy.allowed_schemes:
            raise AcquisitionError(f"scheme {scheme!r} is not allowed")
        headers: Dict[str, str] = {}
        if scheme == "file":
            path = Path(urllib.request.url2pathname(parsed.path) if parsed.scheme else locator).resolve()
            if policy.allowed_file_roots:
                roots = tuple(Path(x).resolve() for x in policy.allowed_file_roots)
                if not any(path == root or root in path.parents for root in roots):
                    raise AcquisitionError("file locator is outside configured roots")
            if not path.is_file():
                raise AcquisitionError("file locator is not a regular file")
            data = path.read_bytes()
            transport = "filesystem"
        else:
            self._check_remote_url(locator, policy)
            req = urllib.request.Request(locator, headers={"User-Agent": "TheField/0.9 (+replayable-research)"})
            opener = urllib.request.build_opener(_PolicyRedirectHandler(self, policy))
            try:
                with opener.open(req, timeout=policy.timeout_seconds) as response:
                    final_url = response.geturl()
                    self._check_remote_url(final_url, policy)
                    headers = {str(k).lower(): str(v) for k, v in response.headers.items()}
                    length = int(headers.get("content-length", "0") or 0)
                    if length > policy.max_bytes:
                        raise AcquisitionError("artifact exceeds configured maximum")
                    data = response.read(policy.max_bytes + 1)
            except AcquisitionError:
                raise
            except Exception as exc:
                raise AcquisitionError(f"fetch failed: {type(exc).__name__}: {exc}") from exc
            if len(data) > policy.max_bytes:
                raise AcquisitionError("artifact exceeds configured maximum")
            transport = scheme
        if len(data) > policy.max_bytes:
            raise AcquisitionError("artifact exceeds configured maximum")
        media = self._media(headers, locator)
        if not any(media.startswith(p) for p in policy.allowed_media_prefixes):
            raise AcquisitionError(f"media type {media!r} is not allowed")
        digest, path = self.store.put(data, {"locator": locator, "media_type": media, "retrieved_at": time.time()})
        receipt = ArtifactReceipt(_id("ART"), locator, digest, len(data), media, time.time(), transport, str(path), headers=headers)
        parser = next((p for p in self.parsers if p.supports(media, locator)), None)
        if parser is None:
            raise AcquisitionError(f"no registered parser for {media!r}")
        try:
            text, meta, warnings = parser.parse(data, media, locator)
            status = "parsed"
        except Exception as exc:
            raise AcquisitionError(f"parser {parser.name} failed: {type(exc).__name__}: {exc}") from exc
        td = hashlib.sha256(text.encode("utf-8")).hexdigest()
        pr = ParseReceipt(_id("PAR"), receipt.artifact_id, parser.name, parser.version, td, len(text), status, tuple(warnings), dict(meta))
        self.receipts[receipt.artifact_id] = receipt; self.parses[pr.parse_id] = pr
        return ParsedArtifact(receipt, pr, text)

    def verify(self) -> dict:
        store = self.store.verify()
        missing = [r.artifact_id for r in self.receipts.values() if not Path(r.store_path).exists()]
        return {"valid": store["valid"] and not missing, "store": store, "missing": missing,
                "receipts": len(self.receipts), "parses": len(self.parses)}

    def to_dict(self) -> dict:
        return {"receipts": [asdict(x) for x in self.receipts.values()], "parses": [asdict(x) for x in self.parses.values()]}

    @classmethod
    def from_dict(cls, root, raw):
        obj = cls(root)
        obj.receipts = {x["artifact_id"]: ArtifactReceipt(**x) for x in raw.get("receipts", [])}
        obj.parses = {x["parse_id"]: ParseReceipt(**x) for x in raw.get("parses", [])}
        return obj
