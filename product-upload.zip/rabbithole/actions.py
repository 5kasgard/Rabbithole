"""Capability-secured transactional external action registry.

Action permission is separate from epistemic authority.  The registry enforces
least privilege, preconditions, approval, idempotency, monitoring and explicit
compensation where possible.  Irreversible actions cannot pretend to have a
rollback path.
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Callable, Dict, Mapping, Optional

from .capabilities import CapabilityIssuer
from .wal import EventLog


@dataclass
class ActionSpec:
    action_id: str
    resource: str
    reversible: bool
    dry_run_supported: bool
    required_approval: str  # none|user|two_person|policy
    execute: Callable[[Mapping[str, object], bool], Mapping[str, object]]
    compensate: Optional[Callable[[Mapping[str, object]], Mapping[str, object]]] = None
    precondition: Optional[Callable[[Mapping[str, object]], tuple[bool, str]]] = None
    monitor: Optional[Callable[[Mapping[str, object]], Mapping[str, object]]] = None
    risk_tier: str = "low"
    idempotent: bool = True


@dataclass
class ActionReceipt:
    action_id: str
    resource: str
    request: Mapping[str, object]
    dry_run: bool
    status: str
    output: Mapping[str, object]
    reversible: bool
    approval: str
    started_at: float
    ended_at: float
    request_digest: str = ""
    idempotency_key: str = ""
    precondition: str = ""
    monitoring: Mapping[str, object] = field(default_factory=dict)
    compensated: bool = False
    compensation: Mapping[str, object] = field(default_factory=dict)
    rid: str = field(default_factory=lambda: f"ACT{uuid.uuid4().hex[:12]}")


class ActionRegistry:
    def __init__(self, capabilities: Optional[CapabilityIssuer] = None):
        self.capabilities = capabilities or CapabilityIssuer()
        self.actions: Dict[str, ActionSpec] = {}
        self.receipts: Dict[str, ActionReceipt] = {}
        self.idempotency: Dict[str, str] = {}
        self.audit = EventLog()

    @staticmethod
    def _digest(action_id: str, request: Mapping[str, object]) -> str:
        return hashlib.sha256(json.dumps({"action_id": action_id, "request": request},
                                         sort_keys=True, default=str,
                                         separators=(",", ":")).encode()).hexdigest()

    def register(self, spec: ActionSpec) -> None:
        if spec.action_id in self.actions:
            raise ValueError(f"action {spec.action_id!r} already registered")
        if spec.required_approval not in {"none", "user", "two_person", "policy"}:
            raise ValueError("unknown approval policy")
        if spec.risk_tier not in {"low", "medium", "high", "critical"}:
            raise ValueError("unknown risk tier")
        if not spec.reversible and spec.compensate is not None:
            raise ValueError("irreversible action cannot claim a compensator")
        if not spec.reversible and spec.required_approval == "none":
            raise ValueError("irreversible action requires accountable approval")
        self.actions[spec.action_id] = spec
        self.audit.append("action_registered", {
            "action_id": spec.action_id, "resource": spec.resource,
            "reversible": spec.reversible, "dry_run_supported": spec.dry_run_supported,
            "required_approval": spec.required_approval, "risk_tier": spec.risk_tier,
            "idempotent": spec.idempotent,
        })

    def run(self, action_id: str, request: Mapping[str, object], *, holder: str,
            capability: dict, dry_run: bool = True, approval: str = "none",
            idempotency_key: str = "") -> ActionReceipt:
        if action_id not in self.actions:
            raise KeyError(action_id)
        spec = self.actions[action_id]
        if not self.capabilities.check(capability, "execute_action", spec.resource, holder=holder):
            raise PermissionError("action capability denied")
        if dry_run and not spec.dry_run_supported:
            raise ValueError("action does not support dry-run")
        if not dry_run and spec.required_approval != "none" and approval != spec.required_approval:
            raise PermissionError(f"action requires approval {spec.required_approval!r}")
        digest = self._digest(action_id, request)
        key = idempotency_key or digest
        if not dry_run and spec.idempotent and key in self.idempotency:
            return self.receipts[self.idempotency[key]]
        precondition_text = "not configured"
        if spec.precondition is not None:
            ok, precondition_text = spec.precondition(request)
            if not ok:
                receipt = ActionReceipt(action_id, spec.resource, dict(request), dry_run,
                                        "precondition_failed", {}, spec.reversible, approval,
                                        time.time(), time.time(), digest, key, precondition_text)
                self.receipts[receipt.rid] = receipt
                self.audit.append("action_precondition_failed", asdict(receipt))
                return receipt
        start = time.time()
        try:
            output = dict(spec.execute(request, dry_run))
            status = "dry_run" if dry_run else "executed"
        except Exception as exc:
            output = {"error": f"{type(exc).__name__}: {exc}"}
            status = "failed"
        monitoring = {}
        if status == "executed" and spec.monitor is not None:
            try:
                monitoring = dict(spec.monitor(output))
                if monitoring.get("ok") is False:
                    status = "monitor_failed"
            except Exception as exc:
                monitoring = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
                status = "monitor_failed"
        receipt = ActionReceipt(action_id, spec.resource, dict(request), dry_run,
                                status, output, spec.reversible, approval,
                                start, time.time(), digest, key, precondition_text,
                                monitoring)
        self.receipts[receipt.rid] = receipt
        if not dry_run and spec.idempotent and status in {"executed", "monitor_failed"}:
            self.idempotency[key] = receipt.rid
        self.audit.append("action_executed", asdict(receipt))
        return receipt

    def compensate(self, receipt_id: str, *, holder: str, capability: dict) -> Mapping[str, object]:
        receipt = self.receipts[receipt_id]
        spec = self.actions[receipt.action_id]
        if receipt.compensated:
            return receipt.compensation
        if not receipt.reversible or spec.compensate is None:
            raise ValueError("action is not compensatable")
        if not self.capabilities.check(capability, "execute_action", spec.resource, holder=holder):
            raise PermissionError("action capability denied")
        result = dict(spec.compensate(receipt.output))
        receipt.compensated = True
        receipt.compensation = result
        receipt.status = "compensated"
        self.audit.append("action_compensated", {"receipt_id": receipt_id, "result": result})
        return result
