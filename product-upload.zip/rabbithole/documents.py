"""Representation-preserving document IR and source-traceable carving."""
from __future__ import annotations

import hashlib
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Sequence, Tuple

from .acquisition import ParsedArtifact
from .wal import EventLog


def _id(prefix:str)->str:return f"{prefix}{uuid.uuid4().hex[:12]}"

@dataclass(frozen=True)
class SourceRegion:
    artifact_id:str
    parse_id:str
    modality:str
    page:int=0
    bbox:Tuple[float,float,float,float]=()
    row:int=-1
    column:int=-1
    char_start:int=-1
    char_end:int=-1
    region_digest:str=""
    region_id:str=field(default_factory=lambda:_id("REG"))

@dataclass(frozen=True)
class DocumentNode:
    kind:str
    content:str
    region_id:str
    parent_id:str=""
    attributes:Mapping[str,object]=field(default_factory=dict)
    node_id:str=field(default_factory=lambda:_id("NOD"))

@dataclass
class DocumentIR:
    artifact_id:str
    parse_id:str
    media_type:str
    nodes:Tuple[DocumentNode,...]
    regions:Tuple[SourceRegion,...]
    warnings:Tuple[str,...]=()
    structural_coverage:Mapping[str,int]=field(default_factory=dict)
    created_at:float=field(default_factory=time.time)
    document_id:str=field(default_factory=lambda:_id("DOC"))

@dataclass(frozen=True)
class CarvingProposal:
    document_id:str
    claim_text:str
    claim_class:str
    region_ids:Tuple[str,...]
    scope:Mapping[str,object]=field(default_factory=dict)
    extractor_id:str="deterministic"
    status:str="proposed"  # proposed|abstained|rejected
    abstention_reason:str=""
    authority_ceiling:float=0.0
    carving_id:str=field(default_factory=lambda:_id("CRV"))

class DocumentIRRegistry:
    def __init__(self):
        self.documents:Dict[str,DocumentIR]={};self.carvings:Dict[str,CarvingProposal]={};self.audit=EventLog()

    @staticmethod
    def _region(artifact_id:str,parse_id:str,modality:str,content:str,**kwargs)->SourceRegion:
        digest=hashlib.sha256(content.encode("utf-8",errors="replace")).hexdigest()
        return SourceRegion(artifact_id,parse_id,modality,region_digest=digest,**kwargs)

    def build(self,parsed:ParsedArtifact)->DocumentIR:
        meta=dict(parsed.parse.metadata);regions=[];nodes=[]
        # PDF preserves pages, blocks, tables, and image counts.
        for page in meta.get("pages",()) or ():
            p=int(page.get("page",0));page_text=str(page.get("text",""))
            pr=self._region(parsed.artifact.artifact_id,parsed.parse.parse_id,"page",page_text,page=p)
            regions.append(pr);pn=DocumentNode("page",page_text,pr.region_id,attributes={"page":p,"width":page.get("width"),"height":page.get("height")});nodes.append(pn)
            for block in page.get("blocks",()) or ():
                text=str(block.get("text",""));bbox=tuple(float(x) for x in block.get("bbox",()))
                br=self._region(parsed.artifact.artifact_id,parsed.parse.parse_id,"text-block",text,page=p,bbox=bbox if len(bbox)==4 else ())
                regions.append(br);nodes.append(DocumentNode("text-block",text,br.region_id,pn.node_id,{"page":p,"block_type":block.get("block_type")}))
            for ti,table in enumerate(page.get("tables",()) or ()):
                parent=""
                for ri,row in enumerate(table):
                    for ci,cell in enumerate(row):
                        text="" if cell is None else str(cell)
                        rr=self._region(parsed.artifact.artifact_id,parsed.parse.parse_id,"table-cell",text,page=p,row=ri,column=ci)
                        regions.append(rr);nodes.append(DocumentNode("table-cell",text,rr.region_id,pn.node_id,{"page":p,"table":ti,"row":ri,"column":ci}))
            for ii in range(int(page.get("images",0) or 0)):
                rr=self._region(parsed.artifact.artifact_id,parsed.parse.parse_id,"image","",page=p)
                regions.append(rr);nodes.append(DocumentNode("image","",rr.region_id,pn.node_id,{"page":p,"image_index":ii,"semantic_status":"unparsed"}))
        # HTML tables/headings and CSV table metadata.
        if not nodes:
            text=parsed.text
            rr=self._region(parsed.artifact.artifact_id,parsed.parse.parse_id,"text",text,char_start=0,char_end=len(text))
            regions.append(rr);nodes.append(DocumentNode("text",text,rr.region_id))
            for hi,h in enumerate(meta.get("headings",()) or ()):
                content=str(h.get("text",""));hr=self._region(parsed.artifact.artifact_id,parsed.parse.parse_id,"heading",content)
                regions.append(hr);nodes.append(DocumentNode("heading",content,hr.region_id,attributes={"level":h.get("level"),"index":hi}))
            for ti,table in enumerate(meta.get("tables",()) or ()):
                for ri,row in enumerate(table):
                    for ci,cell in enumerate(row):
                        content="" if cell is None else str(cell);tr=self._region(parsed.artifact.artifact_id,parsed.parse.parse_id,"table-cell",content,row=ri,column=ci)
                        regions.append(tr);nodes.append(DocumentNode("table-cell",content,tr.region_id,attributes={"table":ti,"row":ri,"column":ci}))
        coverage={k:sum(1 for n in nodes if n.kind==k) for k in sorted({n.kind for n in nodes})}
        doc=DocumentIR(parsed.artifact.artifact_id,parsed.parse.parse_id,parsed.artifact.media_type,tuple(nodes),tuple(regions),parsed.parse.warnings,coverage)
        self.documents[doc.document_id]=doc;self.audit.append("document_ir_built",asdict(doc));return doc

    def propose(self,document_id:str,claim_text:str,claim_class:str,region_ids:Sequence[str],*,scope:Mapping[str,object]|None=None,extractor_id:str="deterministic")->CarvingProposal:
        doc=self.documents[document_id];valid={r.region_id for r in doc.regions};regions=tuple(region_ids)
        if not claim_text.strip():
            c=CarvingProposal(document_id,"",claim_class,regions,dict(scope or {}),extractor_id,"abstained","empty claim")
        elif not regions or any(x not in valid for x in regions):
            c=CarvingProposal(document_id,claim_text,claim_class,regions,dict(scope or {}),extractor_id,"abstained","missing or invalid source region")
        else:
            c=CarvingProposal(document_id,claim_text,claim_class,regions,dict(scope or {}),extractor_id,"proposed","",0.0)
        self.carvings[c.carving_id]=c;self.audit.append("carving_proposed",asdict(c));return c

    def abstain_unparsed_images(self,document_id:str)->Tuple[CarvingProposal,...]:
        doc=self.documents[document_id];out=[]
        for node in doc.nodes:
            if node.kind=="image" and node.attributes.get("semantic_status")=="unparsed":
                c=CarvingProposal(document_id,"","unknown",(node.region_id,),{},"no-vlm","abstained","image semantics unavailable",0.0)
                self.carvings[c.carving_id]=c;out.append(c);self.audit.append("carving_abstained",asdict(c))
        return tuple(out)

    def trace(self,carving_id:str)->dict:
        c=self.carvings[carving_id];doc=self.documents[c.document_id];reg={r.region_id:asdict(r) for r in doc.regions}
        return {"carving":asdict(c),"regions":[reg[x] for x in c.region_ids if x in reg],"traceable":all(x in reg for x in c.region_ids)}

    def to_dict(self)->dict:return {"documents":[asdict(x) for x in self.documents.values()],"carvings":[asdict(x) for x in self.carvings.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw:Mapping[str,object])->"DocumentIRRegistry":
        obj=cls()
        for row in raw.get("documents",[]):
            d=dict(row);d["nodes"]=tuple(DocumentNode(**({**n,"attributes":dict(n.get("attributes",{}))})) for n in d.get("nodes",()))
            d["regions"]=tuple(SourceRegion(**({**r,"bbox":tuple(r.get("bbox",()))})) for r in d.get("regions",()));d["warnings"]=tuple(d.get("warnings",()))
            doc=DocumentIR(**d);obj.documents[doc.document_id]=doc
        for row in raw.get("carvings",[]):
            d=dict(row);d["region_ids"]=tuple(d.get("region_ids",()));c=CarvingProposal(**d);obj.carvings[c.carving_id]=c
        obj.audit=EventLog.from_dict(raw.get("audit",{}));return obj
