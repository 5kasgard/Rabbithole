"""Stage 5 independent longitudinal validation ledger and analysis gate.

This module completes the executable protocol for external validation without
pretending to supply time, private challenges, independent evaluators, or future
outcomes.  A study can be preregistered, content-digested, populated
with evaluator/challenge/prediction/outcome receipts, analysed by a frozen paired
plan, and promoted only after duration, coverage, independence, contamination,
safety, utility, calibration, cost, and maintenance gates pass.

The ledger is append-only through the public API and uses a hash-chained
EventLog. Records are never
updated in place.  Corrections are new records that reference the superseded
record.  Identity and organisational independence are attestations unless an
external verifier is attached; the software therefore exposes those limits in
status rather than treating distinct strings as proof of independence. The
local chain is not a substitute for externally anchored state digests: a fully
privileged party could otherwise rewrite the complete ledger and recompute it.
"""
from __future__ import annotations

import hashlib
import json
import math
import random
import statistics
import time
import uuid
from collections import Counter
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, Mapping, Sequence, Tuple

from .wal import EventLog


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


def _canon(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False, default=str).encode("utf-8")


def _digest(value: object) -> str:
    return hashlib.sha256(_canon(value)).hexdigest()


def _resource_ratio(numerator: float, denominator: float) -> float:
    """Return a comparison ratio without turning 0/0 into a free pass.

    Equal zero observations are treated as parity. A non-zero primary cost
    against a genuinely zero comparator cost is unbounded.
    """
    if denominator == 0.0:
        return 1.0 if numerator == 0.0 else math.inf
    return numerator / denominator


@dataclass(frozen=True)
class ValidationProtocol:
    study_id: str
    title: str
    target_claim: str
    arms: Tuple[str, ...]
    primary_arm: str
    comparator_arms: Tuple[str, ...]
    primary_endpoints: Tuple[str, ...]
    secondary_endpoints: Tuple[str, ...]
    domains: Tuple[str, ...]
    minimum_duration_days: int
    minimum_challenges: int
    minimum_evaluators: int
    minimum_evaluator_organisations: int
    minimum_challenges_per_evaluator: int
    maximum_evaluator_fraction: float
    maximum_organisation_fraction: float
    minimum_domains: int
    minimum_challenges_per_domain: int
    minimum_shift_fraction: float
    critical_error_noninferiority_margin: float
    utility_superiority_margin: float
    confidence_level: float
    maximum_cost_ratio: float
    maximum_human_burden_ratio: float
    required_external_reviews: Tuple[str, ...]
    exclusion_rules: Tuple[str, ...]
    stopping_rules: Tuple[str, ...]
    analysis_plan: str
    developer_ids: Tuple[str, ...]
    protocol_author: str
    administrator_role: str
    registered_at: float = field(default_factory=time.time)
    protocol_digest: str = ""

    def material(self) -> dict:
        raw = asdict(self)
        raw.pop("protocol_digest", None)
        return raw

    def validate(self) -> None:
        if not self.study_id or not self.title or not self.target_claim:
            raise ValueError("validation protocol requires id, title and claim")
        if len(self.arms) < 2 or len(set(self.arms)) != len(self.arms) or self.primary_arm not in self.arms:
            raise ValueError("protocol requires unique primary and comparator arms")
        if set(self.comparator_arms) != set(self.arms) - {self.primary_arm}:
            raise ValueError("every non-primary arm must be a frozen comparator")
        if self.minimum_duration_days < 1 or self.minimum_challenges < 2:
            raise ValueError("longitudinal protocol requires duration and repeated challenges")
        if min(self.minimum_evaluators, self.minimum_evaluator_organisations,
               self.minimum_challenges_per_evaluator, self.minimum_domains,
               self.minimum_challenges_per_domain) < 1:
            raise ValueError("invalid evaluator/domain minimum")
        if not 0.0 < self.maximum_evaluator_fraction <= 1.0:
            raise ValueError("maximum evaluator fraction must be in (0,1]")
        if self.maximum_evaluator_fraction < 1.0 / self.minimum_evaluators:
            raise ValueError("maximum evaluator fraction is incompatible with evaluator minimum")
        if not 0.0 < self.maximum_organisation_fraction <= 1.0:
            raise ValueError("maximum organisation fraction must be in (0,1]")
        if self.minimum_evaluator_organisations > self.minimum_evaluators:
            raise ValueError("organisation minimum cannot exceed evaluator minimum")
        if self.maximum_organisation_fraction < 1.0 / self.minimum_evaluator_organisations:
            raise ValueError("maximum organisation fraction is incompatible with organisation minimum")
        if self.minimum_challenges < self.minimum_evaluators * self.minimum_challenges_per_evaluator:
            raise ValueError("challenge minimum cannot satisfy evaluator repetition minimum")
        if self.minimum_challenges < self.minimum_domains * self.minimum_challenges_per_domain:
            raise ValueError("challenge minimum cannot satisfy domain repetition minimum")
        if len(set(self.domains)) != len(self.domains) or self.minimum_domains > len(self.domains):
            raise ValueError("invalid or duplicate domain registry")
        if len(set(self.required_external_reviews)) != len(self.required_external_reviews):
            raise ValueError("external review tags must be unique")
        if not 0.0 <= self.minimum_shift_fraction <= 1.0:
            raise ValueError("shift fraction must be in [0,1]")
        if not -1.0 <= self.critical_error_noninferiority_margin <= 1.0:
            raise ValueError("critical-error margin must be in [-1,1]")
        if not 0.0 <= self.utility_superiority_margin <= 1.0:
            raise ValueError("utility margin must be in [0,1]")
        if not 0.5 < self.confidence_level < 1.0:
            raise ValueError("confidence level must be in (0.5,1)")
        if self.maximum_cost_ratio <= 0 or self.maximum_human_burden_ratio <= 0:
            raise ValueError("resource ratios must be positive")
        if not self.primary_endpoints or not self.analysis_plan or not self.stopping_rules:
            raise ValueError("protocol requires endpoints, analysis and stopping rules")
        expected = _digest(self.material())
        if self.protocol_digest and self.protocol_digest != expected:
            raise ValueError("protocol digest mismatch")

    def frozen(self) -> "ValidationProtocol":
        raw = self.material()
        return ValidationProtocol(**raw, protocol_digest=_digest(raw))


@dataclass(frozen=True)
class ArmCommitment:
    arm: str
    artifact_digest: str
    runtime_profile_digest: str
    resource_policy_digest: str
    committed_by: str
    timestamp_receipt_digest: str = ""
    committed_at: float = field(default_factory=time.time)
    commitment_digest: str = ""

    def material(self) -> dict:
        raw = asdict(self)
        raw.pop("commitment_digest", None)
        return raw

    def validate(self) -> None:
        if not self.arm or not self.committed_by:
            raise ValueError("arm commitment requires arm and committer")
        if not self.artifact_digest or not self.runtime_profile_digest or not self.resource_policy_digest:
            raise ValueError("arm commitment requires artifact, runtime and resource-policy digests")
        if not self.timestamp_receipt_digest:
            raise ValueError("arm commitment requires an external timestamp receipt digest")
        expected = _digest(self.material())
        if self.commitment_digest and self.commitment_digest != expected:
            raise ValueError("arm commitment digest mismatch")

    def frozen(self) -> "ArmCommitment":
        raw = self.material()
        return ArmCommitment(**raw, commitment_digest=_digest(raw))


@dataclass(frozen=True)
class ExternalReviewAttestation:
    review_id: str
    review_tag: str
    reviewer_id: str
    organisation: str
    identity_reference: str
    scope: str
    evidence_digest: str
    independent_of_developers: bool
    reviewed_at: float = field(default_factory=time.time)
    review_digest: str = ""

    def material(self) -> dict:
        raw = asdict(self)
        raw.pop("review_digest", None)
        return raw

    def validate(self) -> None:
        if not self.review_id or not self.review_tag or not self.reviewer_id:
            raise ValueError("external review requires id, tag and reviewer")
        if not self.organisation or not self.identity_reference or not self.scope or not self.evidence_digest:
            raise ValueError("external review attestation is incomplete")
        if not self.independent_of_developers:
            raise ValueError("external reviewer has not attested independence")
        expected = _digest(self.material())
        if self.review_digest and self.review_digest != expected:
            raise ValueError("external review digest mismatch")

    def frozen(self) -> "ExternalReviewAttestation":
        raw = self.material()
        return ExternalReviewAttestation(**raw, review_digest=_digest(raw))


@dataclass(frozen=True)
class EvaluatorAttestation:
    evaluator_id: str
    organisation: str
    role: str
    identity_reference: str
    public_key_fingerprint: str
    conflict_statement: str
    contamination_policy: str
    independent_of_developers: bool
    competent_for_domains: Tuple[str, ...]
    attested_at: float = field(default_factory=time.time)
    attestation_digest: str = ""

    def material(self) -> dict:
        raw = asdict(self)
        raw.pop("attestation_digest", None)
        return raw

    def validate(self) -> None:
        if not self.evaluator_id or not self.organisation or not self.role:
            raise ValueError("evaluator attestation incomplete")
        if (not self.identity_reference or not self.public_key_fingerprint
                or not self.conflict_statement or not self.contamination_policy):
            raise ValueError("evaluator must attest identity, signing key, conflicts and contamination policy")
        if not self.independent_of_developers:
            raise ValueError("evaluator has not attested independence")
        if not self.competent_for_domains:
            raise ValueError("evaluator requires declared competence scope")
        expected = _digest(self.material())
        if self.attestation_digest and self.attestation_digest != expected:
            raise ValueError("evaluator attestation digest mismatch")

    def frozen(self) -> "EvaluatorAttestation":
        raw = self.material()
        return EvaluatorAttestation(**raw, attestation_digest=_digest(raw))


@dataclass(frozen=True)
class ChallengeCommitment:
    challenge_id: str
    evaluator_id: str
    domain: str
    challenge_type: str
    shift_type: str
    private_content_digest: str
    scoring_contract_digest: str
    release_after: float
    timestamp_receipt_digest: str = ""
    blinded_arm_map_digest: str = ""
    committed_at: float = field(default_factory=time.time)
    commitment_id: str = field(default_factory=lambda: _id("CHC"))

    def validate(self) -> None:
        if not self.challenge_id or not self.evaluator_id or not self.domain:
            raise ValueError("challenge commitment incomplete")
        if not self.challenge_type:
            raise ValueError("challenge commitment requires a declared type")
        if self.shift_type not in {"none", "covariate", "label", "concept", "mechanism", "adversarial"}:
            raise ValueError("invalid shift type")
        if not self.private_content_digest or not self.scoring_contract_digest:
            raise ValueError("challenge commitment requires digests")
        if not self.timestamp_receipt_digest or not self.blinded_arm_map_digest:
            raise ValueError("challenge commitment requires timestamp and blinded-arm-map receipts")
        if self.release_after < self.committed_at:
            raise ValueError("challenge release cannot predate commitment")


@dataclass(frozen=True)
class ArmPrediction:
    challenge_id: str
    arm: str
    arm_commitment_digest: str
    prediction: object
    confidence: float
    decision: str
    abstained: bool
    evidence_digest: str
    process_trace_digest: str
    execution_receipt_digest: str
    timestamp_receipt_digest: str
    latency_ms: float
    cost_units: float
    human_minutes: float
    author: str
    recorded_at: float = field(default_factory=time.time)
    prediction_id: str = field(default_factory=lambda: _id("PRD"))

    def validate(self) -> None:
        if not self.challenge_id or not self.arm or not self.author or not self.arm_commitment_digest:
            raise ValueError("prediction incomplete")
        if not self.decision:
            raise ValueError("prediction requires a decision or explicit abstention record")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence must be in [0,1]")
        if min(self.latency_ms, self.cost_units, self.human_minutes) < 0:
            raise ValueError("resource observations cannot be negative")
        if not self.evidence_digest or not self.process_trace_digest:
            raise ValueError("prediction requires evidence and process digests")
        if not self.execution_receipt_digest or not self.timestamp_receipt_digest:
            raise ValueError("prediction requires execution and timestamp receipt digests")


@dataclass(frozen=True)
class ChallengeOutcome:
    challenge_id: str
    evaluator_id: str
    revealed_content_digest: str
    outcome: object
    utility_by_arm: Mapping[str, float]
    critical_error_by_arm: Mapping[str, bool]
    correctness_by_arm: Mapping[str, float]
    contamination_attested: bool
    scoring_receipt_digest: str
    external_review_tags: Tuple[str, ...]
    revealed_scoring_contract_digest: str = ""
    blinding_attested: bool = False
    timestamp_receipt_digest: str = ""
    recorded_at: float = field(default_factory=time.time)
    outcome_id: str = field(default_factory=lambda: _id("OUT"))

    def validate(self) -> None:
        if not self.challenge_id or not self.evaluator_id:
            raise ValueError("outcome incomplete")
        if not self.revealed_content_digest or not self.scoring_receipt_digest:
            raise ValueError("outcome requires content and scoring receipts")
        if not self.revealed_scoring_contract_digest or not self.timestamp_receipt_digest:
            raise ValueError("outcome requires revealed scoring-contract and timestamp receipts")
        if not self.blinding_attested:
            raise ValueError("outcome scorer must attest arm blinding")
        if any(not math.isfinite(float(v)) or not 0.0 <= float(v) <= 1.0
               for v in self.utility_by_arm.values()):
            raise ValueError("utility must be finite and normalized to [0,1]")
        if any(not 0.0 <= float(v) <= 1.0 for v in self.correctness_by_arm.values()):
            raise ValueError("correctness must be in [0,1]")
        if any(type(v) is not bool for v in self.critical_error_by_arm.values()):
            raise ValueError("critical-error observations must be JSON booleans")


@dataclass(frozen=True)
class MaintenanceEvent:
    arm: str
    event_type: str
    severity: str
    detected_at: float
    recovered_at: float
    operator_minutes: float
    irreversible_harm: bool
    evidence_digest: str
    evaluator_id: str
    event_id: str = field(default_factory=lambda: _id("MNT"))

    def validate(self) -> None:
        if not self.arm or not self.event_type or not self.evaluator_id:
            raise ValueError("maintenance event incomplete")
        if self.severity not in {"low", "medium", "high", "critical"}:
            raise ValueError("invalid maintenance severity")
        if self.recovered_at < self.detected_at:
            raise ValueError("recovery cannot predate detection")
        if self.operator_minutes < 0 or not self.evidence_digest:
            raise ValueError("invalid maintenance event")


@dataclass(frozen=True)
class AnalysisResult:
    study_id: str
    status: str
    gates: Mapping[str, bool]
    gate_details: Mapping[str, object]
    arm_metrics: Mapping[str, Mapping[str, float]]
    paired_effects: Mapping[str, Mapping[str, float]]
    verdict: str
    rationale: str
    analysed_at: float = field(default_factory=time.time)
    analysis_id: str = field(default_factory=lambda: _id("ANL"))


class LongitudinalValidationStudy:
    """Frozen Stage 5 protocol with append-only external contact receipts."""

    def __init__(self, protocol: ValidationProtocol) -> None:
        frozen = protocol.frozen()
        frozen.validate()
        self.protocol = frozen
        self.arm_commitments: Dict[str, ArmCommitment] = {}
        self.evaluators: Dict[str, EvaluatorAttestation] = {}
        self.external_reviews: Dict[str, ExternalReviewAttestation] = {}
        self.challenges: Dict[str, ChallengeCommitment] = {}
        self.predictions: Dict[str, ArmPrediction] = {}
        self.outcomes: Dict[str, ChallengeOutcome] = {}
        self.maintenance: Dict[str, MaintenanceEvent] = {}
        self.analyses: Dict[str, AnalysisResult] = {}
        self.audit = EventLog()
        self.audit.append("validation_protocol_frozen", {
            "study_id": frozen.study_id, "protocol_digest": frozen.protocol_digest,
            "target_claim": frozen.target_claim,
        })

    def register_arm(self, commitment: ArmCommitment) -> str:
        frozen = commitment.frozen()
        frozen.validate()
        if frozen.arm not in self.protocol.arms:
            raise ValueError("arm commitment outside frozen protocol")
        if frozen.committed_by in self.protocol.developer_ids:
            raise ValueError("declared developer cannot freeze study arms")
        if frozen.committed_at < self.protocol.registered_at:
            raise ValueError("arm commitment predates protocol registration")
        if self.challenges:
            raise ValueError("arm commitments cannot change after challenge enrollment")
        prior = self.arm_commitments.get(frozen.arm)
        if prior and prior.commitment_digest != frozen.commitment_digest:
            raise ValueError("arm already committed differently")
        self.arm_commitments[frozen.arm] = frozen
        self.audit.append("validation_arm_committed", {
            "arm": frozen.arm, "commitment_digest": frozen.commitment_digest,
            "artifact_digest": frozen.artifact_digest,
            "timestamp_receipt_digest": frozen.timestamp_receipt_digest,
        })
        return frozen.commitment_digest

    def register_external_review(self, review: ExternalReviewAttestation) -> str:
        frozen = review.frozen()
        frozen.validate()
        if frozen.reviewer_id in self.protocol.developer_ids:
            raise ValueError("developer cannot supply an external review")
        if frozen.reviewed_at < self.protocol.registered_at:
            raise ValueError("external review predates protocol registration")
        if frozen.review_tag not in self.protocol.required_external_reviews:
            raise ValueError("review tag outside frozen protocol")
        if frozen.reviewer_id in self.evaluators:
            raise ValueError("study evaluator cannot also supply an external methods/security review")
        if frozen.organisation in {e.organisation for e in self.evaluators.values()}:
            raise ValueError("evaluator organisation cannot supply an external review")
        if any(r.organisation == frozen.organisation and r.review_id != frozen.review_id
               for r in self.external_reviews.values()):
            raise ValueError("required external reviews must come from distinct organisations")
        prior = self.external_reviews.get(frozen.review_id)
        if prior and prior.review_digest != frozen.review_digest:
            raise ValueError("external review already registered differently")
        self.external_reviews[frozen.review_id] = frozen
        self.audit.append("validation_external_review_registered", {
            "review_id": frozen.review_id, "review_tag": frozen.review_tag,
            "review_digest": frozen.review_digest, "organisation": frozen.organisation,
        })
        return frozen.review_id

    def register_evaluator(self, attestation: EvaluatorAttestation) -> str:
        frozen = attestation.frozen()
        frozen.validate()
        if frozen.evaluator_id in self.protocol.developer_ids:
            raise ValueError("developer cannot be an independent evaluator")
        if frozen.attested_at < self.protocol.registered_at:
            raise ValueError("evaluator attestation predates protocol registration")
        if not frozen.independent_of_developers:
            raise ValueError("evaluator has not attested independence")
        if any(r.reviewer_id == frozen.evaluator_id for r in self.external_reviews.values()):
            raise ValueError("external reviewer cannot also become a study evaluator")
        if frozen.organisation in {r.organisation for r in self.external_reviews.values()}:
            raise ValueError("external-review organisation cannot also become an evaluator organisation")
        prior = self.evaluators.get(frozen.evaluator_id)
        if prior and prior.attestation_digest != frozen.attestation_digest:
            raise ValueError("evaluator already registered differently")
        self.evaluators[frozen.evaluator_id] = frozen
        self.audit.append("validation_evaluator_registered", {
            "evaluator_id": frozen.evaluator_id,
            "attestation_digest": frozen.attestation_digest,
            "organisation": frozen.organisation,
        })
        return frozen.evaluator_id

    def commit_challenge(self, challenge: ChallengeCommitment) -> str:
        challenge.validate()
        if challenge.evaluator_id not in self.evaluators:
            raise KeyError(challenge.evaluator_id)
        if set(self.arm_commitments) != set(self.protocol.arms):
            raise ValueError("every frozen arm must be committed before challenge enrollment")
        evaluator = self.evaluators[challenge.evaluator_id]
        if challenge.committed_at < evaluator.attested_at:
            raise ValueError("challenge commitment predates evaluator attestation")
        if challenge.committed_at < max(x.committed_at for x in self.arm_commitments.values()):
            raise ValueError("challenge commitment predates an arm commitment")
        if challenge.domain not in self.protocol.domains:
            raise ValueError("challenge domain outside frozen protocol")
        if challenge.domain not in evaluator.competent_for_domains:
            raise ValueError("challenge owner is not attested competent for the domain")
        if any(existing.commitment_id == challenge.commitment_id
               and existing.challenge_id != challenge.challenge_id
               for existing in self.challenges.values()):
            raise ValueError("challenge commitment id already belongs to another challenge")
        if challenge.challenge_id in self.challenges:
            prior = self.challenges[challenge.challenge_id]
            if _digest(asdict(prior)) != _digest(asdict(challenge)):
                raise ValueError("challenge already committed differently")
            return prior.commitment_id
        self.challenges[challenge.challenge_id] = challenge
        self.audit.append("validation_challenge_committed", {
            "challenge_id": challenge.challenge_id,
            "commitment_id": challenge.commitment_id,
            "private_content_digest": challenge.private_content_digest,
            "scoring_contract_digest": challenge.scoring_contract_digest,
            "timestamp_receipt_digest": challenge.timestamp_receipt_digest,
            "blinded_arm_map_digest": challenge.blinded_arm_map_digest,
        })
        return challenge.commitment_id

    def record_prediction(self, prediction: ArmPrediction) -> str:
        prediction.validate()
        prior_id = self.predictions.get(prediction.prediction_id)
        if prior_id is not None:
            if _digest(asdict(prior_id)) == _digest(asdict(prediction)):
                return prior_id.prediction_id
            raise ValueError("prediction id already registered differently")
        if prediction.challenge_id not in self.challenges:
            raise KeyError(prediction.challenge_id)
        if prediction.arm not in self.protocol.arms:
            raise ValueError("prediction arm outside protocol")
        challenge = self.challenges[prediction.challenge_id]
        arm_commitment = self.arm_commitments.get(prediction.arm)
        if not arm_commitment or prediction.arm_commitment_digest != arm_commitment.commitment_digest:
            raise ValueError("prediction is not bound to the frozen arm artifact and resource policy")
        if prediction.recorded_at < challenge.committed_at:
            raise ValueError("prediction recorded before challenge commitment")
        if prediction.recorded_at > challenge.release_after:
            raise ValueError("prediction recorded after challenge release")
        if any(o.challenge_id == prediction.challenge_id for o in self.outcomes.values()):
            raise ValueError("prediction cannot be added after outcome")
        duplicate = [p for p in self.predictions.values()
                     if p.challenge_id == prediction.challenge_id and p.arm == prediction.arm]
        if duplicate:
            raise ValueError("one frozen prediction per arm/challenge")
        self.predictions[prediction.prediction_id] = prediction
        self.audit.append("validation_prediction_recorded", {
            "prediction_id": prediction.prediction_id,
            "challenge_id": prediction.challenge_id, "arm": prediction.arm,
            "arm_commitment_digest": prediction.arm_commitment_digest,
            "evidence_digest": prediction.evidence_digest,
            "process_trace_digest": prediction.process_trace_digest,
            "execution_receipt_digest": prediction.execution_receipt_digest,
            "timestamp_receipt_digest": prediction.timestamp_receipt_digest,
        })
        return prediction.prediction_id

    def record_outcome(self, outcome: ChallengeOutcome) -> str:
        outcome.validate()
        prior_id = self.outcomes.get(outcome.outcome_id)
        if prior_id is not None:
            if _digest(asdict(prior_id)) == _digest(asdict(outcome)):
                return prior_id.outcome_id
            raise ValueError("outcome id already registered differently")
        if outcome.challenge_id not in self.challenges:
            raise KeyError(outcome.challenge_id)
        challenge = self.challenges[outcome.challenge_id]
        if outcome.evaluator_id not in self.evaluators:
            raise ValueError("outcome scorer is not a registered evaluator")
        if outcome.evaluator_id == challenge.evaluator_id:
            raise ValueError("challenge owner cannot be the sole outcome scorer")
        scorer = self.evaluators[outcome.evaluator_id]
        owner = self.evaluators[challenge.evaluator_id]
        if scorer.organisation == owner.organisation:
            raise ValueError("outcome scorer must be from a different organisation than the challenge owner")
        if challenge.domain not in scorer.competent_for_domains:
            raise ValueError("outcome scorer is not attested competent for the domain")
        if outcome.recorded_at < scorer.attested_at:
            raise ValueError("outcome predates scorer attestation")
        if outcome.recorded_at < challenge.release_after:
            raise ValueError("outcome recorded before frozen release")
        predicted_arms = {p.arm for p in self.predictions.values()
                          if p.challenge_id == outcome.challenge_id}
        if predicted_arms != set(self.protocol.arms):
            raise ValueError("outcome requires predictions from every frozen arm")
        for mapping in (outcome.utility_by_arm, outcome.critical_error_by_arm, outcome.correctness_by_arm):
            if set(mapping) != set(self.protocol.arms):
                raise ValueError("outcome arm set differs from protocol")
        if outcome.revealed_content_digest != challenge.private_content_digest:
            raise ValueError("revealed challenge does not match commitment")
        if outcome.revealed_scoring_contract_digest != challenge.scoring_contract_digest:
            raise ValueError("revealed scoring contract does not match commitment")
        if not outcome.blinding_attested:
            raise ValueError("outcome scorer did not attest arm blinding")
        if any(o.challenge_id == outcome.challenge_id for o in self.outcomes.values()):
            raise ValueError("one immutable outcome per challenge")
        self.outcomes[outcome.outcome_id] = outcome
        self.audit.append("validation_outcome_recorded", {
            "outcome_id": outcome.outcome_id,
            "challenge_id": outcome.challenge_id,
            "scoring_receipt_digest": outcome.scoring_receipt_digest,
            "contamination_attested": outcome.contamination_attested,
            "blinding_attested": outcome.blinding_attested,
            "timestamp_receipt_digest": outcome.timestamp_receipt_digest,
        })
        return outcome.outcome_id

    def record_maintenance(self, event: MaintenanceEvent) -> str:
        event.validate()
        prior = self.maintenance.get(event.event_id)
        if prior is not None:
            if _digest(asdict(prior)) == _digest(asdict(event)):
                return prior.event_id
            raise ValueError("maintenance event id already registered differently")
        if event.arm not in self.protocol.arms or event.evaluator_id not in self.evaluators:
            raise ValueError("maintenance event references unknown arm/evaluator")
        if event.detected_at < self.protocol.registered_at:
            raise ValueError("maintenance event predates protocol registration")
        if event.detected_at < self.evaluators[event.evaluator_id].attested_at:
            raise ValueError("maintenance event predates evaluator attestation")
        self.maintenance[event.event_id] = event
        self.audit.append("validation_maintenance_recorded", {
            "event_id": event.event_id, "arm": event.arm,
            "severity": event.severity, "irreversible_harm": event.irreversible_harm,
        })
        return event.event_id

    def _completed_challenges(self, *, now: float | None = None) -> list[str]:
        cutoff = time.time() if now is None else float(now)
        return sorted(o.challenge_id for o in self.outcomes.values() if o.recorded_at <= cutoff)

    def _bootstrap_effect(self, values: Sequence[float], confidence: float) -> tuple[float, float, float]:
        if not values:
            return 0.0, 0.0, 0.0
        mean = statistics.mean(values)
        if len(values) == 1:
            return mean, mean, mean
        rng = random.Random(int(self.protocol.protocol_digest[:16], 16) + len(values))
        draws = []
        for _ in range(2000):
            sample = [values[rng.randrange(len(values))] for _ in values]
            draws.append(statistics.mean(sample))
        draws.sort()
        alpha = (1.0 - confidence) / 2.0
        lo = draws[max(0, min(len(draws) - 1, int(alpha * len(draws))))]
        hi = draws[max(0, min(len(draws) - 1, int((1.0 - alpha) * len(draws)) - 1))]
        return mean, lo, hi


    def _paired_binary_difference_interval(self, primary: Sequence[bool], comparator: Sequence[bool],
                                           confidence: float) -> tuple[float, float, float]:
        """Bonferroni-Wilson interval for a paired risk difference.

        Naive bootstrap intervals collapse to zero when both arms observe no
        critical errors.  That manufactures certainty.  We instead bound the
        two discordant multinomial cells separately and combine them.
        """
        if len(primary) != len(comparator):
            raise ValueError("paired binary vectors must have equal length")
        n = len(primary)
        if n == 0:
            return 0.0, -1.0, 1.0
        primary_only = sum(1 for a, b in zip(primary, comparator) if a and not b)
        comparator_only = sum(1 for a, b in zip(primary, comparator) if b and not a)
        alpha = 1.0 - confidence
        # Two Wilson intervals are combined into one risk-difference interval.
        # Bonferroni therefore assigns alpha/2 to each interval, with two tails
        # inside each interval: z = 1 - alpha/4, not the ordinary alpha/2.
        z = statistics.NormalDist().inv_cdf(1.0 - alpha / 4.0)

        def wilson(k: int) -> tuple[float, float]:
            phat = k / n
            z2 = z * z
            denom = 1.0 + z2 / n
            centre = (phat + z2 / (2.0 * n)) / denom
            half = z * math.sqrt((phat * (1.0 - phat) / n) + z2 / (4.0 * n * n)) / denom
            return max(0.0, centre - half), min(1.0, centre + half)

        p_lo, p_hi = wilson(primary_only)
        c_lo, c_hi = wilson(comparator_only)
        delta = (primary_only - comparator_only) / n
        return delta, max(-1.0, p_lo - c_hi), min(1.0, p_hi - c_lo)

    def analyse(self, *, now: float | None = None, record: bool = True) -> AnalysisResult:
        now = time.time() if now is None else float(now)
        completed = self._completed_challenges(now=now)
        outcomes_by_challenge = {o.challenge_id: o for o in self.outcomes.values()}
        preds = {(p.challenge_id, p.arm): p for p in self.predictions.values()}
        elapsed_days = max(0.0, (now - self.protocol.registered_at) / 86400.0)
        evaluator_counts = Counter(self.challenges[cid].evaluator_id for cid in completed)
        scorer_counts = Counter(outcomes_by_challenge[cid].evaluator_id for cid in completed)
        domain_counts = Counter(self.challenges[cid].domain for cid in completed)
        evaluator_ids = set(evaluator_counts) | set(scorer_counts)
        domains = set(domain_counts)
        qualified_evaluators = {eid for eid, count in evaluator_counts.items()
                                if count >= self.protocol.minimum_challenges_per_evaluator}
        qualified_scorers = {eid for eid, count in scorer_counts.items()
                             if count >= self.protocol.minimum_challenges_per_evaluator}
        qualified_domains = {domain for domain, count in domain_counts.items()
                             if count >= self.protocol.minimum_challenges_per_domain}
        max_evaluator_fraction = (max(evaluator_counts.values()) / len(completed)
                                  if completed else 1.0)
        max_scorer_fraction = (max(scorer_counts.values()) / len(completed)
                               if completed else 1.0)
        organisation_counts: Counter[str] = Counter()
        for eid, count in evaluator_counts.items():
            if eid in self.evaluators:
                organisation_counts[self.evaluators[eid].organisation] += count
        for eid, count in scorer_counts.items():
            if eid in self.evaluators:
                organisation_counts[self.evaluators[eid].organisation] += count
        organisation_fraction = (max(organisation_counts.values()) / (2.0 * len(completed))
                                 if completed and organisation_counts else 1.0)
        shifted = [cid for cid in completed if self.challenges[cid].shift_type != "none"]
        shift_fraction = len(shifted) / len(completed) if completed else 0.0
        contamination_ok = bool(completed) and all(outcomes_by_challenge[cid].contamination_attested for cid in completed)
        blinding_ok = bool(completed) and all(outcomes_by_challenge[cid].blinding_attested for cid in completed)
        eligible_reviews = [review for review in self.external_reviews.values()
                            if review.reviewed_at <= now and review.independent_of_developers
                            and review.reviewer_id not in self.protocol.developer_ids]
        external_tags = {review.review_tag for review in eligible_reviews}
        review_orgs = {review.organisation for review in eligible_reviews}
        evaluator_orgs = {e.organisation for e in self.evaluators.values()}
        reviews_ok = (set(self.protocol.required_external_reviews).issubset(external_tags)
                      and len(review_orgs) >= len(self.protocol.required_external_reviews)
                      and not (review_orgs & evaluator_orgs))
        evaluator_attestations_ok = bool(evaluator_ids) and all(
            eid in self.evaluators and self.evaluators[eid].independent_of_developers
            and eid not in self.protocol.developer_ids for eid in evaluator_ids)

        arm_metrics: Dict[str, Dict[str, float]] = {}
        for arm in self.protocol.arms:
            utilities = [float(outcomes_by_challenge[cid].utility_by_arm[arm]) for cid in completed]
            errors = [1.0 if outcomes_by_challenge[cid].critical_error_by_arm[arm] else 0.0 for cid in completed]
            correctness = [float(outcomes_by_challenge[cid].correctness_by_arm[arm]) for cid in completed]
            confidences, binary_correct = [], []
            costs, burdens, latencies = [], [], []
            for cid in completed:
                p = preds.get((cid, arm))
                if p:
                    confidences.append(float(p.confidence))
                    binary_correct.append(1.0 if outcomes_by_challenge[cid].correctness_by_arm[arm] >= 0.999 else 0.0)
                    costs.append(float(p.cost_units)); burdens.append(float(p.human_minutes)); latencies.append(float(p.latency_ms))
            brier = statistics.mean((c - y) ** 2 for c, y in zip(confidences, binary_correct)) if confidences else 1.0
            maintenance = [m for m in self.maintenance.values()
                           if m.arm == arm and m.detected_at <= now]
            arm_metrics[arm] = {
                "n": float(len(completed)),
                "mean_utility": statistics.mean(utilities) if utilities else 0.0,
                "critical_error_rate": statistics.mean(errors) if errors else 1.0,
                "mean_correctness": statistics.mean(correctness) if correctness else 0.0,
                "brier_score": brier,
                "mean_cost": statistics.mean(costs) if costs else 0.0,
                "mean_human_minutes": statistics.mean(burdens) if burdens else 0.0,
                "median_latency_ms": statistics.median(latencies) if latencies else 0.0,
                "maintenance_events": float(len(maintenance)),
                "mean_recovery_hours": statistics.mean((m.recovered_at - m.detected_at) / 3600.0 for m in maintenance) if maintenance else 0.0,
                "irreversible_harms": float(sum(1 for m in maintenance if m.irreversible_harm)),
            }

        primary = self.protocol.primary_arm
        paired_effects: Dict[str, Dict[str, float]] = {}
        safety_ok = True
        utility_ok = True
        resources_ok = True
        for comp in self.protocol.comparator_arms:
            utility_diff = [float(outcomes_by_challenge[cid].utility_by_arm[primary])
                            - float(outcomes_by_challenge[cid].utility_by_arm[comp]) for cid in completed]
            correctness_diff = [float(outcomes_by_challenge[cid].correctness_by_arm[primary])
                                - float(outcomes_by_challenge[cid].correctness_by_arm[comp]) for cid in completed]
            um, ulo, uhi = self._bootstrap_effect(utility_diff, self.protocol.confidence_level)
            cm, clo, chi = self._bootstrap_effect(correctness_diff, self.protocol.confidence_level)
            primary_errors = [bool(outcomes_by_challenge[cid].critical_error_by_arm[primary])
                              for cid in completed]
            comparator_errors = [bool(outcomes_by_challenge[cid].critical_error_by_arm[comp])
                                 for cid in completed]
            error_delta, error_lo, error_hi = self._paired_binary_difference_interval(
                primary_errors, comparator_errors, self.protocol.confidence_level)
            cost_ratio = _resource_ratio(arm_metrics[primary]["mean_cost"],
                                         arm_metrics[comp]["mean_cost"])
            burden_ratio = _resource_ratio(arm_metrics[primary]["mean_human_minutes"],
                                           arm_metrics[comp]["mean_human_minutes"])
            paired_effects[comp] = {
                "utility_mean": um, "utility_ci_low": ulo, "utility_ci_high": uhi,
                "correctness_mean": cm, "correctness_ci_low": clo, "correctness_ci_high": chi,
                "critical_error_delta": error_delta,
                "critical_error_ci_low": error_lo, "critical_error_ci_high": error_hi,
                "cost_ratio": cost_ratio, "human_burden_ratio": burden_ratio,
            }
            safety_ok = safety_ok and error_hi <= self.protocol.critical_error_noninferiority_margin
            utility_ok = utility_ok and ulo >= self.protocol.utility_superiority_margin
            resources_ok = resources_ok and cost_ratio <= self.protocol.maximum_cost_ratio and burden_ratio <= self.protocol.maximum_human_burden_ratio

        gates = {
            "integrity": self.verify()["valid"],
            "arm_commitments_frozen": set(self.arm_commitments) == set(self.protocol.arms),
            "duration": elapsed_days >= self.protocol.minimum_duration_days,
            "challenge_count": len(completed) >= self.protocol.minimum_challenges,
            "evaluator_count": len(qualified_evaluators) >= self.protocol.minimum_evaluators,
            "scorer_count": len(qualified_scorers) >= self.protocol.minimum_evaluators,
            "evaluator_organisation_count": len(organisation_counts) >= self.protocol.minimum_evaluator_organisations,
            "evaluator_concentration": max_evaluator_fraction <= self.protocol.maximum_evaluator_fraction,
            "scorer_concentration": max_scorer_fraction <= self.protocol.maximum_evaluator_fraction,
            "organisation_concentration": organisation_fraction <= self.protocol.maximum_organisation_fraction,
            "domain_count": len(qualified_domains) >= self.protocol.minimum_domains,
            "shift_coverage": shift_fraction >= self.protocol.minimum_shift_fraction,
            "independence_attested": evaluator_attestations_ok,
            "contamination_attested": contamination_ok,
            "arm_blinding_attested": blinding_ok,
            "external_reviews": reviews_ok,
            "safety_noninferiority": safety_ok and bool(completed),
            "utility_superiority": utility_ok and bool(completed),
            "resource_bounds": resources_ok and bool(completed),
            "no_irreversible_harm": arm_metrics.get(primary, {}).get("irreversible_harms", 0.0) == 0.0,
        }
        stop_harm = not gates["no_irreversible_harm"]
        complete_design = all(gates[k] for k in (
            "arm_commitments_frozen", "duration", "challenge_count", "evaluator_count",
            "scorer_count", "evaluator_organisation_count", "evaluator_concentration",
            "scorer_concentration", "organisation_concentration", "domain_count", "shift_coverage",
            "independence_attested", "contamination_attested", "arm_blinding_attested", "external_reviews"))
        if stop_harm:
            status, verdict = "stopped", "rejected"
            rationale = "irreversible harm stopping rule triggered"
        elif not complete_design:
            status, verdict = "collecting", "blocked"
            rationale = "minimum independent longitudinal evidence has not accumulated"
        elif all(gates.values()):
            status, verdict = "complete", "validated"
            rationale = "all frozen design, safety, utility, resource, and integrity gates passed"
        else:
            status, verdict = "complete", "not_validated"
            rationale = "the study reached analysis maturity but one or more promotion gates failed"
        details = {
            "elapsed_days": elapsed_days,
            "completed_challenges": len(completed),
            "evaluators": sorted(evaluator_ids), "evaluator_counts": dict(sorted(evaluator_counts.items())),
            "scorer_counts": dict(sorted(scorer_counts.items())),
            "qualified_evaluators": sorted(qualified_evaluators),
            "qualified_scorers": sorted(qualified_scorers),
            "maximum_evaluator_fraction_observed": max_evaluator_fraction,
            "maximum_scorer_fraction_observed": max_scorer_fraction,
            "organisation_counts": dict(sorted(organisation_counts.items())),
            "maximum_organisation_fraction_observed": organisation_fraction,
            "domains": sorted(domains), "domain_counts": dict(sorted(domain_counts.items())),
            "qualified_domains": sorted(qualified_domains),
            "shift_fraction": shift_fraction, "external_review_tags": sorted(external_tags),
            "external_review_organisations": sorted(review_orgs),
            "protocol_digest": self.protocol.protocol_digest,
            "identity_limit": "attestations are not cryptographic proof of organisational independence unless externally verified",
        }
        result = AnalysisResult(self.protocol.study_id, status, gates, details,
                                arm_metrics, paired_effects, verdict, rationale,
                                analysed_at=now)
        if record:
            self.analyses[result.analysis_id] = result
            self.audit.append("validation_analysis_recorded", {
                "analysis_id": result.analysis_id, "status": status,
                "verdict": verdict, "gates_digest": _digest(gates),
            })
        return result

    def verify(self) -> dict:
        problems = []
        audit = self.audit.verify()
        if not audit.get("valid"):
            problems.append("audit chain invalid")
        # A persisted study ends with a hash-chained full-state snapshot.  This
        # closes the gap between an intact event chain and a separately edited
        # materialized state dictionary.  Live in-memory studies may have
        # events after the most recent snapshot; only a terminal snapshot is
        # expected to represent the current state.
        if self.audit.events and self.audit.events[-1].type == "snapshot":
            event = self.audit.events[-1]
            snapshot = self.audit.snapshots.get(event.payload.get("snapshot_seq"))
            if snapshot is None or _digest(snapshot) != _digest(self._state_without_audit()):
                problems.append("persisted state differs from terminal audit snapshot")
        try:
            self.protocol.validate()
        except ValueError as exc:
            problems.append(f"protocol:{exc}")
        for key, commitment in self.arm_commitments.items():
            try:
                commitment.validate()
            except ValueError as exc:
                problems.append(f"arm:{commitment.arm}:{exc}")
            if key != commitment.arm:
                problems.append(f"arm:{key}:registry key mismatch")
            if commitment.arm not in self.protocol.arms:
                problems.append(f"arm:{commitment.arm}:outside protocol")
            if commitment.committed_by in self.protocol.developer_ids:
                problems.append(f"arm:{commitment.arm}:developer custodian")
            if commitment.committed_at < self.protocol.registered_at:
                problems.append(f"arm:{commitment.arm}:predates protocol")
        for key, evaluator in self.evaluators.items():
            try:
                evaluator.validate()
            except ValueError as exc:
                problems.append(f"evaluator:{evaluator.evaluator_id}:{exc}")
            if key != evaluator.evaluator_id:
                problems.append(f"evaluator:{key}:registry key mismatch")
            if evaluator.evaluator_id in self.protocol.developer_ids:
                problems.append(f"evaluator:{evaluator.evaluator_id}:developer evaluator")
            if not evaluator.independent_of_developers:
                problems.append(f"evaluator:{evaluator.evaluator_id}:independence not attested")
            if evaluator.attested_at < self.protocol.registered_at:
                problems.append(f"evaluator:{evaluator.evaluator_id}:predates protocol")
            if not set(evaluator.competent_for_domains).issubset(self.protocol.domains):
                problems.append(f"evaluator:{evaluator.evaluator_id}:domain outside protocol")
        for key, review in self.external_reviews.items():
            try:
                review.validate()
            except ValueError as exc:
                problems.append(f"review:{review.review_id}:{exc}")
            if key != review.review_id:
                problems.append(f"review:{key}:registry key mismatch")
            if review.reviewer_id in self.protocol.developer_ids:
                problems.append(f"review:{review.review_id}:developer reviewer")
            if review.reviewer_id in self.evaluators:
                problems.append(f"review:{review.review_id}:reviewer is also evaluator")
            if review.reviewed_at < self.protocol.registered_at:
                problems.append(f"review:{review.review_id}:predates protocol")
            if review.review_tag not in self.protocol.required_external_reviews:
                problems.append(f"review:{review.review_id}:tag outside protocol")
        review_orgs = [review.organisation for review in self.external_reviews.values()]
        if len(review_orgs) != len(set(review_orgs)):
            problems.append("review:required external reviews share an organisation")
        evaluator_orgs = {evaluator.organisation for evaluator in self.evaluators.values()}
        if evaluator_orgs & set(review_orgs):
            problems.append("review:external-review organisation also supplies an evaluator")
        challenge_ids: set[str] = set()
        challenge_commitment_ids: set[str] = set()
        for key, challenge in self.challenges.items():
            try:
                challenge.validate()
            except ValueError as exc:
                problems.append(f"challenge:{challenge.challenge_id}:{exc}")
            if key != challenge.challenge_id:
                problems.append(f"challenge:{key}:registry key mismatch")
            if challenge.challenge_id in challenge_ids:
                problems.append(f"challenge:{challenge.challenge_id}:duplicate id")
            challenge_ids.add(challenge.challenge_id)
            if challenge.commitment_id in challenge_commitment_ids:
                problems.append(f"challenge:{challenge.challenge_id}:duplicate commitment id")
            challenge_commitment_ids.add(challenge.commitment_id)
            if challenge.domain not in self.protocol.domains:
                problems.append(f"challenge:{challenge.challenge_id}:domain outside protocol")
            if challenge.evaluator_id not in self.evaluators:
                problems.append(f"challenge:{challenge.challenge_id}:missing evaluator")
            else:
                evaluator = self.evaluators[challenge.evaluator_id]
                if challenge.committed_at < evaluator.attested_at:
                    problems.append(f"challenge:{challenge.challenge_id}:predates evaluator attestation")
                if challenge.domain not in evaluator.competent_for_domains:
                    problems.append(f"challenge:{challenge.challenge_id}:owner not competent for domain")
            if set(self.arm_commitments) != set(self.protocol.arms):
                problems.append(f"challenge:{challenge.challenge_id}:incomplete arm commitments")
            elif challenge.committed_at < max(x.committed_at for x in self.arm_commitments.values()):
                problems.append(f"challenge:{challenge.challenge_id}:predates arm commitment")
        prediction_pairs: set[tuple[str, str]] = set()
        for key, prediction in self.predictions.items():
            try:
                prediction.validate()
            except ValueError as exc:
                problems.append(f"prediction:{prediction.prediction_id}:{exc}")
            if key != prediction.prediction_id:
                problems.append(f"prediction:{key}:registry key mismatch")
            pair = (prediction.challenge_id, prediction.arm)
            if pair in prediction_pairs:
                problems.append(f"prediction:{prediction.prediction_id}:duplicate challenge/arm")
            prediction_pairs.add(pair)
            if prediction.arm not in self.protocol.arms:
                problems.append(f"prediction:{prediction.prediction_id}:arm outside protocol")
            challenge = self.challenges.get(prediction.challenge_id)
            arm = self.arm_commitments.get(prediction.arm)
            if (not challenge or prediction.recorded_at < challenge.committed_at
                    or prediction.recorded_at > challenge.release_after):
                problems.append(f"prediction:{prediction.prediction_id}:chronology invalid")
            if not arm or prediction.arm_commitment_digest != arm.commitment_digest:
                problems.append(f"prediction:{prediction.prediction_id}:arm commitment mismatch")
        outcomes_by_challenge: dict[str, ChallengeOutcome] = {}
        for key, outcome in self.outcomes.items():
            try:
                outcome.validate()
            except ValueError as exc:
                problems.append(f"outcome:{outcome.outcome_id}:{exc}")
            if key != outcome.outcome_id:
                problems.append(f"outcome:{key}:registry key mismatch")
            if outcome.challenge_id in outcomes_by_challenge:
                problems.append(f"outcome:{outcome.outcome_id}:duplicate challenge outcome")
            outcomes_by_challenge[outcome.challenge_id] = outcome
            challenge = self.challenges.get(outcome.challenge_id)
            if not challenge or outcome.recorded_at < challenge.release_after:
                problems.append(f"outcome:{outcome.outcome_id}:chronology invalid")
            elif outcome.revealed_content_digest != challenge.private_content_digest:
                problems.append(f"outcome:{outcome.outcome_id}:content commitment mismatch")
            elif outcome.revealed_scoring_contract_digest != challenge.scoring_contract_digest:
                problems.append(f"outcome:{outcome.outcome_id}:scoring-contract commitment mismatch")
            elif not outcome.blinding_attested:
                problems.append(f"outcome:{outcome.outcome_id}:arm blinding not attested")
            else:
                scorer = self.evaluators.get(outcome.evaluator_id)
                if scorer is None:
                    problems.append(f"outcome:{outcome.outcome_id}:missing scorer")
                else:
                    if outcome.evaluator_id == challenge.evaluator_id:
                        problems.append(f"outcome:{outcome.outcome_id}:owner scored own challenge")
                    owner = self.evaluators.get(challenge.evaluator_id)
                    if owner and scorer.organisation == owner.organisation:
                        problems.append(f"outcome:{outcome.outcome_id}:scorer organisation matches owner")
                    if challenge.domain not in scorer.competent_for_domains:
                        problems.append(f"outcome:{outcome.outcome_id}:scorer not competent for domain")
                    if outcome.recorded_at < scorer.attested_at:
                        problems.append(f"outcome:{outcome.outcome_id}:predates scorer attestation")
                predicted_arms = {p.arm for p in self.predictions.values()
                                  if p.challenge_id == outcome.challenge_id}
                if predicted_arms != set(self.protocol.arms):
                    problems.append(f"outcome:{outcome.outcome_id}:missing frozen-arm predictions")
                for mapping_name, mapping in (
                    ("utility", outcome.utility_by_arm),
                    ("critical_error", outcome.critical_error_by_arm),
                    ("correctness", outcome.correctness_by_arm),
                ):
                    if set(mapping) != set(self.protocol.arms):
                        problems.append(f"outcome:{outcome.outcome_id}:{mapping_name} arm mismatch")
        for prediction in self.predictions.values():
            outcome = outcomes_by_challenge.get(prediction.challenge_id)
            if outcome and prediction.recorded_at > outcome.recorded_at:
                problems.append(f"prediction:{prediction.prediction_id}:recorded after outcome")
        for key, event in self.maintenance.items():
            try:
                event.validate()
            except ValueError as exc:
                problems.append(f"maintenance:{event.event_id}:{exc}")
            if key != event.event_id:
                problems.append(f"maintenance:{key}:registry key mismatch")
            if event.arm not in self.protocol.arms:
                problems.append(f"maintenance:{event.event_id}:arm outside protocol")
            evaluator = self.evaluators.get(event.evaluator_id)
            if evaluator is None:
                problems.append(f"maintenance:{event.event_id}:missing evaluator")
            elif event.detected_at < evaluator.attested_at:
                problems.append(f"maintenance:{event.event_id}:predates evaluator attestation")
            if event.detected_at < self.protocol.registered_at:
                problems.append(f"maintenance:{event.event_id}:predates protocol")
        return {"valid": not problems, "problems": problems,
                "events": audit.get("events", 0),
                "state_digest": _digest(self._state_without_audit())}

    def status(self, *, now: float | None = None) -> dict:
        analysis = self.analyse(now=now, record=False)
        return {
            "study_id": self.protocol.study_id,
            "protocol": asdict(self.protocol),
            "counts": {
                "arm_commitments": len(self.arm_commitments),
                "evaluators": len(self.evaluators), "external_reviews": len(self.external_reviews),
                "challenges": len(self.challenges),
                "predictions": len(self.predictions), "outcomes": len(self.outcomes),
                "maintenance_events": len(self.maintenance), "analyses": len(self.analyses),
            },
            "latest_analysis": asdict(analysis),
            "integrity": self.verify(),
            "completion_boundary": {
                "software_and_protocol": "complete",
                "independent_longitudinal_outcome": analysis.verdict,
                "reason": analysis.rationale,
            },
            "nonclaims": [
                "the protocol does not manufacture independent evaluators",
                "private challenge commitments do not prove challenge quality",
                "elapsed time and future outcomes cannot be simulated into longitudinal evidence",
                "a blocked verdict is an intended truthful state",
            ],
        }

    def _state_without_audit(self) -> dict:
        return {
            "protocol": asdict(self.protocol),
            "arm_commitments": {k: asdict(v) for k, v in self.arm_commitments.items()},
            "evaluators": {k: asdict(v) for k, v in self.evaluators.items()},
            "external_reviews": {k: asdict(v) for k, v in self.external_reviews.items()},
            "challenges": {k: asdict(v) for k, v in self.challenges.items()},
            "predictions": {k: asdict(v) for k, v in self.predictions.items()},
            "outcomes": {k: asdict(v) for k, v in self.outcomes.items()},
            "maintenance": {k: asdict(v) for k, v in self.maintenance.items()},
            "analyses": {k: asdict(v) for k, v in self.analyses.items()},
        }

    def to_dict(self) -> dict:
        return {**self._state_without_audit(), "audit": self.audit.to_dict()}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "LongitudinalValidationStudy":
        obj = cls.__new__(cls)
        obj.protocol = ValidationProtocol(**_tuple_protocol(dict(raw["protocol"])))
        obj.arm_commitments = {k: ArmCommitment(**dict(v)) for k, v in dict(raw.get("arm_commitments", {})).items()}
        obj.evaluators = {k: EvaluatorAttestation(**_tuple_evaluator(v)) for k, v in dict(raw.get("evaluators", {})).items()}
        obj.external_reviews = {k: ExternalReviewAttestation(**dict(v)) for k, v in dict(raw.get("external_reviews", {})).items()}
        obj.challenges = {k: ChallengeCommitment(**dict(v)) for k, v in dict(raw.get("challenges", {})).items()}
        obj.predictions = {k: ArmPrediction(**dict(v)) for k, v in dict(raw.get("predictions", {})).items()}
        obj.outcomes = {k: ChallengeOutcome(**_tuple_outcome(v)) for k, v in dict(raw.get("outcomes", {})).items()}
        obj.maintenance = {k: MaintenanceEvent(**dict(v)) for k, v in dict(raw.get("maintenance", {})).items()}
        obj.analyses = {k: AnalysisResult(**dict(v)) for k, v in dict(raw.get("analyses", {})).items()}
        obj.audit = EventLog.from_dict(dict(raw.get("audit", {})))
        return obj

    def save(self, path: str | Path) -> None:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        state = self._state_without_audit()
        # Persisted state is bound into the same tamper-evident chain as the
        # operation receipts. Avoid duplicate terminal snapshots when a caller
        # saves an unchanged study repeatedly.
        terminal_matches = False
        if self.audit.events and self.audit.events[-1].type == "snapshot":
            seq = self.audit.events[-1].payload.get("snapshot_seq")
            snapshot = self.audit.snapshots.get(seq)
            terminal_matches = snapshot is not None and _digest(snapshot) == _digest(state)
        if not terminal_matches:
            self.audit.snapshot(state)
        target.write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True, allow_nan=False))

    @classmethod
    def load(cls, path: str | Path) -> "LongitudinalValidationStudy":
        return cls.from_dict(json.loads(Path(path).read_text()))


def _tuple_fields(raw: Mapping[str, object], keys: Sequence[str]) -> dict:
    out = dict(raw)
    for key in keys:
        out[key] = tuple(out.get(key, ()))
    return out


def _tuple_protocol(raw: Mapping[str, object]) -> dict:
    return _tuple_fields(raw, ("arms", "comparator_arms", "primary_endpoints", "secondary_endpoints",
                               "domains", "required_external_reviews", "exclusion_rules",
                               "stopping_rules", "developer_ids"))


def _tuple_evaluator(raw: Mapping[str, object]) -> dict:
    return _tuple_fields(raw, ("competent_for_domains",))


def _tuple_outcome(raw: Mapping[str, object]) -> dict:
    return _tuple_fields(raw, ("external_review_tags",))
