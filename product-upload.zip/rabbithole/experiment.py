"""Multiple-working-hypothesis discriminating test selection."""
from __future__ import annotations

import math
import uuid
from dataclasses import dataclass, field
from typing import Mapping, Tuple


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:11]}"


@dataclass
class Hypothesis:
    name: str
    prior: float
    scope: str = ""
    hid: str = field(default_factory=lambda: _id("H"))


@dataclass
class CandidateTest:
    name: str
    outcomes: Tuple[str, ...]
    likelihoods: Mapping[str, Mapping[str, float]]
    cost: float
    contact_quality: float
    reversible: bool = True
    latency: float = 0.0
    risk: float = 0.0
    reuse_value: float = 0.0
    correlation_group: str = ""
    tid: str = field(default_factory=lambda: _id("T"))


@dataclass
class TestRanking:
    test_id: str
    expected_information_gain: float
    minimum_expected_elimination: float
    score: float
    valid: bool
    reason: str


class ExperimentPlanner:
    @staticmethod
    def _entropy(probabilities) -> float:
        return -sum(p * math.log(max(p, 1e-15), 2) for p in probabilities if p > 0)

    def rank(self, hypotheses: Tuple[Hypothesis, ...], tests: Tuple[CandidateTest, ...]) -> Tuple[TestRanking, ...]:
        total = sum(max(0.0, h.prior) for h in hypotheses)
        if total <= 0:
            raise ValueError("positive prior mass is required")
        priors = {h.hid: max(0.0, h.prior) / total for h in hypotheses}
        prior_entropy = self._entropy(priors.values())
        ranked = []
        for test in tests:
            reason = ""
            if test.cost < 0 or test.latency < 0 or not 0 <= test.contact_quality <= 1 or not 0 <= test.risk <= 1:
                ranked.append(TestRanking(test.tid, 0.0, 0.0, 0.0, False, "invalid cost, quality, latency, or risk"))
                continue
            if not test.outcomes:
                ranked.append(TestRanking(test.tid, 0.0, 0.0, 0.0, False, "no outcomes"))
                continue
            valid = True
            for h in hypotheses:
                row = test.likelihoods.get(h.hid, {})
                if not row or any(float(row.get(o, 0.0)) < 0 for o in test.outcomes) or abs(sum(float(row.get(o, 0.0)) for o in test.outcomes) - 1.0) > 1e-6:
                    valid = False; reason = f"invalid likelihood row for {h.hid}"; break
            if not valid:
                ranked.append(TestRanking(test.tid, 0.0, 0.0, 0.0, False, reason)); continue
            expected_entropy = 0.0
            eliminations = []
            for outcome in test.outcomes:
                p_outcome = sum(priors[h.hid] * float(test.likelihoods[h.hid].get(outcome, 0.0)) for h in hypotheses)
                if p_outcome <= 0:
                    continue
                posterior = {h.hid: priors[h.hid] * float(test.likelihoods[h.hid].get(outcome, 0.0)) / p_outcome for h in hypotheses}
                expected_entropy += p_outcome * self._entropy(posterior.values())
                eliminations.append(1.0 - max(posterior.values()))
            eig = max(0.0, prior_entropy - expected_entropy)
            minimum_elimination = min(eliminations) if eliminations else 0.0
            resource_cost = test.cost + test.latency + test.risk * 10.0 + 1e-9
            reversibility_factor = 1.15 if test.reversible else 0.75
            score = eig * test.contact_quality * reversibility_factor * (1.0 + max(0.0, test.reuse_value)) / resource_cost
            ranked.append(TestRanking(test.tid, eig, minimum_elimination, score, True, "valid discriminating test"))
        return tuple(sorted(ranked, key=lambda x: (-x.score, -x.expected_information_gain, x.test_id)))
