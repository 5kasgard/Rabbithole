"""Typed bridges between proposers, the field, and reality.

The critical authority split is explicit in this version:

* ``propose`` / ``ingest(..., mode='propose')`` validates a model candidate but
  does not mutate the field and does not create invariants.
* ``ingest(..., mode='declared')`` is a low-level, explicit operation for a
  human-scoped model, definition, convention, or already verified invariant.
* tested values return through registered reality executors, never through an
  LLM confidence score.

An external language model is therefore structurally unable to mint a wall by
calling the default path.
"""

from __future__ import annotations

import copy
import time
import uuid
from dataclasses import dataclass
from typing import Optional, Union

from .core import UNITS
from .field import Field, SettleReport

BRIDGE_SPEC = """You are an external proposer for a constraint field.
Translate the user's intent into STRICT JSON (no prose, no markdown). The JSON
is a PROPOSAL and has zero structural authority until explicitly promoted:

{
  "variables":  [{"name": str, "unit": str, "lo": num?, "hi": num?, "note": str?}],
  "constraints":[
     {"type":"sum",     "terms":[str,...], "total": str, "statement": str},
     {"type":"linear",  "terms":[{"coeff": num, "var": str},...], "total": str, "statement": str},
     {"type":"product", "a": str, "b": str, "c": str,    "statement": str},
     {"type":"power",   "a": str, "n": int, "c": str,    "statement": str},
     {"type":"bound",   "var": str, "lo": num?, "hi": num?, "statement": str}
  ],
  "clamps":    [{"var": str, "value": num?, "lo": num?, "hi": num?, "reason": str}],
  "evidence":  [{"var": str, "value": num, "sigma": num, "source": str,
                   "confidence": num, "contact": str?, "author": str?}]
}

Rules: every quantity gets a variable with a known unit. Similarity and fluency
never authorize a constraint. Do not invent numbers. User goals and declared
states are clamps; sourced claims are untested evidence. Known units: """ + ", ".join(
    sorted(u for u in UNITS if u)
)


class BridgeError(Exception):
    pass


@dataclass
class BridgeProposal:
    proposal_id: str
    spec: dict
    proposer: str
    valid: bool
    reason: str
    created_at: float


def _apply_declared(spec: dict, f: Field, source: str = "declared model",
                    authority_class: str = "declared_model") -> Field:
    kind_map = {
        "definition": "definition",
        "convention": "convention",
        "declared_model": "model",
        "verified_invariant": "invariant",
    }
    if authority_class not in kind_map:
        raise BridgeError(f"unknown authority class {authority_class!r}")
    factor_kind = kind_map[authority_class]
    for v in spec.get("variables", []):
        unit = v.get("unit", "")
        if unit not in UNITS:
            raise BridgeError(
                f"unknown unit {unit!r} for variable {v.get('name')!r}. "
                f"Known units: {', '.join(sorted(u for u in UNITS if u))}"
            )
        if v["name"] in f.variables:
            existing = f.variables[v["name"]]
            if existing.dim != UNITS[unit][0]:
                raise BridgeError(
                    f"variable {v['name']!r} already exists with incompatible dimension"
                )
            continue
        f.var(v["name"], unit,
              lo=v.get("lo", float("-inf")), hi=v.get("hi", float("inf")),
              note=v.get("note", ""), bound_source=source)

    for c in spec.get("constraints", []):
        t = c.get("type")
        stmt = c.get("statement", "")
        if t == "sum":
            f.sum_is(c["terms"], c["total"], stmt, source=source, kind=factor_kind)
        elif t == "linear":
            f.linear_is([(tm["coeff"], tm["var"]) for tm in c["terms"]],
                        c["total"], stmt, source=source, kind=factor_kind)
        elif t == "product":
            f.product_is(c["a"], c["b"], c["c"], stmt, source=source, kind=factor_kind)
        elif t == "power":
            f.power_is(c["a"], int(c["n"]), c["c"], stmt, source=source, kind=factor_kind)
        elif t == "bound":
            # A promoted model bound is structural only within the declared
            # scope recorded by `source`; it is not promoted by its JSON label.
            scale = f.variables[c["var"]].unit_scale
            lo, hi = c.get("lo", float("-inf")), c.get("hi", float("inf"))
            from .core import Interval
            iv = Interval(lo * scale if lo != float("-inf") else lo,
                          hi * scale if hi != float("inf") else hi)
            f._bound(c["var"], iv, factor_kind, stmt or f"{c['var']} bounded", source)
        else:
            raise BridgeError(f"unknown constraint type {t!r}")

    for cl in spec.get("clamps", []):
        f.clamp(cl["var"], value=cl.get("value"),
                lo=cl.get("lo", float("-inf")), hi=cl.get("hi", float("inf")),
                reason=cl.get("reason", "declared boundary condition"))

    for e in spec.get("evidence", []):
        # Bridge evidence is testimony by default. It receives zero authority
        # until a registered test grounds it.
        f.add_evidence(e["var"], e["value"], e["sigma"], e["source"],
                       e.get("confidence", 0.5), tested=False,
                       contact=e.get("contact", "model"),
                       author=e.get("author", e["source"]))
    return f


def validate_spec(spec: dict, field: Optional[Field] = None,
                  authority_class: str = "declared_model") -> Field:
    """Apply to an isolated probe. Returns the probe if every wall survives."""
    probe = Field("bridge-probe") if field is None else Field.from_dict(field.to_dict())
    return _apply_declared(copy.deepcopy(spec), probe, source="bridge validation probe",
                           authority_class=authority_class)


def propose(spec: dict, field: Optional[Field] = None,
            proposer: str = "unknown") -> BridgeProposal:
    try:
        validate_spec(spec, field)
        return BridgeProposal(f"BP{uuid.uuid4().hex[:10]}", copy.deepcopy(spec),
                              proposer, True,
                              "proposal is dimensionally and structurally admissible; no field mutation",
                              time.time())
    except Exception as exc:
        return BridgeProposal(f"BP{uuid.uuid4().hex[:10]}", copy.deepcopy(spec),
                              proposer, False, f"{type(exc).__name__}: {exc}", time.time())


def ingest(spec: dict, field: Optional[Field] = None, *, mode: str = "propose",
           source: str = "declared model",
           authority_class: str = "declared_model") -> Union[Field, BridgeProposal]:
    """Validate or explicitly promote a bridge specification.

    ``mode='propose'`` is the safe default and returns ``BridgeProposal``.
    ``mode='declared'`` mutates/returns a ``Field`` and must be called only after
    the authority class was decided outside the LLM bridge.
    """
    if mode == "propose":
        return propose(spec, field)
    if mode != "declared":
        raise BridgeError("mode must be 'propose' or 'declared'")
    if field is None:
        return _apply_declared(copy.deepcopy(spec), Field("bridged"), source=source,
                               authority_class=authority_class)
    validate_spec(spec, field, authority_class=authority_class)  # transactional preflight
    return _apply_declared(copy.deepcopy(spec), field, source=source,
                           authority_class=authority_class)


def report_test(field: Field, var: str, value: float, sigma: float,
                source: str, confidence: float = 0.9,
                contact: str = "instrument", author: str = "registered executor") -> str:
    """Register a value that actually returned through a reality executor."""
    return field.add_evidence(var, value, sigma, source, confidence,
                              grounded_at=time.time(), tested=True,
                              contact=contact, author=author)


def explain_for_bridge(field: Field, report: SettleReport) -> dict:
    out: dict = {
        "status": report.status,
        "pops": report.pops,
        "contractions": report.contractions,
        "elapsed_ms": round(report.elapsed_ms, 3),
        "variables": {n: repr(v.domain) + (f" {v.unit_name}" if v.unit_name else "")
                      for n, v in field.variables.items()},
    }
    if report.conflict:
        c = report.conflict
        out["contradiction"] = {
            "emptied": c.emptied_var,
            "minimal_conflict": [{"id": x.fid, "kind": x.prov.kind,
                                  "statement": x.prov.statement,
                                  "source": x.prov.source} for x in c.conflict],
            "nearest_possible": [{"var": r.var, "requested": repr(r.requested),
                                  "feasible": repr(r.feasible),
                                  "nearest": r.nearest} for r in c.relaxations],
        }
    contested = []
    for name in field.variables:
        b = field.belief(name)
        if b.test is not None:
            contested.append({"var": name, "reason": b.test.reason,
                              "sources": b.test.discriminates,
                              "fused_mean": b.mean, "fused_sigma": b.sigma})
    if contested:
        out["tests_that_would_resolve"] = contested
    return out
