"""Role/task explanation contracts, mutations, and blinded-study packages."""
from __future__ import annotations
import hashlib,json,time,uuid
from dataclasses import asdict,dataclass,field
from typing import Dict,Mapping,Sequence,Tuple
from .wal import EventLog

def _id(p):return f"{p}{uuid.uuid4().hex[:12]}"
@dataclass(frozen=True)
class ViewContract:
    contract_id:str;role:str;task_type:str;required_sections:Tuple[str,...];forbidden_omissions:Tuple[str,...];max_words:int=1000
@dataclass
class ExplanationArtifact:
    contract_id:str;sections:Mapping[str,object];source_object_ids:Tuple[str,...];status:str="prepared";artifact_id:str=field(default_factory=lambda:_id("EXP"))
@dataclass
class StudyPackage:
    contract_id:str;artifact_ids:Tuple[str,...];outcome_measures:Tuple[str,...];consent_text:str;randomization_commitment:str;blinded:bool;external_required:bool=True;package_id:str=field(default_factory=lambda:_id("STP"))
class ExplanationStudyRegistry:
    def __init__(self):self.contracts:Dict[str,ViewContract]={};self.artifacts:Dict[str,ExplanationArtifact]={};self.packages:Dict[str,StudyPackage]={};self.audit=EventLog()
    def register(self,c:ViewContract):self.contracts[c.contract_id]=c;self.audit.append("view_contract_registered",asdict(c))
    def prepare(self,contract_id:str,sections:Mapping[str,object],source_object_ids:Sequence[str])->ExplanationArtifact:
        c=self.contracts[contract_id];missing=[x for x in c.required_sections if x not in sections];forbidden=[x for x in c.forbidden_omissions if x not in sections]
        status="prepared" if not missing and not forbidden else "invalid"
        a=ExplanationArtifact(contract_id,dict(sections),tuple(source_object_ids),status);self.artifacts[a.artifact_id]=a;self.audit.append("explanation_prepared",asdict(a)|{"missing":missing,"forbidden_omissions":forbidden});return a
    def mutate(self,artifact_id:str,remove_section:str)->dict:
        a=self.artifacts[artifact_id];c=self.contracts[a.contract_id];sections=dict(a.sections);sections.pop(remove_section,None);killed=remove_section in c.required_sections or remove_section in c.forbidden_omissions
        r={"artifact_id":artifact_id,"mutation":f"remove:{remove_section}","killed_by_contract":killed,"remaining_sections":sorted(sections)};self.audit.append("explanation_mutated",r);return r
    def package_study(self,contract_id:str,artifact_ids:Sequence[str],outcome_measures:Sequence[str],consent_text:str,random_seed_commitment:str)->StudyPackage:
        if not consent_text.strip():raise ValueError("consent text is required")
        if any(a not in self.artifacts or self.artifacts[a].status!="prepared" for a in artifact_ids):raise ValueError("study artifacts must be valid")
        p=StudyPackage(contract_id,tuple(artifact_ids),tuple(outcome_measures),consent_text,hashlib.sha256(random_seed_commitment.encode()).hexdigest(),True,True);self.packages[p.package_id]=p;self.audit.append("explanation_study_packaged",asdict(p));return p
    def status(self,package_id:str)->dict:return {"package":asdict(self.packages[package_id]),"claim_state":"independent_user_study_required","self_certified":False}
    def to_dict(self):return {"contracts":[asdict(x) for x in self.contracts.values()],"artifacts":[asdict(x) for x in self.artifacts.values()],"packages":[asdict(x) for x in self.packages.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw):
        o=cls()
        for r in raw.get("contracts",[]):
            d=dict(r);d["required_sections"]=tuple(d.get("required_sections",()));d["forbidden_omissions"]=tuple(d.get("forbidden_omissions",()));c=ViewContract(**d);o.contracts[c.contract_id]=c
        for r in raw.get("artifacts",[]):
            d=dict(r);d["source_object_ids"]=tuple(d.get("source_object_ids",()));a=ExplanationArtifact(**d);o.artifacts[a.artifact_id]=a
        for r in raw.get("packages",[]):
            d=dict(r);d["artifact_ids"]=tuple(d.get("artifact_ids",()));d["outcome_measures"]=tuple(d.get("outcome_measures",()));p=StudyPackage(**d);o.packages[p.package_id]=p
        o.audit=EventLog.from_dict(raw.get("audit",{}));return o
