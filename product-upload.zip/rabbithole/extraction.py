"""Proposal-only carving from parsed artifacts.

Deterministic extraction handles a bounded quantitative language.  An optional
proposal faculty may add broader candidates, but no extractor can grant truth or
identity authority.
"""
from __future__ import annotations
import json, re, time, uuid
from dataclasses import asdict, dataclass, field
from typing import Mapping, Optional, Sequence, Tuple

from .akbc import Carving, KindRegistry
from .faculties import ProposalFaculty


def _id(p): return f"{p}{uuid.uuid4().hex[:12]}"

UNIT_ALIASES = {
    "kg/m3": "kg/m^3", "kg m-3": "kg/m^3", "g/cm3": "g/cm^3",
    "n m": "N*m", "n·m": "N*m", "j/k": "J/K", "m s-1": "m/s",
    "s-1": "Hz", "1/s": "Hz", "°c": "degC", "c": "degC",
}
UNIT_PATTERN = r"kg/m\^?3|kg\s*m-3|g/cm\^?3|N[·* ]m|J/K|J|Hz|Bq|m/s|m\s*s-1|K|°C|degC|Pa|A|V|W|s-1|1/s"

@dataclass
class GenericClaimCarving:
    statement: str
    artifact_id: str
    parse_id: str
    extractor: str
    confidence: float
    qualifiers: Mapping[str, object] = field(default_factory=dict)
    cid: str = field(default_factory=lambda: _id("CLM"))

@dataclass
class ExtractionReceipt:
    extraction_id: str
    artifact_id: str
    parse_id: str
    extractor: str
    extractor_version: str
    quantitative_count: int
    generic_count: int
    warnings: Tuple[str, ...]
    created_at: float = field(default_factory=time.time)

@dataclass
class ExtractionBundle:
    quantitative: Tuple[Carving, ...]
    generic: Tuple[GenericClaimCarving, ...]
    receipt: ExtractionReceipt

class DeterministicQuantityExtractor:
    name, version = "deterministic-quantity", "2"
    pattern = re.compile(rf"(?P<label>[A-Za-z][A-Za-z0-9 _\-/]{{1,80}}?)\s*(?:=|:|is|was|measured at|reported as)\s*(?P<value>[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)\s*(?:±|\+/-)?\s*(?P<sigma>\d+(?:\.\d+)?)?\s*(?P<unit>{UNIT_PATTERN})\b", re.I)

    @staticmethod
    def _unit(raw: str) -> str:
        x = re.sub(r"\s+", " ", raw.strip()).lower()
        return UNIT_ALIASES.get(x, raw.strip().replace("·", "*").replace(" ", "") if raw.lower().startswith("n") else raw.strip())

    @staticmethod
    def _scope(text: str, start: int) -> dict:
        window = text[max(0, start-220):start+80]
        scope = {}
        for key, pat in (
            ("sample_id", r"(?i)sample\s+(?:id\s*)?[#:]?\s*([A-Za-z0-9_-]+)"),
            ("device_id", r"(?i)device\s+(?:id\s*)?[#:]?\s*([A-Za-z0-9_-]+)"),
            ("location", r"(?i)(?:at|location)\s+([A-Z][A-Za-z0-9_-]{1,30})"),
        ):
            m = re.search(pat, window)
            if m: scope[key] = m.group(1)
        return scope

    def extract(self, text: str, *, artifact_id: str, parse_id: str, source: str,
                locator: str, kinds: KindRegistry) -> ExtractionBundle:
        out, warnings = [], []
        for m in self.pattern.finditer(text):
            label = " ".join(m.group("label").split())[-80:].strip(" .,-")
            label = re.sub(r"(?i)^(?:the|a|an)\s+", "", label)
            unit = self._unit(m.group("unit"))
            value = float(m.group("value")); sigma = float(m.group("sigma")) if m.group("sigma") else max(abs(value)*0.01, 1e-12)
            known = kinds.resolve(label=label)
            try:
                carving = Carving(label=label, unit=unit, value=value, sigma=sigma,
                    source=source, citation=locator, confidence=0.65,
                    kind_id=known.kid if known else "", kind_label=known.label if known else label,
                    algebraic_type=known.algebraic_type if known else "unknown",
                    phenomenon=known.phenomenon if known else "",
                    operational_tags=known.operational_tags if known else (),
                    scope=self._scope(text, m.start()), source_locator=locator,
                    source_snapshot=text, media_type="text/plain", extractor=self.name,
                    extraction_version=self.version)
                carving.validate(); out.append(carving)
            except Exception as exc:
                warnings.append(f"rejected candidate {label!r}: {type(exc).__name__}: {exc}")
        receipt = ExtractionReceipt(_id("EXT"), artifact_id, parse_id, self.name, self.version, len(out), 0, tuple(warnings))
        return ExtractionBundle(tuple(out), (), receipt)

class FacultyClaimExtractor:
    name, version = "proposal-faculty", "1"
    def __init__(self, faculty: ProposalFaculty): self.faculty = faculty
    def extract(self, text: str, *, artifact_id: str, parse_id: str, source: str, locator: str) -> ExtractionBundle:
        schema = {"type":"object","required":["claims"],"properties":{"claims":{"type":"array","items":{"type":"object","required":["statement","confidence"],"properties":{"statement":{"type":"string"},"confidence":{"type":"number"},"qualifiers":{"type":"object"}}}}}}
        instruction = "Extract atomic factual claim candidates. Do not decide truth. Preserve qualifiers, scope, and uncertainty. Return JSON only."
        receipt = self.faculty.propose(instruction, text[:120000], schema)
        payload = receipt.output
        claims = tuple(GenericClaimCarving(str(x["statement"]), artifact_id, parse_id, self.name,
                                           min(1.0,max(0.0,float(x.get("confidence",0.5)))),
                                           dict(x.get("qualifiers",{}))) for x in payload.get("claims",[]))
        er = ExtractionReceipt(_id("EXT"), artifact_id, parse_id, self.name, self.version, 0, len(claims), ())
        return ExtractionBundle((), claims, er)
