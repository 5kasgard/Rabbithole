"""Versioned non-destructive ontology and semantic mapping registry."""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Tuple


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


@dataclass
class ConceptVersion:
    label: str
    concept_type: str
    properties: Mapping[str, object]
    aliases: Tuple[str, ...] = ()
    external_ids: Tuple[str, ...] = ()
    predecessor_ids: Tuple[str, ...] = ()
    status: str = "provisional"
    scope: Mapping[str, object] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    vid: str = field(default_factory=lambda: _id("CON"))


@dataclass
class MappingHypothesis:
    source_id: str
    target_id: str
    relation: str
    evidence_ids: Tuple[str, ...] = ()
    vetoes: Tuple[str, ...] = ()
    status: str = "proposed"
    scope: Mapping[str, object] = field(default_factory=dict)
    confidence: float = 0.0
    reason: str = ""
    created_at: float = field(default_factory=time.time)
    mid: str = field(default_factory=lambda: _id("MAP"))


class OntologyRegistry:
    RELATIONS = {
        "same_as", "same_kind", "same_measurand", "equivalent_representation",
        "subclass_of", "part_of", "derived_from", "convertible_to",
        "causally_related", "disjoint_from", "related_to", "supersedes",
    }
    STATUSES = {"proposed", "accepted", "rejected", "retracted", "contested"}

    def __init__(self):
        self.concepts: Dict[str, ConceptVersion] = {}
        self.mappings: Dict[str, MappingHypothesis] = {}

    def add(self, concept: ConceptVersion) -> str:
        if concept.status not in {"provisional", "active", "deprecated", "rejected", "revoked"}:
            raise ValueError(concept.status)
        if not concept.label or not concept.concept_type:
            raise ValueError("concept label and type are required")
        if concept.vid in self.concepts:
            raise ValueError("concept version already exists")
        if any(x not in self.concepts for x in concept.predecessor_ids):
            raise KeyError("concept predecessor is absent")
        self.concepts[concept.vid] = concept
        return concept.vid

    def map(self, mapping: MappingHypothesis) -> str:
        if mapping.relation not in self.RELATIONS:
            raise ValueError(mapping.relation)
        if mapping.status not in self.STATUSES:
            raise ValueError(mapping.status)
        if mapping.source_id not in self.concepts or mapping.target_id not in self.concepts:
            raise KeyError("mapping endpoint is absent")
        if mapping.source_id == mapping.target_id:
            raise ValueError("mapping endpoints must be distinct")
        if not 0 <= mapping.confidence <= 1:
            raise ValueError("mapping confidence must be in [0,1]")
        if mapping.status == "accepted" and mapping.vetoes:
            raise ValueError("a mapping with unresolved vetoes cannot be accepted")
        self.mappings[mapping.mid] = mapping
        return mapping.mid

    def set_mapping_status(self, mapping_id: str, status: str, reason: str = "") -> None:
        if status not in self.STATUSES:
            raise ValueError(status)
        m = self.mappings[mapping_id]
        if status == "accepted" and m.vetoes:
            raise ValueError("cannot accept a vetoed mapping")
        m.status = status
        if reason:
            m.reason = reason

    def evolve(self, predecessors: Tuple[str, ...], label: str, concept_type: str,
               properties: Mapping[str, object], reason: str, *,
               scope: Mapping[str, object] | None = None) -> ConceptVersion:
        if not predecessors or any(x not in self.concepts for x in predecessors):
            raise KeyError("predecessor is absent")
        successor = ConceptVersion(label, concept_type, dict(properties),
                                   predecessor_ids=predecessors, status="active",
                                   scope=dict(scope or {}))
        self.add(successor)
        for pid in predecessors:
            self.concepts[pid].status = "deprecated"
            self.map(MappingHypothesis(pid, successor.vid, "supersedes",
                                       status="accepted", confidence=1.0,
                                       reason=reason))
        return successor

    def canonical_view(self, vid: str) -> str:
        if vid not in self.concepts:
            raise KeyError(vid)
        current = vid
        seen = {current}
        while True:
            accepted = [m for m in self.mappings.values()
                        if m.source_id == current and m.relation == "same_as" and m.status == "accepted"]
            if not accepted:
                return current
            accepted.sort(key=lambda x: (x.created_at, x.mid))
            current = accepted[-1].target_id
            if current in seen:
                raise RuntimeError("accepted same_as mapping cycle")
            seen.add(current)

    def to_dict(self) -> dict:
        return {"concepts": [asdict(x) for x in self.concepts.values()],
                "mappings": [asdict(x) for x in self.mappings.values()]}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "OntologyRegistry":
        obj = cls()
        for row in raw.get("concepts", []):
            d = dict(row)
            for key in ("aliases", "external_ids", "predecessor_ids"):
                d[key] = tuple(d.get(key, ()))
            c = ConceptVersion(**d); obj.concepts[c.vid] = c
        for row in raw.get("mappings", []):
            d = dict(row)
            for key in ("evidence_ids", "vetoes"):
                d[key] = tuple(d.get(key, ()))
            m = MappingHypothesis(**d); obj.mappings[m.mid] = m
        return obj
