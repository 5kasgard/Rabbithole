"""Protocols for externally administered stateful environments.

Adapters can be implemented and tested locally, but a gate remains external
unless the task is supplied and administered outside the builder/system.
"""
from __future__ import annotations
import hashlib,json,time,uuid
from dataclasses import asdict,dataclass,field
from typing import Dict,Mapping,Optional,Protocol,Sequence,Tuple
from .wal import EventLog

def _id(p):return f"{p}{uuid.uuid4().hex[:12]}"
class StatefulAdapter(Protocol):
    def reset(self,seed:int)->Mapping[str,object]:...
    def observe(self)->Mapping[str,object]:...
    def act(self,action:Mapping[str,object])->Mapping[str,object]:...
    def check(self,goal:Mapping[str,object])->Mapping[str,object]:...
@dataclass
class EnvironmentSpec:
    environment_id:str;environment_type:str;version:str;action_schema:Mapping[str,object];observation_schema:Mapping[str,object];reproducible_reset:bool;external_administration_required:bool=True
@dataclass
class EnvironmentTask:
    environment_id:str;goal:Mapping[str,object];max_steps:int;seed:int;hidden_state_commitment:str="";fault_schedule:Tuple[Mapping[str,object],...]=();external_task_id:str="";task_id:str=field(default_factory=lambda:_id("EVT"))
@dataclass
class EnvironmentTrace:
    task_id:str;steps:Tuple[Mapping[str,object],...];completion:Mapping[str,object];externally_administered:bool;state:str;trace_digest:str;trace_id:str=field(default_factory=lambda:_id("EVR"))
class EnvironmentRegistry:
    def __init__(self):self.specs:Dict[str,EnvironmentSpec]={};self.adapters:Dict[str,StatefulAdapter]={};self.traces:Dict[str,EnvironmentTrace]={};self.audit=EventLog()
    def register(self,s:EnvironmentSpec,adapter:Optional[StatefulAdapter]=None):self.specs[s.environment_id]=s;self.audit.append("environment_registered",asdict(s)|{"adapter_attached":adapter is not None});self.adapters.update({s.environment_id:adapter} if adapter else {})
    def run(self,task:EnvironmentTask,actions:Sequence[Mapping[str,object]],*,externally_administered:bool=False)->EnvironmentTrace:
        s=self.specs[task.environment_id]
        if task.environment_id not in self.adapters:raise RuntimeError("environment adapter is not attached")
        if len(actions)>task.max_steps:raise ValueError("action plan exceeds maximum steps")
        a=self.adapters[task.environment_id];steps=[{"reset":dict(a.reset(task.seed))}]
        for i,action in enumerate(actions):
            before=dict(a.observe());effect=dict(a.act(action));after=dict(a.observe());steps.append({"step":i,"action":dict(action),"before":before,"effect":effect,"after":after})
        completion=dict(a.check(task.goal));payload={"task":asdict(task),"steps":steps,"completion":completion};digest=hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest()
        ext=externally_administered and bool(task.external_task_id) and bool(task.hidden_state_commitment)
        state="externally_observed" if ext else "internal_protocol_run"
        tr=EnvironmentTrace(task.task_id,tuple(steps),completion,ext,state,digest);self.traces[tr.trace_id]=tr;self.audit.append("environment_task_run",asdict(tr));return tr
    def gate_status(self,trace_id:str)->dict:
        t=self.traces[trace_id];return {"trace_id":trace_id,"passed_external_boundary":t.externally_administered and bool(t.completion.get("success")),"state":t.state,"completion":dict(t.completion)}
    def to_dict(self):return {"specs":[asdict(x) for x in self.specs.values()],"traces":[asdict(x) for x in self.traces.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw):
        o=cls()
        for r in raw.get("specs",[]):s=EnvironmentSpec(**dict(r));o.specs[s.environment_id]=s
        for r in raw.get("traces",[]):
            d=dict(r);d["steps"]=tuple(d.get("steps",()));t=EnvironmentTrace(**d);o.traces[t.trace_id]=t
        o.audit=EventLog.from_dict(raw.get("audit",{}));return o
