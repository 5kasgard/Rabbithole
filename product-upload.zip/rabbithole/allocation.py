"""Replayable test-allocation policies and regret benchmarks."""
from __future__ import annotations
import math,random,time,uuid
from dataclasses import asdict,dataclass,field
from typing import Dict,Mapping,Sequence,Tuple
from .experiment import CandidateTest,Hypothesis,ExperimentPlanner
from .wal import EventLog

def _id(p):return f"{p}{uuid.uuid4().hex[:12]}"
@dataclass(frozen=True)
class AllocationScenario:
    hypotheses:Tuple[Hypothesis,...];tests:Tuple[CandidateTest,...];true_hypothesis_id:str;outcomes:Mapping[str,str]
    decision_values:Mapping[str,float]=field(default_factory=dict);sid:str=field(default_factory=lambda:_id("ALS"))
@dataclass
class AllocationResult:
    policy:str;scenario_id:str;selected_test_id:str;observed_outcome:str;decision_quality:float;cost:float;false_confidence:bool;safety_violation:bool
    result_id:str=field(default_factory=lambda:_id("ALR"))
class TestAllocationHarness:
    POLICIES=("robust","random","cheap_first","uncertainty_only","oracle")
    def __init__(self):self.results:Dict[str,AllocationResult]={};self.audit=EventLog();self.planner=ExperimentPlanner()
    @staticmethod
    def _posterior(sc:AllocationScenario,test:CandidateTest,outcome:str)->dict:
        total=sum(max(0,h.prior) for h in sc.hypotheses);priors={h.hid:max(0,h.prior)/total for h in sc.hypotheses};raw={h.hid:priors[h.hid]*float(test.likelihoods[h.hid].get(outcome,0)) for h in sc.hypotheses};z=sum(raw.values());return {k:(v/z if z else 0) for k,v in raw.items()}
    def choose(self,sc:AllocationScenario,policy:str,seed:int=0)->CandidateTest:
        if policy not in self.POLICIES:raise ValueError(policy)
        valid=[t for t in sc.tests if t.tid in sc.outcomes]
        if not valid:raise ValueError("scenario has no observable tests")
        if policy=="random":return random.Random(seed).choice(valid)
        if policy=="cheap_first":return min(valid,key=lambda t:(t.cost+t.latency+t.risk*10,t.tid))
        ranked={r.test_id:r for r in self.planner.rank(sc.hypotheses,tuple(valid)) if r.valid}
        if policy=="uncertainty_only":return max(valid,key=lambda t:(ranked[t.tid].expected_information_gain,t.tid))
        if policy=="robust":return max(valid,key=lambda t:(ranked[t.tid].score+0.25*ranked[t.tid].minimum_expected_elimination,t.tid))
        # Oracle can see the realized outcome.  It maximizes the same primary
        # decision-quality metric used by benchmark regret, then breaks ties by
        # safety, reversibility, and cost.  Mixing a quality/cost ratio here and
        # later computing quality-only regret can produce impossible negative
        # regret, so the objectives must remain aligned.
        def oracle_value(t):
            post=self._posterior(sc,t,sc.outcomes[t.tid])
            quality=post.get(sc.true_hypothesis_id,0)
            unsafe=int(t.risk>0.5 and not t.reversible)
            total_cost=t.cost+t.latency+t.risk*10
            return (quality,-unsafe,int(t.reversible),-total_cost,t.tid)
        return max(valid,key=oracle_value)
    def run(self,sc:AllocationScenario,policy:str,seed:int=0)->AllocationResult:
        t=self.choose(sc,policy,seed);out=sc.outcomes[t.tid];post=self._posterior(sc,t,out);quality=post.get(sc.true_hypothesis_id,0);false=max(post,key=post.get)!=sc.true_hypothesis_id and max(post.values())>=0.8;safety=t.risk>0.5 and not t.reversible
        r=AllocationResult(policy,sc.sid,t.tid,out,quality,t.cost+t.latency+t.risk*10,false,safety);self.results[r.result_id]=r;self.audit.append("allocation_result",asdict(r));return r
    def benchmark(self,scenarios:Sequence[AllocationScenario],seed:int=0)->dict:
        by={p:[] for p in self.POLICIES}
        for sc in scenarios:
            for p in self.POLICIES:by[p].append(self.run(sc,p,seed))
        oracle_q=sum(r.decision_quality for r in by["oracle"])/max(1,len(scenarios))
        rows={}
        for p,rs in by.items():
            q=sum(r.decision_quality for r in rs)/max(1,len(rs));cost=sum(r.cost for r in rs)/max(1,len(rs));rows[p]={"decision_quality":q,"mean_cost":cost,"regret":oracle_q-q,"false_confidence":sum(r.false_confidence for r in rs),"safety_violations":sum(r.safety_violation for r in rs)}
        robust=rows["robust"];baselines=[rows[x] for x in ("random","cheap_first","uncertainty_only")]
        passed=robust["decision_quality"]>=max(x["decision_quality"] for x in baselines) and robust["false_confidence"]<=min(x["false_confidence"] for x in baselines) and robust["safety_violations"]<=min(x["safety_violations"] for x in baselines)
        result={"policies":rows,"robust_improves":passed,"scenario_count":len(scenarios)};self.audit.append("allocation_benchmark",result);return result
    def to_dict(self):return {"results":[asdict(x) for x in self.results.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw):
        o=cls()
        for r in raw.get("results",[]):x=AllocationResult(**dict(r));o.results[x.result_id]=x
        o.audit=EventLog.from_dict(raw.get("audit",{}));return o
