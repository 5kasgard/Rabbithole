"""Resource-honest utility and uncertainty-reduction accounting.

Scores are local to a declared metric contract. They are never summed across
incommensurable domains or treated as epistemic authority.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Mapping


@dataclass(frozen=True)
class UtilityContract:
    contract_id: str
    uncertainty_metric: str  # binary_entropy | interval_width | categorical_entropy
    resource_unit: str
    outcome_metric: str
    risk_ceiling: float
    allow_cross_task_aggregation: bool = False

    def validate(self) -> None:
        if self.uncertainty_metric not in {"binary_entropy", "interval_width", "categorical_entropy"}:
            raise ValueError("unsupported uncertainty metric")
        if not self.contract_id or not self.resource_unit or not self.outcome_metric:
            raise ValueError("utility contract fields are required")
        if not 0 <= self.risk_ceiling <= 1:
            raise ValueError("risk ceiling must be in [0,1]")


@dataclass(frozen=True)
class UtilityReceipt:
    contract_id: str
    prior_uncertainty: float
    posterior_uncertainty: float
    uncertainty_reduction: float
    outcome_value: float
    resource_used: float
    risk_observed: float
    useful_reduction_per_resource: float | None
    valid: bool
    reason: str
    semantic_authority_granted: bool = False
    metadata: Mapping[str, object] = field(default_factory=dict)


def binary_entropy(p: float) -> float:
    if not 0 <= p <= 1:
        raise ValueError("probability must be in [0,1]")
    if p in {0, 1}:
        return 0.0
    return -(p * math.log2(p) + (1 - p) * math.log2(1 - p))


def categorical_entropy(probabilities: list[float] | tuple[float, ...]) -> float:
    if not probabilities or any(p < 0 for p in probabilities):
        raise ValueError("probabilities must be non-negative and non-empty")
    total = sum(probabilities)
    if not math.isclose(total, 1.0, abs_tol=1e-9):
        raise ValueError("probabilities must sum to one")
    return -sum(p * math.log2(p) for p in probabilities if p > 0)


def account_utility(contract: UtilityContract, *, prior_uncertainty: float,
                    posterior_uncertainty: float, outcome_value: float,
                    resource_used: float, risk_observed: float,
                    metadata: Mapping[str, object] | None = None) -> UtilityReceipt:
    contract.validate()
    if min(prior_uncertainty, posterior_uncertainty, resource_used, risk_observed) < 0:
        raise ValueError("utility inputs cannot be negative")
    reduction = prior_uncertainty - posterior_uncertainty
    if risk_observed > contract.risk_ceiling:
        return UtilityReceipt(contract.contract_id, prior_uncertainty, posterior_uncertainty,
                              reduction, outcome_value, resource_used, risk_observed, None,
                              False, "risk ceiling exceeded", metadata=metadata or {})
    if reduction < 0:
        return UtilityReceipt(contract.contract_id, prior_uncertainty, posterior_uncertainty,
                              reduction, outcome_value, resource_used, risk_observed, None,
                              False, "uncertainty increased", metadata=metadata or {})
    if resource_used == 0:
        ratio = None if reduction > 0 else 0.0
        reason = "zero resource denominator; ratio withheld" if reduction > 0 else "no change"
    else:
        ratio = reduction * max(0.0, outcome_value) / resource_used
        reason = "bounded local utility receipt"
    return UtilityReceipt(contract.contract_id, prior_uncertainty, posterior_uncertainty,
                          reduction, outcome_value, resource_used, risk_observed, ratio,
                          True, reason, metadata=metadata or {})
