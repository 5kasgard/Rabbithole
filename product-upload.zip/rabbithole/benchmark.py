"""Executable validation for the ARC-5 discovery method.

The benchmark has two honest layers:

* a deterministic pre-discovery lineage retrieval benchmark that asks whether
  broad search can recover the mechanism families later expressed in the v5 ARC;
* a causal-analogy negative-control benchmark that rejects elegant transfers
  lacking preserved relations, counterexamples, boundaries, work accounting, or
  falsifiers.

This does not claim autonomous semantic reconstruction.  A complete blind test
also requires an independently configured proposal faculty.  The deterministic
layer establishes that the search and analogy gates expose rather than hide the
known discovery material.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Mapping, Sequence, Tuple

from .analogy import AnalogyGate, AnalogyHypothesis
from .search import LocalCorpusProvider


@dataclass(frozen=True)
class RecoveryTarget:
    name: str
    query: str
    required_term_groups: Tuple[Tuple[str, ...], ...]
    top_k: int = 10


@dataclass
class RecoveryResult:
    target: str
    recovered: bool
    matching_documents: Tuple[str, ...]
    top_documents: Tuple[str, ...]
    missing_groups: Tuple[Tuple[str, ...], ...]


@dataclass
class MethodBenchmarkReport:
    corpus_documents: int
    recovery_results: Tuple[RecoveryResult, ...]
    recovery_rate: float
    invalid_analogies_rejected: int
    invalid_analogies_total: int
    valid_analogy_admitted: bool
    passed: bool
    boundary: str


DEFAULT_TARGETS = (
    RecoveryTarget(
        "constraint-foraging",
        "mine internet constraints not content forager autonomous acquisition",
        (("forager",), ("constraint", "constraints"), ("internet", "search", "web")),
    ),
    RecoveryTarget(
        "placement-and-routing",
        "placement shared memory movement roofline heterogeneous substrate",
        (("placement",), ("roofline", "arithmetic intensity"), ("cpu",), ("gpu",)),
    ),
    RecoveryTarget(
        "reality-contact-harness",
        "reality harness machine checkable tests verifier tether grounding loop",
        (("realityharness", "reality harness"), ("machine-checkable", "machine checkable"),
         ("groundingloop", "grounding loop", "tether")),
    ),
    RecoveryTarget(
        "active-test-allocation",
        "expected information gain scheduler uncertainty reduction cost active test",
        (("expected information",), ("scheduler", "allocate"), ("uncertainty",), ("cost",)),
    ),
    RecoveryTarget(
        "conservation-of-work",
        "abstraction relocates work conservation cost moved not removed",
        (("relocat", "moved"), ("work", "cost"), ("abstraction",)),
    ),
    RecoveryTarget(
        "heterogeneous-substrates",
        "heterogeneous cpu gpu roofline substrate sparse dense workload",
        (("heterogeneous", "substrate"), ("cpu",), ("gpu",), ("sparse", "dense")),
    ),
    RecoveryTarget(
        "anti-drift-reflexivity",
        "anti drift amendment state recursive self audit constitution",
        (("anti-drift", "anti drift"), ("amendment",), ("state",), ("audit", "recursive")),
    ),
    RecoveryTarget(
        "thin-waist-interoperability",
        "thin waist shared coordinate local conformance pairwise reconciliation ontology",
        (("interoperab",), ("standard", "protocol", "interface"),
         ("local", "adapter"), ("ontology", "reconciliation", "mapping")),
    ),
)


def _matches(content: str, groups: Sequence[Sequence[str]]) -> tuple[bool, tuple[tuple[str, ...], ...]]:
    low = content.lower()
    missing = tuple(tuple(g) for g in groups if not any(term.lower() in low for term in g))
    return not missing, missing


class ARC5MethodBenchmark:
    def __init__(self, corpus_root: str | Path,
                 *, exclude_patterns: Sequence[str] = ("rhx/r0/", "arc_discoveries")):
        self.provider = LocalCorpusProvider([corpus_root], exclude_patterns=exclude_patterns)

    def recover(self, targets: Sequence[RecoveryTarget] = DEFAULT_TARGETS) -> Tuple[RecoveryResult, ...]:
        out = []
        for target in targets:
            results = list(self.provider.search(target.query, limit=target.top_k))
            matching = []
            combined = "\n".join(x.snapshot for x in results)
            recovered, missing_collective = _matches(combined, target.required_term_groups)
            # Record documents that contribute at least one required term group;
            # the process is allowed to compose evidence across independent records.
            for result in results:
                low = result.snapshot.lower()
                if any(any(term.lower() in low for term in group)
                       for group in target.required_term_groups):
                    matching.append(result.locator)
            out.append(RecoveryResult(
                target.name, recovered, tuple(matching),
                tuple(x.locator for x in results), tuple(missing_collective)))
        return tuple(out)

    @staticmethod
    def analogy_controls() -> tuple[int, int, bool]:
        invalid = (
            # Evolution does not imply a single global objective.
            AnalogyHypothesis("natural selection", "system routing", "selection among variants",
                "differential reproduction", ("population", "heredity"),
                "choose one global fitness function for every task", ("variants are compared",),
                (), ("local adaptation",), (), (), (), (), ""),
            # Markets do not make price a truth signal.
            AnalogyHypothesis("market", "claim grounding", "distributed aggregation",
                "price formation", ("tradable claims", "budget constraints"),
                "treat consensus price as truth", ("many participants", "local information"),
                (), ("liquid market",), (), ("manipulation",), (), (), ""),
            # Physical settling does not prove all abstract reasoning is continuous.
            AnalogyHypothesis("energy minimisation", "abstract reasoning", "constraint satisfaction",
                "gradient descent", ("continuous state", "defined energy"),
                "encode every proposition as one scalar potential", ("constraints prune",),
                (), ("convex system",), (), (), (), (), ""),
            # Attention is not universal epistemic authority.
            AnalogyHypothesis("neural attention", "evidence weighting", "resource allocation",
                "learned softmax weighting", ("fixed model", "training distribution"),
                "use attention weights as source credibility", ("weights allocate compute",),
                (), ("language modelling",), (), (), (), (), ""),
        )
        rejected = sum(not AnalogyGate.assess(x).admissible for x in invalid)
        valid = AnalogyHypothesis(
            source_system="TCP/IP narrow waist",
            target_problem="independently acquired knowledge does not compose",
            abstract_function="permit heterogeneous producers and consumers to interoperate without pairwise adapters",
            source_mechanism="thin mandatory packet contract with local conformance and layered extension",
            source_context=("packet networks", "independent implementations", "end-to-end principle"),
            target_translation="use a minimal typed carving/placement contract while retaining domain-specific structures outside the waist",
            preserved_relations=("local conformance replaces pairwise negotiation",
                                 "heterogeneity remains above and below the shared contract",
                                 "the waist is smaller than the ecosystem it connects"),
            broken_relations=("knowledge identity is uncertain and reversible whereas packet syntax is mechanically decidable",),
            positive_cases=("Internet protocol interoperability", "shipping-container intermodal transfer"),
            negative_cases=("over-rich universal middleware", "pairwise schema-adapter explosion"),
            boundary_conditions=("only fields with mechanically checkable shared semantics belong in the waist",),
            work_relocated_to=("adapter construction at intake", "placement and verification", "versioned mappings"),
            alternative_mechanisms=("federated task-local mappings", "canonical universal ontology"),
            falsifier="a task distribution where the proposed waist either loses necessary distinctions or fails to reduce reconciliation cost",
        )
        return rejected, len(invalid), AnalogyGate.assess(valid).admissible

    def run(self) -> MethodBenchmarkReport:
        recovery = self.recover()
        rate = sum(x.recovered for x in recovery) / max(1, len(recovery))
        rejected, total, valid = self.analogy_controls()
        passed = rate >= 0.875 and rejected == total and valid
        return MethodBenchmarkReport(
            corpus_documents=len(self.provider._docs), recovery_results=recovery,
            recovery_rate=rate, invalid_analogies_rejected=rejected,
            invalid_analogies_total=total, valid_analogy_admitted=valid,
            passed=passed,
            boundary=("Deterministic retrieval and analogy-gate benchmark only; "
                      "autonomous semantic reconstruction requires a separately configured proposal faculty."),
        )

    def save(self, path: str | Path) -> MethodBenchmarkReport:
        report = self.run()
        Path(path).write_text(json.dumps(asdict(report), indent=2, sort_keys=True))
        return report
