"""Holobiont-style operational ecology for The Field.

The metaphor is used narrowly: a host capability may depend on replaceable,
specialised organs with partially independent failure roots.  Component count is
not diversity.  This module measures contribution, correlated failure,
replaceability, dependency concentration, dormant organs, and host-level mutation
results.  It does not assume cooperation or treat the whole as a unit of truth.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Dict, Iterable, Mapping, Sequence, Tuple

from .organs import MutationResult, OrganRegistry


@dataclass
class EcologyMember:
    organ: str
    capabilities: Tuple[str, ...]
    failure_domains: Tuple[str, ...]
    lineage: str = ""
    replaceable_by: Tuple[str, ...] = ()
    resource_cost: Mapping[str, float] = field(default_factory=dict)


@dataclass
class EcologyReport:
    capability: str
    members: Tuple[str, ...]
    active_members: Tuple[str, ...]
    dormant_members: Tuple[str, ...]
    independent_failure_domains: Tuple[str, ...]
    failure_domain_hhi: float
    single_points_of_failure: Tuple[str, ...]
    replaceable_members: Tuple[str, ...]
    decorative_members: Tuple[str, ...]
    load_bearing_members: Tuple[str, ...]
    dysbiosis_flags: Tuple[str, ...]

    @property
    def healthy(self) -> bool:
        return not self.dysbiosis_flags


class OrganEcology:
    def __init__(self):
        self.members: Dict[str, EcologyMember] = {}
        self.mutations: Dict[tuple[str, str], MutationResult] = {}

    def register(self, member: EcologyMember) -> None:
        if not member.organ.strip() or not member.capabilities:
            raise ValueError("ecology member requires organ and capabilities")
        if not member.failure_domains:
            raise ValueError("ecology member requires at least one failure domain")
        self.members[member.organ] = member

    def record_mutation(self, result: MutationResult) -> None:
        self.mutations[(result.capability, result.organ)] = result

    def assess(self, registry: OrganRegistry, capability: str) -> EcologyReport:
        names = tuple(sorted(n for n, m in self.members.items()
                             if capability in m.capabilities and n in registry.specs))
        active = tuple(n for n in names if registry.specs[n].enabled and any(
            t.organ == n and t.capability == capability and t.outcome == "passed"
            for t in registry.traces))
        dormant = tuple(n for n in names if n not in active)
        counts: Dict[str, int] = {}
        for n in names:
            for root in self.members[n].failure_domains:
                counts[root] = counts.get(root, 0) + 1
        total = sum(counts.values())
        hhi = sum((v / total) ** 2 for v in counts.values()) if total else 1.0
        roots = tuple(sorted(counts))
        # A root shared by all serving members is a host-level common-cause risk.
        spof = tuple(sorted(r for r, n in counts.items() if names and n == len(names)))
        replaceable = tuple(sorted(n for n in names if any(
            alt in names and alt != n for alt in self.members[n].replaceable_by)))
        load = tuple(sorted(n for n in names
                            if self.mutations.get((capability, n)) is not None
                            and self.mutations[(capability, n)].load_bearing))
        decorative = tuple(sorted(n for n in active
                                  if (capability, n) in self.mutations
                                  and not self.mutations[(capability, n)].load_bearing))
        flags = []
        if not names:
            flags.append("no registered ecology members for capability")
        if dormant:
            flags.append("registered members have not participated through the public surface")
        if spof:
            flags.append("common failure roots span every serving member")
        if len(names) > 1 and len(roots) <= 1:
            flags.append("component multiplicity is a monoculture")
        if hhi > 0.5 and len(names) > 1:
            flags.append("failure-domain concentration is high")
        if decorative:
            flags.append("active organs are not deletion-sensitive")
        if names and not load:
            flags.append("no member has passed a host-level mutation gate")
        return EcologyReport(capability, names, active, dormant, roots, hhi,
                             spof, replaceable, decorative, load, tuple(flags))

    def to_dict(self) -> dict:
        return {"members": [asdict(x) for x in self.members.values()],
                "mutations": [asdict(x) for x in self.mutations.values()]}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "OrganEcology":
        obj = cls()
        for row in raw.get("members", []):
            d = dict(row)
            for k in ("capabilities", "failure_domains", "replaceable_by"):
                d[k] = tuple(d.get(k, ()))
            obj.register(EcologyMember(**d))
        for row in raw.get("mutations", []):
            obj.record_mutation(MutationResult(**row))
        return obj
