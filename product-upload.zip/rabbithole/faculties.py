"""Swappable proposal faculties.

Faculties translate, decompose and propose.  Their outputs are retained with the
exact prompt/response receipt but receive no epistemic authority.  All proposals
must pass deterministic schema checks and later search/contact gates.

Supported transports:
* OpenAI-compatible chat-completions HTTP endpoint;
* Ollama chat HTTP endpoint;
* local subprocess that consumes one JSON request and emits one JSON response.
"""
from __future__ import annotations

import json
import os
import subprocess
import time
import urllib.request
import uuid
from dataclasses import dataclass, field
from typing import Callable, Mapping, Optional, Protocol, Sequence, Tuple


class FacultyError(RuntimeError):
    pass


@dataclass
class FacultyReceipt:
    faculty: str
    model: str
    request: Mapping[str, object]
    response: Mapping[str, object]
    started_at: float
    ended_at: float
    rid: str = field(default_factory=lambda: f"FAC{uuid.uuid4().hex[:12]}")


class ProposalFaculty(Protocol):
    name: str
    model: str

    def propose_json(self, *, system: str, user: str,
                     schema: Mapping[str, object], temperature: float = 0.2) -> FacultyReceipt:
        ...


def _json_object(text: str) -> Mapping[str, object]:
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)
        if text.lstrip().startswith("json"):
            text = text.lstrip()[4:].lstrip()
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end <= start:
            raise FacultyError("faculty did not return a JSON object")
        try:
            value = json.loads(text[start:end + 1])
        except json.JSONDecodeError as exc:
            raise FacultyError("faculty returned invalid JSON") from exc
    if not isinstance(value, Mapping):
        raise FacultyError("faculty response must be a JSON object")
    return value


class OpenAICompatibleFaculty:
    name = "openai-compatible"

    def __init__(self, model: str, *, base_url: str = "https://api.openai.com/v1",
                 api_key: Optional[str] = None, timeout: float = 120.0,
                 http_post: Optional[Callable[[str, bytes, Mapping[str, str], float], bytes]] = None):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or os.getenv("OPENAI_API_KEY", "")
        self.timeout = float(timeout)
        self.http_post = http_post or self._post

    @staticmethod
    def _post(url: str, body: bytes, headers: Mapping[str, str], timeout: float) -> bytes:
        req = urllib.request.Request(url, data=body, headers=dict(headers), method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                return response.read()
        except Exception as exc:
            raise FacultyError(f"faculty endpoint failed: {exc}") from exc

    def propose_json(self, *, system: str, user: str,
                     schema: Mapping[str, object], temperature: float = 0.2) -> FacultyReceipt:
        if not self.api_key and self.base_url.startswith("https://api.openai.com"):
            raise FacultyError("OPENAI_API_KEY is not configured")
        request = {
            "model": self.model,
            "messages": [{"role": "system", "content": system},
                         {"role": "user", "content": user}],
            "temperature": float(temperature),
            "response_format": {"type": "json_schema", "json_schema": {
                "name": "field_proposal", "strict": True, "schema": dict(schema)}},
        }
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        start = time.time()
        raw = self.http_post(f"{self.base_url}/chat/completions",
                             json.dumps(request).encode(), headers, self.timeout)
        end = time.time()
        payload = json.loads(raw.decode())
        try:
            text = payload["choices"][0]["message"]["content"]
        except Exception as exc:
            raise FacultyError("unexpected chat-completions response") from exc
        response = _json_object(text)
        return FacultyReceipt(self.name, self.model, request, response, start, end)


class OllamaFaculty:
    name = "ollama"

    def __init__(self, model: str, *, base_url: str = "http://127.0.0.1:11434",
                 timeout: float = 180.0,
                 http_post: Optional[Callable[[str, bytes, Mapping[str, str], float], bytes]] = None):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout = float(timeout)
        self.http_post = http_post or OpenAICompatibleFaculty._post

    def propose_json(self, *, system: str, user: str,
                     schema: Mapping[str, object], temperature: float = 0.2) -> FacultyReceipt:
        request = {
            "model": self.model,
            "messages": [{"role": "system", "content": system},
                         {"role": "user", "content": user}],
            "stream": False, "format": dict(schema),
            "options": {"temperature": float(temperature)},
        }
        start = time.time()
        raw = self.http_post(f"{self.base_url}/api/chat", json.dumps(request).encode(),
                             {"Content-Type": "application/json"}, self.timeout)
        end = time.time()
        payload = json.loads(raw.decode())
        response = _json_object(payload.get("message", {}).get("content", ""))
        return FacultyReceipt(self.name, self.model, request, response, start, end)


class SubprocessFaculty:
    name = "subprocess"

    def __init__(self, command: Sequence[str], *, model: str = "local-subprocess",
                 timeout: float = 180.0):
        if not command:
            raise ValueError("subprocess faculty command is required")
        self.command = tuple(command)
        self.model = model
        self.timeout = float(timeout)

    def propose_json(self, *, system: str, user: str,
                     schema: Mapping[str, object], temperature: float = 0.2) -> FacultyReceipt:
        request = {"system": system, "user": user, "schema": dict(schema),
                   "temperature": float(temperature)}
        start = time.time()
        try:
            proc = subprocess.run(self.command, input=json.dumps(request), text=True,
                                  capture_output=True, timeout=self.timeout, check=False)
        except Exception as exc:
            raise FacultyError(f"subprocess faculty failed to start: {exc}") from exc
        end = time.time()
        if proc.returncode != 0:
            raise FacultyError(f"subprocess faculty exited {proc.returncode}: {proc.stderr.strip()}")
        response = _json_object(proc.stdout)
        return FacultyReceipt(self.name, self.model, request, response, start, end)
