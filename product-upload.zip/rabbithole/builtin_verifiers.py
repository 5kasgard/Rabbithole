"""Small independently executable verifier implementations.

These verifiers are intentionally narrow.  Their strength is that their
contracts and trusted bases are explicit; they refuse inputs outside scope.
"""
from __future__ import annotations

import ast
import hashlib
import json
import math
import os
import re
import statistics
import subprocess
from pathlib import Path
from typing import Mapping, Sequence

from .verification import Claim


_ALLOWED_AST = (
    ast.Expression, ast.BinOp, ast.UnaryOp, ast.Add, ast.Sub, ast.Mult, ast.Div,
    ast.Pow, ast.Mod, ast.USub, ast.UAdd, ast.Name, ast.Constant, ast.Load,
)


def _safe_sympy(expression: str, symbols: Sequence[str]):
    import sympy as sp
    tree = ast.parse(expression, mode="eval")
    if any(not isinstance(node, _ALLOWED_AST) for node in ast.walk(tree)):
        raise ValueError("expression contains unsupported syntax")
    allowed_symbols = {name: sp.Symbol(name) for name in symbols}

    def convert(node):
        if isinstance(node, ast.Expression): return convert(node.body)
        if isinstance(node, ast.Constant):
            if not isinstance(node.value, (int, float)): raise ValueError("non-numeric constant")
            return sp.Rational(str(node.value))
        if isinstance(node, ast.Name):
            if node.id not in allowed_symbols: raise ValueError(f"undeclared symbol {node.id!r}")
            return allowed_symbols[node.id]
        if isinstance(node, ast.UnaryOp):
            value = convert(node.operand)
            return -value if isinstance(node.op, ast.USub) else value
        if isinstance(node, ast.BinOp):
            left, right = convert(node.left), convert(node.right)
            if isinstance(node.op, ast.Add): return left + right
            if isinstance(node.op, ast.Sub): return left - right
            if isinstance(node.op, ast.Mult): return left * right
            if isinstance(node.op, ast.Div): return left / right
            if isinstance(node.op, ast.Pow): return left ** right
            if isinstance(node.op, ast.Mod): return left % right
        raise ValueError("unsupported expression")
    return convert(tree)


def math_equality_verifier(claim: Claim, inputs: Mapping[str, object]) -> Mapping[str, object]:
    spec = inputs.get("formal_statement")
    if not isinstance(spec, Mapping):
        return {"state": "inconclusive", "reason": "formal_statement must be a mapping"}
    lhs, rhs = str(spec.get("lhs", "")), str(spec.get("rhs", ""))
    symbols = tuple(str(x) for x in spec.get("symbols", ()))
    if not lhs or not rhs:
        return {"state": "inconclusive", "reason": "lhs and rhs are required"}
    import sympy as sp
    left, right = _safe_sympy(lhs, symbols), _safe_sympy(rhs, symbols)
    residual = sp.simplify(left - right)
    supported = residual == 0
    receipt = hashlib.sha256(json.dumps({"lhs": lhs, "rhs": rhs, "symbols": symbols,
                                        "residual": str(residual)}, sort_keys=True).encode()).hexdigest()
    return {"state": "supported" if supported else "falsified",
            "observed": {"residual": str(residual), "checker_receipt": receipt},
            "checker_receipt": receipt,
            "reason": "symbolic identity reduced to zero" if supported else "symbolic residual is non-zero"}


def software_command_verifier(claim: Claim, inputs: Mapping[str, object]) -> Mapping[str, object]:
    artifact = Path(str(inputs.get("artifact", ""))).resolve()
    prop = inputs.get("property")
    if not isinstance(prop, Mapping):
        return {"state": "inconclusive", "reason": "property must be a mapping"}
    allowed_root = Path(str(prop.get("allowed_root", artifact.parent))).resolve()
    if not (artifact == allowed_root or allowed_root in artifact.parents):
        return {"state": "execution_failed", "reason": "artifact is outside allowed root"}
    command = prop.get("command")
    if not isinstance(command, Sequence) or isinstance(command, (str, bytes)) or not command:
        return {"state": "inconclusive", "reason": "property.command must be an argv sequence"}
    argv = [str(x).replace("{artifact}", str(artifact)) for x in command]
    timeout = min(60.0, max(0.1, float(prop.get("timeout", 10.0))))
    env = {"PATH": os.environ.get("PATH", ""), "PYTHONPATH": os.environ.get("PYTHONPATH", "")}
    try:
        proc = subprocess.run(argv, cwd=str(allowed_root), capture_output=True, text=True,
                              timeout=timeout, env=env, shell=False)
    except subprocess.TimeoutExpired:
        return {"state": "execution_failed", "reason": "property command timed out"}
    observed = {"returncode": proc.returncode, "stdout": proc.stdout[-4000:], "stderr": proc.stderr[-4000:]}
    return {"state": "supported" if proc.returncode == 0 else "falsified",
            "observed": observed,
            "reason": "registered command exited zero" if proc.returncode == 0 else "registered command failed"}


def statistical_mean_verifier(claim: Claim, inputs: Mapping[str, object]) -> Mapping[str, object]:
    dataset = inputs.get("dataset")
    assumptions = inputs.get("assumptions")
    estimand = inputs.get("estimand")
    if not isinstance(dataset, Sequence) or isinstance(dataset, (str, bytes)):
        return {"state": "inconclusive", "reason": "dataset must be a numeric sequence"}
    xs = [float(x) for x in dataset]
    if len(xs) < 2 or not all(math.isfinite(x) for x in xs):
        return {"state": "inconclusive", "reason": "at least two finite observations are required"}
    if estimand != "mean":
        return {"state": "inconclusive", "reason": "this verifier only supports the mean estimand"}
    if not isinstance(assumptions, Mapping) or not assumptions.get("independent", False):
        return {"state": "inconclusive", "reason": "independence assumption is not declared"}
    expected = inputs.get("expected_interval")
    mean = statistics.fmean(xs); sd = statistics.stdev(xs); se = sd / math.sqrt(len(xs))
    # Normal approximation is deliberately stated and bounded to this simple verifier.
    interval = (mean - 1.96 * se, mean + 1.96 * se)
    if not isinstance(expected, Sequence) or len(expected) != 2:
        return {"state": "inconclusive", "observed": {"mean": mean, "interval95": interval},
                "reason": "expected_interval is required to decide the claim"}
    lo, hi = float(expected[0]), float(expected[1])
    supported = interval[0] >= lo and interval[1] <= hi
    return {"state": "supported" if supported else "falsified",
            "observed": {"n": len(xs), "mean": mean, "sd": sd, "interval95": interval,
                         "assumption": "independent approximately normal sample mean"},
            "reason": "estimated interval lies inside declared claim interval" if supported else
                      "estimated interval is not contained in declared claim interval"}


def documentary_verifier(claim: Claim, inputs: Mapping[str, object]) -> Mapping[str, object]:
    locator = Path(str(inputs.get("record_locator", ""))).resolve()
    pattern = str(inputs.get("fact_pattern", ""))
    if not locator.is_file() or not pattern:
        return {"state": "inconclusive", "reason": "record file and fact pattern are required"}
    data = locator.read_bytes()
    text = data.decode("utf-8", errors="replace")
    mode = str(inputs.get("match", "literal"))
    found = bool(re.search(pattern, text, flags=re.I)) if mode == "regex" else pattern.lower() in text.lower()
    digest = hashlib.sha256(data).hexdigest()
    return {"state": "supported" if found else "falsified",
            "observed": {"record_digest": digest, "matched": found, "locator": str(locator)},
            "artifacts": (f"sha256:{digest}",),
            "reason": "pattern found in preserved record" if found else "pattern absent from preserved record"}


def normative_approval_verifier(claim: Claim, inputs: Mapping[str, object]) -> Mapping[str, object]:
    owner = str(inputs.get("decision_owner", ""))
    values = inputs.get("values")
    jurisdiction = str(inputs.get("jurisdiction", ""))
    approval = str(inputs.get("approval", ""))
    if not owner or not values or not jurisdiction:
        return {"state": "inconclusive", "reason": "owner, values, and jurisdiction are required"}
    if not approval:
        return {"state": "untestable", "reason": "no accountable approval record was supplied"}
    digest = hashlib.sha256(json.dumps({"owner": owner, "values": values,
                                       "jurisdiction": jurisdiction, "approval": approval},
                                      sort_keys=True, default=str).encode()).hexdigest()
    # Contract authority ceiling is zero: this records governance permission, not truth.
    return {"state": "supported", "observed": {"approval_receipt": digest,
                                                  "decision_owner": owner,
                                                  "jurisdiction": jurisdiction},
            "reason": "accountable normative approval was recorded; no epistemic truth authority earned"}


def empirical_json_verifier(claim: Claim, inputs: Mapping[str, object]) -> Mapping[str, object]:
    """Read one explicitly addressed JSON measurement under a bounded transport contract."""
    import urllib.parse, urllib.request, ipaddress, socket
    procedure = inputs.get("procedure")
    measurand = str(inputs.get("measurand", ""))
    if not isinstance(procedure, Mapping) or not measurand:
        return {"state": "inconclusive", "reason": "measurand and procedure mapping are required"}
    locator = str(procedure.get("locator", ""))
    if not locator:
        return {"state": "inconclusive", "reason": "procedure.locator is required"}
    parsed = urllib.parse.urlparse(locator)
    try:
        if parsed.scheme in {"", "file"}:
            path = Path(urllib.request.url2pathname(parsed.path) if parsed.scheme == "file" else locator).resolve()
            root = Path(str(procedure.get("allowed_root", path.parent))).resolve()
            if not (path == root or root in path.parents):
                return {"state": "execution_failed", "reason": "measurement file is outside allowed root"}
            data = path.read_bytes()
        elif parsed.scheme in {"http", "https"}:
            host = parsed.hostname or ""
            infos = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
            private = any(ipaddress.ip_address(x[4][0]).is_private or ipaddress.ip_address(x[4][0]).is_loopback for x in infos)
            if private and not bool(procedure.get("allow_private_network", False)):
                return {"state": "execution_failed", "reason": "private-network measurement contact not authorized"}
            request = urllib.request.Request(locator, headers={"User-Agent": "the-field-measurement/0.9"})
            with urllib.request.urlopen(request, timeout=min(20.0, float(procedure.get("timeout", 5.0)))) as response:
                data = response.read(int(procedure.get("max_bytes", 1_000_000)) + 1)
            if len(data) > int(procedure.get("max_bytes", 1_000_000)):
                return {"state": "execution_failed", "reason": "measurement exceeds byte limit"}
        else:
            return {"state": "execution_failed", "reason": "unsupported measurement scheme"}
        record = json.loads(data)
        key = str(procedure.get("value_key", "value"))
        value = float(record[key])
        sigma = float(record.get(str(procedure.get("sigma_key", "sigma")), 0.0))
        unit = str(record.get(str(procedure.get("unit_key", "unit")), ""))
        expected = procedure.get("expected_interval")
        digest = hashlib.sha256(data).hexdigest()
        observed = {"measurand": measurand, "value": value, "sigma": sigma, "unit": unit,
                    "receipt": f"sha256:{digest}", "locator": locator}
        if not isinstance(expected, Sequence) or len(expected) != 2:
            return {"state": "inconclusive", "observed": observed,
                    "artifacts": (f"sha256:{digest}",),
                    "reason": "measurement captured; expected_interval is required to decide the claim"}
        lo, hi = float(expected[0]), float(expected[1])
        supported = value - sigma >= lo and value + sigma <= hi
        return {"state": "supported" if supported else "falsified", "observed": observed,
                "artifacts": (f"sha256:{digest}",),
                "reason": "measurement uncertainty lies within expected interval" if supported else
                          "measurement uncertainty is outside expected interval"}
    except Exception as exc:
        return {"state": "execution_failed", "reason": f"{type(exc).__name__}: {exc}"}


def causal_identification_verifier(claim: Claim, inputs: Mapping[str, object]) -> Mapping[str, object]:
    """Check graphical identification only; it never supports an effect estimate."""
    from .causal import CausalClaim, CausalModel, CausalRegistry
    graph = inputs.get("causal_graph")
    estimand = inputs.get("estimand")
    assumptions = inputs.get("identification_assumptions")
    if not isinstance(graph, Mapping) or not isinstance(estimand, Mapping):
        return {"state": "inconclusive", "reason": "causal_graph and estimand mappings are required"}
    try:
        model = CausalModel(tuple(graph.get("nodes", ())),
                            tuple(tuple(x) for x in graph.get("edges", ())),
                            tuple(graph.get("observed", ())),
                            tuple(str(x) for x in assumptions or ()),
                            str(graph.get("population", "")),
                            dict(graph.get("valid_conditions", {})))
        registry = CausalRegistry(); registry.register(model)
        cc = CausalClaim(model.mid, str(estimand["treatment"]), str(estimand["outcome"]),
                         tuple(estimand.get("adjustment", ())),
                         str(estimand.get("intervention", "do")),
                         str(estimand.get("estimand", "average_treatment_effect")),
                         str(estimand.get("target_population", "")))
        result = registry.identify_backdoor(cc)
        return {"state": "consistent" if result.identified else "undecidable",
                "observed": {"identified": result.identified, "method": result.method,
                             "adjustment": result.adjustment, "formula": result.formula,
                             "assumptions": result.assumptions, "reasons": result.reasons},
                "reason": "estimand is graphically identified; no effect truth authority earned" if result.identified
                          else "estimand is not identified under the declared graph and assumptions"}
    except Exception as exc:
        return {"state": "inconclusive", "reason": f"{type(exc).__name__}: {exc}"}
