"""Public raw-artifact inquiry spine.

This is intentionally bounded: it performs real acquisition, parsing,
proposal-only carving, reversible placement and auditable presentation.  It
abstains at ungated verification or semantics rather than fabricating completion.
"""
from __future__ import annotations
import time, uuid
from dataclasses import asdict, dataclass, field
from typing import Mapping, Optional, Sequence, Tuple

from .acquisition import AcquisitionEngine, FetchPolicy
from .akbc import FieldSystem
from .argument import ArgumentClaim
from .extraction import DeterministicQuantityExtractor, FacultyClaimExtractor
from .faculties import ProposalFaculty
from .security import ArtifactRiskScanner


def _id(): return f"INQ{uuid.uuid4().hex[:12]}"

@dataclass
class InquiryRequest:
    question: str
    locators: Tuple[str,...]
    source_labels: Mapping[str,str]=field(default_factory=dict)
    allow_private_network: bool=False
    use_faculty_extraction: bool=False
    request_id: str=field(default_factory=_id)

@dataclass
class StageReceipt:
    stage: str
    status: str
    inputs: Tuple[str,...]
    outputs: Tuple[str,...]
    boundary: str=""

@dataclass
class InquiryReport:
    request_id: str
    question: str
    artifacts: Tuple[dict,...]
    extraction_receipts: Tuple[dict,...]
    placements: Tuple[dict,...]
    generic_claims: Tuple[str,...]
    stage_receipts: Tuple[StageReceipt,...]
    abstentions: Tuple[str,...]
    result_state: str
    created_at: float=field(default_factory=time.time)

class InquiryEngine:
    def __init__(self, acquisition: AcquisitionEngine, knowledge: FieldSystem, argument_graph):
        self.acquisition=acquisition; self.knowledge=knowledge; self.arguments=argument_graph
        self.quant=DeterministicQuantityExtractor()

    def run(self, request: InquiryRequest, faculty: Optional[ProposalFaculty]=None) -> InquiryReport:
        if not request.question.strip(): raise ValueError("question is required")
        if not request.locators: raise ValueError("at least one real artifact locator is required")
        artifacts=[]; extraction=[]; placements=[]; claims=[]; stages=[]; abstain=[]
        policy=FetchPolicy(allowed_schemes=("file","http","https") if request.allow_private_network else ("file","https"), allow_private_network=request.allow_private_network)
        for locator in request.locators:
            parsed=self.acquisition.acquire(locator,policy)
            risk=ArtifactRiskScanner.scan(parsed.text)
            artifacts.append({"artifact":asdict(parsed.artifact),"parse":asdict(parsed.parse),"risk":asdict(risk)})
            stages.append(StageReceipt("acquisition","passed",(locator,),(parsed.artifact.artifact_id,),"bytes and parse are receipts, not truth"))
            source=request.source_labels.get(locator,locator)
            bundle=self.quant.extract(parsed.text,artifact_id=parsed.artifact.artifact_id,parse_id=parsed.parse.parse_id,
                                      source=source,locator=locator,kinds=self.knowledge.kinds)
            extraction.append(asdict(bundle.receipt))
            for carving in bundle.quantitative:
                # Preserve exact artifact digest rather than duplicating parsed text as the authority anchor.
                carving.source_snapshot=parsed.text
                decision=self.knowledge.ingest(carving); placements.append(asdict(decision))
            if request.use_faculty_extraction:
                if faculty is None:
                    abstain.append("faculty extraction requested but no proposal faculty was configured")
                elif risk.untrusted:
                    abstain.append(f"faculty extraction refused for {locator}: untrusted-instruction patterns detected")
                else:
                    fb=FacultyClaimExtractor(faculty).extract(parsed.text,artifact_id=parsed.artifact.artifact_id,
                                                               parse_id=parsed.parse.parse_id,source=source,locator=locator)
                    extraction.append(asdict(fb.receipt))
                    for c in fb.generic:
                        claim=ArgumentClaim(c.statement,"unclassified",scope=dict(c.qualifiers),author=source)
                        self.arguments.add_claim(claim); claims.append(claim.cid)
            if not bundle.quantitative and not request.use_faculty_extraction:
                abstain.append(f"no deterministic quantitative carving found in {locator}; broader semantics require a configured proposal faculty")
        stages.append(StageReceipt("carving","passed" if extraction else "abstained",
                                   tuple(x["artifact"]["artifact_id"] for x in artifacts),
                                   tuple(x["extraction_id"] for x in extraction),"all outputs remain zero-authority proposals"))
        stages.append(StageReceipt("placement","passed" if placements else "not-applicable",
                                   tuple(x["extraction_id"] for x in extraction),
                                   tuple(x["observation_id"] for x in placements),"identity remains reversible; no value authority is earned"))
        if placements:
            abstain.append("observations are untested; no empirical truth or derived answer is claimed until a registered verifier contacts the measurands")
        state="provisional" if placements or claims else "abstained"
        return InquiryReport(request.request_id,request.question,tuple(artifacts),tuple(extraction),tuple(placements),tuple(claims),tuple(stages),tuple(abstain),state)
