"""Goal-derived capability and interface graph with gate-backed states."""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Tuple


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:11]}"


STATES = {"absent", "specified", "prototype", "partial", "live", "falsified", "deferred", "blocked"}


@dataclass
class CapabilityNode:
    name: str
    purpose: str
    local_current: Tuple[str, ...]
    local_goal: Tuple[str, ...]
    whole_effects: Tuple[str, ...]
    dependencies: Tuple[str, ...] = ()
    interfaces: Tuple[str, ...] = ()
    authority_effect: str = "none"
    substrate_constraints: Tuple[str, ...] = ()
    failure_modes: Tuple[str, ...] = ()
    evidence_ids: Tuple[str, ...] = ()
    gates: Tuple[str, ...] = ()
    state: str = "specified"
    boundary: str = ""
    cid: str = field(default_factory=lambda: _id("CAP"))

    def validate(self) -> None:
        if self.state not in STATES:
            raise ValueError(self.state)
        if not self.name or not self.local_goal or not self.whole_effects:
            raise ValueError("capability requires a name, local goal, and whole effect")


@dataclass
class InterfaceNode:
    source: str
    target: str
    contract: str
    failure_modes: Tuple[str, ...]
    evidence_ids: Tuple[str, ...] = ()
    state: str = "specified"
    iid: str = field(default_factory=lambda: _id("IF"))


@dataclass
class GateResult:
    capability: str
    gate: str
    passed: bool
    public_surface: str
    observed: str
    evidence_ids: Tuple[str, ...]
    mutation_sensitive: bool
    scope: str = ""
    status: str = "pass"  # pass|fail|partial|blocked
    created_at: float = field(default_factory=time.time)
    gid: str = field(default_factory=lambda: _id("GATE"))


class CapabilityGraph:
    def __init__(self):
        self.capabilities: Dict[str, CapabilityNode] = {}
        self.interfaces: Dict[str, InterfaceNode] = {}
        self.gates: Dict[str, GateResult] = {}

    def register(self, node: CapabilityNode) -> None:
        node.validate(); self.capabilities[node.name] = node

    def connect(self, edge: InterfaceNode) -> None:
        if edge.source not in self.capabilities or edge.target not in self.capabilities:
            raise KeyError("interface endpoint is absent")
        self.interfaces[edge.iid] = edge

    def record_gate(self, gate: GateResult) -> None:
        if gate.capability not in self.capabilities:
            raise KeyError(gate.capability)
        self.gates[gate.gid] = gate
        node = self.capabilities[gate.capability]
        node.gates = tuple(sorted(set(node.gates + (gate.gid,))))
        node.evidence_ids = tuple(sorted(set(node.evidence_ids + gate.evidence_ids + (gate.gid,))))
        relevant = [g for g in self.gates.values() if g.capability == gate.capability]
        if any(g.status == "fail" for g in relevant):
            node.state = "falsified"
        elif any(g.status == "blocked" for g in relevant) and not any(g.passed for g in relevant):
            node.state = "blocked"
        elif all(g.passed and g.mutation_sensitive for g in relevant) and relevant:
            node.state = "live"
        elif any(g.passed for g in relevant) or any(g.status == "partial" for g in relevant):
            # A bounded mechanism can be real while its decisive external or
            # representative contact remains outstanding.  Preserve that as
            # partial rather than leaving it merely specified.
            node.state = "partial"

    def dependency_closure(self, name: str) -> Tuple[str, ...]:
        if name not in self.capabilities:
            raise KeyError(name)
        seen: set[str] = set(); stack = [name]
        while stack:
            current = stack.pop()
            for dep in self.capabilities[current].dependencies:
                if dep not in seen:
                    seen.add(dep); stack.append(dep)
        return tuple(sorted(seen))

    def blast_radius(self, name: str) -> Tuple[str, ...]:
        affected: set[str] = set(); changed = True
        while changed:
            changed = False
            for candidate, node in self.capabilities.items():
                if candidate != name and candidate not in affected and (
                    name in node.dependencies or any(d in affected for d in node.dependencies)
                ):
                    affected.add(candidate); changed = True
        return tuple(sorted(affected))

    def posiwid(self) -> dict:
        counts = {s: 0 for s in STATES}
        for node in self.capabilities.values():
            counts[node.state] += 1
        invalid_live = [name for name, node in self.capabilities.items()
                        if node.state == "live" and not all(
                            g.passed and g.mutation_sensitive for g in self.gates.values()
                            if g.capability == name)]
        return {"counts": counts,
                "missing_or_unproven": sorted(name for name, node in self.capabilities.items()
                                               if node.state not in {"live", "deferred"}),
                "invalid_live_claims": sorted(invalid_live),
                "interfaces": len(self.interfaces), "valid": not invalid_live}

    def to_dict(self) -> dict:
        return {"capabilities": [asdict(x) for x in self.capabilities.values()],
                "interfaces": [asdict(x) for x in self.interfaces.values()],
                "gates": [asdict(x) for x in self.gates.values()]}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "CapabilityGraph":
        obj = cls()
        for row in raw.get("capabilities", []):
            d = dict(row)
            for key in ("local_current", "local_goal", "whole_effects", "dependencies", "interfaces",
                        "substrate_constraints", "failure_modes", "evidence_ids", "gates"):
                d[key] = tuple(d.get(key, ()))
            obj.register(CapabilityNode(**d))
        for row in raw.get("interfaces", []):
            d = dict(row); d["failure_modes"] = tuple(d.get("failure_modes", ())); d["evidence_ids"] = tuple(d.get("evidence_ids", ()))
            edge = InterfaceNode(**d); obj.interfaces[edge.iid] = edge
        for row in raw.get("gates", []):
            d = dict(row); d["evidence_ids"] = tuple(d.get("evidence_ids", ()))
            gate = GateResult(**d); obj.gates[gate.gid] = gate
        return obj


GOAL_FAMILIES = (
    ("intent", "turn input into an explicit falsifiable objective"),
    ("search", "construct and cover the relevant evidence field"),
    ("acquisition", "retrieve immutable external artifacts"),
    ("parsing", "convert artifacts into representation-preserving structures"),
    ("carving", "propose typed observations and claims without authority"),
    ("representation", "select intermediate structures with declared information loss"),
    ("placement", "align kinds, entities, measurands, events, and relations reversibly"),
    ("provenance", "preserve derivation, integrity, independence groups, and receipts"),
    ("verification", "route claims to reality-appropriate verification contracts"),
    ("uncertainty", "preserve uncertainty, contradiction, correlation, and dependency"),
    ("reasoning", "use domain-suited solvers and design mechanisms"),
    ("causal", "separate association from identified causal effects"),
    ("experiment", "choose contacts that discriminate live hypotheses"),
    ("routing", "select mechanisms and substrates from measured performance"),
    ("memory", "retain history, staleness, invalidation, and re-grounding"),
    ("federation", "exchange append-only knowledge without false consensus"),
    ("action", "execute bounded actions with approval, monitoring, and compensation"),
    ("presentation", "expose results, uncertainty, alternatives, and chain of custody"),
    ("security", "contain poisoning, escalation, and supply-chain compromise"),
    ("assurance", "calibrate and test whole-system capability under mutation and shift"),
    ("reflexivity", "improve the system without self-authorising its own claims"),
)


def goal_seed() -> CapabilityGraph:
    graph = CapabilityGraph()
    for name, purpose in GOAL_FAMILIES:
        graph.register(CapabilityNode(
            name, purpose, ("not yet measured",), (purpose,),
            (f"whole system can rely on {name} without hidden authority or manual substitution",),
            state="specified"))
    chain = [x[0] for x in GOAL_FAMILIES[:15]]
    for source, target in zip(chain, chain[1:]):
        node = graph.capabilities[target]
        node.dependencies = tuple(sorted(set(node.dependencies + (source,))))
        graph.connect(InterfaceNode(
            source, target,
            f"{source} output remains typed, scoped, provenance-bearing, and rejectable",
            ("silent coercion", "authority laundering", "information loss", "unhandled abstention")))
    for name in ("federation", "action", "presentation", "security", "assurance", "reflexivity"):
        graph.capabilities[name].dependencies = tuple(sorted(set(graph.capabilities[name].dependencies + ("memory",))))
    return graph
