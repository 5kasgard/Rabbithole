"""Deterministic, resolution-adaptive presentation of one grounded state.

Presentation cannot increase authority.  It exposes support, contest, unknowns,
scope, contact classes, action permission, and next discriminating tests at
several resolutions while keeping one underlying report object.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Mapping, Sequence, Tuple


OUTCOME_STATES = {
    "supported", "supported-within-scope", "falsified", "consistent",
    "contested", "inconclusive", "undecidable", "untestable",
    "insufficient-contact", "normative-decision-required",
    "resource-exhausted", "out-of-scope", "execution-failed", "unresolved",
}
ZERO_AUTHORITY_STATES = {
    "inconclusive", "undecidable", "untestable", "insufficient-contact",
    "normative-decision-required", "resource-exhausted", "out-of-scope",
    "execution-failed", "unresolved",
}


@dataclass
class PresentationInput:
    title: str
    answer: str
    status: str
    supported_by: Tuple[Mapping[str, object], ...] = ()
    contested_by: Tuple[Mapping[str, object], ...] = ()
    unknowns: Tuple[str, ...] = ()
    assumptions: Tuple[str, ...] = ()
    scope: Tuple[str, ...] = ()
    next_tests: Tuple[Mapping[str, object], ...] = ()
    provenance: Tuple[Mapping[str, object], ...] = ()
    action_state: str = "not-requested"
    authority_ceiling: float = 0.0


@dataclass
class ResolutionReport:
    resolution: str
    headline: str
    body: Mapping[str, object]
    authority_ceiling: float


class Presenter:
    LEVELS = {"brief", "standard", "technical", "audit"}

    @classmethod
    def render(cls, item: PresentationInput, resolution: str = "standard") -> ResolutionReport:
        if resolution not in cls.LEVELS:
            raise ValueError(f"unknown presentation resolution {resolution!r}")
        if item.status not in OUTCOME_STATES:
            raise ValueError(f"unknown outcome state {item.status!r}")
        if not (0.0 <= float(item.authority_ceiling) <= 1.0):
            raise ValueError("authority ceiling must be in [0,1]")
        if item.status in ZERO_AUTHORITY_STATES and float(item.authority_ceiling) != 0.0:
            raise ValueError(f"outcome state {item.status!r} cannot carry truth authority")
        headline = f"{item.title}: {item.status}"
        base = {
            "answer": item.answer,
            "status": item.status,
            "unknowns": list(item.unknowns),
            "scope": list(item.scope),
            "authority_ceiling": item.authority_ceiling,
        }
        if resolution == "brief":
            body = base
        elif resolution == "standard":
            body = base | {
                "support_count": len(item.supported_by),
                "contest_count": len(item.contested_by),
                "assumptions": list(item.assumptions),
                "next_tests": list(item.next_tests[:3]),
                "action_state": item.action_state,
            }
        elif resolution == "technical":
            body = base | {
                "supported_by": list(item.supported_by),
                "contested_by": list(item.contested_by),
                "assumptions": list(item.assumptions),
                "next_tests": list(item.next_tests),
                "action_state": item.action_state,
            }
        else:
            body = asdict(item)
        # Rendering never changes the underlying ceiling.
        return ResolutionReport(resolution, headline, body, item.authority_ceiling)
