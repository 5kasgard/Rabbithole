"""Bounded hybrid and heterogeneous performance portfolio.

This module does not treat latency as authority.  It routes only into mechanism
regions that survived the Round-2 ARC-5A contact campaign and retains the
canonical fresh-process/reference path as fallback, rollback target and oracle.

The portfolio is deliberately heterogeneous by bounded function and homogeneous
at authority boundaries:

* Python remains the control, contract and replay authority.
* Cold batching may amortise imports while retaining a fresh authority domain.
* A capability-scoped warm capsule may serve repeated bounded local operations.
* SQLite may own an explicitly restricted idempotent key-set mutation slice.
* Native numerical code may own only admitted integer-exact regular graphs and
  must remain under differential reference checking.
* Unknown, shifted, remote, edge, energy and longitudinal regimes fall back or
  abstain rather than inheriting a benchmark result they did not earn.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Tuple

from .wal import EventLog

BASELINE_V015_SHA256 = "bdabe625624b68d754f64a95ca3427565ccfde0bf469ca6ff8f9d582a538736d"
PARENT_V016_SHA256 = "496a27e7a956f0625aca3c4e7642a947f49f9497ad3a9ef46fc0416088e4572a"
CONTACT_PAYLOAD_SHA256 = "ec15c7c948c5398b1a04677056058199e5b4feac06972f80bac7be4c2bf5fbda"

RISK_LEVELS = {"low", "medium", "high", "critical", "unknown"}
MODES = {
    "fresh_reference",
    "cold_batch",
    "warm_capsule",
    "transactional_state",
    "native_specialist",
    "abstain",
}


def _canon(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()


def _digest(value: object) -> str:
    return hashlib.sha256(_canon(value)).hexdigest()


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:14]}"


def release_source_digest(root: str | os.PathLike[str] | None = None) -> str:
    """Digest executable Python source and frozen stage data.

    This is a process identity, not the distribution archive identity.  The
    archive SHA-256 remains an external release receipt.  The source digest is
    intentionally deterministic and excludes generated evidence, caches and
    runtime state.
    """
    package_root = Path(root) if root else Path(__file__).resolve().parents[1]
    paths = []
    for pattern in ("*.py", "rabbithole/*.py", "stage4c/*.py", "stage4d/*.py",
                    "stage5/*.py", "stage6/*.py"):
        paths.extend(package_root.glob(pattern))
    h = hashlib.sha256()
    for path in sorted({p.resolve() for p in paths if p.is_file()}):
        rel = path.relative_to(package_root.resolve()).as_posix()
        h.update(rel.encode() + b"\0")
        h.update(path.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


@dataclass(frozen=True)
class PerformanceTask:
    operation: str
    risk_level: str = "unknown"
    repetitions: int = 1
    batchable: bool = False
    local_only: bool = True
    network_required: bool = False
    credential_bearing: bool = False
    shared_mutable_state: bool = False
    state_bytes: int = 0
    mutation_rate_per_s: float = 0.0
    mutation_algebra: str = ""
    numeric_shape: str = ""
    integer_exact: bool = False
    regular_graph: bool = False
    production_tail_claim: bool = False
    edge_target: bool = False
    energy_claim: bool = False
    longitudinal_outcome_claim: bool = False
    actor_scope: str = ""
    contract_scope: str = ""
    plugin_digest: str = ""
    expected_release_source_digest: str = ""
    required_capabilities: Tuple[str, ...] = ()
    task_id: str = field(default_factory=lambda: _id("PFT"))

    def validate(self) -> None:
        if not self.operation.strip():
            raise ValueError("performance task requires operation")
        if self.risk_level not in RISK_LEVELS:
            raise ValueError("invalid risk level")
        if self.repetitions < 1 or self.state_bytes < 0 or self.mutation_rate_per_s < 0:
            raise ValueError("invalid performance task size or repetition")
        if not isinstance(self.required_capabilities, tuple):
            raise ValueError("required_capabilities must be a tuple")

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "PerformanceTask":
        data = dict(raw)
        data["required_capabilities"] = tuple(data.get("required_capabilities", ()))
        task = cls(**data)
        task.validate()
        return task


@dataclass(frozen=True)
class ArchitectureProfile:
    architecture_id: str
    structure: str
    composition: Tuple[str, ...]
    local_posiwid: Tuple[str, ...]
    whole_posiwid: Tuple[str, ...]
    observed_posiwid: Tuple[str, ...]
    authority_boundaries: Tuple[str, ...]
    failure_modes: Tuple[str, ...]
    status: str
    evidence_roots: Tuple[str, ...]


@dataclass(frozen=True)
class PerformanceDecision:
    task_id: str
    mode: str
    architecture_id: str
    reason: str
    mechanisms: Tuple[str, ...]
    fallback_mode: str
    contraindications: Tuple[str, ...]
    required_guards: Tuple[str, ...]
    local_posiwid: Tuple[str, ...]
    whole_posiwid: Tuple[str, ...]
    observed_posiwid_basis: Tuple[str, ...]
    evidence_roots: Tuple[str, ...]
    source_digest: str
    selected_at: float = field(default_factory=time.time)
    decision_id: str = field(default_factory=lambda: _id("PFD"))

    def validate(self) -> None:
        if self.mode not in MODES or self.fallback_mode not in MODES:
            raise ValueError("invalid performance mode")
        if self.mode != "abstain" and not self.mechanisms:
            raise ValueError("non-abstaining decision requires mechanisms")
        if not self.source_digest:
            raise ValueError("decision requires release source digest")


@dataclass(frozen=True)
class PerformanceOutcome:
    decision_id: str
    semantic_match: bool
    audit_valid: bool
    critical_error: bool
    latency_ms: float
    error_rate: float
    memory_delta_kb: float = 0.0
    bytes_written: int = 0
    fallback_used: bool = False
    observed_effects: Tuple[str, ...] = ()
    actor: str = "runtime-observer"
    observed_at: float = field(default_factory=time.time)
    outcome_id: str = field(default_factory=lambda: _id("PFO"))

    def validate(self) -> None:
        if self.latency_ms < 0 or not 0 <= self.error_rate <= 1:
            raise ValueError("invalid performance outcome metrics")
        if self.bytes_written < 0:
            raise ValueError("bytes_written must be non-negative")

    @property
    def hard_valid(self) -> bool:
        return self.semantic_match and self.audit_valid and not self.critical_error


CONTACT_EVIDENCE = {
    "warm": (
        "bounded local verify p50 82.19% lower",
        "bounded local ARC status p50 94.94% lower",
        "bounded local two-file investigation p50 91.72% lower",
        "40-operation mixed-scope contact showed no semantic or credential-canary leak",
    ),
    "batch": (
        "six-operation fresh-domain batch reduced per-operation latency 71.06%",
        "batch captured 86.46% of the valid warm verification gain",
    ),
    "transactional": (
        "largest synthetic idempotent key-set state showed 42.80x mutation throughput",
        "application bytes written fell 99.9867% in the synthetic slice",
        "four process-crash transaction boundaries preserved acknowledged state",
    ),
    "native": (
        "admitted integer-exact regular graphs measured 2.36x-3.79x whole-kernel speedup",
        "all admitted cases matched the reference implementation",
    ),
}


class HybridPerformancePortfolio:
    """Select only contacted mechanism regions; never sum correlated gains."""

    def __init__(self, source_digest: str = "") -> None:
        self.source_digest = source_digest or release_source_digest()

    @staticmethod
    def architecture_profiles() -> Dict[str, ArchitectureProfile]:
        roots = (f"contact:{CONTACT_PAYLOAD_SHA256}", f"baseline:{BASELINE_V015_SHA256}")
        return {
            "current_cold_monolith": ArchitectureProfile(
                "current_cold_monolith", "homogeneous",
                ("CPython control", "fresh process", "full runtime materialisation", "canonical reference"),
                ("maximal per-call isolation", "simple rollback", "predictable replay"),
                ("reconstructs the whole organism for small operations", "moves cost into startup and full-state persistence"),
                ("semantic reference survived all inherited gates", "cold lifecycle dominated bounded small operations"),
                ("one process is one authority domain",),
                ("high fixed latency", "repeated immutable work", "full-state write amplification"),
                "retained_reference_not_universal", roots),
            "homogeneous_warm_python": ArchitectureProfile(
                "homogeneous_warm_python", "homogeneous",
                ("CPython control", "persistent in-process state"),
                ("removes repeated imports and reconstruction",),
                ("retains mutable identity and state across calls", "requires reset, expiry and release binding"),
                CONTACT_EVIDENCE["warm"],
                ("actor, contract, plugin and release scope must be identical",),
                ("cross-scope contamination", "stale plugins", "unbounded process growth"),
                "surviving_bounded_region", roots),
            "hybrid_cold_batch": ArchitectureProfile(
                "hybrid_cold_batch", "hybrid",
                ("one cold Python process", "fresh FieldInstrument per operation", "serial batch"),
                ("amortises import while preserving fresh operation state",),
                ("reduces fixed process cost without retaining authority across commands",),
                CONTACT_EVIDENCE["batch"],
                ("all requests must fit one batch authority and release identity",),
                ("large batches increase queueing", "not suitable for shared mutable state"),
                "surviving_bounded_region", roots),
            "bounded_heterogeneous_specialists": ArchitectureProfile(
                "bounded_heterogeneous_specialists", "heterogeneous",
                ("CPython authority plane", "SQLite transactional mutation slice", "native numerical specialist", "reference fallbacks"),
                ("assigns storage and numerical work to mechanisms that matched their contacted shape",),
                ("adds typed boundaries and recovery obligations rather than replacing the organism",),
                CONTACT_EVIDENCE["transactional"] + CONTACT_EVIDENCE["native"],
                ("Python owns contracts, selection, audit and fallback", "specialists cannot raise epistemic authority"),
                ("boundary conversion", "schema evolution", "ABI/build burden", "unmeasured mechanism interaction"),
                "surviving_restricted_regions", roots),
            "fully_distributed_heterogeneous": ArchitectureProfile(
                "fully_distributed_heterogeneous", "heterogeneous",
                ("service-per-organ", "remote storage", "network RPC", "multiple runtimes"),
                ("could scale independently and isolate failures",),
                ("would relocate local latency into serialization, networking, deployment and cross-service recovery"),
                ("no direct contact was performed",),
                ("authority would cross network and service boundaries",),
                ("partial failure", "version skew", "distributed transactions", "operator burden", "tail amplification"),
                "blocked_uncontacted", roots),
            "adaptive_bounded_portfolio": ArchitectureProfile(
                "adaptive_bounded_portfolio", "hybrid_heterogeneous",
                ("fresh reference", "cold batch", "scoped warm capsule", "transactional slice", "native specialist", "abstention"),
                ("uses the least-overhead contacted mechanism for each task shape",),
                ("preserves conservative fallback and refuses unmeasured surfaces", "does not stack speedup numbers"),
                ("all four non-null contenders survived only in narrowed domains", "16 of 42 mapped angles remained null or abstention"),
                ("one authoritative selector", "typed mechanism boundaries", "reference replay remains available"),
                ("misrouting", "interaction effects", "maintenance burden", "selector becoming a hidden universal process"),
                "selected_architecture", roots),
        }

    def select(self, task: PerformanceTask) -> PerformanceDecision:
        task.validate()
        profiles = self.architecture_profiles()
        blocked_surface = any((task.production_tail_claim, task.edge_target, task.energy_claim,
                               task.longitudinal_outcome_claim)) or not task.local_only or task.network_required
        evidence_roots = (f"contact:{CONTACT_PAYLOAD_SHA256}", f"baseline:{BASELINE_V015_SHA256}")

        if task.expected_release_source_digest and task.expected_release_source_digest != self.source_digest:
            return self._decision(task, "abstain", "adaptive_bounded_portfolio",
                                  "release source identity mismatch", (), "fresh_reference",
                                  ("release identity mismatch",),
                                  ("obtain the exact release or recompute and explicitly approve identity",),
                                  profiles, evidence_roots)

        if blocked_surface:
            return self._decision(task, "abstain", "adaptive_bounded_portfolio",
                                  "requested surface has no qualifying contact evidence", (), "fresh_reference",
                                  ("remote, production-tail, edge, energy or longitudinal claim is unmeasured",),
                                  ("run a dedicated frozen contact campaign",), profiles, evidence_roots)

        if task.risk_level in {"high", "critical", "unknown"}:
            return self._decision(task, "fresh_reference", "current_cold_monolith",
                                  "risk requires fresh authority and reference semantics", ("fresh CPython reference",),
                                  "fresh_reference", ("warm and transactional shortcuts are not authorised for this risk" ,),
                                  ("retain complete audit, verification and escalation",), profiles, evidence_roots)

        if task.numeric_shape and task.integer_exact and task.regular_graph:
            return self._decision(task, "native_specialist", "bounded_heterogeneous_specialists",
                                  "task matches the contacted native numerical admission region",
                                  ("native integer-exact specialist", "Python differential reference"),
                                  "fresh_reference", ("decimal, irregular or unsupported graphs must fall back",),
                                  ("run reference parity", "reject output on mismatch"), profiles, evidence_roots)

        if (task.state_bytes >= 1_000_000 or task.mutation_rate_per_s >= 100) and \
                task.mutation_algebra == "idempotent_key_set" and not task.shared_mutable_state:
            return self._decision(task, "transactional_state", "bounded_heterogeneous_specialists",
                                  "large or rapidly mutating state matches the contacted transactional slice",
                                  ("SQLite WAL/FULL transactional key-set store", "canonical snapshot fallback"),
                                  "fresh_reference", ("not authorised for general object graphs or non-idempotent mutations",),
                                  ("acknowledge only after commit", "verify event/materialised parity", "retain exportable snapshot"),
                                  profiles, evidence_roots)

        same_scope = bool(task.actor_scope and task.contract_scope)
        if (task.repetitions >= 3 and same_scope and not task.credential_bearing and
                not task.shared_mutable_state):
            return self._decision(task, "warm_capsule", "homogeneous_warm_python",
                                  "repeated bounded local work can amortise lifecycle cost",
                                  ("digest-bound capability-scoped warm CPython capsule",),
                                  "fresh_reference", ("scope, plugin or release change forces restart",),
                                  ("operation and age limits", "explicit reset", "semantic digest parity", "fresh fallback"),
                                  profiles, evidence_roots)

        if task.batchable and task.repetitions >= 2 and not task.shared_mutable_state:
            return self._decision(task, "cold_batch", "hybrid_cold_batch",
                                  "batching amortises import while retaining fresh operation instances",
                                  ("single cold process", "fresh per-operation FieldInstrument", "serial batch"),
                                  "fresh_reference", ("not for shared mutable state or unbounded queues",),
                                  ("bounded batch size", "per-operation semantic digest", "deadline"), profiles, evidence_roots)

        return self._decision(task, "fresh_reference", "current_cold_monolith",
                              "no contacted shortcut dominates the reference for this task shape",
                              ("fresh CPython reference",), "fresh_reference", (),
                              ("preserve audit and exact semantics",), profiles, evidence_roots)

    def _decision(self, task: PerformanceTask, mode: str, architecture_id: str, reason: str,
                  mechanisms: Tuple[str, ...], fallback: str, contraindications: Tuple[str, ...],
                  guards: Tuple[str, ...], profiles: Mapping[str, ArchitectureProfile],
                  evidence_roots: Tuple[str, ...]) -> PerformanceDecision:
        p = profiles[architecture_id]
        row = PerformanceDecision(
            task.task_id, mode, architecture_id, reason, mechanisms, fallback,
            contraindications, guards, p.local_posiwid, p.whole_posiwid,
            p.observed_posiwid, evidence_roots, self.source_digest,
        )
        row.validate()
        return row


class PerformanceLedger:
    """Persist decisions and actual POSIWID without letting metrics raise authority."""

    def __init__(self, path: str | os.PathLike[str]) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.decisions: Dict[str, PerformanceDecision] = {}
        self.outcomes: Dict[str, PerformanceOutcome] = {}
        self.audit = EventLog()
        if self.path.exists():
            self._load()

    def register(self, decision: PerformanceDecision, actor: str = "performance-selector") -> str:
        decision.validate()
        prior = self.decisions.get(decision.decision_id)
        if prior and _digest(asdict(prior)) != _digest(asdict(decision)):
            raise ValueError("decision id already registered differently")
        self.decisions[decision.decision_id] = decision
        self.audit.append("performance_decision", {"actor": actor, "decision": asdict(decision)})
        self.save()
        return decision.decision_id

    def record(self, outcome: PerformanceOutcome) -> dict:
        outcome.validate()
        if outcome.decision_id not in self.decisions:
            raise KeyError("unknown performance decision")
        self.outcomes[outcome.outcome_id] = outcome
        rollback = not outcome.hard_valid
        self.audit.append("performance_outcome", {
            "outcome": asdict(outcome),
            "hard_valid": outcome.hard_valid,
            "rollback_required": rollback,
        })
        self.save()
        return {"hard_valid": outcome.hard_valid, "rollback_required": rollback}

    def posiwid(self) -> dict:
        hard_valid = [o for o in self.outcomes.values() if o.hard_valid]
        invalid = [o for o in self.outcomes.values() if not o.hard_valid]
        by_mode: Dict[str, dict] = {}
        for d in self.decisions.values():
            row = by_mode.setdefault(d.mode, {"decisions": 0, "outcomes": 0, "hard_valid": 0,
                                               "latency_ms": [], "fallbacks": 0})
            row["decisions"] += 1
        for o in self.outcomes.values():
            d = self.decisions[o.decision_id]
            row = by_mode[d.mode]
            row["outcomes"] += 1
            row["hard_valid"] += int(o.hard_valid)
            row["latency_ms"].append(o.latency_ms)
            row["fallbacks"] += int(o.fallback_used)
        for row in by_mode.values():
            vals = row.pop("latency_ms")
            row["mean_latency_ms"] = sum(vals) / len(vals) if vals else None
        return {
            "declared_effect": "reduce latency, error and resource cost without weakening semantic, audit, authority or recovery gates",
            "observed_effects": {
                "decisions": len(self.decisions),
                "outcomes": len(self.outcomes),
                "hard_valid_outcomes": len(hard_valid),
                "invalid_outcomes": len(invalid),
                "rollback_required": len(invalid),
                "by_mode": by_mode,
            },
            "authority": "performance measurements never raise epistemic authority",
            "audit": self.audit.verify(),
        }

    def verify(self) -> dict:
        audit = self.audit.verify()
        missing = [o.outcome_id for o in self.outcomes.values() if o.decision_id not in self.decisions]
        return {"valid": bool(audit.get("valid")) and not missing,
                "audit": audit, "missing_decisions": missing,
                "decisions": len(self.decisions), "outcomes": len(self.outcomes)}

    def save(self) -> None:
        raw = {
            "decisions": [asdict(x) for x in self.decisions.values()],
            "outcomes": [asdict(x) for x in self.outcomes.values()],
            "audit": self.audit.to_dict(),
        }
        snapshot = {"decisions": raw["decisions"], "outcomes": raw["outcomes"]}
        raw["state_sha256"] = _digest(snapshot)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(raw, indent=2, sort_keys=True) + "\n")
        os.replace(tmp, self.path)

    def _load(self) -> None:
        raw = json.loads(self.path.read_text())
        snapshot = {"decisions": raw.get("decisions", []), "outcomes": raw.get("outcomes", [])}
        if raw.get("state_sha256") != _digest(snapshot):
            raise ValueError("performance ledger state digest mismatch")
        self.decisions = {}
        for x in snapshot["decisions"]:
            d = dict(x)
            for key in ("mechanisms", "contraindications", "required_guards", "local_posiwid",
                        "whole_posiwid", "observed_posiwid_basis", "evidence_roots"):
                d[key] = tuple(d.get(key, ()))
            row = PerformanceDecision(**d)
            row.validate()
            self.decisions[row.decision_id] = row
        self.outcomes = {}
        for x in snapshot["outcomes"]:
            d = dict(x); d["observed_effects"] = tuple(d.get("observed_effects", ()))
            row = PerformanceOutcome(**d); row.validate(); self.outcomes[row.outcome_id] = row
        self.audit = EventLog.from_dict(raw.get("audit", {}))
        if not self.verify()["valid"]:
            raise ValueError("invalid performance ledger")


def architecture_posiwid_report() -> dict:
    profiles = HybridPerformancePortfolio.architecture_profiles()
    selected = profiles["adaptive_bounded_portfolio"]
    return {
        "profiles": {k: asdict(v) for k, v in profiles.items()},
        "selected_architecture": selected.architecture_id,
        "selection_rule": "heterogeneous by bounded function; homogeneous at authority boundaries; no untested mechanism stacking",
        "universal_winner": None,
        "forbidden_inferences": [
            "do not multiply or add speedups from separate mechanisms",
            "do not infer production p99 from bounded local samples",
            "do not treat SQLite results as authority for whole-runtime migration",
            "do not treat native-kernel parity as authority for a language rewrite",
            "do not treat structural portfolio coverage as real-world outcome superiority",
        ],
    }
