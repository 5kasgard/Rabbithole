"""RabbitHole epistemic organ — coverage (C), allocate (E5), commit (E6).

COVERAGE answers, per conclusion: what support was sought, what was
found, what is missing — and composes it honestly. Per the Attack-doc
amendment (Attack 38), composition is structure-dependent: constraints
on a variable are CONJUNCTIVE, so composed coverage is the MINIMUM over
support leaves (the weakest link), never an average that lets strong
branches launder weak ones.

Support-leaf scores (documented, gated):
  walled / clamped     -> 1.00   structure and declared intent are present
                                 by construction; they are holds, not claims
  tested evidence      -> mean authority of the tested claims (0..1];
                          counts as STALE (and scores accordingly) once
                          decayed below half its confidence
  asserted only        -> 0.25   a claim exists but nothing has survived
                                 contact; visible, cheap, and insufficient
  nothing              -> the var is derived-through; it inherits from its
                          neighbors via the min-composition
If the cone contains no support leaves at all, coverage is 0.0 — open.

ALLOCATE ranks what is most worth testing next: contested beliefs,
untested assertion mass, and decayed authority, weighted by how much of
the conclusion hangs on them. It is deliberately simple and deliberately
gated on behavior (grounding a target must drop its score).

COMMIT is the A8 organ: an action record carrying the coverage it was
made under, a risk note derived from the field, a reversibility plan,
and a test plan. A commitment whose minimum coverage is below threshold
REFUSES unless forced — and a forced commitment is flagged forever in
the record and the WAL. Commitments cannot silently exceed grounding.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field as dc_field
from typing import Dict, List, Optional, Tuple

from .field import Field


# ---------------------------------------------------------------------------
# Coverage
# ---------------------------------------------------------------------------

@dataclass
class CoverageReport:
    var: str
    grounded_fraction: float          # min-composed over support leaves
    status: str                       # walled|clamped|tested|asserted|open|mixed
    sought: List[str]                 # the support slots the conclusion rests on
    found: List[str]                  # slots with grounded support
    missing: List[str]                # open requests, untested-only vars, open sides
    stale: List[str]                  # tested evidence decayed past half confidence
    contacts: Dict[str, int]          # contact-type mix across the cone
    cone: List[str]                   # variables the conclusion depends on


def _cone(field: Field, var: str) -> Tuple[List[str], List[str]]:
    """All variables and factors the conclusion at `var` can depend on."""
    seen_v, seen_f = {var}, set()
    frontier = [var]
    while frontier:
        v = frontier.pop()
        for fid in field._adj.get(v, []):
            if fid in seen_f or fid not in field.factors:
                continue
            seen_f.add(fid)
            for u in field.factors[fid].vars():
                if u not in seen_v:
                    seen_v.add(u)
                    frontier.append(u)
    return sorted(seen_v), sorted(seen_f)


def coverage(field: Field, var: str, now: Optional[float] = None) -> CoverageReport:
    now = time.time() if now is None else now
    cone_v, cone_f = _cone(field, var)
    sought: List[str] = []
    found: List[str] = []
    missing: List[str] = []
    stale: List[str] = []
    contacts: Dict[str, int] = {}
    leaf_scores: List[float] = []

    bound_kinds: Dict[str, set] = {v: set() for v in cone_v}
    for fid in cone_f:
        fac = field.factors[fid]
        if hasattr(fac, "var"):                       # BoundFactor
            bound_kinds[fac.var].add(fac.prov.kind)

    for v in cone_v:
        kinds = bound_kinds[v]
        evs = [e for e in field.evidence.values() if e.var == v]
        tested = [e for e in evs if e.prov.test_count > 0]
        asserted = [e for e in evs if e.prov.test_count == 0]
        for e in tested:
            c = getattr(e, "contact", "human") or "human"
            contacts[c] = contacts.get(c, 0) + 1

        slot = f"{v}"
        if kinds & {"constant", "invariant", "definition", "convention"}:
            sought.append(slot + " (structure)")
            found.append(slot + " — walled")
            leaf_scores.append(1.0)
        elif kinds & {"clamp", "model"}:
            sought.append(slot + " (declared)")
            found.append(slot + " — declared/model boundary")
            leaf_scores.append(1.0)

        if tested:
            auths = [e.authority(now) for e in tested]
            score = sum(auths) / len(auths)
            sought.append(slot + " (tested claim)")
            fresh = [e for e in tested
                     if e.authority(now) >= 0.5 * e.prov.confidence]
            if fresh:
                found.append(slot + f" — tested (authority {score:.2f})")
            for e in tested:
                if e.authority(now) < 0.5 * e.prov.confidence:
                    stale.append(e.eid)
            leaf_scores.append(max(score, 1e-9))
        elif asserted:
            sought.append(slot + " (claim)")
            missing.append(slot + f" — {len(asserted)} untested assertion(s)")
            leaf_scores.append(0.25)

        b = field.belief(v, now=now)
        if b is not None and b.test is not None:
            missing.append(slot + " — open GroundingRequest: " + b.test.reason)

    dom = field.variables[var].domain
    if not dom.is_empty():
        import math as _m
        if _m.isinf(dom.lo):
            missing.append(f"{var} — lower side unbounded")
        if _m.isinf(dom.hi):
            missing.append(f"{var} — upper side unbounded")

    if leaf_scores:
        frac = min(leaf_scores)                       # Attack 38: conjunction = ∩
    else:
        frac = 0.0
        missing.append(f"{var} — no support in the cone")

    if frac == 0.0:
        status = "open"
    elif frac >= 0.999 and not stale:
        kinds_all = set().union(*bound_kinds.values()) if bound_kinds else set()
        status = "walled" if kinds_all & {"constant", "invariant", "definition", "convention"} else "clamped"
        if any("tested" in f for f in found):
            status = "tested"
    elif frac <= 0.25:
        status = "asserted"
    else:
        status = "mixed"
    return CoverageReport(var, frac, status, sought, found, missing,
                          stale, contacts, cone_v)


# ---------------------------------------------------------------------------
# Allocate (E5)
# ---------------------------------------------------------------------------

def allocate(field: Field, top_k: int = 3,
             now: Optional[float] = None) -> List[dict]:
    """What is most worth testing next. Score per variable:
       span x need — the size of the live disagreement times the mass of
    untested assertion and decayed authority hanging on it."""
    now = time.time() if now is None else now
    out = []
    for v in field.variables:
        evs = [e for e in field.evidence.values() if e.var == v]
        if not evs:
            continue
        scale = field.variables[v].unit_scale
        vals = [e.value / scale for e in evs]
        span = (max(vals) - min(vals)) if len(vals) > 1 else 0.0
        b = field.belief(v, now=now)
        norm = max(1.0, abs(b.mean) if b and b.mean is not None else 1.0)
        contested = 1.0 if (b and b.test is not None) else 0.0
        untested = sum(1 for e in evs if e.prov.test_count == 0)
        deficit = sum(max(0.0, e.prov.confidence - e.authority(now))
                      for e in evs)
        base = span / norm + contested + (0.3 if untested else 0.0)
        score = base * (1.0 + untested + deficit)
        if score <= 0:
            continue
        why = []
        if contested:
            why.append("sources disagree beyond stated uncertainty")
        if untested:
            why.append(f"{untested} untested assertion(s)")
        if deficit > 0.05:
            why.append(f"authority decayed by {deficit:.2f}")
        out.append({"var": v, "score": round(score, 4), "why": "; ".join(why)})
    out.sort(key=lambda d: -d["score"])
    return out[:top_k]


# ---------------------------------------------------------------------------
# Commit (E6 / A8)
# ---------------------------------------------------------------------------

class CommitmentIntegrityError(Exception):
    pass


@dataclass
class Commitment:
    cid: str
    statement: str
    action: str
    vars: List[str]
    coverage_at_commit: Dict[str, float]
    min_coverage: float
    risk_note: str
    reversibility: str
    test_plan: List[str]
    created: float
    forced: bool = False
    status: str = "open"               # open | kept | broken | revised
    outcome_note: str = ""


def commit(field: Field, statement: str, action: str, vars: List[str],
           reversibility: str, test_plan: List[str],
           min_required: float = 0.5, force: bool = False,
           now: Optional[float] = None) -> Commitment:
    """A8: a commitment cannot silently exceed its grounding. Coverage is
    computed at commit time over every variable the action rests on; if the
    weakest link is below threshold, the commit REFUSES with the missing
    list — unless forced, in which case the record and the WAL carry the
    flag forever."""
    now = time.time() if now is None else now
    covs = {v: coverage(field, v, now=now) for v in vars}
    fractions = {v: c.grounded_fraction for v, c in covs.items()}
    weakest = min(fractions.values()) if fractions else 0.0
    if weakest < min_required and not force:
        gaps = [m for c in covs.values() for m in c.missing]
        raise CommitmentIntegrityError(
            f"commitment refused: minimum coverage {weakest:.2f} < required "
            f"{min_required:.2f}. Missing: " + "; ".join(gaps[:6]) +
            (" …" if len(gaps) > 6 else "") +
            ". Ground the gaps, lower the stakes, or force=True (flagged forever).")
    widths = []
    for v in vars:
        d = field.variables[v].domain
        if not d.is_empty():
            import math as _m
            widths.append("∞" if (_m.isinf(d.lo) or _m.isinf(d.hi))
                          else f"{v} width {d.width():.4g}")
    risk = "; ".join(widths) or "no live domains"
    c = Commitment(cid=f"C{uuid.uuid4().hex[:8]}", statement=statement,
                   action=action, vars=list(vars),
                   coverage_at_commit=fractions, min_coverage=weakest,
                   risk_note=risk, reversibility=reversibility,
                   test_plan=list(test_plan), created=now, forced=bool(force))
    field.commitments[c.cid] = c
    field._emit("commit", {"cid": c.cid, "statement": statement,
                           "min_coverage": round(weakest, 4),
                           "forced": bool(force), "vars": list(vars),
                           "test_plan": list(test_plan)})
    return c


def resolve_commitment(field: Field, cid: str, outcome: str,
                       note: str = "") -> Commitment:
    c = field.commitments[cid]
    if outcome not in ("kept", "broken", "revised"):
        raise ValueError("outcome must be kept | broken | revised")
    c.status = outcome
    c.outcome_note = note
    field._emit("commit_resolved", {"cid": cid, "outcome": outcome,
                                    "note": note})
    return c