"""Scoped inverse design over registered domain dialects and validators."""
from __future__ import annotations
import time,uuid
from dataclasses import asdict,dataclass,field
from typing import Callable,Dict,Mapping,Optional,Sequence,Tuple
from .wal import EventLog

def _id(p):return f"{p}{uuid.uuid4().hex[:12]}"
Generator=Callable[[Mapping[str,object]],Sequence[Mapping[str,object]]]
Validator=Callable[[Mapping[str,object],Mapping[str,object]],Mapping[str,object]]
@dataclass
class DesignDialect:
    dialect_id:str;domain:str;representation:str;goal_fields:Tuple[str,...];constraint_fields:Tuple[str,...];validator_id:str
    authority_ceiling:float=0.;enabled:bool=True
@dataclass
class DesignCandidate:
    dialect_id:str;goal:Mapping[str,object];configuration:Mapping[str,object];validation:Mapping[str,object];status:str
    candidate_id:str=field(default_factory=lambda:_id("DSN"));created_at:float=field(default_factory=time.time)
class DomainDesignRegistry:
    def __init__(self):self.dialects:Dict[str,DesignDialect]={};self.generators:Dict[str,Generator]={};self.validators:Dict[str,Validator]={};self.candidates:Dict[str,DesignCandidate]={};self.audit=EventLog()
    def register(self,d:DesignDialect,generator:Optional[Generator]=None,validator:Optional[Validator]=None):
        self.dialects[d.dialect_id]=d
        if generator:self.generators[d.dialect_id]=generator
        if validator:self.validators[d.validator_id]=validator
        self.audit.append("design_dialect_registered",asdict(d)|{"generator_attached":generator is not None,"validator_attached":validator is not None})
    def design(self,dialect_id:str,goal:Mapping[str,object])->Tuple[DesignCandidate,...]:
        if dialect_id not in self.dialects:raise LookupError("unsupported design domain")
        d=self.dialects[dialect_id]
        if not d.enabled or dialect_id not in self.generators or d.validator_id not in self.validators:raise RuntimeError("design dialect is not operational")
        missing=[x for x in d.goal_fields if x not in goal]
        if missing:raise ValueError(f"missing goal fields: {missing}")
        out=[]
        for config in self.generators[dialect_id](goal):
            validation=dict(self.validators[d.validator_id](goal,config));status="verified_feasible" if validation.get("valid") else "rejected"
            c=DesignCandidate(dialect_id,dict(goal),dict(config),validation,status);self.candidates[c.candidate_id]=c;out.append(c)
        self.audit.append("inverse_design_executed",{"dialect_id":dialect_id,"goal":dict(goal),"candidates":[asdict(x) for x in out]});return tuple(out)
    def benchmark(self,cases:Sequence[Mapping[str,object]])->dict:
        rows=[]
        for case in cases:
            try:cands=self.design(str(case["dialect_id"]),dict(case["goal"]));ok=any(x.status=="verified_feasible" for x in cands);rows.append({"case":case.get("name",""),"supported":True,"passed":ok})
            except LookupError:rows.append({"case":case.get("name",""),"supported":False,"passed":bool(case.get("expect_refusal",False))})
            except Exception as exc:rows.append({"case":case.get("name",""),"supported":True,"passed":False,"error":f"{type(exc).__name__}: {exc}"})
        return {"cases":rows,"passed":all(x["passed"] for x in rows),"domains":len({x.get("dialect_id") for x in cases if not x.get("expect_refusal")})}
    def to_dict(self):return {"dialects":[asdict(x) for x in self.dialects.values()],"candidates":[asdict(x) for x in self.candidates.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw):
        o=cls()
        for r in raw.get("dialects",[]):
            d=dict(r);d["goal_fields"]=tuple(d.get("goal_fields",()));d["constraint_fields"]=tuple(d.get("constraint_fields",()));x=DesignDialect(**d);o.dialects[x.dialect_id]=x
        for r in raw.get("candidates",[]):x=DesignCandidate(**dict(r));o.candidates[x.candidate_id]=x
        o.audit=EventLog.from_dict(raw.get("audit",{}));return o
