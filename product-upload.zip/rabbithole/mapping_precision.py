"""Task-loss-aware reversible mapping and placement evaluation."""
from __future__ import annotations
import time, uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Sequence, Tuple
from .ontology import OntologyRegistry, MappingHypothesis
from .wal import EventLog

def _id(p): return f"{p}{uuid.uuid4().hex[:12]}"

@dataclass(frozen=True)
class TaskLossPolicy:
    policy_id:str
    false_merge_cost:float
    false_split_cost:float
    abstention_cost:float
    temporal_mismatch_cost:float=1.0
    allowed_relations:Tuple[str,...]=()
    confidence_accept_threshold:float=0.95

@dataclass
class CompetingMappingSet:
    source_id:str
    candidates:Tuple[str,...]
    mapping_ids:Tuple[str,...]
    task_policy_id:str
    resolved_mapping_id:str=""
    status:str="open"
    set_id:str=field(default_factory=lambda:_id("CMS"))

@dataclass(frozen=True)
class MappingBenchmarkCase:
    source_id:str
    target_id:str
    true_relation:str
    predicted_relation:str
    predicted_status:str
    temporal_overlap:bool=True
    case_id:str=field(default_factory=lambda:_id("MBC"))

class MappingPrecisionRegistry:
    def __init__(self, ontology:OntologyRegistry):
        self.ontology=ontology;self.policies:Dict[str,TaskLossPolicy]={};self.competitions:Dict[str,CompetingMappingSet]={};self.audit=EventLog()
    def register_policy(self,p:TaskLossPolicy)->None:
        if min(p.false_merge_cost,p.false_split_cost,p.abstention_cost,p.temporal_mismatch_cost)<0:raise ValueError("losses cannot be negative")
        self.policies[p.policy_id]=p;self.audit.append("mapping_loss_policy_registered",asdict(p))
    def propose_competing(self,source_id:str,candidates:Sequence[tuple[str,str,float,Sequence[str],Mapping[str,object]]],policy_id:str)->CompetingMappingSet:
        if policy_id not in self.policies:raise KeyError(policy_id)
        mids=[];targets=[]
        for target,relation,confidence,vetoes,scope in candidates:
            if self.policies[policy_id].allowed_relations and relation not in self.policies[policy_id].allowed_relations:raise ValueError("relation not allowed by policy")
            m=MappingHypothesis(source_id,target,relation,vetoes=tuple(vetoes),status="proposed",scope=dict(scope),confidence=confidence,reason=f"task-policy:{policy_id}")
            self.ontology.map(m);mids.append(m.mid);targets.append(target)
        c=CompetingMappingSet(source_id,tuple(targets),tuple(mids),policy_id);self.competitions[c.set_id]=c;self.audit.append("competing_mappings_proposed",asdict(c));return c
    def resolve(self,set_id:str,mapping_id:str,reason:str)->dict:
        c=self.competitions[set_id];p=self.policies[c.task_policy_id]
        if mapping_id not in c.mapping_ids:raise KeyError(mapping_id)
        m=self.ontology.mappings[mapping_id]
        if m.vetoes or m.confidence<p.confidence_accept_threshold:raise ValueError("mapping does not satisfy acceptance policy")
        for mid in c.mapping_ids:self.ontology.set_mapping_status(mid,"accepted" if mid==mapping_id else "rejected",reason)
        c.resolved_mapping_id=mapping_id;c.status="resolved";self.audit.append("competing_mapping_resolved",{"set_id":set_id,"mapping_id":mapping_id,"reason":reason});return asdict(c)
    def retract(self,mapping_id:str,reason:str)->dict:
        self.ontology.set_mapping_status(mapping_id,"retracted",reason);affected=[]
        for c in self.competitions.values():
            if c.resolved_mapping_id==mapping_id:c.resolved_mapping_id="";c.status="reopened";affected.append(c.set_id)
        r={"mapping_id":mapping_id,"reason":reason,"reopened_sets":affected};self.audit.append("mapping_retracted",r);return r
    def benchmark(self,policy_id:str,cases:Sequence[MappingBenchmarkCase])->dict:
        p=self.policies[policy_id];loss=0.;false_merges=false_splits=abstentions=temporal=0
        for c in cases:
            if c.predicted_status in {"proposed","contested","unresolved"}:loss+=p.abstention_cost;abstentions+=1
            elif c.predicted_relation in {"same_as","equivalent_representation","same_kind","same_measurand"} and c.predicted_relation!=c.true_relation:
                loss+=p.false_merge_cost;false_merges+=1
            elif c.predicted_relation!=c.true_relation:loss+=p.false_split_cost;false_splits+=1
            if not c.temporal_overlap and c.predicted_relation=="same_as":loss+=p.temporal_mismatch_cost;temporal+=1
        result={"cases":len(cases),"loss":loss,"mean_loss":loss/max(1,len(cases)),"false_merges":false_merges,"false_splits":false_splits,"abstentions":abstentions,"temporal_mismatches":temporal}
        self.audit.append("mapping_benchmark",{"policy_id":policy_id,**result});return result
    def to_dict(self):return {"policies":[asdict(x) for x in self.policies.values()],"competitions":[asdict(x) for x in self.competitions.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,ontology,raw):
        o=cls(ontology)
        for r in raw.get("policies",[]):
            d=dict(r);d["allowed_relations"]=tuple(d.get("allowed_relations",()));p=TaskLossPolicy(**d);o.policies[p.policy_id]=p
        for r in raw.get("competitions",[]):
            d=dict(r);d["candidates"]=tuple(d.get("candidates",()));d["mapping_ids"]=tuple(d.get("mapping_ids",()));c=CompetingMappingSet(**d);o.competitions[c.set_id]=c
        o.audit=EventLog.from_dict(raw.get("audit",{}));return o
