"""Physical/empirical contact interfaces with calibration and raw-byte receipts."""
from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable, Dict, Mapping, Optional, Tuple

from .wal import EventLog


def _id(prefix:str)->str:return f"{prefix}{uuid.uuid4().hex[:12]}"

@dataclass
class InstrumentSpec:
    instrument_id:str
    measurement_classes:Tuple[str,...]
    unit_families:Tuple[str,...]
    adapter_kind:str
    owner:str
    location:str=""
    enabled:bool=True

@dataclass
class CalibrationCertificate:
    instrument_id:str
    reference_id:str
    valid_from:float
    valid_until:float
    uncertainty:float
    scope:Mapping[str,object]
    artifact_digest:str
    issued_by:str
    status:str="provisional"  # provisional|independently_verified|revoked|expired
    certificate_id:str=field(default_factory=lambda:_id("CAL"))

@dataclass
class MeasurementReceipt:
    instrument_id:str
    measurement_class:str
    raw_digest:str
    raw_path:str
    parsed:Mapping[str,object]
    calibration_id:str
    status:str
    authority_ceiling:float
    reason:str
    observed_at:float=field(default_factory=time.time)
    receipt_id:str=field(default_factory=lambda:_id("MEA"))

Adapter=Callable[[Mapping[str,object]],bytes]
Parser=Callable[[bytes],Mapping[str,object]]

class InstrumentRegistry:
    def __init__(self,root:str|os.PathLike[str]):
        self.root=Path(root);self.blobs=self.root/"blobs";self.blobs.mkdir(parents=True,exist_ok=True)
        self.specs:Dict[str,InstrumentSpec]={};self.certificates:Dict[str,CalibrationCertificate]={};self.measurements:Dict[str,MeasurementReceipt]={}
        self.adapters:Dict[str,Adapter]={};self.parsers:Dict[str,Parser]={};self.audit=EventLog()

    def register(self,spec:InstrumentSpec,adapter:Optional[Adapter]=None,parser:Optional[Parser]=None)->None:
        if spec.instrument_id in self.specs:raise ValueError("instrument already registered")
        self.specs[spec.instrument_id]=spec
        if adapter:self.adapters[spec.instrument_id]=adapter
        if parser:self.parsers[spec.instrument_id]=parser
        self.audit.append("instrument_registered",asdict(spec)|{"runtime_attached":adapter is not None})
    def attach(self,instrument_id:str,adapter:Adapter,parser:Parser)->None:
        if instrument_id not in self.specs:raise KeyError(instrument_id)
        self.adapters[instrument_id]=adapter;self.parsers[instrument_id]=parser;self.audit.append("instrument_attached",{"instrument_id":instrument_id})
    def add_calibration(self,cert:CalibrationCertificate)->str:
        if cert.instrument_id not in self.specs:raise KeyError(cert.instrument_id)
        if cert.valid_until<=cert.valid_from or cert.uncertainty<0:raise ValueError("invalid calibration certificate")
        self.certificates[cert.certificate_id]=cert;self.audit.append("calibration_certificate_added",asdict(cert));return cert.certificate_id
    def revoke_calibration(self,certificate_id:str,reason:str)->dict:
        cert=self.certificates[certificate_id];cert.status="revoked";affected=[]
        for m in self.measurements.values():
            if m.calibration_id==certificate_id and m.status=="contact_recorded":
                m.status="revoked";m.authority_ceiling=0.0;m.reason=f"calibration revoked: {reason}";affected.append(m.receipt_id)
        result={"certificate_id":certificate_id,"reason":reason,"affected":affected};self.audit.append("calibration_revoked",result);return result
    def measure(self,instrument_id:str,measurement_class:str,request:Mapping[str,object],*,calibration_id:str="")->MeasurementReceipt:
        spec=self.specs[instrument_id]
        if not spec.enabled:raise RuntimeError("instrument disabled")
        if measurement_class not in spec.measurement_classes:raise ValueError("unsupported measurement class")
        if instrument_id not in self.adapters or instrument_id not in self.parsers:raise RuntimeError("physical instrument adapter is not attached")
        raw=self.adapters[instrument_id](request);digest=hashlib.sha256(raw).hexdigest();path=self.blobs/digest
        if not path.exists():path.write_bytes(raw)
        parsed=dict(self.parsers[instrument_id](raw));status="contact_recorded";ceiling=0.0;reason="calibration not independently verified"
        cert=self.certificates.get(calibration_id)
        now=time.time()
        if cert and cert.instrument_id==instrument_id and cert.status=="independently_verified" and cert.valid_from<=now<=cert.valid_until:
            ceiling=0.9;reason="traceable contact with active independently verified calibration"
        elif cert and now>cert.valid_until:
            cert.status="expired";status="expired_calibration";reason="calibration certificate expired"
        rec=MeasurementReceipt(instrument_id,measurement_class,digest,str(path),parsed,calibration_id,status,ceiling,reason)
        self.measurements[rec.receipt_id]=rec;self.audit.append("measurement_recorded",asdict(rec));return rec
    def verify(self)->dict:
        invalid=[]
        for r in self.measurements.values():
            p=Path(r.raw_path)
            if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=r.raw_digest:invalid.append(r.receipt_id)
        return {"valid":not invalid and self.audit.verify().get("valid",False),"invalid":invalid,"instruments":len(self.specs),"measurements":len(self.measurements)}
    def to_dict(self)->dict:return {"specs":[asdict(x) for x in self.specs.values()],"certificates":[asdict(x) for x in self.certificates.values()],"measurements":[asdict(x) for x in self.measurements.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,root:str|os.PathLike[str],raw:Mapping[str,object])->"InstrumentRegistry":
        obj=cls(root)
        for row in raw.get("specs",[]):
            d=dict(row);d["measurement_classes"]=tuple(d.get("measurement_classes",()));d["unit_families"]=tuple(d.get("unit_families",()));s=InstrumentSpec(**d);obj.specs[s.instrument_id]=s
        for row in raw.get("certificates",[]):c=CalibrationCertificate(**dict(row));obj.certificates[c.certificate_id]=c
        for row in raw.get("measurements",[]):m=MeasurementReceipt(**dict(row));obj.measurements[m.receipt_id]=m
        obj.audit=EventLog.from_dict(raw.get("audit",{}));return obj
