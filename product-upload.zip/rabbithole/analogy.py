"""Causal analogy gate for ARC-5.

Analogy is useful only as a candidate-mechanism retrieval operation.  This module
prevents surface resemblance from being promoted into an invariant.  A transfer
must name the function, the source mechanism, relations preserved by the target,
relations that break, positive and negative cases, scope, work relocation, and a
falsifier.  Passing the gate still grants zero epistemic authority; it only makes
the analogy admissible for adversarial testing.
"""
from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from typing import Mapping, Sequence, Tuple


def _id() -> str:
    return f"AN{uuid.uuid4().hex[:12]}"


@dataclass
class AnalogyHypothesis:
    source_system: str
    target_problem: str
    abstract_function: str
    source_mechanism: str
    source_context: Tuple[str, ...]
    target_translation: str
    preserved_relations: Tuple[str, ...]
    broken_relations: Tuple[str, ...]
    positive_cases: Tuple[str, ...]
    negative_cases: Tuple[str, ...]
    boundary_conditions: Tuple[str, ...]
    work_relocated_to: Tuple[str, ...]
    alternative_mechanisms: Tuple[str, ...]
    falsifier: str
    aid: str = field(default_factory=_id)


@dataclass
class AnalogyAssessment:
    analogy_id: str
    admissible: bool
    reasons: Tuple[str, ...]
    authority: float = 0.0


class AnalogyGate:
    """Deterministic minimum gate before an analogy enters reduction."""

    REQUIRED_RELATION_MIN = 2

    @classmethod
    def assess(cls, h: AnalogyHypothesis) -> AnalogyAssessment:
        reasons = []
        if not h.source_system.strip() or not h.target_problem.strip():
            reasons.append("source and target are required")
        if not h.abstract_function.strip() or not h.source_mechanism.strip():
            reasons.append("abstract function and causal source mechanism are required")
        if not h.target_translation.strip():
            reasons.append("target translation is missing")
        if len(h.preserved_relations) < cls.REQUIRED_RELATION_MIN:
            reasons.append("fewer than two preserved causal relations")
        if not h.broken_relations:
            reasons.append("no broken/non-transferable relation named")
        if not h.positive_cases:
            reasons.append("no successful comparison case")
        if not h.negative_cases:
            reasons.append("no failed or counterexample case")
        if not h.boundary_conditions:
            reasons.append("scope/boundary conditions are missing")
        if not h.work_relocated_to:
            reasons.append("conservation of work is unaccounted")
        if not h.alternative_mechanisms:
            reasons.append("no competing mechanism was constructed")
        if not h.falsifier.strip():
            reasons.append("no discriminating observation/falsifier")
        return AnalogyAssessment(h.aid, not reasons, tuple(reasons), 0.0)

    @classmethod
    def require(cls, h: AnalogyHypothesis) -> AnalogyAssessment:
        result = cls.assess(h)
        if not result.admissible:
            raise ValueError("inadmissible analogy: " + "; ".join(result.reasons))
        return result
