"""RabbitHole field: the phase itself.

A Field holds variables and heterogeneous factors:

  walls   — hard invariants (conservation sums, products, powers, bounds).
            They contract domains absolutely. Authority 1.0, never decays.
  clamps  — user intent. "This variable is fixed here; propagate."
  weights — soft evidence. "Source S says X ± sigma with confidence C."
            Never contracts the hard domain; fused into a belief layer.
            Authority decays by abandonment (time since last grounding),
            never by disagreement.

Computation is settling: an AC-3-style worklist over interval contractors
(forward-backward / HC4-revise style). Pruning, never generation. Any
subset of variables may be clamped — forward, inverse, and poly-directional
inference are the same operation.

Contradiction handling: when a domain empties, a deletion-filter
(QuickXplain-family) extracts a MINIMAL conflict set, and each clamp in the
conflict is relaxed to report the nearest feasible value.

Everything carries provenance. Serialization preserves full form —
statement, source, timestamps, test history. No compression.
"""

from __future__ import annotations

import json
import math
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field as dc_field
from typing import Dict, List, Optional, Sequence, Tuple

from .core import Dim, Interval, unit as lookup_unit

INF = math.inf

# ---------------------------------------------------------------------------
# Errors / provenance
# ---------------------------------------------------------------------------


class DimensionalWall(Exception):
    """Raised at registration when a constraint is dimensionally impossible."""


@dataclass
class Provenance:
    pid: str
    statement: str
    source: str
    kind: str  # invariant|definition|convention|model|projection|constant|prior|clamp|evidence
    confidence: float = 1.0
    created_at: float = 0.0
    last_grounded_at: float = 0.0
    test_count: int = 0
    half_life_days: float = 180.0

    def authority(self, now: float) -> float:
        """Walls are absolute. Evidence gains authority only by surviving a
        test (A2): untested assertions carry zero weight, however many times
        they are repeated (T2). Grounded evidence decays by abandonment only."""
        if self.kind in ("invariant", "definition", "convention", "model",
                          "projection", "constant", "prior", "clamp"):
            return 1.0
        if self.test_count <= 0:
            return 0.0  # an assertion is not a test
        age_seconds = max(0.0, now - self.last_grounded_at)
        # Staleness is epistemic time, not call-order noise. Sub-second creation
        # differences must not change fusion weights for evidence registered in
        # one transaction or test run.
        age_days = 0.0 if age_seconds < 1.0 else age_seconds / 86400.0
        return self.confidence * (0.5 ** (age_days / self.half_life_days))

    def ground(self, now: float) -> None:
        """A test touched reality and this claim survived."""
        self.test_count += 1
        self.last_grounded_at = now


# ---------------------------------------------------------------------------
# Variables
# ---------------------------------------------------------------------------


@dataclass
class Variable:
    name: str
    dim: Dim
    unit_name: str = ""
    unit_scale: float = 1.0
    domain: Interval = dc_field(default_factory=Interval.full)
    note: str = ""

    def display(self) -> str:
        d = self.domain
        if self.unit_scale != 1.0 and not d.is_empty():
            d = Interval(d.lo / self.unit_scale, d.hi / self.unit_scale)
        u = f" {self.unit_name}" if self.unit_name else ""
        return f"{d!r}{u}"


# ---------------------------------------------------------------------------
# Factors
# ---------------------------------------------------------------------------


class Factor:
    fid: str
    prov: Provenance

    def vars(self) -> Sequence[str]:  # pragma: no cover - interface
        raise NotImplementedError

    def dim_check(self, field: "Field") -> None:  # pragma: no cover
        raise NotImplementedError

    def contract(self, dom: Dict[str, Interval]) -> Dict[str, Interval]:
        raise NotImplementedError  # pragma: no cover

    def describe(self) -> str:
        return f"[{self.fid} {self.prov.kind}] {self.prov.statement} (source: {self.prov.source})"


class SumFactor(Factor):
    """t1 + t2 + ... + tn = total. Conservation lives here."""

    def __init__(self, fid: str, prov: Provenance, terms: List[str], total: str):
        self.fid, self.prov, self.terms, self.total = fid, prov, list(terms), total

    def vars(self):
        return self.terms + [self.total]

    def dim_check(self, field):
        dt = field.variables[self.total].dim
        for t in self.terms:
            d = field.variables[t].dim
            if d.exps != dt.exps:
                raise DimensionalWall(
                    f"WALL {self.fid}: '{self.prov.statement}' adds {d} to {dt}. "
                    f"Term '{t}' cannot sum into '{self.total}'. Rejected at registration."
                )

    def contract(self, dom):
        out: Dict[str, Interval] = {}
        n = len(self.terms)

        # Fast paths matter because binary conservation factors dominate the
        # propagation graph.  Keep them allocation-light while retaining the
        # same outward-rounded interval operations as the general algorithm.
        if n == 0:
            out[self.total] = dom[self.total].intersect(Interval.point(0.0))
            return out
        if n == 1:
            term = self.terms[0]
            out[self.total] = dom[self.total].intersect(dom[term])
            out[term] = dom[term].intersect(dom[self.total])
            return out
        if n == 2:
            left, right = self.terms
            out[self.total] = dom[self.total].intersect(dom[left] + dom[right])
            out[left] = dom[left].intersect(dom[self.total] - dom[right])
            out[right] = dom[right].intersect(dom[self.total] - dom[left])
            return out

        # Compute each "sum of all other terms" in linear rather than
        # quadratic time. Prefix/suffix interval sums remain outward-rounded;
        # regrouping may widen by a few ulps but cannot remove a valid value.
        prefix = [Interval.point(0.0)]
        for t in self.terms:
            prefix.append(prefix[-1] + dom[t])
        suffix = [Interval.point(0.0) for _ in range(n + 1)]
        for i in range(n - 1, -1, -1):
            suffix[i] = dom[self.terms[i]] + suffix[i + 1]
        out[self.total] = dom[self.total].intersect(prefix[-1])
        for i, t in enumerate(self.terms):
            rest = prefix[i] + suffix[i + 1]
            out[t] = dom[t].intersect(dom[self.total] - rest)
        return out


def _scale_iv(c: float, x: Interval) -> Interval:
    """Scalar multiple of an interval, with the 0·∞ = 0 convention."""
    if x.is_empty():
        return x
    if c == 0.0:
        return Interval.point(0.0)
    a, b = c * x.lo, c * x.hi
    return Interval(a, b) if c > 0 else Interval(b, a)


class LinearFactor(Factor):
    """c1·x1 + c2·x2 + ... + cn·xn = total.

    Subsumes subtraction (a = b − c  ⇔  1·b + (−1)·c = a … or terms on
    either side), scaling, and weighted balances. Coefficients are exact
    dimensionless reals; every term must share the total's dimension.
    """

    def __init__(self, fid: str, prov: Provenance,
                 terms: List[Tuple[float, str]], total: str):
        self.fid, self.prov = fid, prov
        self.coeffs = [float(c) for c, _ in terms]
        self.terms = [v for _, v in terms]
        self.total = total

    def vars(self):
        return self.terms + [self.total]

    def dim_check(self, field):
        dt = field.variables[self.total].dim
        for t in self.terms:
            d = field.variables[t].dim
            if d.exps != dt.exps:
                raise DimensionalWall(
                    f"WALL {self.fid}: '{self.prov.statement}' — term '{t}' is {d} "
                    f"but the balance '{self.total}' is {dt}. Rejected at registration."
                )

    def contract(self, dom):
        out: Dict[str, Interval] = {}
        s = Interval.point(0.0)
        scaled = [_scale_iv(c, dom[t]) for c, t in zip(self.coeffs, self.terms)]
        for sv in scaled:
            s = s + sv
        out[self.total] = dom[self.total].intersect(s)
        for i, t in enumerate(self.terms):
            ci = self.coeffs[i]
            if ci == 0.0:
                continue  # no information flows through a zero coefficient
            rest = Interval.point(0.0)
            for j, sv in enumerate(scaled):
                if j != i:
                    rest = rest + sv
            out[t] = dom[t].intersect(_scale_iv(1.0 / ci, dom[self.total] - rest))
        return out


class ProductFactor(Factor):
    """a * b = c."""

    def __init__(self, fid: str, prov: Provenance, a: str, b: str, c: str):
        self.fid, self.prov, self.a, self.b, self.c = fid, prov, a, b, c

    def vars(self):
        return [self.a, self.b, self.c]

    def dim_check(self, field):
        da, db, dc = (field.variables[v].dim for v in (self.a, self.b, self.c))
        if (da * db).exps != dc.exps:
            raise DimensionalWall(
                f"WALL {self.fid}: '{self.prov.statement}' — {da} · {db} = {da*db}, "
                f"but '{self.c}' is {dc}. Rejected at registration."
            )

    def contract(self, dom):
        a, b, c = dom[self.a], dom[self.b], dom[self.c]
        return {
            self.c: c.intersect(a * b),
            self.a: a.intersect(c / b),
            self.b: b.intersect(c / a),
        }


class PowerFactor(Factor):
    """a ** n = c, integer n >= 1. Backward step is branch-aware."""

    def __init__(self, fid: str, prov: Provenance, a: str, n: int, c: str):
        self.fid, self.prov, self.a, self.n, self.c = fid, prov, a, int(n), c

    def vars(self):
        return [self.a, self.c]

    def dim_check(self, field):
        da, dc = field.variables[self.a].dim, field.variables[self.c].dim
        if da.power(self.n).exps != dc.exps:
            raise DimensionalWall(
                f"WALL {self.fid}: '{self.prov.statement}' — ({da})^{self.n} = "
                f"{da.power(self.n)}, but '{self.c}' is {dc}. Rejected at registration."
            )

    def contract(self, dom):
        a, c = dom[self.a], dom[self.c]
        new_c = c.intersect(a.power(self.n))
        back = Interval.empty()
        for br in new_c.root_branches(self.n):
            back = back.hull(br.intersect(a))
        return {self.c: new_c, self.a: back}


class BoundFactor(Factor):
    """x in [lo, hi]. Used for clamps, priors, invariant bounds, constants."""

    def __init__(self, fid: str, prov: Provenance, var: str, iv: Interval):
        self.fid, self.prov, self.var, self.iv = fid, prov, var, iv

    def vars(self):
        return [self.var]

    def dim_check(self, field):
        pass  # a bound is always dimensionally native to its variable

    def contract(self, dom):
        return {self.var: dom[self.var].intersect(self.iv)}


@dataclass
class Evidence:
    eid: str
    var: str
    value: float  # SI-coherent
    sigma: float  # SI-coherent
    prov: Provenance
    contact: str = "human"   # D3 contact type
    author: str = ""         # who authored the claim/test (self-authorship visible)
    independence_key: str = ""  # correlated contacts share one fusion slot
    contact_quality: float = 1.0  # executor-scoped limitation, not source fluency

    def authority(self, now: float) -> float:
        return self.prov.authority(now) * self.contact_quality


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------


@dataclass
class NearestFeasible:
    clamp_id: str
    var: str
    requested: Interval
    feasible: Interval
    nearest: Optional[float]


@dataclass
class ConflictReport:
    emptied_var: str
    conflict: List[Factor]
    relaxations: List[NearestFeasible]

    def describe(self) -> str:
        lines = [f"CONTRADICTION at '{self.emptied_var}'. Minimal conflict:"]
        for f in self.conflict:
            lines.append("  - " + f.describe())
        for r in self.relaxations:
            if r.nearest is not None:
                lines.append(
                    f"  nearest possible for '{r.var}': you asked {r.requested!r}, "
                    f"reality permits {r.feasible!r} (nearest value {r.nearest:g})"
                )
        return "\n".join(lines)


@dataclass
class SettleReport:
    status: str  # "settled" | "contradiction"
    pops: int
    contractions: int
    elapsed_ms: float
    events: List[Tuple[str, str, str, str]]  # (factor_id, var, before, after)
    conflict: Optional[ConflictReport] = None


@dataclass
class GroundingRequest:
    """What the internal bridge would dispatch to reality."""

    var: str
    reason: str
    discriminates: List[str]


@dataclass
class BeliefReport:
    var: str
    mean: Optional[float]
    sigma: Optional[float]
    contested: bool
    within_walls: Optional[bool]
    contributions: List[Tuple[str, float, float, float]]  # (source, value, sigma, authority)
    test: Optional[GroundingRequest]


# ---------------------------------------------------------------------------
# The Field
# ---------------------------------------------------------------------------

_EPS_ABS = 1e-12
_EPS_REL = 1e-9


def _narrowed(old: Interval, new: Interval) -> bool:
    if new.is_empty():
        return not old.is_empty()
    lo_tol = _EPS_ABS + _EPS_REL * (abs(old.lo) if math.isfinite(old.lo) else 1.0)
    hi_tol = _EPS_ABS + _EPS_REL * (abs(old.hi) if math.isfinite(old.hi) else 1.0)
    lo_moved = (new.lo > old.lo + lo_tol) or (math.isinf(old.lo) and math.isfinite(new.lo))
    hi_moved = (new.hi < old.hi - hi_tol) or (math.isinf(old.hi) and math.isfinite(new.hi))
    return lo_moved or hi_moved


class Field:
    def __init__(self, name: str = "field"):
        self.name = name
        self.variables: Dict[str, Variable] = {}
        self.factors: Dict[str, Factor] = {}
        self.evidence: Dict[str, Evidence] = {}
        self._n = 0
        self._adj: Dict[str, List[str]] = defaultdict(list)
        self.log = None  # optional WAL (rabbithole.wal.EventLog)
        self.commitments: Dict[str, object] = {}  # E6 records (epistemic.commit)

    # -- audit spine ----------------------------------------------------------
    def attach_log(self, log=None):
        """Attach an append-only, hash-chained event log. Every mutating
        operation from here on is recorded; a snapshot of the current state
        anchors the record."""
        if log is None:
            from .wal import EventLog
            log = EventLog()
        self.log = log
        log.snapshot(self.to_dict())
        return log

    def _emit(self, etype: str, payload: dict) -> None:
        if self.log is not None:
            self.log.append(etype, payload)

    # -- construction --------------------------------------------------------
    def _next_id(self, prefix: str) -> str:
        self._n += 1
        return f"{prefix}{self._n:03d}"

    def var(self, name: str, unit_name: str = "", lo: float = -INF, hi: float = INF,
            note: str = "", bound_kind: str = "prior", bound_source: str = "declaration") -> Variable:
        dim, scale = lookup_unit(unit_name)
        v = Variable(name, dim, unit_name, scale, Interval.full(), note)
        self.variables[name] = v
        self._emit("var", {"name": name, "unit": unit_name, "note": note})
        if lo != -INF or hi != INF:
            self._bound(name, Interval(lo * scale, hi * scale), bound_kind,
                        f"{name} ∈ [{lo}, {hi}] {unit_name}".strip(), bound_source)
        return v

    def _register(self, f: Factor) -> str:
        f.dim_check(self)
        self.factors[f.fid] = f
        for vname in f.vars():
            self._adj[vname].append(f.fid)
        self._emit("factor", {"fid": f.fid, "ftype": type(f).__name__,
                              "kind": f.prov.kind, "statement": f.prov.statement,
                              "source": f.prov.source, "vars": list(f.vars())})
        return f.fid

    def _bound(self, var: str, iv: Interval, kind: str, statement: str, source: str,
               now: Optional[float] = None) -> str:
        now = time.time() if now is None else now
        fid = self._next_id("F")
        prov = Provenance(fid, statement, source, kind, 1.0, now, now)
        return self._register(BoundFactor(fid, prov, var, iv))

    def invariant_bound(self, var: str, lo: float = -INF, hi: float = INF,
                        statement: str = "", source: str = "invariant") -> str:
        s = self.variables[var].unit_scale
        iv = Interval(lo * s if math.isfinite(lo) else lo, hi * s if math.isfinite(hi) else hi)
        return self._bound(var, iv, "invariant", statement or f"{var} bounded", source)

    def constant(self, var: str, value: float, statement: str, source: str) -> str:
        s = self.variables[var].unit_scale
        return self._bound(var, Interval.point(value * s), "constant", statement, source)

    def clamp(self, var: str, value=None, lo: float = -INF, hi: float = INF,
              reason: str = "user intent") -> str:
        s = self.variables[var].unit_scale
        if value is not None:
            iv = Interval.point(value * s)
            stmt = f"clamp {var} = {value} {self.variables[var].unit_name}".strip()
        else:
            iv = Interval(lo * s if math.isfinite(lo) else lo, hi * s if math.isfinite(hi) else hi)
            stmt = f"clamp {var} ∈ [{lo}, {hi}] {self.variables[var].unit_name}".strip()
        return self._bound(var, iv, "clamp", stmt, reason)

    def release(self, fid: str, force: bool = False) -> None:
        f = self.factors.get(fid)
        if f is None:
            return
        if f.prov.kind in ("invariant", "definition", "convention", "constant") and not force:
            raise PermissionError(
                f"{fid} is a wall ({f.prov.kind}: '{f.prov.statement}'). "
                "Walls are structure, not intent — release(force=True) to "
                "remove it, and the log will show the removal was forced.")
        self.factors.pop(fid)
        for vname in f.vars():
            self._adj[vname] = [x for x in self._adj[vname] if x != fid]
        self._emit("release", {"fid": fid, "statement": f.prov.statement,
                               "kind": f.prov.kind, "forced": bool(force)})

    def sum_is(self, terms: List[str], total: str, statement: str = "",
               source: str = "invariant", kind: str = "invariant") -> str:
        fid = self._next_id("F")
        now = time.time()
        prov = Provenance(fid, statement or f"{' + '.join(terms)} = {total}",
                          source, kind, 1.0, now, now)
        return self._register(SumFactor(fid, prov, terms, total))

    def linear_is(self, terms: List[Tuple[float, str]], total: str,
                  statement: str = "", source: str = "invariant",
                  kind: str = "invariant") -> str:
        fid = self._next_id("F")
        nowt = time.time()
        default = " + ".join(f"{c:g}·{v}" for c, v in terms) + f" = {total}"
        prov = Provenance(fid, statement or default, source, kind,
                          1.0, nowt, nowt)
        return self._register(LinearFactor(fid, prov, terms, total))

    def product_is(self, a: str, b: str, c: str, statement: str = "",
                   source: str = "invariant", kind: str = "invariant") -> str:
        fid = self._next_id("F")
        now = time.time()
        prov = Provenance(fid, statement or f"{a} · {b} = {c}", source, kind, 1.0, now, now)
        return self._register(ProductFactor(fid, prov, a, b, c))

    def power_is(self, a: str, n: int, c: str, statement: str = "",
                 source: str = "invariant", kind: str = "invariant") -> str:
        if int(n) < 1:
            raise ValueError(f"power exponent must be a positive integer (got {n})")
        fid = self._next_id("F")
        now = time.time()
        prov = Provenance(fid, statement or f"{a}^{n} = {c}", source, kind, 1.0, now, now)
        return self._register(PowerFactor(fid, prov, a, n, c))

    # -- evidence (weights) ---------------------------------------------------
    def add_evidence(self, var: str, value: float, sigma: float, source: str,
                     confidence: float, grounded_at: Optional[float] = None,
                     half_life_days: float = 180.0, statement: str = "",
                     tested: bool = False, contact: Optional[str] = None,
                     author: Optional[str] = None,
                     independence_key: Optional[str] = None,
                     contact_quality: float = 1.0) -> str:
        """Register soft evidence. An assertion is not a test: unless
        tested=True (the value came back from an actual test/measurement),
        the claim carries zero fusion weight until something grounds it.
        contact types the reality-touch (D3); author makes self-authored
        grading visible rather than hidden."""
        if var not in self.variables:
            raise KeyError(f"unknown evidence variable {var!r}")
        if not math.isfinite(float(value)):
            raise ValueError(f"evidence value must be finite (got {value!r})")
        if not math.isfinite(float(sigma)) or not (sigma > 0):
            raise ValueError(
                f"evidence sigma must be finite and > 0 (got {sigma}): an exact claim "
                "is a wall, not evidence — use clamp()/constant() instead")
        if not math.isfinite(float(confidence)) or not (0.0 <= confidence <= 1.0):
            raise ValueError(f"evidence confidence must be in [0, 1] (got {confidence!r})")
        if not math.isfinite(float(half_life_days)) or half_life_days <= 0:
            raise ValueError("half_life_days must be finite and > 0")
        allowed_contacts = {"direct", "instrument", "secondary", "derived", "model", "human"}
        if contact is not None and contact not in allowed_contacts:
            raise ValueError(f"unknown contact type {contact!r}")
        if not math.isfinite(float(contact_quality)) or not (0.0 <= contact_quality <= 1.0):
            raise ValueError("contact_quality must be in [0, 1]")
        now = time.time()
        g = now if grounded_at is None else grounded_at
        eid = self._next_id("E")
        s = self.variables[var].unit_scale
        prov = Provenance(eid, statement or f"{source}: {var} = {value} ± {sigma}",
                          source, "evidence", confidence, g, g,
                          1 if tested else 0, half_life_days)
        self.evidence[eid] = Evidence(eid, var, value * s, sigma * s, prov,
                                      contact or "human", author or source,
                                      independence_key or source, float(contact_quality))
        self._emit("evidence", {"eid": eid, "var": var, "source": source,
                                "tested": bool(tested),
                                "contact": contact or "human",
                                "author": author or source,
                                "independence_key": independence_key or source,
                                "contact_quality": float(contact_quality),
                                "statement": prov.statement})
        return eid

    def ground_evidence(self, eid: str, now: Optional[float] = None,
                        contact_quality: Optional[float] = None) -> None:
        if contact_quality is not None:
            q = float(contact_quality)
            if not math.isfinite(q) or not (0.0 <= q <= 1.0):
                raise ValueError("contact_quality must be in [0,1]")
            self.evidence[eid].contact_quality = q
        self.evidence[eid].prov.ground(time.time() if now is None else now)
        self._emit("ground", {"eid": eid,
                              "test_count": self.evidence[eid].prov.test_count})

    def belief(self, var: str, now: Optional[float] = None) -> BeliefReport:
        now = time.time() if now is None else now
        evs = [e for e in self.evidence.values() if e.var == var]
        scale = self.variables[var].unit_scale
        if not evs:
            return BeliefReport(var, None, None, False, None, [], None)
        contribs, wsum, wvsum = [], 0.0, 0.0
        groups: Dict[str, List[Evidence]] = defaultdict(list)
        for e in evs:
            a = e.authority(now)
            contribs.append((e.prov.source, e.value / scale, e.sigma / scale, a))
            groups[e.independence_key or e.prov.source].append(e)

        # Independence-as-immunity: a source split into many correlated records
        # receives one fusion slot, not N votes. Within each lineage select the
        # most informative currently grounded contact. Repetition may improve
        # audit coverage but cannot manufacture statistical independence.
        representatives: List[Evidence] = []
        for group in groups.values():
            representatives.append(max(
                group,
                key=lambda e: (e.authority(now) / (e.sigma * e.sigma))
                              if e.sigma > 0 else 0.0,
            ))
        for e in representatives:
            a = e.authority(now)
            if e.sigma > 0 and a > 0:
                w = a / (e.sigma * e.sigma)
                wsum += w
                wvsum += w * e.value
        mean = (wvsum / wsum) if wsum > 0 else None
        fsig = math.sqrt(1.0 / wsum) if wsum > 0 else None
        contested = False
        for group in groups.values():
            for i in range(len(group)):
                for j in range(i + 1, len(group)):
                    if abs(group[i].value - group[j].value) > 2.0 * (group[i].sigma + group[j].sigma):
                        contested = True
        for i in range(len(representatives)):
            for j in range(i + 1, len(representatives)):
                if abs(representatives[i].value - representatives[j].value) > 2.0 * (representatives[i].sigma + representatives[j].sigma):
                    contested = True
        dom = self.variables[var].domain
        within = None
        if mean is not None and not dom.is_empty() and (math.isfinite(dom.lo) or math.isfinite(dom.hi)):
            within = dom.contains(mean)
            if not within:
                contested = True
        test = None
        if contested:
            disc = [f"{s}: {v:g} ± {sg:g} (authority {a:.3f})" for s, v, sg, a in contribs]
            test = GroundingRequest(
                var,
                "sources disagree beyond their stated uncertainty"
                + ("" if within in (None, True) else "; belief lies outside hard walls"),
                disc,
            )
        return BeliefReport(var,
                            (mean / scale) if mean is not None else None,
                            (fsig / scale) if fsig is not None else None,
                            contested, within, contribs, test)

    def project_belief(self, var: str, k_sigma: float = 2.0,
                       allow_contested: bool = False,
                       source: str = "belief projection") -> str:
        """Project tested soft evidence into a reversible working interval.

        Evidence must first earn authority through tests.  The resulting bound
        is *not* an invariant or a constant; it is a scenario projection used so
        the hard contractor graph can calculate with epistemic uncertainty.
        It can be released normally, carries the fused sources in provenance,
        and is refused when evidence is absent or contested unless explicitly
        overridden.
        """
        if not math.isfinite(float(k_sigma)) or k_sigma <= 0:
            raise ValueError("k_sigma must be finite and > 0")
        b = self.belief(var)
        if b.mean is None or b.sigma is None:
            raise ValueError(f"cannot project {var!r}: no tested weighted evidence")
        if b.contested and not allow_contested:
            raise ValueError(f"cannot project {var!r}: evidence is contested")
        lo, hi = b.mean - k_sigma * b.sigma, b.mean + k_sigma * b.sigma
        scale = self.variables[var].unit_scale
        sources = ", ".join(sorted({c[0] for c in b.contributions if c[3] > 0}))
        stmt = (f"working projection {var} = {b.mean:g} ± {k_sigma:g}σ "
                f"({self.variables[var].unit_name}); tested sources: {sources or 'none'}")
        return self._bound(var, Interval(lo * scale, hi * scale), "projection",
                           stmt, source)

    # -- settling --------------------------------------------------------------
    def _run(self, exclude: Optional[set] = None, record: bool = False,
             max_pops: int = 2_000_000):
        exclude = exclude or set()
        dom: Dict[str, Interval] = {n: Interval.full() for n in self.variables}
        active = [f for fid, f in self.factors.items() if fid not in exclude]
        queue = deque(active)
        inq = {f.fid for f in active}
        events: List[Tuple[str, str, str, str]] = []
        pops = contractions = 0
        emptied: Optional[str] = None
        while queue:
            f = queue.popleft()
            inq.discard(f.fid)
            pops += 1
            if pops > max_pops:
                break
            proposed = f.contract(dom)
            for vname, new in proposed.items():
                old = dom[vname]
                if _narrowed(old, new):
                    dom[vname] = new
                    contractions += 1
                    if record:
                        events.append((f.fid, vname, repr(old), repr(new)))
                    if new.is_empty():
                        emptied = vname
                        queue.clear()
                        break
                    for nfid in self._adj[vname]:
                        if nfid not in exclude and nfid not in inq and nfid in self.factors:
                            queue.append(self.factors[nfid])
                            inq.add(nfid)
            if emptied:
                break
        return dom, events, pops, contractions, emptied

    def _feasible(self, exclude: set) -> bool:
        _, _, _, _, emptied = self._run(exclude=exclude, record=False)
        return emptied is None

    def settle(self, explain_conflict: bool = True) -> SettleReport:
        t0 = time.perf_counter()
        dom, events, pops, contractions, emptied = self._run(record=True)
        for n, iv in dom.items():
            self.variables[n].domain = iv
        ms = (time.perf_counter() - t0) * 1e3
        if emptied is None:
            self._emit("settle", {"status": "settled", "pops": pops,
                                  "contractions": contractions,
                                  "elapsed_ms": round(ms, 3)})
            return SettleReport("settled", pops, contractions, ms, events)
        if not explain_conflict:
            self._emit("settle", {"status": "contradiction", "pops": pops,
                                  "contractions": contractions,
                                  "elapsed_ms": round(ms, 3), "emptied": emptied,
                                  "conflict": "deferred"})
            return SettleReport("contradiction", pops, contractions, ms, events, None)
        conflict = self._explain(emptied, events)
        self._emit("settle", {"status": "contradiction", "pops": pops,
                              "contractions": contractions,
                              "elapsed_ms": round(ms, 3), "emptied": emptied,
                              "conflict": [x.fid for x in conflict.conflict]})
        return SettleReport("contradiction", pops, contractions, ms, events, conflict)

    # -- contradiction: minimal conflict + nearest feasible ---------------------
    def _explain(self, emptied_var: str, events) -> ConflictReport:
        # Seed ordering from the trace: factors that never fired are tried
        # for removal first, so the reported minimal set hugs the causal path.
        fired = {fid for fid, *_ in events}
        ordered = [fid for fid in self.factors if fid not in fired] + \
                  [fid for fid in self.factors if fid in fired]
        # Deletion filter (QuickXplain family): tentatively remove each factor;
        # if the contradiction survives without it, it is not part of the
        # minimal conflict and stays removed. What remains is minimal.
        removed: set = set()
        for fid in ordered:
            if not self._feasible(removed | {fid}):
                removed.add(fid)
        conflict = [self.factors[fid] for fid in self.factors if fid not in removed]
        relax: List[NearestFeasible] = []
        for f in conflict:
            if f.prov.kind == "clamp" and isinstance(f, BoundFactor):
                dom, *_rest, emptied = self._run(exclude=removed | {f.fid})
                if emptied is None:
                    feas = dom[f.var]
                    req = f.iv
                    nearest = None
                    if not feas.is_empty():
                        want = req.mid()
                        nearest = min(max(want, feas.lo), feas.hi)
                        if math.isinf(nearest):
                            nearest = feas.lo if math.isfinite(feas.lo) else feas.hi
                    sc = self.variables[f.var].unit_scale
                    relax.append(NearestFeasible(
                        f.fid, f.var,
                        Interval(req.lo / sc, req.hi / sc),
                        Interval(feas.lo / sc, feas.hi / sc) if not feas.is_empty() else feas,
                        (nearest / sc) if (nearest is not None and math.isfinite(nearest)) else None))
        return ConflictReport(emptied_var, conflict, relax)

    # -- persistence: full form, no compression ---------------------------------
    def to_dict(self) -> dict:
        def prov_d(p: Provenance) -> dict:
            return {"pid": p.pid, "statement": p.statement, "source": p.source,
                    "kind": p.kind, "confidence": p.confidence, "created_at": p.created_at,
                    "last_grounded_at": p.last_grounded_at, "test_count": p.test_count,
                    "half_life_days": p.half_life_days}

        def num(x: float):
            if x == INF:
                return "∞"
            if x == -INF:
                return "-∞"
            return x

        factors = []
        for f in self.factors.values():
            base = {"fid": f.fid, "prov": prov_d(f.prov)}
            if isinstance(f, SumFactor):
                base.update(type="sum", terms=f.terms, total=f.total)
            elif isinstance(f, LinearFactor):
                base.update(type="linear", coeffs=f.coeffs, vars=f.terms,
                            total=f.total)
            elif isinstance(f, ProductFactor):
                base.update(type="product", a=f.a, b=f.b, c=f.c)
            elif isinstance(f, PowerFactor):
                base.update(type="power", a=f.a, n=f.n, c=f.c)
            elif isinstance(f, BoundFactor):
                base.update(type="bound", var=f.var, lo=num(f.iv.lo), hi=num(f.iv.hi))
            factors.append(base)
        return {
            "name": self.name,
            "counter": self._n,
            "variables": [{"name": v.name, "unit": v.unit_name, "note": v.note,
                           "dim": [str(e) for e in v.dim.exps],
                           "unit_scale": v.unit_scale}
                          for v in self.variables.values()],
            "factors": factors,
            "evidence": [{"eid": e.eid, "var": e.var, "value": e.value,
                          "sigma": e.sigma, "prov": prov_d(e.prov),
                          "contact": e.contact, "author": e.author,
                          "independence_key": e.independence_key,
                          "contact_quality": e.contact_quality}
                         for e in self.evidence.values()],
            "commitments": [
                (c if isinstance(c, dict) else
                 {k: getattr(c, k) for k in (
                     "cid", "statement", "action", "vars",
                     "coverage_at_commit", "min_coverage", "risk_note",
                     "reversibility", "test_plan", "created", "forced",
                     "status", "outcome_note")})
                for c in self.commitments.values()],
        }

    @staticmethod
    def from_dict(d: dict) -> "Field":
        f = Field(d.get("name", "field"))
        for v in d["variables"]:
            nv = f.var(v["name"], v.get("unit", ""), note=v.get("note", ""))
            if "dim" in v:
                from fractions import Fraction
                nv.dim = Dim(tuple(Fraction(e) for e in v["dim"]))
            if "unit_scale" in v:
                nv.unit_scale = v["unit_scale"]
        for fd in d["factors"]:
            p = fd["prov"]
            prov = Provenance(p["pid"], p["statement"], p["source"], p["kind"],
                              p["confidence"], p["created_at"], p["last_grounded_at"],
                              p["test_count"], p["half_life_days"])
            t = fd["type"]
            if t == "sum":
                f._register(SumFactor(fd["fid"], prov, fd["terms"], fd["total"]))
            elif t == "linear":
                f._register(LinearFactor(fd["fid"], prov,
                                         list(zip(fd["coeffs"], fd["vars"])),
                                         fd["total"]))
            elif t == "product":
                f._register(ProductFactor(fd["fid"], prov, fd["a"], fd["b"], fd["c"]))
            elif t == "power":
                f._register(PowerFactor(fd["fid"], prov, fd["a"], fd["n"], fd["c"]))
            elif t == "bound":
                def denum(x):
                    if x == "∞":
                        return INF
                    if x == "-∞":
                        return -INF
                    return float(x)
                f._register(BoundFactor(fd["fid"], prov, fd["var"],
                                        Interval(denum(fd["lo"]), denum(fd["hi"]))))
        for ed in d.get("evidence", []):
            p = ed["prov"]
            prov = Provenance(p["pid"], p["statement"], p["source"], p["kind"],
                              p["confidence"], p["created_at"], p["last_grounded_at"],
                              p["test_count"], p["half_life_days"])
            f.evidence[ed["eid"]] = Evidence(ed["eid"], ed["var"], ed["value"],
                                             ed["sigma"], prov,
                                             ed.get("contact", "human"),
                                             ed.get("author", p["source"]),
                                             ed.get("independence_key", p["source"]),
                                             float(ed.get("contact_quality", 1.0)))
        for cd in d.get("commitments", []):
            try:
                from .epistemic import Commitment
                f.commitments[cd["cid"]] = Commitment(**cd)
            except Exception:
                f.commitments[cd["cid"]] = cd
        f._n = d.get("counter", len(f.factors) + len(f.evidence))
        return f

    def save(self, path: str) -> None:
        with open(path, "w") as fh:
            json.dump(self.to_dict(), fh, indent=2)

    @staticmethod
    def load(path: str) -> "Field":
        with open(path) as fh:
            return Field.from_dict(json.load(fh))


# ---------------------------------------------------------------------------
# The shipped core: standing structure present on day one
# ---------------------------------------------------------------------------


def ship_core(name: str = "field") -> Field:
    """A field that arrives already holding universal invariants:
    exact SI constants (walls with full provenance) ready to be wired
    into any graph the user grows."""
    f = Field(name)
    src = "SI (2019 redefinition) — exact by definition"
    f.var("c_light", "m/s", note="speed of light in vacuum")
    f.constant("c_light", 299_792_458.0, "c = 299 792 458 m/s", src)
    f.var("h_planck", "J*s", note="Planck constant")
    f.constant("h_planck", 6.626_070_15e-34, "h = 6.62607015e-34 J·s", src)
    f.var("k_boltzmann", "J/K", note="Boltzmann constant")
    f.constant("k_boltzmann", 1.380_649e-23, "k_B = 1.380649e-23 J/K", src)
    f.var("e_charge", "C", note="elementary charge")
    f.constant("e_charge", 1.602_176_634e-19, "e = 1.602176634e-19 C", src)
    f.var("N_avogadro", "1/mol", note="Avogadro constant")
    f.constant("N_avogadro", 6.022_140_76e23, "N_A = 6.02214076e23 /mol", src)
    f.var("g_standard", "m/s^2", note="standard gravity")
    f.constant("g_standard", 9.806_65, "g0 = 9.80665 m/s^2",
               "CGPM 1901 conventional value")
    return f