"""RabbitHole fast engine — the pure-Python kernel compiled to native speed.

The Python Field in field.py remains the specification and the oracle.
This module packs a Field's factor graph into flat arrays once, then runs
settling in C (src/rhfast.c) through ctypes. Same semantics, same results,
orders of magnitude faster. Zero dependencies beyond a C compiler; the
shared library is built on first use and cached.

    from rabbithole.fast import FastEngine
    eng = FastEngine(field)      # compile the graph
    report = eng.settle()        # identical SettleReport (events omitted)

Contradictions get the same treatment as the reference: a deletion-filter
minimal conflict plus nearest-feasible relaxations, with every feasibility
probe running natively.
"""

from __future__ import annotations

import ctypes as C
import math
import os
import subprocess
import time
from array import array
from typing import Dict, List, Optional, Set

from .core import Interval
from .field import (
    BoundFactor, ConflictReport, Field, LinearFactor, NearestFeasible,
    PowerFactor, ProductFactor, SettleReport, SumFactor,
)

INF = math.inf
_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_SRC = os.path.join(_HERE, "src", "rhfast.c")
_SO = os.path.join(_HERE, "src", "librhfast.so")

_lib_handle = None


def available() -> bool:
    try:
        return _lib() is not None
    except Exception:
        return False


def _lib():
    global _lib_handle
    if _lib_handle is not None:
        return _lib_handle
    if not os.path.exists(_SO) or os.path.getmtime(_SO) < os.path.getmtime(_SRC):
        subprocess.run(
            ["gcc", "-O3", "-fPIC", "-shared", "-o", _SO, _SRC, "-lm"],
            check=True, capture_output=True,
        )
    lib = C.CDLL(_SO)
    lib.rh_run.restype = C.c_int
    lib.rh_run.argtypes = [
        C.c_int, C.c_int,
        C.POINTER(C.c_int), C.POINTER(C.c_int), C.POINTER(C.c_int),
        C.POINTER(C.c_int), C.POINTER(C.c_double),
        C.POINTER(C.c_int), C.POINTER(C.c_int),
        C.POINTER(C.c_ubyte), C.c_long,
        C.POINTER(C.c_double), C.POINTER(C.c_double),
        C.POINTER(C.c_long), C.POINTER(C.c_long), C.POINTER(C.c_int),
    ]
    _lib_handle = lib
    return lib


def _ptr(arr, ctype):
    addr, _n = arr.buffer_info()
    return C.cast(addr, C.POINTER(ctype))


class FastEngine:
    """A Field compiled to the native settle loop."""

    def __init__(self, field: Field):
        self.field = field
        self.lib = _lib()
        self._pack()
        self._fp = self._fingerprint()

    def _fingerprint(self):
        return (len(self.field.variables), tuple(self.field.factors.keys()))

    # -- packing: Field -> flat CSR arrays --------------------------------
    def _pack(self) -> None:
        f = self.field
        self.vnames: List[str] = list(f.variables.keys())
        vix = {n: i for i, n in enumerate(self.vnames)}
        self.fids: List[str] = list(f.factors.keys())
        self.fix = {fid: i for i, fid in enumerate(self.fids)}

        ftype, fptr, vidx = array("i"), array("i", [0]), array("i")
        pptr, pdata = array("i", [0]), array("d")
        adj: Dict[int, List[int]] = {i: [] for i in range(len(self.vnames))}

        for k, fid in enumerate(self.fids):
            fac = f.factors[fid]
            if isinstance(fac, BoundFactor):
                ftype.append(0)
                vidx.append(vix[fac.var])
                pdata.extend((fac.iv.lo, fac.iv.hi))
            elif isinstance(fac, ProductFactor):
                ftype.append(2)
                vidx.extend((vix[fac.a], vix[fac.b], vix[fac.c]))
            elif isinstance(fac, PowerFactor):
                ftype.append(3)
                vidx.extend((vix[fac.a], vix[fac.c]))
                pdata.append(float(fac.n))
            elif isinstance(fac, SumFactor):          # sum == linear, coeffs 1
                ftype.append(4)
                for t in fac.terms:
                    vidx.append(vix[t]); pdata.append(1.0)
                vidx.append(vix[fac.total])
            elif isinstance(fac, LinearFactor):
                ftype.append(4)
                for c, t in zip(fac.coeffs, fac.terms):
                    vidx.append(vix[t]); pdata.append(float(c))
                vidx.append(vix[fac.total])
            else:  # pragma: no cover
                raise TypeError(f"unpackable factor {type(fac).__name__}")
            fptr.append(len(vidx))
            pptr.append(len(pdata))
            for vn in fac.vars():
                adj[vix[vn]].append(k)

        aptr, adata = array("i", [0]), array("i")
        for i in range(len(self.vnames)):
            adata.extend(adj[i])
            aptr.append(len(adata))

        self._ftype, self._fptr, self._vidx = ftype, fptr, vidx
        self._pptr, self._pdata = pptr, pdata
        self._aptr, self._adata = aptr, adata
        self._lo = array("d", [0.0] * max(1, len(self.vnames)))
        self._hi = array("d", [0.0] * max(1, len(self.vnames)))
        if not pdata:
            self._pdata = array("d", [0.0])
        if not vidx:
            self._vidx = array("i", [0])
        if not adata:
            self._adata = array("i", [0])

    # -- raw native run -----------------------------------------------------
    def run(self, exclude: Optional[Set[str]] = None,
            max_pops: int = 200_000_000):
        if self._fingerprint() != self._fp:   # field mutated since packing
            self._pack()
            self._fp = self._fingerprint()
        nf = len(self.fids)
        excl_ptr = C.cast(None, C.POINTER(C.c_ubyte))
        excl_arr = None
        if exclude:
            excl_arr = array("B", bytes(nf))
            for fid in exclude:
                excl_arr[self.fix[fid]] = 1
            excl_ptr = _ptr(excl_arr, C.c_ubyte)
        pops, contr = C.c_long(0), C.c_long(0)
        emptied = C.c_int(-1)
        rc = self.lib.rh_run(
            len(self.vnames), nf,
            _ptr(self._ftype, C.c_int), _ptr(self._fptr, C.c_int),
            _ptr(self._vidx, C.c_int),
            _ptr(self._pptr, C.c_int), _ptr(self._pdata, C.c_double),
            _ptr(self._aptr, C.c_int), _ptr(self._adata, C.c_int),
            excl_ptr, max_pops,
            _ptr(self._lo, C.c_double), _ptr(self._hi, C.c_double),
            C.byref(pops), C.byref(contr), C.byref(emptied),
        )
        if rc != 0:  # pragma: no cover
            raise RuntimeError("native engine failed")
        del excl_arr
        return pops.value, contr.value, emptied.value

    def _feasible(self, exclude: Set[str]) -> bool:
        return self.run(exclude)[2] < 0

    def _domains(self) -> Dict[str, Interval]:
        return {n: Interval(self._lo[i], self._hi[i])
                for i, n in enumerate(self.vnames)}

    # -- full settle with writeback + explanation ----------------------------
    def settle(self) -> SettleReport:
        t0 = time.perf_counter()
        pops, contr, emptied = self.run()
        ms = (time.perf_counter() - t0) * 1e3
        dom = self._domains()
        for n, ivl in dom.items():
            self.field.variables[n].domain = ivl
        if emptied < 0:
            self.field._emit("settle", {"status": "settled", "pops": pops,
                                        "contractions": contr,
                                        "elapsed_ms": round(ms, 3),
                                        "engine": "native"})
            return SettleReport("settled", pops, contr, ms, [])
        conflict = self._explain(self.vnames[emptied])
        self.field._emit("settle", {"status": "contradiction", "pops": pops,
                                    "contractions": contr,
                                    "elapsed_ms": round(ms, 3),
                                    "emptied": self.vnames[emptied],
                                    "conflict": [x.fid for x in conflict.conflict],
                                    "engine": "native"})
        return SettleReport("contradiction", pops, contr, ms, [], conflict)

    def _explain(self, emptied_var: str) -> ConflictReport:
        removed: Set[str] = set()
        for fid in self.fids:                     # deletion filter, native probes
            if not self._feasible(removed | {fid}):
                removed.add(fid)
        conflict = [self.field.factors[fid] for fid in self.fids
                    if fid not in removed]
        relax: List[NearestFeasible] = []
        for fac in conflict:
            if fac.prov.kind == "clamp" and isinstance(fac, BoundFactor):
                _p, _c, e2 = self.run(removed | {fac.fid})
                if e2 < 0:
                    feas = self._domains()[fac.var]
                    req = fac.iv
                    nearest = None
                    if not feas.is_empty():
                        want = req.mid()
                        nearest = min(max(want, feas.lo), feas.hi)
                        if math.isinf(nearest):
                            nearest = feas.lo if math.isfinite(feas.lo) else feas.hi
                    sc = self.field.variables[fac.var].unit_scale
                    relax.append(NearestFeasible(
                        fac.fid, fac.var,
                        Interval(req.lo / sc, req.hi / sc),
                        Interval(feas.lo / sc, feas.hi / sc)
                        if not feas.is_empty() else feas,
                        (nearest / sc) if (nearest is not None
                                           and math.isfinite(nearest)) else None))
        return ConflictReport(emptied_var, conflict, relax)


def settle_fast(field: Field) -> SettleReport:
    """Settle a field natively; identical semantics to field.settle()
    (per-event trace omitted for speed). Falls back to the pure engine
    if no C compiler is available."""
    try:
        return FastEngine(field).settle()
    except Exception:
        return field.settle()