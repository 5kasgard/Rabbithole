"""Corpus ingestion helpers.

Repomix bundles are first-class source artifacts in this project.  This parser
recovers their individual text files without trusting embedded paths or silently
executing anything.  The recovered files can be searched by LocalCorpusProvider.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, List, Optional, Tuple


_HEADER = re.compile(r"^## File: (.+?)\s*$")
_NUMBERED = re.compile(r"^\s*\d+:(.*)$")


@dataclass
class RecoveredFile:
    source_path: str
    output_path: str
    bytes_written: int


def iter_repomix_files(text: str) -> Iterator[Tuple[str, str]]:
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        match = _HEADER.match(lines[i])
        if not match:
            i += 1
            continue
        name = match.group(1).strip()
        i += 1
        while i < len(lines) and not lines[i].lstrip().startswith("```"):
            i += 1
        if i >= len(lines):
            break
        fence = lines[i].lstrip()
        marker = fence[:len(fence) - len(fence.lstrip('`'))]
        if len(marker) < 3:
            i += 1
            continue
        i += 1
        content: List[str] = []
        while i < len(lines) and lines[i].strip() != marker:
            line = lines[i]
            numbered = _NUMBERED.match(line)
            if numbered:
                line = numbered.group(1)
                if line.startswith(" "):
                    line = line[1:]
            content.append(line)
            i += 1
        yield name, "\n".join(content) + ("\n" if content else "")
        i += 1


def extract_repomix(bundle: str | Path, output_root: str | Path,
                    *, prefix: str = "") -> List[RecoveredFile]:
    bundle_path = Path(bundle)
    root = Path(output_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    recovered: List[RecoveredFile] = []
    for source_name, content in iter_repomix_files(bundle_path.read_text(errors="replace")):
        rel = Path(source_name)
        # Strip optional repository prefix and prohibit absolute/traversal paths.
        if prefix and source_name.startswith(prefix.rstrip("/") + "/"):
            rel = Path(source_name[len(prefix.rstrip("/")) + 1:])
        if rel.is_absolute() or ".." in rel.parts:
            continue
        target = (root / rel).resolve()
        if root not in target.parents and target != root:
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)
        recovered.append(RecoveredFile(source_name, str(target), len(content.encode())))
    return recovered
