"""One bounded public task contract for the Stage 3 organism.

The task surface does not pretend to solve arbitrary work.  It coordinates an
explicit goal, real artifact acquisition, claim-class verification and optional
bounded action.  It halts at the first missing contract/contact instead of
fabricating completion.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Mapping, Tuple

from .acquisition import FetchPolicy
from .goal import GoalRequest
from .verification import Claim


def _id() -> str:
    return f"TSK{uuid.uuid4().hex[:12]}"


@dataclass(frozen=True)
class TaskVerification:
    claim: Claim
    contract_id: str
    verifier_id: str
    inputs: Mapping[str, object]


@dataclass(frozen=True)
class TaskAction:
    action_id: str
    request: Mapping[str, object]
    holder: str
    capability: Mapping[str, object]
    dry_run: bool = True
    approval: str = "none"
    idempotency_key: str = ""


@dataclass(frozen=True)
class TaskRequest:
    goal: GoalRequest
    question: str
    source_locators: Tuple[str, ...] = ()
    fetch_policy: FetchPolicy = field(default_factory=FetchPolicy)
    extraction_mode: str = "quantity"
    verifications: Tuple[TaskVerification, ...] = ()
    action: TaskAction | None = None
    task_id: str = field(default_factory=_id)


@dataclass(frozen=True)
class TaskStage:
    name: str
    state: str
    detail: Mapping[str, object]


@dataclass(frozen=True)
class TaskReport:
    task_id: str
    terminal_state: str
    stages: Tuple[TaskStage, ...]
    unresolved: Tuple[str, ...]
    result_object_ids: Tuple[str, ...]
