"""Typed representation transformations with executable loss contracts."""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Callable, Dict, Mapping, Optional, Sequence, Tuple

from .wal import EventLog


def _id(prefix:str)->str:return f"{prefix}{uuid.uuid4().hex[:12]}"
def _digest(x:object)->str:return hashlib.sha256(json.dumps(x,sort_keys=True,default=str,separators=(",",":")).encode()).hexdigest()

Transform=Callable[[object],object]
Comparator=Callable[[object,object],bool]

@dataclass
class TransformationContract:
    transform_id:str
    input_dialect:str
    output_dialect:str
    preserves:Tuple[str,...]
    loses:Tuple[str,...]
    required_inputs:Tuple[str,...]=()
    reversible:bool=False
    inverse_id:str=""
    comparator_id:str=""
    enabled:bool=True
    version:str="1"

@dataclass
class TransformationReceipt:
    transform_id:str
    input_digest:str
    output_digest:str
    required_distinctions:Tuple[str,...]
    preserved_required:Tuple[str,...]
    lost_required:Tuple[str,...]
    status:str
    reason:str
    roundtrip_passed:Optional[bool]=None
    created_at:float=field(default_factory=time.time)
    receipt_id:str=field(default_factory=lambda:_id("TRN"))

class TransformationRegistry:
    def __init__(self):
        self.contracts:Dict[str,TransformationContract]={};self.transforms:Dict[str,Transform]={};self.comparators:Dict[str,Comparator]={};self.receipts:Dict[str,TransformationReceipt]={};self.audit=EventLog()

    def register_comparator(self,comparator_id:str,fn:Comparator)->None:self.comparators[comparator_id]=fn
    def register(self,contract:TransformationContract,fn:Optional[Transform]=None)->None:
        if contract.transform_id in self.contracts:raise ValueError("transformation already registered")
        if set(contract.preserves)&set(contract.loses):raise ValueError("a distinction cannot be both preserved and lost")
        self.contracts[contract.transform_id]=contract
        if fn is not None:self.transforms[contract.transform_id]=fn
        self.audit.append("transformation_registered",asdict(contract)|{"runtime_attached":fn is not None})
    def attach(self,transform_id:str,fn:Transform)->None:
        if transform_id not in self.contracts:raise KeyError(transform_id)
        self.transforms[transform_id]=fn;self.audit.append("transformation_attached",{"transform_id":transform_id})

    def apply(self,transform_id:str,value:object,*,required_distinctions:Sequence[str]=())->tuple[object,TransformationReceipt]:
        c=self.contracts[transform_id]
        if not c.enabled:raise RuntimeError("transformation disabled")
        required=tuple(sorted(set(required_distinctions)));lost=tuple(sorted(set(required)&set(c.loses)))
        undeclared=tuple(sorted(set(required)-set(c.preserves)-set(c.loses)))
        if lost or undeclared:
            reason=(f"declared required loss: {lost}" if lost else f"preservation undeclared: {undeclared}")
            r=TransformationReceipt(transform_id,_digest(value),"",required,tuple(sorted(set(required)&set(c.preserves))),lost or undeclared,"refused",reason)
            self.receipts[r.receipt_id]=r;self.audit.append("transformation_refused",asdict(r));raise ValueError(reason)
        if transform_id not in self.transforms:raise RuntimeError("transformation runtime is not attached")
        output=self.transforms[transform_id](value);roundtrip=None
        if c.reversible and c.inverse_id and c.inverse_id in self.transforms:
            restored=self.transforms[c.inverse_id](output)
            comp=self.comparators.get(c.comparator_id,lambda a,b:a==b);roundtrip=bool(comp(value,restored))
            if not roundtrip:
                r=TransformationReceipt(transform_id,_digest(value),_digest(output),required,required,(),"failed","roundtrip comparator failed",False)
                self.receipts[r.receipt_id]=r;self.audit.append("transformation_failed",asdict(r));raise ValueError("roundtrip comparator failed")
        r=TransformationReceipt(transform_id,_digest(value),_digest(output),required,required,(),"passed","contract satisfied",roundtrip)
        self.receipts[r.receipt_id]=r;self.audit.append("transformation_applied",asdict(r));return output,r

    def loss_mutation(self,transform_id:str,value:Mapping[str,object],required_field:str)->dict:
        if required_field not in value:raise KeyError(required_field)
        mutated=dict(value);mutated.pop(required_field)
        detected=False;reason=""
        try:self.apply(transform_id,mutated,required_distinctions=(required_field,))
        except Exception as exc:detected=True;reason=f"{type(exc).__name__}: {exc}"
        result={"transform_id":transform_id,"mutation":f"drop:{required_field}","killed":detected,"reason":reason}
        self.audit.append("transformation_loss_mutation",result);return result

    def to_dict(self)->dict:return {"contracts":[asdict(x) for x in self.contracts.values()],"receipts":[asdict(x) for x in self.receipts.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw:Mapping[str,object])->"TransformationRegistry":
        obj=cls()
        for row in raw.get("contracts",[]):
            d=dict(row)
            for k in ("preserves","loses","required_inputs"):d[k]=tuple(d.get(k,()))
            c=TransformationContract(**d);obj.contracts[c.transform_id]=c
        for row in raw.get("receipts",[]):
            d=dict(row)
            for k in ("required_distinctions","preserved_required","lost_required"):d[k]=tuple(d.get(k,()))
            r=TransformationReceipt(**d);obj.receipts[r.receipt_id]=r
        obj.audit=EventLog.from_dict(raw.get("audit",{}));return obj
