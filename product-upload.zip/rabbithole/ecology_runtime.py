"""Conflict-aware specialist governance, contribution, quarantine, and replacement."""
from __future__ import annotations
import time,uuid
from dataclasses import asdict,dataclass,field
from typing import Dict,Mapping,Sequence,Tuple
from .wal import EventLog

def _id(p):return f"{p}{uuid.uuid4().hex[:12]}"
@dataclass
class Specialist:
    specialist_id:str;capabilities:Tuple[str,...];failure_roots:Tuple[str,...];resource_quota:Mapping[str,float];replacement_ids:Tuple[str,...]=();state:str="active";lineage:str="";security_risk:float=0.;maintenance_cost:float=0.
@dataclass
class ContributionExperiment:
    specialist_id:str;capability:str;baseline_quality:float;removed_quality:float;baseline_cost:float;removed_cost:float;security_incidents_delta:int=0
    experiment_id:str=field(default_factory=lambda:_id("ECO"));created_at:float=field(default_factory=time.time)
    @property
    def marginal_value(self):return (self.baseline_quality-self.removed_quality)-(self.baseline_cost-self.removed_cost)-max(0,self.security_incidents_delta)
class SpecialistEcology:
    def __init__(self):self.specialists:Dict[str,Specialist]={};self.experiments:Dict[str,ContributionExperiment]={};self.receipts=[];self.audit=EventLog()
    def register(self,s:Specialist):
        if not s.capabilities or not s.failure_roots:raise ValueError("capabilities and failure roots required")
        self.specialists[s.specialist_id]=s;self.audit.append("specialist_registered",asdict(s))
    def record_experiment(self,e:ContributionExperiment):
        if e.specialist_id not in self.specialists:raise KeyError(e.specialist_id)
        self.experiments[e.experiment_id]=e;self.audit.append("contribution_experiment",asdict(e)|{"marginal_value":e.marginal_value});return e.experiment_id
    def assess(self,capability:str)->dict:
        members=[s for s in self.specialists.values() if capability in s.capabilities and s.state=="active"]
        roots={r for s in members for r in s.failure_roots};root_counts={r:sum(r in s.failure_roots for s in members) for r in roots};hhi=sum((n/max(1,len(members)))**2 for n in root_counts.values())
        contrib={s.specialist_id:sum(e.marginal_value for e in self.experiments.values() if e.specialist_id==s.specialist_id and e.capability==capability) for s in members}
        dys=[]
        if len(roots)<2 and len(members)>1:dys.append("correlated_monoculture")
        dys += [f"negative_marginal:{sid}" for sid,v in contrib.items() if v<0]
        dys += [f"quota_missing:{s.specialist_id}" for s in members if not s.resource_quota]
        return {"capability":capability,"members":[s.specialist_id for s in members],"failure_roots":sorted(roots),"root_hhi":hhi,"marginal_values":contrib,"dysbiosis":dys,"healthy":not dys}
    def quarantine(self,specialist_id:str,reason:str):
        s=self.specialists[specialist_id];s.state="quarantined";r={"specialist_id":specialist_id,"action":"quarantine","reason":reason,"at":time.time()};self.receipts.append(r);self.audit.append("specialist_quarantined",r);return r
    def replace(self,specialist_id:str,replacement_id:str,reason:str):
        old=self.specialists[specialist_id];new=self.specialists[replacement_id]
        if replacement_id not in old.replacement_ids:raise ValueError("replacement not declared")
        if not set(old.capabilities)<=set(new.capabilities):raise ValueError("replacement lacks capability")
        old.state="decommissioned";new.state="active";r={"specialist_id":specialist_id,"replacement_id":replacement_id,"action":"replace","reason":reason,"at":time.time()};self.receipts.append(r);self.audit.append("specialist_replaced",r);return r
    def enforce_quota(self,specialist_id:str,usage:Mapping[str,float])->dict:
        s=self.specialists[specialist_id];viol={k:{"used":float(v),"quota":float(s.resource_quota.get(k,0))} for k,v in usage.items() if k in s.resource_quota and float(v)>float(s.resource_quota[k])}
        if viol:self.quarantine(specialist_id,"resource quota exceeded")
        return {"specialist_id":specialist_id,"violations":viol,"within_quota":not viol}
    def to_dict(self):return {"specialists":[asdict(x) for x in self.specialists.values()],"experiments":[asdict(x) for x in self.experiments.values()],"receipts":self.receipts,"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw):
        o=cls()
        for r in raw.get("specialists",[]):
            d=dict(r)
            for k in ("capabilities","failure_roots","replacement_ids"):d[k]=tuple(d.get(k,()))
            s=Specialist(**d);o.specialists[s.specialist_id]=s
        for r in raw.get("experiments",[]):e=ContributionExperiment(**dict(r));o.experiments[e.experiment_id]=e
        o.receipts=list(raw.get("receipts",[]));o.audit=EventLog.from_dict(raw.get("audit",{}));return o
