"""RabbitHole WAL — the append-only, hash-chained audit spine.

Ported from the precursor (RabbitHole v2.x single-file build), which paid
for three lessons this port bakes in rather than re-learns:

  1. An unwired WAL is fiction. Here the log is attached to a Field and
     every mutating operation emits through one hook; a gate counts them.
  2. Version stamps must bind to code, not to a sentinel. Every event
     carries a hash of the kernel sources that produced it.
  3. A snapshot stored by live reference (or outside the hash chain) lets
     history be silently rewritten. Snapshots are deep-isolated and their
     state hash is committed INTO the chained event, so tampering the
     stored state breaks verify() exactly like tampering an event.

Properties (the precursor's names, kept):
  P1 complete record   — every change appended, stamped with the exact
                         kernel version that produced it.
  P2 tamper-evidence   — each event carries the hash of the prior; any
                         alteration is detectable by anyone, including
                         the operator.
  P6 retention/restore — snapshots + the event record reconstruct any
                         past state; explain(seq) is the causal view.

The field is a projection; the log is what happened.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import asdict, dataclass
from typing import Optional

_GENESIS = "0" * 64
_HERE = os.path.dirname(os.path.abspath(__file__))


def kernel_version() -> str:
    """Hash the kernel sources so every event is bound to the exact code
    that produced it. Never returns a silent sentinel without trying."""
    h = hashlib.sha256()
    found = False
    for name in (
        "core.py", "field.py", "bridge.py", "fast.py", "wal.py",
        "akbc.py", "tether.py", "routing.py", "capabilities.py",
        "epistemic.py", "instrument.py", "organs.py", "arc_kernel.py",
        "arc_campaign.py", "resources.py", "evaluation.py", "providers.py",
        "campaign_search.py", "documents.py", "transformations.py",
        "empirical.py", "mapping_precision.py", "regime_calibration.py",
        "design_registry.py", "allocation.py", "portfolio_benchmark.py",
        "ecology_runtime.py", "shift_portfolio.py", "environment.py",
        "explanation_study.py", "mutation_campaign.py",
        "scenario_profiles.py", "process_portfolio.py",
        "substrate_campaign.py", "longitudinal_validation.py",
        "performance_fabric.py", "performance_runtime.py", "performance_store.py",
        "interchange.py", "master_registry.py", "outward_loop.py",
    ):
        try:
            with open(os.path.join(_HERE, name), "rb") as fh:
                h.update(fh.read())
            found = True
        except OSError:
            continue
    return h.hexdigest()[:16] if found else "unknown-version"


def _event_hash(seq: int, ts: float, version: str, etype: str,
                payload: dict, prev_hash: str) -> str:
    body = json.dumps({"seq": seq, "ts": ts, "version": version,
                       "type": etype, "payload": payload, "prev": prev_hash},
                      sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(body.encode()).hexdigest()


def _state_hash(state: dict) -> str:
    return hashlib.sha256(
        json.dumps(state, sort_keys=True).encode()).hexdigest()


@dataclass
class Event:
    seq: int
    ts: float
    version: str
    type: str      # 'var'|'factor'|'release'|'evidence'|'ground'|'settle'|'snapshot'
    payload: dict
    prev_hash: str
    hash: str


class EventLog:
    """Append-only, hash-chained, version-stamped. The single source of
    truth about what happened to a field."""

    def __init__(self):
        self.events: list = []
        self.snapshots: dict = {}          # seq -> deep-isolated state dict
        self._version = kernel_version()

    # -------------------------------------------------- append
    def append(self, etype: str, payload: dict) -> Event:
        seq = len(self.events)
        ts = time.time()
        prev = self.events[-1].hash if self.events else _GENESIS
        h = _event_hash(seq, ts, self._version, etype, payload, prev)
        e = Event(seq, ts, self._version, etype, payload, prev, h)
        self.events.append(e)
        return e

    def snapshot(self, state: dict) -> Event:
        """Record a full-state snapshot. The state is deep-isolated via a
        JSON round-trip and its digest is committed into the chained event,
        so a later edit of the stored state is caught by verify()."""
        seq = len(self.events)
        isolated = json.loads(json.dumps(state))
        self.snapshots[seq] = isolated
        return self.append("snapshot",
                           {"snapshot_seq": seq,
                            "state_hash": _state_hash(isolated)})

    # -------------------------------------------------- P2 tamper-evidence
    def verify(self) -> dict:
        """Recompute the whole chain. Any altered event — or any tampered
        snapshot state — breaks it here."""
        prev = _GENESIS
        for i, e in enumerate(self.events):
            if e.seq != i:
                return {"valid": False, "broken_at": i, "reason": "seq mismatch"}
            if e.prev_hash != prev:
                return {"valid": False, "broken_at": i,
                        "reason": "prev-hash mismatch"}
            if _event_hash(e.seq, e.ts, e.version, e.type,
                           e.payload, e.prev_hash) != e.hash:
                return {"valid": False, "broken_at": i,
                        "reason": "content-hash mismatch (tampered event)"}
            if e.type == "snapshot" and "state_hash" in e.payload:
                st = self.snapshots.get(e.payload["snapshot_seq"])
                if st is None:
                    return {"valid": False, "broken_at": i,
                            "reason": "snapshot state missing"}
                if _state_hash(st) != e.payload["state_hash"]:
                    return {"valid": False, "broken_at": i,
                            "reason": "snapshot state tampered"}
            prev = e.hash
        return {"valid": True, "events": len(self.events)}

    # -------------------------------------------------- audit views
    def history(self, etype: Optional[str] = None) -> list:
        return [asdict(e) for e in self.events
                if etype is None or e.type == etype]

    def explain(self, seq: int) -> dict:
        """Why did the field look as it did at event `seq`? The event plus
        the causal record that produced it."""
        if seq < 0 or seq >= len(self.events):
            return {"error": "seq out of range"}
        return {"event": asdict(self.events[seq]),
                "preceding": [asdict(e) for e in self.events[:seq]],
                "version": self.events[seq].version}

    def latest_snapshot_before(self, seq: int):
        candidates = [s for s in self.snapshots if s <= seq]
        if not candidates:
            return None, None
        s = max(candidates)
        return s, self.snapshots[s]

    def versions_used(self) -> set:
        return {e.version for e in self.events}

    # -------------------------------------------------- persistence
    def to_dict(self) -> dict:
        return {"version": self._version,
                "events": [asdict(e) for e in self.events],
                "snapshots": {str(k): v for k, v in self.snapshots.items()}}

    @classmethod
    def from_dict(cls, d: dict) -> "EventLog":
        log = cls()
        log._version = d.get("version", kernel_version())
        log.events = [Event(**e) for e in d.get("events", [])]
        log.snapshots = {int(k): v for k, v in d.get("snapshots", {}).items()}
        return log

    def save(self, path: str) -> None:
        with open(path, "w") as fh:
            json.dump(self.to_dict(), fh, indent=2)

    @staticmethod
    def load(path: str) -> "EventLog":
        with open(path) as fh:
            return EventLog.from_dict(json.load(fh))