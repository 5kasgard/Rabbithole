"""Root-of-trust and integrity registry for executable components.

Registration attests identity, bytes, version and admitted scope.  It does not
prove semantic correctness; that still requires calibration, independent tests,
and claim-specific verification contracts.
"""
from __future__ import annotations

import hashlib
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, Mapping, Sequence, Tuple


def _id() -> str:
    return f"CMP{uuid.uuid4().hex[:12]}"


@dataclass
class ComponentAttestation:
    name: str
    component_kind: str
    version: str
    implementation_digest: str
    admitted_operations: Tuple[str, ...]
    scope: Mapping[str, object] = field(default_factory=dict)
    dependencies: Tuple[str, ...] = ()
    source: str = ""
    status: str = "admitted"  # admitted|quarantined|revoked
    evidence_ids: Tuple[str, ...] = ()
    created_at: float = field(default_factory=time.time)
    component_id: str = field(default_factory=_id)

    def validate(self) -> None:
        if self.status not in {"admitted", "quarantined", "revoked"}:
            raise ValueError(self.status)
        if not self.name or not self.component_kind or not self.version:
            raise ValueError("component identity is incomplete")
        if len(self.implementation_digest) != 64:
            raise ValueError("implementation digest must be SHA-256")
        if not self.admitted_operations:
            raise ValueError("at least one admitted operation is required")


class ComponentRegistry:
    def __init__(self):
        self.components: Dict[str, ComponentAttestation] = {}

    @staticmethod
    def digest_path(path: str | Path) -> str:
        p = Path(path)
        if p.is_file():
            return hashlib.sha256(p.read_bytes()).hexdigest()
        if p.is_dir():
            h = hashlib.sha256()
            for f in sorted(x for x in p.rglob("*") if x.is_file()):
                h.update(str(f.relative_to(p)).encode())
                h.update(hashlib.sha256(f.read_bytes()).digest())
            return h.hexdigest()
        raise FileNotFoundError(path)

    def attest_path(self, name: str, component_kind: str, version: str,
                    path: str | Path, admitted_operations: Sequence[str], *,
                    scope: Mapping[str, object] | None = None,
                    dependencies: Sequence[str] = (), evidence_ids: Sequence[str] = ()) -> ComponentAttestation:
        att = ComponentAttestation(
            name=name, component_kind=component_kind, version=version,
            implementation_digest=self.digest_path(path),
            admitted_operations=tuple(admitted_operations), scope=dict(scope or {}),
            dependencies=tuple(dependencies), source=str(Path(path).resolve()),
            evidence_ids=tuple(evidence_ids),
        )
        self.register(att)
        return att

    def register(self, attestation: ComponentAttestation) -> str:
        attestation.validate()
        if attestation.component_id in self.components:
            raise ValueError("component id already registered")
        self.components[attestation.component_id] = attestation
        return attestation.component_id

    def admit(self, component_id: str, operation: str) -> Tuple[bool, str]:
        if component_id not in self.components:
            return False, "component is not attested"
        c = self.components[component_id]
        if c.status != "admitted":
            return False, f"component status is {c.status}"
        if operation not in c.admitted_operations:
            return False, "operation is outside attested scope"
        if c.source:
            try:
                current = self.digest_path(c.source)
            except OSError as exc:
                return False, f"component source cannot be read: {exc}"
            if current != c.implementation_digest:
                return False, "component bytes changed since attestation"
        for dep in c.dependencies:
            if dep not in self.components or self.components[dep].status != "admitted":
                return False, f"dependency {dep!r} is not admitted"
        return True, "admitted"

    def set_status(self, component_id: str, status: str) -> None:
        if status not in {"admitted", "quarantined", "revoked"}:
            raise ValueError(status)
        self.components[component_id].status = status

    def verify(self) -> dict:
        failures = {}
        for cid, c in self.components.items():
            for op in c.admitted_operations:
                ok, reason = self.admit(cid, op)
                if not ok and c.status == "admitted":
                    failures.setdefault(cid, []).append(reason)
        return {"valid": not failures, "components": len(self.components), "failures": failures}

    def to_dict(self) -> dict:
        return {"components": [asdict(x) for x in self.components.values()]}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "ComponentRegistry":
        obj = cls()
        for row in raw.get("components", []):
            d = dict(row)
            for key in ("admitted_operations", "dependencies", "evidence_ids"):
                d[key] = tuple(d.get(key, ()))
            c = ComponentAttestation(**d)
            obj.components[c.component_id] = c
        return obj
