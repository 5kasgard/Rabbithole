"""Empirical heterogeneous mechanism portfolio.

Static substrate rules are hypotheses.  This router records actual performance by
problem features and selects only among mechanisms whose contracts satisfy the
task.  It preserves hard soundness/authority requirements before optimizing
success probability, latency and fuel.
"""
from __future__ import annotations

import math
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Optional, Sequence, Tuple

from .wal import EventLog


@dataclass
class TaskShape:
    task_class: str
    features: Mapping[str, float]
    required_properties: Tuple[str, ...] = ()
    max_authority: float = 0.0
    cost_weights: Mapping[str, float] = field(default_factory=lambda: {"latency": 1.0, "fuel": 1.0})
    tid: str = field(default_factory=lambda: f"TSK{uuid.uuid4().hex[:12]}")


@dataclass
class MechanismProfile:
    mechanism_id: str
    task_classes: Tuple[str, ...]
    properties: Tuple[str, ...]
    substrate: str
    authority_ceiling: float
    sound: bool
    feature_limits: Mapping[str, Tuple[float, float]] = field(default_factory=dict)
    prior_success: float = 0.5
    prior_latency_ms: float = 1000.0
    prior_fuel: float = 1.0
    enabled: bool = True
    prior_resources: Mapping[str, float] = field(default_factory=dict)

    def compatible(self, task: TaskShape) -> Tuple[bool, str]:
        if not self.enabled:
            return False, "disabled"
        if task.task_class not in self.task_classes:
            return False, "unsupported task class"
        missing = set(task.required_properties) - set(self.properties)
        if missing:
            return False, f"missing properties: {', '.join(sorted(missing))}"
        if task.max_authority > self.authority_ceiling:
            return False, "authority ceiling too low"
        for key, value in task.features.items():
            if key in self.feature_limits:
                lo, hi = self.feature_limits[key]
                if not lo <= value <= hi:
                    return False, f"feature {key} outside supported range"
        return True, "compatible"


@dataclass
class PerformanceRecord:
    mechanism_id: str
    task_class: str
    features: Mapping[str, float]
    success: bool
    latency_ms: float
    fuel: float
    correctness_contact: str
    failure_type: str = ""
    created_at: float = field(default_factory=time.time)
    rid: str = field(default_factory=lambda: f"PER{uuid.uuid4().hex[:12]}")
    resource_values: Mapping[str, float] = field(default_factory=dict)


@dataclass
class Selection:
    mechanism_id: str
    substrate: str
    predicted_success: float
    predicted_latency_ms: float
    predicted_fuel: float
    score: float
    reason: str
    predicted_resources: Mapping[str, float] = field(default_factory=dict)


class MechanismPortfolio:
    def __init__(self):
        self.profiles: Dict[str, MechanismProfile] = {}
        self.records: Dict[str, PerformanceRecord] = {}
        self.audit = EventLog()

    def register(self, profile: MechanismProfile) -> None:
        if profile.mechanism_id in self.profiles:
            raise ValueError(f"mechanism {profile.mechanism_id!r} already registered")
        if not 0 <= profile.prior_success <= 1 or not 0 <= profile.authority_ceiling <= 1:
            raise ValueError("probabilities and authority ceilings must be in [0,1]")
        self.profiles[profile.mechanism_id] = profile
        self.audit.append("portfolio_mechanism_registered", asdict(profile))

    def record(self, record: PerformanceRecord) -> None:
        if record.mechanism_id not in self.profiles:
            raise KeyError(record.mechanism_id)
        if record.latency_ms < 0 or record.fuel < 0 or any(float(v) < 0 for v in record.resource_values.values()):
            raise ValueError("performance costs cannot be negative")
        self.records[record.rid] = record
        self.audit.append("portfolio_performance_recorded", asdict(record))

    @staticmethod
    def _distance(a: Mapping[str, float], b: Mapping[str, float]) -> float:
        keys = set(a) | set(b)
        if not keys:
            return 0.0
        return math.sqrt(sum((float(a.get(k, 0)) - float(b.get(k, 0))) ** 2 for k in keys))

    def predict(self, mechanism_id: str, task: TaskShape) -> Tuple[float, float, float, int]:
        p = self.profiles[mechanism_id]
        records = [r for r in self.records.values()
                   if r.mechanism_id == mechanism_id and r.task_class == task.task_class]
        if not records:
            return p.prior_success, p.prior_latency_ms, p.prior_fuel, 0
        weighted = []
        for r in records:
            weight = 1.0 / (1.0 + self._distance(task.features, r.features))
            weighted.append((weight, r))
        # Beta(2p,2(1-p)) prior prevents one lucky run from dominating.
        alpha = 2 * p.prior_success + sum(w for w, r in weighted if r.success)
        beta = 2 * (1 - p.prior_success) + sum(w for w, r in weighted if not r.success)
        success = alpha / (alpha + beta)
        total = sum(w for w, _ in weighted)
        latency = ((p.prior_latency_ms + sum(w * r.latency_ms for w, r in weighted)) /
                   (1 + total))
        fuel = ((p.prior_fuel + sum(w * r.fuel for w, r in weighted)) /
                (1 + total))
        return success, latency, fuel, len(records)

    def predict_resources(self, mechanism_id: str, task: TaskShape) -> Mapping[str, float]:
        """Predict non-latency/fuel resource dimensions without collapsing them.

        Values are locally weighted in the same feature space as success and
        cost predictions.  Missing dimensions remain missing; selection applies
        an explicit unknown penalty only when the task declares that dimension
        decision-relevant.
        """
        profile = self.profiles[mechanism_id]
        records = [r for r in self.records.values()
                   if r.mechanism_id == mechanism_id and r.task_class == task.task_class]
        keys = set(profile.prior_resources)
        for record in records:
            keys.update(record.resource_values)
        result = {}
        for key in sorted(keys):
            prior = profile.prior_resources.get(key)
            weighted = []
            for record in records:
                if key in record.resource_values:
                    weight = 1.0 / (1.0 + self._distance(task.features, record.features))
                    weighted.append((weight, float(record.resource_values[key])))
            if prior is None and not weighted:
                continue
            numerator = (float(prior) if prior is not None else 0.0) + sum(w*v for w,v in weighted)
            denominator = (1.0 if prior is not None else 0.0) + sum(w for w,_ in weighted)
            result[key] = numerator / max(denominator, 1e-12)
        return result

    def select(self, task: TaskShape) -> Selection:
        candidates = []
        rejected = {}
        for mid, profile in self.profiles.items():
            ok, reason = profile.compatible(task)
            if not ok:
                rejected[mid] = reason
                continue
            success, latency, fuel, n = self.predict(mid, task)
            lw = float(task.cost_weights.get("latency", 1.0))
            fw = float(task.cost_weights.get("fuel", 1.0))
            resources = dict(self.predict_resources(mid, task))
            cost = lw * latency / 1000.0 + fw * fuel
            unknown_penalty = float(task.cost_weights.get("_unknown_penalty", 1000.0))
            unknown = []
            for key, weight in task.cost_weights.items():
                if key in {"latency", "fuel", "_unknown_penalty"}:
                    continue
                if key not in resources:
                    cost += abs(float(weight)) * unknown_penalty
                    unknown.append(key)
                else:
                    cost += float(weight) * float(resources[key])
            score = success / (cost + 1e-9)
            reason = f"compatible; {n} empirical records"
            if unknown:
                reason += f"; unknown resource dimensions penalized: {', '.join(sorted(unknown))}"
            candidates.append(Selection(mid, profile.substrate, success, latency, fuel,
                                        score, reason, resources))
        if not candidates:
            self.audit.append("portfolio_refused", {"task": asdict(task), "rejected": rejected})
            raise LookupError(f"no compatible mechanism: {rejected}")
        candidates.sort(key=lambda x: (-x.score, -x.predicted_success, x.mechanism_id))
        selected = candidates[0]
        self.audit.append("portfolio_selected", {"task": asdict(task),
                                                  "selection": asdict(selected),
                                                  "alternatives": [asdict(x) for x in candidates[1:]],
                                                  "rejected": rejected})
        return selected

    def ablation_report(self, task: TaskShape) -> dict:
        baseline = self.select(task)
        effects = []
        for mid, profile in self.profiles.items():
            old = profile.enabled
            profile.enabled = False
            try:
                alt = self.select(task)
                effects.append({"removed": mid, "replacement": alt.mechanism_id,
                                "score_delta": alt.score - baseline.score})
            except LookupError:
                effects.append({"removed": mid, "replacement": None,
                                "capability_lost": mid == baseline.mechanism_id})
            finally:
                profile.enabled = old
        return {"baseline": asdict(baseline), "ablations": effects}

    def to_dict(self) -> dict:
        return {"profiles": [asdict(x) for x in self.profiles.values()],
                "records": [asdict(x) for x in self.records.values()],
                "audit": self.audit.to_dict()}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "MechanismPortfolio":
        p = cls()
        p.profiles = {}
        for x in raw.get("profiles", []):
            d = dict(x)
            for key in ("task_classes", "properties"):
                d[key] = tuple(d.get(key, ()))
            d["feature_limits"] = {k: tuple(v) for k, v in d.get("feature_limits", {}).items()}
            p.profiles[d["mechanism_id"]] = MechanismProfile(**d)
        p.records = {x["rid"]: PerformanceRecord(**x) for x in raw.get("records", [])}
        p.audit = EventLog.from_dict(raw.get("audit", {}))
        return p
