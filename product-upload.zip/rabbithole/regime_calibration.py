"""Regime-aware, forward-time calibration and abstention policies."""
from __future__ import annotations
import math,time,uuid
from dataclasses import asdict,dataclass,field
from typing import Dict,Mapping,Optional,Sequence,Tuple
from .wal import EventLog

def _id(p):return f"{p}{uuid.uuid4().hex[:12]}"
@dataclass(frozen=True)
class CalibrationRegime:
    regime_id:str
    task_family:str
    conditions:Mapping[str,object]
    minimum_outcomes:int=20
    maximum_brier:float=0.25
    maximum_gap:float=0.15
    abstain_below:float=0.5
@dataclass
class ForecastOutcome:
    actor:str;regime_id:str;predicted:float;outcome:Optional[float]
    prediction_time:float;outcome_time:float=0.;independence_group:str="";external:bool=False
    context:Mapping[str,object]=field(default_factory=dict);event_id:str=field(default_factory=lambda:_id("FCO"))
class RegimeCalibration:
    def __init__(self):self.regimes:Dict[str,CalibrationRegime]={};self.events:Dict[str,ForecastOutcome]={};self.audit=EventLog()
    def register(self,r:CalibrationRegime):self.regimes[r.regime_id]=r;self.audit.append("calibration_regime_registered",asdict(r))
    def record_prediction(self,e:ForecastOutcome):
        if e.regime_id not in self.regimes:raise KeyError(e.regime_id)
        if not 0<=e.predicted<=1 or (e.outcome is not None and not 0<=e.outcome<=1):raise ValueError("probabilities/outcomes in [0,1]")
        if e.outcome is not None and e.outcome_time<=e.prediction_time:raise ValueError("outcome must occur after prediction")
        self.events[e.event_id]=e;self.audit.append("forecast_outcome_recorded",asdict(e));return e.event_id
    def attach_outcome(self,event_id:str,outcome:float,outcome_time:float,*,external:bool,independence_group:str=""):
        e=self.events[event_id]
        if outcome_time<=e.prediction_time:raise ValueError("forward-time outcome required")
        e.outcome=float(outcome);e.outcome_time=float(outcome_time);e.external=bool(external);e.independence_group=independence_group or e.independence_group
        self.audit.append("future_outcome_attached",asdict(e))
    def report(self,actor:str,regime_id:str)->dict:
        r=self.regimes[regime_id];xs=[x for x in self.events.values() if x.actor==actor and x.regime_id==regime_id and x.outcome is not None]
        ext=[x for x in xs if x.external];groups=len({x.independence_group or x.event_id for x in ext})
        if not xs:return {"state":"no_outcomes","n":0,"external_n":0,"authority_cap":0.0}
        brier=sum((x.predicted-float(x.outcome))**2 for x in xs)/len(xs);mp=sum(x.predicted for x in xs)/len(xs);rate=sum(float(x.outcome) for x in xs)/len(xs);gap=abs(mp-rate)
        enough=len(ext)>=r.minimum_outcomes and groups>=max(3,min(r.minimum_outcomes,10))
        passed=enough and brier<=r.maximum_brier and gap<=r.maximum_gap
        return {"state":"externally_calibrated" if passed else ("internally_observed" if xs else "no_outcomes"),"n":len(xs),"external_n":len(ext),"independent_groups":groups,"brier":brier,"gap":gap,"mean_prediction":mp,"empirical_rate":rate,"authority_cap":max(0.,1-max(brier,gap)) if passed else 0.0,"scope":dict(r.conditions)}
    def decision(self,actor:str,regime_id:str,prediction:float)->dict:
        rep=self.report(actor,regime_id);r=self.regimes[regime_id]
        if rep.get("authority_cap",0)<=0:return {"action":"abstain","reason":"regime not externally calibrated","report":rep}
        if prediction<r.abstain_below:return {"action":"abstain","reason":"prediction below declared threshold","report":rep}
        return {"action":"proceed_with_scope","authority_cap":min(prediction,rep["authority_cap"]),"report":rep}
    def to_dict(self):return {"regimes":[asdict(x) for x in self.regimes.values()],"events":[asdict(x) for x in self.events.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw):
        o=cls()
        for r in raw.get("regimes",[]):x=CalibrationRegime(**dict(r));o.regimes[x.regime_id]=x
        for r in raw.get("events",[]):x=ForecastOutcome(**dict(r));o.events[x.event_id]=x
        o.audit=EventLog.from_dict(raw.get("audit",{}));return o
