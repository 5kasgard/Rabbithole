"""Capability-scoped bidirectional transport registry using FIP envelopes.

Recovered from the early transport boundary, updated so transport validity never
creates semantic authority. The registry supports in-process reference transport
and bounded file-drop interchange; network transports remain adapters.
"""
from __future__ import annotations

import json
import queue
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping

from .interchange import canonical_bytes, parse_json, validate_shape


@dataclass(frozen=True)
class TransportCapability:
    capability_id: str
    actor: str
    allowed_kinds: tuple[str, ...]
    scope: Mapping[str, str] = field(default_factory=dict)
    expires_at: float | None = None

    def permits(self, envelope: Mapping[str, Any]) -> bool:
        if self.expires_at is not None and time.time() >= self.expires_at:
            return False
        if str(envelope.get("object_type", "")) not in self.allowed_kinds:
            return False
        scope = envelope.get("payload", {}).get("scope", {}) if isinstance(envelope.get("payload"), Mapping) else {}
        return all(str(scope.get(k, "")) == str(v) for k, v in self.scope.items())


@dataclass(frozen=True)
class TransportReceipt:
    transport_id: str
    direction: str
    envelope_id: str
    accepted: bool
    reason: str
    recorded_at: float = field(default_factory=time.time)
    semantic_authority_granted: bool = False


class InProcessFIPTransport:
    def __init__(self, transport_id: str = "in-process"):
        self.transport_id = transport_id
        self._inbound: queue.Queue[dict[str, Any]] = queue.Queue()
        self._subscribers: list[Callable[[Mapping[str, Any]], None]] = []
        self._lock = threading.Lock()
        self.receipts: list[TransportReceipt] = []

    def submit(self, envelope: Mapping[str, Any], capability: TransportCapability) -> TransportReceipt:
        accepted = capability.permits(envelope)
        receipt = TransportReceipt(self.transport_id, "inbound", str(envelope.get("identity", "")), accepted,
                                   "capability accepted" if accepted else "capability denied")
        self.receipts.append(receipt)
        if accepted:
            self._inbound.put(envelope)
        return receipt

    def poll(self, timeout: float | None = None) -> dict[str, Any] | None:
        try:
            return self._inbound.get(timeout=timeout)
        except queue.Empty:
            return None

    def push(self, envelope: Mapping[str, Any], capability: TransportCapability) -> TransportReceipt:
        accepted = capability.permits(envelope)
        receipt = TransportReceipt(self.transport_id, "outbound", str(envelope.get("identity", "")), accepted,
                                   "capability accepted" if accepted else "capability denied")
        self.receipts.append(receipt)
        if accepted:
            with self._lock:
                subscribers = list(self._subscribers)
            for handler in subscribers:
                handler(envelope)
        return receipt

    def subscribe(self, handler: Callable[[Mapping[str, Any]], None]) -> None:
        with self._lock:
            self._subscribers.append(handler)


class FileDropFIPTransport:
    """Atomic file-drop adapter for offline and air-gapped interoperability."""
    def __init__(self, directory: str | Path, transport_id: str = "file-drop"):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.transport_id = transport_id

    def write(self, envelope: Mapping[str, Any], capability: TransportCapability) -> TransportReceipt:
        if not capability.permits(envelope):
            return TransportReceipt(self.transport_id, "outbound", str(envelope.get("identity", "")), False, "capability denied")
        validate_shape(envelope)
        data = canonical_bytes(envelope)
        path = self.directory / f"{str(envelope.get('identity', ''))}.fip.json"
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_bytes(data)
        tmp.replace(path)
        return TransportReceipt(self.transport_id, "outbound", str(envelope.get("identity", "")), True, str(path))

    def read(self, logical_id: str) -> dict[str, Any]:
        obj = parse_json((self.directory / f"{logical_id}.fip.json").read_text())
        validate_shape(obj)
        return dict(obj)
