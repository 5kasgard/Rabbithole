"""Bounded perpetual outward-loop profile.

The loop is deliberately smaller than the vision.  It makes the operational
invariant executable: acquire -> test -> reversible action -> monitor -> replan
or abstain under a frozen objective and resource budget.  It does not claim
perpetual external utility until elapsed-time and independent-evaluator gates
are satisfied.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol

from .waist import ContractStore
from .wal import EventLog


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp-{uuid.uuid4().hex[:8]}")
    with tmp.open("wb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    tmp.replace(path)


@dataclass(frozen=True)
class ExternalObjective:
    objective_id: str
    statement: str
    success_conditions: tuple[str, ...]
    allowed_actions: tuple[str, ...]
    resource_budget: Mapping[str, float]
    actor: str
    risk_tier: str = "low"
    reversible_only: bool = True
    expires_at: float | None = None
    created_at: float = field(default_factory=time.time)

    def validate(self) -> None:
        if not self.objective_id or not self.statement or not self.actor:
            raise ValueError("objective identity, statement and actor are required")
        if not self.success_conditions:
            raise ValueError("at least one success condition is required")
        if self.risk_tier not in {"low", "moderate", "high", "critical"}:
            raise ValueError("unsupported risk tier")
        if self.risk_tier in {"high", "critical"} and not self.reversible_only:
            raise ValueError("master-candidate loop forbids irreversible high-risk actions")
        if self.expires_at is not None and self.expires_at <= self.created_at:
            raise ValueError("objective expiry must follow creation")
        for name, value in self.resource_budget.items():
            if float(value) < 0:
                raise ValueError(f"negative resource budget: {name}")


@dataclass(frozen=True)
class AcquisitionResult:
    ok: bool
    payload: Mapping[str, Any]
    source_id: str
    content_sha256: str
    error: str = ""
    resource: Mapping[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class VerificationResult:
    state: str  # supported | falsified | inconclusive | blocked
    observed: Mapping[str, Any]
    reason: str
    authority_ceiling: float = 0.0
    resource: Mapping[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class ActionResult:
    state: str  # executed | abstained | failed
    receipt: Mapping[str, Any]
    reversible: bool
    reason: str
    resource: Mapping[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class MonitorResult:
    state: str  # confirmed | contradicted | unavailable
    observed: Mapping[str, Any]
    reason: str
    resource: Mapping[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class ReplanResult:
    next_state: str  # continue | stop | abstain | human_required
    reason: str
    changes: Mapping[str, Any] = field(default_factory=dict)


class AcquireAdapter(Protocol):
    def __call__(self, objective: ExternalObjective, cycle: int) -> AcquisitionResult: ...


class VerifyAdapter(Protocol):
    def __call__(
        self, objective: ExternalObjective, acquisition: AcquisitionResult, cycle: int
    ) -> VerificationResult: ...


class ActionAdapter(Protocol):
    def __call__(
        self,
        objective: ExternalObjective,
        verification: VerificationResult,
        cycle: int,
    ) -> ActionResult: ...


class MonitorAdapter(Protocol):
    def __call__(
        self,
        objective: ExternalObjective,
        action: ActionResult,
        cycle: int,
    ) -> MonitorResult: ...


class ReplanAdapter(Protocol):
    def __call__(
        self,
        objective: ExternalObjective,
        acquisition: AcquisitionResult,
        verification: VerificationResult,
        action: ActionResult,
        monitor: MonitorResult,
        cycle: int,
    ) -> ReplanResult: ...


@dataclass(frozen=True)
class LoopCycleReceipt:
    cycle: int
    started_at: float
    completed_at: float
    acquisition: AcquisitionResult
    verification: VerificationResult
    action: ActionResult
    monitor: MonitorResult
    replan: ReplanResult
    status: str
    resource_used: Mapping[str, float]
    observation_id: str = ""
    result_id: str = ""


class OutwardLoopEngine:
    """One objective-scoped loop with exact audit, resource and abstention rules."""

    def __init__(
        self,
        state_dir: str | Path,
        objective: ExternalObjective,
        *,
        acquire: AcquireAdapter,
        verify: VerifyAdapter,
        act: ActionAdapter,
        monitor: MonitorAdapter,
        replan: ReplanAdapter,
    ):
        objective.validate()
        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.objective = objective
        self.acquire_adapter = acquire
        self.verify_adapter = verify
        self.action_adapter = act
        self.monitor_adapter = monitor
        self.replan_adapter = replan
        self.contracts = ContractStore()
        self.audit = EventLog()
        self.cycles: list[LoopCycleReceipt] = []
        self.resource_used: dict[str, float] = {}
        self.created_at = time.time()
        self.stopped = False
        self.stop_reason = ""
        self.audit.append("outward_loop_initialized", {
            "objective": asdict(objective),
            "external_claims_closed": False,
        })

    def _budget_allows(self, incremental: Mapping[str, float]) -> tuple[bool, str]:
        for key, value in incremental.items():
            total = self.resource_used.get(key, 0.0) + float(value)
            limit = self.objective.resource_budget.get(key)
            if limit is not None and total > float(limit):
                return False, f"resource budget exceeded: {key}"
        return True, "within budget"

    @staticmethod
    def _combine_resources(*rows: Mapping[str, float]) -> dict[str, float]:
        out: dict[str, float] = {}
        for row in rows:
            for key, value in row.items():
                out[key] = out.get(key, 0.0) + float(value)
        return out

    def step(self) -> LoopCycleReceipt:
        if self.stopped:
            raise RuntimeError(f"loop stopped: {self.stop_reason}")
        if self.objective.expires_at is not None and time.time() >= self.objective.expires_at:
            self.stopped = True
            self.stop_reason = "objective expired"
            raise RuntimeError(self.stop_reason)

        cycle = len(self.cycles)
        started = time.time()
        acquisition = self.acquire_adapter(self.objective, cycle)
        if not acquisition.ok:
            verification = VerificationResult("blocked", {}, acquisition.error or "acquisition failed")
            action = ActionResult("abstained", {}, True, "no action without acquisition")
            monitor = MonitorResult("unavailable", {}, "no action to monitor")
            replan = ReplanResult("continue", "retry or change source through explicit adapter policy")
        else:
            verification = self.verify_adapter(self.objective, acquisition, cycle)
            if verification.state != "supported":
                action = ActionResult("abstained", {}, True, "verification did not support action")
                monitor = MonitorResult("unavailable", {}, "no action to monitor")
            else:
                action = self.action_adapter(self.objective, verification, cycle)
                if self.objective.reversible_only and not action.reversible:
                    action = ActionResult(
                        "abstained", dict(action.receipt), False,
                        "objective permits reversible actions only", action.resource,
                    )
                monitor = self.monitor_adapter(self.objective, action, cycle)
            replan = self.replan_adapter(
                self.objective, acquisition, verification, action, monitor, cycle
            )

        resource = self._combine_resources(
            acquisition.resource,
            verification.resource,
            action.resource,
            monitor.resource,
        )
        budget_ok, budget_reason = self._budget_allows(resource)
        if not budget_ok:
            action = ActionResult("abstained", dict(action.receipt), action.reversible, budget_reason)
            replan = ReplanResult("stop", budget_reason)

        observation = self.contracts.append(
            "observation",
            {
                "cycle": cycle,
                "source_id": acquisition.source_id,
                "content_sha256": acquisition.content_sha256,
                "payload": dict(acquisition.payload),
                "acquisition_ok": acquisition.ok,
            },
            scope={"objective_id": self.objective.objective_id},
            representation="application/json",
            status="proposed",
            authority_ceiling=0.0,
            resource=acquisition.resource,
        )
        result_status = {
            "supported": "supported",
            "falsified": "falsified",
            "inconclusive": "inconclusive",
            "blocked": "untestable",
        }[verification.state]
        result = self.contracts.append(
            "result",
            {
                "cycle": cycle,
                "verification": asdict(verification),
                "action": asdict(action),
                "monitor": asdict(monitor),
                "replan": asdict(replan),
                "external_utility_established": False,
            },
            scope={"objective_id": self.objective.objective_id},
            dependency_ids=(observation.logical_id,),
            verification_contract="outward-loop-profile-v1",
            status=result_status,
            authority_ceiling=max(0.0, min(1.0, verification.authority_ceiling)),
            resource=resource,
        )

        for key, value in resource.items():
            self.resource_used[key] = self.resource_used.get(key, 0.0) + float(value)
        status = "completed" if (
            verification.state == "supported"
            and action.state == "executed"
            and monitor.state == "confirmed"
        ) else "abstained"
        receipt = LoopCycleReceipt(
            cycle=cycle,
            started_at=started,
            completed_at=time.time(),
            acquisition=acquisition,
            verification=verification,
            action=action,
            monitor=monitor,
            replan=replan,
            status=status,
            resource_used=resource,
            observation_id=observation.logical_id,
            result_id=result.logical_id,
        )
        self.cycles.append(receipt)
        self.audit.append("outward_loop_cycle", asdict(receipt))
        if replan.next_state in {"stop", "human_required"}:
            self.stopped = True
            self.stop_reason = replan.reason
        self.save()
        return receipt

    def run(self, *, max_cycles: int, max_seconds: float | None = None) -> list[LoopCycleReceipt]:
        if max_cycles < 1:
            raise ValueError("max_cycles must be positive")
        deadline = time.time() + max_seconds if max_seconds is not None else None
        out: list[LoopCycleReceipt] = []
        while len(out) < max_cycles and not self.stopped:
            if deadline is not None and time.time() >= deadline:
                self.stopped = True
                self.stop_reason = "run duration bound reached"
                break
            out.append(self.step())
        self.save()
        return out

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "field.outward-loop-state/1",
            "objective": asdict(self.objective),
            "created_at": self.created_at,
            "cycles": [asdict(row) for row in self.cycles],
            "resource_used": self.resource_used,
            "stopped": self.stopped,
            "stop_reason": self.stop_reason,
            "contracts": self.contracts.to_dict(),
            "audit": self.audit.to_dict(),
            "external_claims": {
                "72_hour_live_loop": "blocked_not_elapsed",
                "14_day_continuation": "blocked_not_elapsed",
                "independent_utility": "blocked_no_independent_evaluator",
                "longitudinal_safety": "blocked_no_external_study",
            },
        }

    def save(self) -> None:
        data = (json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":")) + "\n").encode()
        _atomic_write(self.state_dir / "outward_loop_state.json", data)
        _atomic_write(self.state_dir / "outward_loop_state.sha256", (_sha256_bytes(data) + "\n").encode())

    @classmethod
    def load(
        cls,
        state_dir: str | Path,
        *,
        acquire: AcquireAdapter,
        verify: VerifyAdapter,
        act: ActionAdapter,
        monitor: MonitorAdapter,
        replan: ReplanAdapter,
    ) -> "OutwardLoopEngine":
        state_dir = Path(state_dir)
        state_path = state_dir / "outward_loop_state.json"
        digest_path = state_dir / "outward_loop_state.sha256"
        data = state_path.read_bytes()
        if _sha256_bytes(data) != digest_path.read_text().strip():
            raise ValueError("outward-loop state digest mismatch")
        raw = json.loads(data)
        objective_raw = dict(raw["objective"])
        objective_raw["success_conditions"] = tuple(objective_raw.get("success_conditions", ()))
        objective_raw["allowed_actions"] = tuple(objective_raw.get("allowed_actions", ()))
        objective = ExternalObjective(**objective_raw)
        engine = cls.__new__(cls)
        engine.state_dir = state_dir
        engine.objective = objective
        engine.acquire_adapter = acquire
        engine.verify_adapter = verify
        engine.action_adapter = act
        engine.monitor_adapter = monitor
        engine.replan_adapter = replan
        engine.contracts = ContractStore.from_dict(raw.get("contracts", {}))
        engine.audit = EventLog.from_dict(raw.get("audit", {}))
        engine.cycles = []
        for row in raw.get("cycles", []):
            engine.cycles.append(LoopCycleReceipt(
                cycle=int(row["cycle"]),
                started_at=float(row["started_at"]),
                completed_at=float(row["completed_at"]),
                acquisition=AcquisitionResult(**dict(row["acquisition"])),
                verification=VerificationResult(**dict(row["verification"])),
                action=ActionResult(**dict(row["action"])),
                monitor=MonitorResult(**dict(row["monitor"])),
                replan=ReplanResult(**dict(row["replan"])),
                status=str(row["status"]),
                resource_used=dict(row.get("resource_used", {})),
                observation_id=str(row.get("observation_id", "")),
                result_id=str(row.get("result_id", "")),
            ))
        engine.resource_used = {str(k): float(v) for k, v in raw.get("resource_used", {}).items()}
        engine.created_at = float(raw.get("created_at", time.time()))
        engine.stopped = bool(raw.get("stopped", False))
        engine.stop_reason = str(raw.get("stop_reason", ""))
        return engine

    def verify_integrity(self) -> dict[str, Any]:
        errors: list[str] = []
        state_path = self.state_dir / "outward_loop_state.json"
        digest_path = self.state_dir / "outward_loop_state.sha256"
        if state_path.exists() != digest_path.exists():
            errors.append("state and digest presence mismatch")
        if state_path.exists():
            data = state_path.read_bytes()
            if _sha256_bytes(data) != digest_path.read_text().strip():
                errors.append("state digest mismatch")
        for name, result in {
            "contracts": self.contracts.verify(),
            "audit": self.audit.verify(),
        }.items():
            if not result.get("valid"):
                errors.append(f"{name} integrity invalid: {result}")
        if any(row.action.state == "executed" and not row.action.reversible for row in self.cycles):
            errors.append("irreversible executed action in reversible-only profile")
        return {
            "valid": not errors,
            "cycles": len(self.cycles),
            "completed": sum(row.status == "completed" for row in self.cycles),
            "abstained": sum(row.status == "abstained" for row in self.cycles),
            "resource_used": dict(self.resource_used),
            "external_claims_closed": False,
            "errors": errors,
        }


class FileIntegrityProfile:
    """Concrete reversible profile for a local file and status output.

    This profile is intentionally small enough to be audited and deployed.  It
    is useful for release manifests, sensor-export files, downloaded artifacts,
    or any other source where an expected digest is an appropriate contact.
    """

    def __init__(self, source: str | Path, expected_sha256: str, output: str | Path):
        self.source = Path(source)
        self.expected_sha256 = expected_sha256.lower()
        self.output = Path(output)
        self._prior: bytes | None = None

    def acquire(self, _objective: ExternalObjective, _cycle: int) -> AcquisitionResult:
        started = time.perf_counter()
        try:
            data = self.source.read_bytes()
        except Exception as exc:
            return AcquisitionResult(False, {}, str(self.source), "", str(exc), {"wall_seconds": time.perf_counter() - started, "io_bytes": 0})
        digest = _sha256_bytes(data)
        return AcquisitionResult(
            True,
            {"path": str(self.source), "bytes": len(data), "observed_sha256": digest},
            str(self.source),
            digest,
            resource={"wall_seconds": time.perf_counter() - started, "io_bytes": float(len(data))},
        )

    def verify(self, _objective: ExternalObjective, acquisition: AcquisitionResult, _cycle: int) -> VerificationResult:
        supported = acquisition.content_sha256 == self.expected_sha256
        return VerificationResult(
            "supported" if supported else "falsified",
            {"expected_sha256": self.expected_sha256, "observed_sha256": acquisition.content_sha256},
            "exact digest match" if supported else "digest mismatch",
            authority_ceiling=0.75 if supported else 0.0,
        )

    def act(self, objective: ExternalObjective, verification: VerificationResult, cycle: int) -> ActionResult:
        if "write-status" not in objective.allowed_actions:
            return ActionResult("abstained", {}, True, "action not allowed by objective")
        if verification.state != "supported":
            return ActionResult("abstained", {}, True, "verification did not support action")
        payload = {
            "objective_id": objective.objective_id,
            "cycle": cycle,
            "verified": True,
            "source": str(self.source),
            "sha256": self.expected_sha256,
            "written_at": time.time(),
        }
        self._prior = self.output.read_bytes() if self.output.exists() else None
        data = (json.dumps(payload, sort_keys=True) + "\n").encode()
        _atomic_write(self.output, data)
        return ActionResult(
            "executed",
            {"path": str(self.output), "payload": payload, "prior_present": self._prior is not None},
            True,
            "atomic reversible status write",
            {"io_bytes": float(len(data))},
        )

    def monitor(self, _objective: ExternalObjective, action: ActionResult, _cycle: int) -> MonitorResult:
        if action.state != "executed":
            return MonitorResult("unavailable", {}, "no executed action")
        try:
            observed = json.loads(self.output.read_text())
        except Exception as exc:
            return MonitorResult("contradicted", {}, f"monitor failed: {exc}")
        expected = action.receipt.get("payload")
        return MonitorResult(
            "confirmed" if observed == expected else "contradicted",
            observed,
            "output matches action receipt" if observed == expected else "output diverged",
        )

    @staticmethod
    def replan(
        _objective: ExternalObjective,
        _acquisition: AcquisitionResult,
        verification: VerificationResult,
        action: ActionResult,
        monitor: MonitorResult,
        _cycle: int,
    ) -> ReplanResult:
        if verification.state == "falsified":
            return ReplanResult("human_required", "source digest changed; human review required")
        if action.state == "executed" and monitor.state == "confirmed":
            return ReplanResult("continue", "continue monitoring frozen objective")
        return ReplanResult("continue", "explicit abstention; retry within budget")


def file_integrity_engine(
    state_dir: str | Path,
    objective: ExternalObjective,
    *,
    source: str | Path,
    expected_sha256: str,
    output: str | Path,
) -> OutwardLoopEngine:
    profile = FileIntegrityProfile(source, expected_sha256, output)
    return OutwardLoopEngine(
        state_dir,
        objective,
        acquire=profile.acquire,
        verify=profile.verify,
        act=profile.act,
        monitor=profile.monitor,
        replan=profile.replan,
    )
