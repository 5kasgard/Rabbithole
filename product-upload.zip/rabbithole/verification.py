"""Heterogeneous verification contracts for claims.

There is no universal abstract truth wall.  Different claim classes admit
different contacts: proof checking, execution, model checking, statistical
analysis, causal identification, measurement, document inspection, or explicit
human normative judgment.  A contract states the admissible verifier and the
maximum authority its contact can earn.

Classifiers and LLMs may *propose* a contract.  Only a registered contract and
executor can record a verification result, and executor success is distinct from
support for the claim.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Callable, Dict, Mapping, Optional, Sequence, Tuple

from .capabilities import CapabilityIssuer
from .wal import EventLog
from .components import ComponentRegistry
from .calibration import CalibrationRegistry


VERIFICATION_STATES = {
    "consistent", "supported", "falsified", "undecidable", "untestable",
    "inconclusive", "execution_failed",
}


@dataclass(frozen=True)
class Claim:
    statement: str
    claim_class: str
    scope: Mapping[str, object] = field(default_factory=dict)
    source_ids: Tuple[str, ...] = ()
    proposed_contract: str = ""
    cid: str = field(default_factory=lambda: f"CLM{uuid.uuid4().hex[:12]}")


@dataclass
class VerificationContract:
    contract_id: str
    claim_class: str
    description: str
    verifier_kinds: Tuple[str, ...]
    admissible_contacts: Tuple[str, ...]
    result_vocabulary: Tuple[str, ...] = tuple(sorted(VERIFICATION_STATES))
    minimum_quality: float = 0.0
    authority_ceiling: float = 0.0
    requires_independent_author: bool = True
    required_inputs: Tuple[str, ...] = ()
    required_outputs: Tuple[str, ...] = ()
    falsifier_form: str = ""
    scope_limits: Tuple[str, ...] = ()
    requires_attested_component: bool = False
    minimum_calibration_groups: int = 0

    def validate(self) -> None:
        if not self.contract_id or not self.claim_class:
            raise ValueError("contract id and claim class are required")
        if not self.verifier_kinds or not self.admissible_contacts:
            raise ValueError("contract needs verifier kinds and admissible contacts")
        if not (0.0 <= self.minimum_quality <= 1.0):
            raise ValueError("minimum quality must be in [0,1]")
        if not (0.0 <= self.authority_ceiling <= 1.0):
            raise ValueError("authority ceiling must be in [0,1]")
        if not set(self.result_vocabulary) <= VERIFICATION_STATES:
            raise ValueError("contract result vocabulary contains unknown states")
        if self.minimum_calibration_groups < 0:
            raise ValueError("minimum calibration groups cannot be negative")


@dataclass
class VerificationRequest:
    claim: Claim
    contract_id: str
    verifier_id: str
    inputs: Mapping[str, object]
    requested_by: str
    rid: str = field(default_factory=lambda: f"VRQ{uuid.uuid4().hex[:12]}")


@dataclass
class VerificationResult:
    request_id: str
    claim_id: str
    contract_id: str
    verifier_id: str
    state: str
    contact_type: str
    contact_quality: float
    earned_authority: float
    independent: bool
    observed: Mapping[str, object]
    artifacts: Tuple[str, ...]
    reason: str
    started_at: float
    ended_at: float
    result_id: str = field(default_factory=lambda: f"VRS{uuid.uuid4().hex[:12]}")
    configured_quality: float = 0.0
    calibration_state: str = "not_required"
    calibration_groups: int = 0
    component_status: str = "not_required"


Verifier = Callable[[Claim, Mapping[str, object]], Mapping[str, object]]


@dataclass
class RegisteredVerifier:
    verifier_id: str
    kind: str
    contact_type: str
    contact_quality: float
    author: str
    execute: Verifier
    resource: str = ""
    component_id: str = ""
    task_family: str = ""
    independence_group: str = ""


class VerificationRegistry:
    def __init__(self, capabilities: Optional[CapabilityIssuer] = None,
                 components: Optional[ComponentRegistry] = None,
                 calibration: Optional[CalibrationRegistry] = None):
        self.contracts: Dict[str, VerificationContract] = {}
        self.verifiers: Dict[str, RegisteredVerifier] = {}
        self.results: Dict[str, VerificationResult] = {}
        self.capabilities = capabilities or CapabilityIssuer()
        self.components = components or ComponentRegistry()
        self.calibration = calibration or CalibrationRegistry()
        self.audit = EventLog()

    def register_contract(self, contract: VerificationContract) -> None:
        contract.validate()
        if contract.contract_id in self.contracts:
            raise ValueError(f"contract {contract.contract_id!r} already exists")
        self.contracts[contract.contract_id] = contract
        self.audit.append("verification_contract_registered", asdict(contract))

    def register_verifier(self, verifier: RegisteredVerifier) -> None:
        if verifier.verifier_id in self.verifiers:
            raise ValueError(f"verifier {verifier.verifier_id!r} already exists")
        if not (0.0 <= verifier.contact_quality <= 1.0):
            raise ValueError("verifier contact quality must be in [0,1]")
        self.verifiers[verifier.verifier_id] = verifier
        self.audit.append("verifier_registered", {
            "verifier_id": verifier.verifier_id, "kind": verifier.kind,
            "contact_type": verifier.contact_type,
            "contact_quality": verifier.contact_quality,
            "author": verifier.author, "resource": verifier.resource,
            "component_id": verifier.component_id, "task_family": verifier.task_family,
            "independence_group": verifier.independence_group,
        })

    def compatible_contracts(self, claim_class: str) -> Tuple[str, ...]:
        return tuple(sorted(c.contract_id for c in self.contracts.values()
                            if c.claim_class == claim_class))

    def verify(self, request: VerificationRequest, *, capability: Optional[dict] = None) -> VerificationResult:
        if request.contract_id not in self.contracts:
            raise KeyError(f"unknown verification contract {request.contract_id!r}")
        if request.verifier_id not in self.verifiers:
            raise KeyError(f"unknown verifier {request.verifier_id!r}")
        contract = self.contracts[request.contract_id]
        verifier = self.verifiers[request.verifier_id]
        if request.claim.claim_class != contract.claim_class:
            raise ValueError("claim class does not match verification contract")
        if verifier.kind not in contract.verifier_kinds:
            raise ValueError("verifier kind is not admitted by contract")
        if verifier.contact_type not in contract.admissible_contacts:
            raise ValueError("contact type is not admitted by contract")
        missing = [x for x in contract.required_inputs if x not in request.inputs]
        if missing:
            raise ValueError(f"missing verification inputs: {', '.join(missing)}")
        resource = verifier.resource or f"verifier:{verifier.verifier_id}"
        if capability is not None and not self.capabilities.check(
                capability, "execute_verifier", resource, holder=request.requested_by):
            raise PermissionError("verification capability denied")
        component_status = "not_required"
        if contract.requires_attested_component or verifier.component_id:
            if not verifier.component_id:
                raise PermissionError("verification contract requires an attested component")
            admitted, component_status = self.components.admit(verifier.component_id, "verify")
            if not admitted:
                raise PermissionError(f"verifier component is not admitted: {component_status}")
        start = time.time()
        try:
            raw = dict(verifier.execute(request.claim, request.inputs))
        except Exception as exc:
            raw = {"state": "execution_failed", "reason": f"{type(exc).__name__}: {exc}"}
        end = time.time()
        state = str(raw.get("state", "inconclusive"))
        if state not in contract.result_vocabulary:
            state = "inconclusive"
            raw["reason"] = "verifier returned a state outside the contract vocabulary"
        observed = raw.get("observed", {})
        if not isinstance(observed, Mapping):
            observed = {"value": observed}
        artifacts = tuple(str(x) for x in raw.get("artifacts", ()))
        reason = str(raw.get("reason", ""))
        available_outputs = set(raw) | set(observed)
        missing_outputs = [x for x in contract.required_outputs if x not in available_outputs]
        if missing_outputs:
            state = "inconclusive"
            suffix = "missing required verifier outputs: " + ", ".join(missing_outputs)
            reason = f"{reason}; {suffix}" if reason else suffix
        independent = (not contract.requires_independent_author or
                       verifier.author not in request.claim.source_ids)
        configured_quality = verifier.contact_quality
        quality = configured_quality
        calibration_state = "not_required"
        calibration_groups = 0
        if contract.minimum_calibration_groups > 0:
            report = self.calibration.report(
                verifier.verifier_id, verifier.task_family or contract.claim_class,
                minimum_groups=contract.minimum_calibration_groups)
            calibration_state = report.state
            calibration_groups = report.independent_groups
            quality = min(quality, report.authority_cap)
        passes_quality = quality >= contract.minimum_quality
        authority_states = {"supported", "falsified"}
        earned = (min(contract.authority_ceiling, quality)
                  if state in authority_states and passes_quality and independent else 0.0)
        result = VerificationResult(
            request.rid, request.claim.cid, contract.contract_id, verifier.verifier_id,
            state, verifier.contact_type, quality, earned, independent,
            dict(observed), artifacts, reason, start, end,
            configured_quality=configured_quality, calibration_state=calibration_state,
            calibration_groups=calibration_groups, component_status=component_status,
        )
        self.results[result.result_id] = result
        self.audit.append("verification_executed", asdict(result))
        return result

    def coverage(self) -> dict:
        classes = sorted({c.claim_class for c in self.contracts.values()})
        executable = []
        for c in self.contracts.values():
            matches = [v.verifier_id for v in self.verifiers.values()
                       if v.kind in c.verifier_kinds and v.contact_type in c.admissible_contacts]
            executable.append({"contract_id": c.contract_id, "claim_class": c.claim_class,
                               "verifiers": sorted(matches), "executable": bool(matches)})
        return {"claim_classes": classes, "contracts": executable,
                "audit_valid": self.audit.verify().get("valid", False)}


def core_contracts() -> Tuple[VerificationContract, ...]:
    """A conservative seed pack.  It is a routing vocabulary, not a world ontology."""
    return (
        VerificationContract(
            "math-proof", "mathematical_proposition",
            "Check a formal statement in a proof assistant or trusted proof checker.",
            ("proof_checker",), ("formal",), minimum_quality=0.95,
            authority_ceiling=1.0, required_inputs=("formal_statement",),
            required_outputs=("checker_receipt",),
            falsifier_form="a checker-rejected proof or countermodel",
        ),
        VerificationContract(
            "software-property", "software_behaviour",
            "Execute tests, model checking, static analysis, or metamorphic relations.",
            ("test_runner", "model_checker", "static_analyser", "metamorphic_tester"),
            ("execution", "formal"), minimum_quality=0.7, authority_ceiling=0.9,
            required_inputs=("artifact", "property"),
            falsifier_form="a reproducible input or trace violating the property",
            scope_limits=("only the tested implementation and environment",),
        ),
        VerificationContract(
            "empirical-measurement", "empirical_quantity",
            "Measure a specified measurand with a calibrated instrument or direct observation.",
            ("instrument", "sensor", "measurement_protocol"),
            ("instrument", "direct"), minimum_quality=0.75, authority_ceiling=0.95,
            required_inputs=("measurand", "procedure"),
            falsifier_form="independent calibrated measurement outside the uncertainty interval",
        ),
        VerificationContract(
            "statistical-generalisation", "statistical_generalisation",
            "Evaluate a pre-specified statistical claim against identified data and assumptions.",
            ("statistical_test", "replication"), ("dataset", "replication"),
            minimum_quality=0.65, authority_ceiling=0.8,
            required_inputs=("dataset", "estimand", "assumptions"),
            falsifier_form="a valid analysis or replication that rejects the stated effect",
            scope_limits=("population and design represented by the data",),
        ),
        VerificationContract(
            "causal-identification", "causal_claim",
            "Check an explicit causal estimand under a declared identification strategy.",
            ("causal_analysis", "randomised_experiment", "natural_experiment"),
            ("dataset", "instrument", "replication"), minimum_quality=0.75,
            authority_ceiling=0.85,
            required_inputs=("causal_graph", "estimand", "identification_assumptions"),
            falsifier_form="violation of identification assumptions or contradictory intervention",
        ),
        VerificationContract(
            "documentary-fact", "documentary_fact",
            "Inspect primary records with provenance and temporal scope.",
            ("document_inspector", "database_query"), ("primary_source", "database"),
            minimum_quality=0.6, authority_ceiling=0.75,
            required_inputs=("record_locator", "fact_pattern"),
            falsifier_form="a more authoritative contemporaneous record or record invalidation",
        ),
        VerificationContract(
            "normative-judgment", "normative_claim",
            "Record accountable human or institutional judgment; does not mint truth authority.",
            ("human_decision", "governance_process"), ("human", "institutional"),
            minimum_quality=0.0, authority_ceiling=0.0,
            requires_independent_author=False,
            required_inputs=("decision_owner", "values", "jurisdiction"),
            falsifier_form="not truth-apt; challenge through governance and consequences",
        ),
    )
