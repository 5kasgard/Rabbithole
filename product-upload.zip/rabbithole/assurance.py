"""Capability assurance through traceability and architectural mutation.

This module prevents a recurring failure in the project: a capability being
claimed because a file, diagram, or direct unit test exists.  A capability case
starts at observable local and whole-system effects, follows them through the
public surface to runtime organ traces, and then removes each claimed organ.
The organ is load-bearing only when its removal causes the representative
capability to fail in the predicted way.

Assurance is evidence about a specific workload and envelope, never proof of
universal capability.  The record therefore preserves scope, input digest,
observed effects, failed mutations, and untested requirements.
"""
from __future__ import annotations

import hashlib
import json
import math
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Callable, Dict, Mapping, Optional, Sequence, Tuple

from .organs import MutationResult, OrganRegistry, OrganUnavailable
from .wal import EventLog


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


def _digest(value: object) -> str:
    text = json.dumps(value, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@dataclass
class CapabilityRequirement:
    capability: str
    public_surface: str
    local_effects: Tuple[str, ...]
    whole_effects: Tuple[str, ...]
    required_organs: Tuple[str, ...]
    success_observations: Tuple[str, ...]
    failure_observations: Tuple[str, ...]
    forbidden_effects: Tuple[str, ...] = ()
    scope: str = ""
    representative_input_digest: str = ""
    external_contact_required: bool = False
    rid: str = field(default_factory=lambda: _id("REQ"))

    def validate(self) -> None:
        if not self.capability.strip() or not self.public_surface.strip():
            raise ValueError("capability and public surface are required")
        if not self.local_effects or not self.whole_effects:
            raise ValueError("local and whole observable effects are required")
        if not self.success_observations or not self.failure_observations:
            raise ValueError("success and failure observations are required")
        if len(set(self.required_organs)) != len(self.required_organs):
            raise ValueError("required organs must be unique")


@dataclass
class CapabilityObservation:
    requirement_id: str
    passed: bool
    result_digest: str
    observed_effects: Tuple[str, ...]
    organ_trace_ids: Tuple[int, ...]
    external_contacts: Tuple[str, ...] = ()
    missing_effects: Tuple[str, ...] = ()
    forbidden_observed: Tuple[str, ...] = ()
    reason: str = ""
    created_at: float = field(default_factory=time.time)
    oid: str = field(default_factory=lambda: _id("OBS"))


@dataclass
class CapabilityCase:
    requirement: CapabilityRequirement
    baseline: Optional[CapabilityObservation] = None
    mutations: Tuple[MutationResult, ...] = ()
    untested_organs: Tuple[str, ...] = ()
    scope_limitations: Tuple[str, ...] = ()
    cid: str = field(default_factory=lambda: _id("CASE"))

    @property
    def passed(self) -> bool:
        return bool(
            self.baseline and self.baseline.passed
            and not self.untested_organs
            and all(x.load_bearing for x in self.mutations)
        )

    def report(self) -> dict:
        return {
            "case_id": self.cid,
            "requirement": asdict(self.requirement),
            "baseline": asdict(self.baseline) if self.baseline else None,
            "mutations": [asdict(x) | {"load_bearing": x.load_bearing}
                          for x in self.mutations],
            "untested_organs": list(self.untested_organs),
            "scope_limitations": list(self.scope_limitations),
            "passed": self.passed,
        }


class AssuranceRegistry:
    def __init__(self):
        self.requirements: Dict[str, CapabilityRequirement] = {}
        self.cases: Dict[str, CapabilityCase] = {}
        self.audit = EventLog()

    def register(self, requirement: CapabilityRequirement) -> str:
        requirement.validate()
        if requirement.rid in self.requirements:
            raise ValueError(f"requirement {requirement.rid!r} already exists")
        self.requirements[requirement.rid] = requirement
        self.audit.append("capability_requirement_registered", asdict(requirement))
        return requirement.rid

    def evaluate(
        self,
        requirement_id: str,
        organs: OrganRegistry,
        invoke: Callable[[], object],
        observe: Callable[[object], Mapping[str, object]],
        *,
        mutation_invoke: Optional[Callable[[], object]] = None,
        failure_predicates: Optional[Mapping[str, Callable[[BaseException], bool]]] = None,
        equivalence: Optional[Callable[[object, object], bool]] = None,
        scope_limitations: Sequence[str] = (),
    ) -> CapabilityCase:
        """Run baseline observation and deletion tests through a public surface.

        ``observe`` converts the public result into explicit effects and contacts:
        ``{"passed": bool, "effects": [...], "external_contacts": [...],
        "reason": str}``.  The evaluator does not infer capability from fluent
        output or file presence.
        """
        requirement = self.requirements[requirement_id]
        before = len(organs.traces)
        result = invoke()
        after = len(organs.traces)
        raw = dict(observe(result))
        effects = tuple(str(x) for x in raw.get("effects", ()))
        contacts = tuple(str(x) for x in raw.get("external_contacts", ()))
        missing = tuple(x for x in requirement.success_observations if x not in effects)
        forbidden = tuple(x for x in requirement.forbidden_effects if x in effects)
        traces = tuple(range(before, after))
        traced_organs = {organs.traces[i].organ for i in traces}
        missing_organs = tuple(x for x in requirement.required_organs if x not in traced_organs)
        contact_failure = requirement.external_contact_required and not contacts
        passed = bool(raw.get("passed", False)) and not missing and not forbidden and not missing_organs and not contact_failure
        reasons = []
        if raw.get("reason"):
            reasons.append(str(raw["reason"]))
        if missing:
            reasons.append(f"missing success observations: {', '.join(missing)}")
        if forbidden:
            reasons.append(f"forbidden effects observed: {', '.join(forbidden)}")
        if missing_organs:
            reasons.append(f"required organs not traversed: {', '.join(missing_organs)}")
        if contact_failure:
            reasons.append("no external contact recorded")
        baseline = CapabilityObservation(
            requirement_id=requirement_id,
            passed=passed,
            result_digest=_digest(result),
            observed_effects=effects,
            organ_trace_ids=traces,
            external_contacts=contacts,
            missing_effects=missing,
            forbidden_observed=forbidden,
            reason="; ".join(reasons),
        )

        mutations = []
        untested = []
        if baseline.passed:
            mutator = mutation_invoke or invoke
            for organ in requirement.required_organs:
                if organ not in organs.specs:
                    untested.append(organ)
                    continue
                predicate = (failure_predicates or {}).get(organ)
                mutations.append(organs.mutation_test(
                    organ, requirement.capability, mutator,
                    failure_predicate=predicate,
                    equivalence=equivalence,
                ))
        else:
            untested.extend(requirement.required_organs)

        case = CapabilityCase(requirement, baseline, tuple(mutations),
                              tuple(untested), tuple(scope_limitations))
        self.cases[case.cid] = case
        self.audit.append("capability_case_evaluated", case.report())
        return case

    def coverage(self) -> dict:
        tested = {case.requirement.rid for case in self.cases.values()}
        passing = [case.cid for case in self.cases.values() if case.passed]
        return {
            "requirements": len(self.requirements),
            "tested_requirements": len(tested),
            "untested_requirements": sorted(set(self.requirements) - tested),
            "passing_cases": passing,
            "failing_cases": [x.cid for x in self.cases.values() if not x.passed],
            "audit_valid": self.audit.verify().get("valid", False),
        }

    def to_dict(self) -> dict:
        return {
            "requirements": [asdict(x) for x in self.requirements.values()],
            "cases": [x.report() for x in self.cases.values()],
            "audit": self.audit.to_dict(),
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "AssuranceRegistry":
        reg = cls()
        for x in raw.get("requirements", []):
            d = dict(x)
            for key in ("local_effects", "whole_effects", "required_organs",
                        "success_observations", "failure_observations", "forbidden_effects"):
                d[key] = tuple(d.get(key, ()))
            req = CapabilityRequirement(**d)
            reg.requirements[req.rid] = req
        for x in raw.get("cases", []):
            req_raw = dict(x["requirement"])
            for key in ("local_effects", "whole_effects", "required_organs",
                        "success_observations", "failure_observations", "forbidden_effects"):
                req_raw[key] = tuple(req_raw.get(key, ()))
            req = CapabilityRequirement(**req_raw)
            obs = None
            if x.get("baseline"):
                d = dict(x["baseline"])
                for key in ("observed_effects", "organ_trace_ids", "external_contacts",
                            "missing_effects", "forbidden_observed"):
                    d[key] = tuple(d.get(key, ()))
                obs = CapabilityObservation(**d)
            muts = tuple(MutationResult(**{k: v for k, v in m.items() if k != "load_bearing"})
                         for m in x.get("mutations", []))
            case = CapabilityCase(req, obs, muts, tuple(x.get("untested_organs", ())),
                                  tuple(x.get("scope_limitations", ())), x.get("case_id", _id("CASE")))
            reg.cases[case.cid] = case
        reg.audit = EventLog.from_dict(raw.get("audit", {}))
        return reg
