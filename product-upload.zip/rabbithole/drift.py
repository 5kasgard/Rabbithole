"""Small explicit distribution-shift monitor for numeric task features.

This is a detector contract, not a universal OOD oracle.  It compares a named
feature against a frozen baseline and recommends scope reduction when the
observed standardized mean shift exceeds a declared threshold.
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Mapping, Sequence


@dataclass(frozen=True)
class DriftBaseline:
    feature: str
    mean: float
    std: float
    n: int
    threshold_z: float = 2.0


@dataclass(frozen=True)
class DriftReport:
    feature: str
    observed_mean: float
    baseline_mean: float
    standardized_shift: float
    state: str
    action: str


class DriftMonitor:
    @staticmethod
    def fit(feature: str, values: Sequence[float], threshold_z: float = 2.0) -> DriftBaseline:
        xs = [float(x) for x in values]
        if len(xs) < 2 or not all(math.isfinite(x) for x in xs):
            raise ValueError("baseline requires at least two finite observations")
        mean = sum(xs) / len(xs)
        var = sum((x - mean) ** 2 for x in xs) / (len(xs) - 1)
        return DriftBaseline(feature, mean, max(math.sqrt(var), 1e-12), len(xs), threshold_z)

    @staticmethod
    def evaluate(baseline: DriftBaseline, values: Sequence[float]) -> DriftReport:
        xs = [float(x) for x in values]
        if not xs or not all(math.isfinite(x) for x in xs):
            raise ValueError("observations must be finite")
        observed = sum(xs) / len(xs)
        shift = abs(observed - baseline.mean) / baseline.std
        shifted = shift > baseline.threshold_z
        return DriftReport(baseline.feature, observed, baseline.mean, shift,
                           "shift_detected" if shifted else "within_baseline",
                           "reduce_scope_and_re-ground" if shifted else "continue_with_declared_scope")
