"""Stage 4D-C substrate campaign: evidence-bound heterogeneous allocation.

The campaign treats language, runtime, storage, networking, and hardware as
separate allocation layers.  It does not award authority to a fashionable
language or to a microbenchmark.  Candidates must satisfy frozen workload and
interface contracts before they can enter a Pareto frontier.  Performance,
correctness, replayability, portability, isolation, integration cost, and human
burden remain separate dimensions.

The module is deliberately stdlib-only.  It can persist and integrity-replay a
campaign, allocate the next benchmark under an explicit uncertainty/cost model,
record independently authored observations, run counterexample/refinement
checks, and preserve unresolved frontiers.  It does not claim that structural
author labels establish real organisational independence or that local
benchmarks establish production superiority.
"""
from __future__ import annotations

import hashlib
import json
import math
import statistics
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, Iterable, Mapping, Sequence, Tuple

from .wal import EventLog


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


def _canon(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False, default=str).encode("utf-8")


def _digest(value: object) -> str:
    return hashlib.sha256(_canon(value)).hexdigest()


LAYERS = ("language", "runtime", "storage", "networking", "hardware")
METRIC_DIRECTIONS = {
    "correctness": "max",
    "determinism": "max",
    "replayability": "max",
    "portability": "max",
    "isolation": "max",
    "formal_soundness": "max",
    "whole_system_fit": "max",
    "debuggability": "max",
    "supply_chain_simplicity": "max",
    "throughput": "max",
    "latency_ms": "min",
    "memory_mb": "min",
    "integration_cost": "min",
    "maintenance_burden": "min",
    "energy_proxy": "min",
}
HARD_QUALITY_METRICS = ("correctness", "determinism", "replayability")


@dataclass(frozen=True)
class SubstrateCandidate:
    candidate_id: str
    layer: str
    name: str
    implementation: str
    role: str
    author: str
    available: bool
    capabilities: Tuple[str, ...]
    preconditions: Tuple[str, ...]
    contraindications: Tuple[str, ...]
    failure_modes: Tuple[str, ...]
    evidence_roots: Tuple[str, ...]
    static_metrics: Mapping[str, float]
    authority_effect: str = "none"
    availability_reason: str = ""

    def validate(self) -> None:
        if self.layer not in LAYERS:
            raise ValueError(f"invalid substrate layer {self.layer!r}")
        if self.role not in {"baseline", "challenger", "specialist", "null"}:
            raise ValueError("invalid substrate candidate role")
        if not self.candidate_id or not self.name or not self.author:
            raise ValueError("candidate requires id, name and author")
        if not self.capabilities or not self.failure_modes:
            raise ValueError("candidate requires capabilities and failure modes")
        for name in ("capabilities", "preconditions", "contraindications",
                     "failure_modes", "evidence_roots"):
            value = getattr(self, name)
            if not isinstance(value, tuple) or any(not isinstance(x, str) or not x for x in value):
                raise ValueError(f"candidate {name} must be a tuple of non-empty strings")
        unknown = set(self.static_metrics) - set(METRIC_DIRECTIONS)
        if unknown:
            raise ValueError(f"unknown substrate metrics: {sorted(unknown)}")
        if any(not 0.0 <= float(v) <= 1.0 for v in self.static_metrics.values()):
            raise ValueError("static substrate metrics must be in [0,1]")
        if not self.available and not self.availability_reason:
            raise ValueError("unavailable candidate requires a reason")


@dataclass(frozen=True)
class WorkloadContract:
    workload_id: str
    layer: str
    name: str
    description: str
    required_capabilities: Tuple[str, ...]
    required_metrics: Tuple[str, ...]
    hard_invariants: Tuple[str, ...]
    representative_of: Tuple[str, ...]
    exclusions: Tuple[str, ...]
    author: str
    risk_level: str
    minimum_repetitions: int = 3

    def validate(self) -> None:
        if self.layer not in LAYERS:
            raise ValueError("invalid workload layer")
        if self.risk_level not in {"low", "medium", "high", "critical"}:
            raise ValueError("invalid workload risk")
        if not self.workload_id or not self.name or not self.author:
            raise ValueError("workload requires id, name and author")
        if not self.required_metrics or not self.hard_invariants:
            raise ValueError("workload requires metrics and invariants")
        for name in ("required_capabilities", "required_metrics", "hard_invariants",
                     "representative_of", "exclusions"):
            value = getattr(self, name)
            if not isinstance(value, tuple) or any(not isinstance(x, str) or not x for x in value):
                raise ValueError(f"workload {name} must be a tuple of non-empty strings")
        if self.minimum_repetitions < 1:
            raise ValueError("minimum repetitions must be positive")
        unknown = set(self.required_metrics) - set(METRIC_DIRECTIONS)
        if unknown:
            raise ValueError(f"unknown workload metrics: {sorted(unknown)}")


@dataclass(frozen=True)
class BenchmarkCommitment:
    benchmark_id: str
    workload_id: str
    candidate_ids: Tuple[str, ...]
    benchmark_author: str
    evaluator: str
    attempted_kill_author: str
    metric_definitions: Mapping[str, str]
    environment_contract: Mapping[str, object]
    warmups: int
    repetitions: int
    frozen_at: float = field(default_factory=time.time)
    commitment_digest: str = ""

    def material(self) -> dict:
        raw = asdict(self)
        raw.pop("commitment_digest", None)
        return raw

    def validate(self) -> None:
        if not self.benchmark_id or not self.workload_id or not self.candidate_ids:
            raise ValueError("benchmark commitment is incomplete")
        if not isinstance(self.candidate_ids, tuple) or any(
                not isinstance(x, str) or not x for x in self.candidate_ids):
            raise ValueError("benchmark candidate ids must be a tuple of non-empty strings")
        authors = {self.benchmark_author, self.evaluator, self.attempted_kill_author}
        if "" in authors or len(authors) < 3:
            raise ValueError("benchmark, evaluator and attempted-kill authors must be distinct")
        if self.repetitions < 1 or self.warmups < 0:
            raise ValueError("invalid benchmark repetitions")
        expected = _digest(self.material())
        if self.commitment_digest and self.commitment_digest != expected:
            raise ValueError("benchmark commitment digest mismatch")

    def frozen(self) -> "BenchmarkCommitment":
        raw = self.material()
        return BenchmarkCommitment(**raw, commitment_digest=_digest(raw))


@dataclass(frozen=True)
class BenchmarkObservation:
    benchmark_id: str
    workload_id: str
    candidate_id: str
    run_index: int
    metrics: Mapping[str, float]
    invariant_results: Mapping[str, bool]
    output_digest: str
    environment_digest: str
    evaluator: str
    benchmark_commitment_digest: str
    raw_receipt_digest: str
    observed_at: float = field(default_factory=time.time)
    observation_id: str = field(default_factory=lambda: _id("SOB"))

    def validate(self) -> None:
        if self.run_index < 0:
            raise ValueError("run index must be non-negative")
        unknown = set(self.metrics) - set(METRIC_DIRECTIONS)
        if unknown:
            raise ValueError(f"unknown observation metrics: {sorted(unknown)}")
        for key, value in self.metrics.items():
            if not math.isfinite(float(value)) or float(value) < 0:
                raise ValueError(f"invalid metric {key}")
        if not self.output_digest or not self.environment_digest or not self.raw_receipt_digest:
            raise ValueError("observation requires content digests")


@dataclass(frozen=True)
class FormalContract:
    contract_id: str
    layer: str
    name: str
    property_statement: str
    model_scope: Tuple[str, ...]
    candidate_ids: Tuple[str, ...]
    checker: str
    author: str
    counterexample_author: str
    required: bool = True

    def validate(self) -> None:
        if self.layer not in LAYERS:
            raise ValueError("invalid formal contract layer")
        if not self.contract_id or not self.property_statement or not self.checker:
            raise ValueError("formal contract is incomplete")
        if self.author == self.counterexample_author:
            raise ValueError("formal and counterexample authors must differ")


@dataclass(frozen=True)
class RefinementRecord:
    contract_id: str
    candidate_id: str
    iteration: int
    status: str
    counterexample: str
    refinement: str
    checker_receipt: str
    author: str
    recorded_at: float = field(default_factory=time.time)
    refinement_id: str = field(default_factory=lambda: _id("REF"))

    def validate(self) -> None:
        if self.status not in {"pass", "fail", "spurious", "refined", "blocked"}:
            raise ValueError("invalid refinement status")
        if self.iteration < 0 or not self.checker_receipt:
            raise ValueError("invalid refinement record")
        if self.status in {"fail", "spurious", "refined"} and not self.counterexample:
            raise ValueError("counterexample-bearing status requires a counterexample")


@dataclass(frozen=True)
class ExperimentAllocation:
    benchmark_id: str
    candidate_id: str
    workload_id: str
    expected_information_gain: float
    expected_cost: float
    score: float
    model: str
    rationale: str
    allocation_id: str = field(default_factory=lambda: _id("SEA"))
    created_at: float = field(default_factory=time.time)


@dataclass(frozen=True)
class CandidateAssessment:
    candidate_id: str
    layer: str
    metrics: Mapping[str, float]
    measured_workloads: Tuple[str, ...]
    missing_workloads: Tuple[str, ...]
    failed_invariants: Tuple[str, ...]
    failed_formal_contracts: Tuple[str, ...]
    hard_valid: bool
    availability: bool
    evidence_roots: Tuple[str, ...]
    assessment_id: str = field(default_factory=lambda: _id("SAS"))


@dataclass(frozen=True)
class LayerDecision:
    layer: str
    candidate_ids: Tuple[str, ...]
    frontier_ids: Tuple[str, ...]
    retained_baseline_ids: Tuple[str, ...]
    experimental_slice_ids: Tuple[str, ...]
    rejected_ids: Tuple[str, ...]
    unresolved: bool
    rationale: str
    decision_id: str = field(default_factory=lambda: _id("SLD"))
    created_at: float = field(default_factory=time.time)


@dataclass(frozen=True)
class MigrationSlice:
    slice_id: str
    layer: str
    component: str
    baseline_candidate_id: str
    contender_candidate_id: str
    trigger_conditions: Tuple[str, ...]
    rollback_conditions: Tuple[str, ...]
    state_compatibility_contract: str
    benchmark_ids: Tuple[str, ...]
    author: str
    evaluator: str
    status: str = "proposed"

    def validate(self) -> None:
        if self.layer not in LAYERS:
            raise ValueError("invalid migration layer")
        if self.status not in {"proposed", "approved", "running", "retained", "rolled_back", "blocked"}:
            raise ValueError("invalid migration status")
        if self.author == self.evaluator:
            raise ValueError("migration author cannot be sole evaluator")
        if not self.trigger_conditions or not self.rollback_conditions:
            raise ValueError("migration slice requires triggers and rollback conditions")


class SubstrateCampaign:
    """Persistent Stage 4D-C campaign with frozen benchmark and Pareto gates."""

    def __init__(self, campaign_id: str, purpose: str, host_process: str,
                 process_profile_digest: str, author: str) -> None:
        if host_process != "arc5a":
            raise ValueError("Stage 4D-C requires ARC-5A as host")
        self.campaign_id = campaign_id
        self.purpose = purpose
        self.host_process = host_process
        self.process_profile_digest = process_profile_digest
        self.author = author
        self.created_at = time.time()
        self.candidates: Dict[str, SubstrateCandidate] = {}
        self.workloads: Dict[str, WorkloadContract] = {}
        self.benchmarks: Dict[str, BenchmarkCommitment] = {}
        self.observations: Dict[str, BenchmarkObservation] = {}
        self.formal_contracts: Dict[str, FormalContract] = {}
        self.refinements: Dict[str, RefinementRecord] = {}
        self.allocations: Dict[str, ExperimentAllocation] = {}
        self.assessments: Dict[str, CandidateAssessment] = {}
        self.decisions: Dict[str, LayerDecision] = {}
        self.migration_slices: Dict[str, MigrationSlice] = {}
        self.external_evidence: Dict[str, dict] = {}
        self.audit = EventLog()
        self.audit.append("substrate_campaign_created", {
            "campaign_id": campaign_id, "purpose": purpose,
            "host_process": host_process, "process_profile_digest": process_profile_digest,
            "author": author,
        })

    def register_candidate(self, candidate: SubstrateCandidate) -> str:
        candidate.validate()
        prior = self.candidates.get(candidate.candidate_id)
        if prior and _digest(asdict(prior)) != _digest(asdict(candidate)):
            raise ValueError("candidate already registered differently")
        self.candidates[candidate.candidate_id] = candidate
        self.audit.append("substrate_candidate_registered", {
            "candidate_id": candidate.candidate_id, "layer": candidate.layer,
            "digest": _digest(asdict(candidate)), "available": candidate.available,
        })
        return candidate.candidate_id

    def register_workload(self, workload: WorkloadContract) -> str:
        workload.validate()
        prior = self.workloads.get(workload.workload_id)
        if prior and _digest(asdict(prior)) != _digest(asdict(workload)):
            raise ValueError("workload already registered differently")
        self.workloads[workload.workload_id] = workload
        self.audit.append("substrate_workload_registered", {
            "workload_id": workload.workload_id, "layer": workload.layer,
            "digest": _digest(asdict(workload)),
        })
        return workload.workload_id

    def freeze_benchmark(self, commitment: BenchmarkCommitment) -> str:
        if commitment.workload_id not in self.workloads:
            raise KeyError(commitment.workload_id)
        if any(cid not in self.candidates for cid in commitment.candidate_ids):
            raise KeyError("benchmark references unknown candidate")
        workload = self.workloads[commitment.workload_id]
        for cid in commitment.candidate_ids:
            if self.candidates[cid].layer != workload.layer:
                raise ValueError("benchmark candidate/workload layer mismatch")
            if self.candidates[cid].author in {commitment.benchmark_author,
                                              commitment.evaluator,
                                              commitment.attempted_kill_author}:
                raise ValueError("candidate author may not own benchmark, evaluation or attempted-kill lane")
        frozen = commitment.frozen()
        frozen.validate()
        prior = self.benchmarks.get(frozen.benchmark_id)
        if prior and prior.commitment_digest != frozen.commitment_digest:
            raise ValueError("benchmark already frozen differently")
        self.benchmarks[frozen.benchmark_id] = frozen
        self.audit.append("substrate_benchmark_frozen", {
            "benchmark_id": frozen.benchmark_id,
            "commitment_digest": frozen.commitment_digest,
            "workload_id": frozen.workload_id,
        })
        return frozen.benchmark_id

    def register_formal_contract(self, contract: FormalContract) -> str:
        contract.validate()
        if any(cid not in self.candidates for cid in contract.candidate_ids):
            raise KeyError("formal contract references unknown candidate")
        if any(self.candidates[cid].layer != contract.layer for cid in contract.candidate_ids):
            raise ValueError("formal contract layer mismatch")
        self.formal_contracts[contract.contract_id] = contract
        self.audit.append("substrate_formal_contract_registered", {
            "contract_id": contract.contract_id, "digest": _digest(asdict(contract)),
        })
        return contract.contract_id

    def record_refinement(self, record: RefinementRecord) -> str:
        record.validate()
        if record.contract_id not in self.formal_contracts:
            raise KeyError(record.contract_id)
        contract = self.formal_contracts[record.contract_id]
        if record.candidate_id not in contract.candidate_ids:
            raise ValueError("candidate outside formal contract")
        prior_iterations = [r.iteration for r in self.refinements.values()
                            if r.contract_id == record.contract_id and r.candidate_id == record.candidate_id]
        if prior_iterations and record.iteration <= max(prior_iterations):
            raise ValueError("refinement iterations must increase")
        self.refinements[record.refinement_id] = record
        self.audit.append("substrate_refinement_recorded", {
            "refinement_id": record.refinement_id, "contract_id": record.contract_id,
            "candidate_id": record.candidate_id, "status": record.status,
            "receipt": record.checker_receipt,
        })
        return record.refinement_id

    def add_external_evidence(self, source_id: str, record: Mapping[str, object]) -> None:
        row = dict(record)
        if not source_id or not row.get("title") or not row.get("url"):
            raise ValueError("external evidence requires source id, title and URL")
        row["digest"] = _digest({k: v for k, v in row.items() if k != "digest"})
        self.external_evidence[source_id] = row
        self.audit.append("substrate_external_evidence_added", {
            "source_id": source_id, "digest": row["digest"],
        })

    def record_observation(self, observation: BenchmarkObservation) -> str:
        observation.validate()
        if observation.benchmark_id not in self.benchmarks:
            raise KeyError(observation.benchmark_id)
        commitment = self.benchmarks[observation.benchmark_id]
        if observation.workload_id != commitment.workload_id:
            raise ValueError("observation workload does not match commitment")
        if observation.candidate_id not in commitment.candidate_ids:
            raise ValueError("observation candidate outside commitment")
        if observation.evaluator != commitment.evaluator:
            raise ValueError("observation evaluator differs from frozen commitment")
        if observation.benchmark_commitment_digest != commitment.commitment_digest:
            raise ValueError("observation is not bound to frozen benchmark")
        if observation.run_index >= commitment.repetitions:
            raise ValueError("observation run exceeds frozen repetition count")
        if set(observation.metrics) != set(self.workloads[observation.workload_id].required_metrics):
            raise ValueError("observation metrics differ from frozen workload contract")
        if set(observation.invariant_results) != set(self.workloads[observation.workload_id].hard_invariants):
            raise ValueError("observation invariant set differs from frozen workload contract")
        duplicate = [x for x in self.observations.values()
                     if x.benchmark_id == observation.benchmark_id
                     and x.candidate_id == observation.candidate_id
                     and x.run_index == observation.run_index]
        if duplicate:
            if _digest(asdict(duplicate[0])) != _digest(asdict(observation)):
                raise ValueError("benchmark run already recorded differently")
            return duplicate[0].observation_id
        self.observations[observation.observation_id] = observation
        self.audit.append("substrate_observation_recorded", {
            "observation_id": observation.observation_id,
            "benchmark_id": observation.benchmark_id,
            "candidate_id": observation.candidate_id,
            "run_index": observation.run_index,
            "raw_receipt_digest": observation.raw_receipt_digest,
        })
        return observation.observation_id

    def allocate_next_experiment(self) -> ExperimentAllocation | None:
        """Allocate one missing run using an explicit normal-variance proxy.

        With no observations, prior variance is 1.  Each observation reduces the
        variance as 1/(n+1).  Expected information gain is log1p(variance), and
        expected cost is the last measured latency plus memory/100, or 1 for an
        unseen pair.  This is a transparent allocation heuristic, not a claim of
        a correctly specified world model.
        """
        choices = []
        for benchmark in self.benchmarks.values():
            for cid in benchmark.candidate_ids:
                candidate = self.candidates[cid]
                if not candidate.available:
                    continue
                rows = [o for o in self.observations.values()
                        if o.benchmark_id == benchmark.benchmark_id and o.candidate_id == cid]
                if len(rows) >= benchmark.repetitions:
                    continue
                variance = 1.0 / (len(rows) + 1.0)
                eig = math.log1p(variance)
                if rows:
                    med_latency = statistics.median(float(o.metrics.get("latency_ms", 1.0)) for o in rows)
                    med_memory = statistics.median(float(o.metrics.get("memory_mb", 0.0)) for o in rows)
                    cost = max(1e-9, med_latency + med_memory / 100.0)
                else:
                    cost = 1.0
                score = eig / cost
                choices.append((score, benchmark, cid, eig, cost))
        if not choices:
            return None
        score, benchmark, cid, eig, cost = max(choices, key=lambda x: (x[0], x[1].benchmark_id, x[2]))
        allocation = ExperimentAllocation(
            benchmark.benchmark_id, cid, benchmark.workload_id, eig, cost, score,
            "normal-variance information-gain proxy",
            "highest remaining uncertainty per measured resource cost",
        )
        self.allocations[allocation.allocation_id] = allocation
        self.audit.append("substrate_experiment_allocated", asdict(allocation))
        return allocation

    def _formal_failures(self, candidate_id: str) -> Tuple[str, ...]:
        failures = []
        for contract in self.formal_contracts.values():
            if candidate_id not in contract.candidate_ids or not contract.required:
                continue
            rows = sorted((r for r in self.refinements.values()
                           if r.contract_id == contract.contract_id
                           and r.candidate_id == candidate_id), key=lambda r: r.iteration)
            if not rows or rows[-1].status != "pass":
                failures.append(contract.contract_id)
        return tuple(sorted(failures))

    def assess_candidate(self, candidate_id: str) -> CandidateAssessment:
        candidate = self.candidates[candidate_id]
        workload_ids = tuple(sorted(w.workload_id for w in self.workloads.values()
                                    if w.layer == candidate.layer
                                    and set(w.required_capabilities).issubset(set(candidate.capabilities))))
        measured, missing, failed_invariants = [], [], []
        metric_values: Dict[str, list[float]] = {k: [] for k in METRIC_DIRECTIONS}
        for wid in workload_ids:
            benchmarks = [b for b in self.benchmarks.values()
                          if b.workload_id == wid and candidate_id in b.candidate_ids]
            rows = [o for o in self.observations.values()
                    if o.workload_id == wid and o.candidate_id == candidate_id]
            required = max((b.repetitions for b in benchmarks), default=self.workloads[wid].minimum_repetitions)
            if len(rows) < required:
                missing.append(wid)
                continue
            measured.append(wid)
            for row in rows:
                for inv, passed in row.invariant_results.items():
                    if not passed:
                        failed_invariants.append(f"{wid}:{inv}")
                for metric, value in row.metrics.items():
                    metric_values[metric].append(float(value))
        metrics: Dict[str, float] = {}
        for metric, static in candidate.static_metrics.items():
            metrics[metric] = float(static)
        for metric, values in metric_values.items():
            if values:
                metrics[metric] = statistics.median(values)
        failed_formal = self._formal_failures(candidate_id)
        hard_valid = bool(candidate.available and workload_ids and not missing
                          and not failed_invariants and not failed_formal
                          and all(float(metrics.get(m, 0.0)) >= 0.999 for m in HARD_QUALITY_METRICS))
        assessment = CandidateAssessment(
            candidate_id, candidate.layer, metrics, tuple(measured), tuple(missing),
            tuple(sorted(set(failed_invariants))), failed_formal, hard_valid,
            candidate.available, candidate.evidence_roots,
        )
        self.assessments[assessment.assessment_id] = assessment
        self.audit.append("substrate_candidate_assessed", {
            "assessment_id": assessment.assessment_id, "candidate_id": candidate_id,
            "hard_valid": hard_valid, "metrics_digest": _digest(metrics),
        })
        return assessment

    @staticmethod
    def _dominates(a: CandidateAssessment, b: CandidateAssessment) -> bool:
        shared = set(a.metrics) & set(b.metrics) & set(METRIC_DIRECTIONS)
        if not shared:
            return False
        weak = True
        strict = False
        for metric in shared:
            av, bv = float(a.metrics[metric]), float(b.metrics[metric])
            if METRIC_DIRECTIONS[metric] == "max":
                weak = weak and av >= bv
                strict = strict or av > bv
            else:
                weak = weak and av <= bv
                strict = strict or av < bv
        return weak and strict

    def decide_layer(self, layer: str) -> LayerDecision:
        if layer not in LAYERS:
            raise ValueError(layer)
        candidates = [c for c in self.candidates.values() if c.layer == layer]
        assessments = [self.assess_candidate(c.candidate_id) for c in candidates]
        valid = [a for a in assessments if a.hard_valid]
        frontier = [a for a in valid if not any(self._dominates(other, a)
                                                for other in valid if other.candidate_id != a.candidate_id)]
        baseline_ids = tuple(sorted(c.candidate_id for c in candidates if c.role == "baseline"))
        frontier_ids = tuple(sorted(a.candidate_id for a in frontier))
        retained = tuple(cid for cid in baseline_ids if cid in frontier_ids)
        experimental = tuple(sorted(cid for cid in frontier_ids if cid not in baseline_ids))
        rejected = tuple(sorted(c.candidate_id for c in candidates if c.candidate_id not in frontier_ids))
        unresolved = len(frontier_ids) != 1 or bool(experimental)
        if not frontier_ids:
            rationale = "no candidate satisfied all frozen workload, invariance, and formal-contract gates"
        elif retained and experimental:
            rationale = "retain authority baseline while running bounded contender slices; local measurements do not justify whole-layer replacement"
        elif retained:
            rationale = "baseline remains on the hard-valid Pareto frontier"
        else:
            rationale = "one or more contenders entered the frontier; migration remains slice-bound and reversible"
        decision = LayerDecision(layer, tuple(sorted(c.candidate_id for c in candidates)),
                                 frontier_ids, retained, experimental, rejected,
                                 unresolved, rationale)
        self.decisions[layer] = decision
        self.audit.append("substrate_layer_decided", {
            "layer": layer, "decision_id": decision.decision_id,
            "frontier_ids": list(frontier_ids), "unresolved": unresolved,
        })
        return decision

    def register_migration_slice(self, migration: MigrationSlice) -> str:
        migration.validate()
        if migration.baseline_candidate_id not in self.candidates or migration.contender_candidate_id not in self.candidates:
            raise KeyError("migration references unknown candidate")
        if self.candidates[migration.baseline_candidate_id].layer != migration.layer or self.candidates[migration.contender_candidate_id].layer != migration.layer:
            raise ValueError("migration candidate layer mismatch")
        if any(bid not in self.benchmarks for bid in migration.benchmark_ids):
            raise KeyError("migration references unknown benchmark")
        self.migration_slices[migration.slice_id] = migration
        self.audit.append("substrate_migration_slice_registered", {
            "slice_id": migration.slice_id, "layer": migration.layer,
            "status": migration.status, "digest": _digest(asdict(migration)),
        })
        return migration.slice_id

    def status(self) -> dict:
        return {
            "campaign_id": self.campaign_id,
            "purpose": self.purpose,
            "host_process": self.host_process,
            "process_profile_digest": self.process_profile_digest,
            "created_at": self.created_at,
            "counts": {
                "candidates": len(self.candidates), "workloads": len(self.workloads),
                "benchmarks": len(self.benchmarks), "observations": len(self.observations),
                "formal_contracts": len(self.formal_contracts), "refinements": len(self.refinements),
                "allocations": len(self.allocations), "decisions": len(self.decisions),
                "migration_slices": len(self.migration_slices),
            },
            "availability": {layer: {
                "available": sorted(c.candidate_id for c in self.candidates.values()
                                    if c.layer == layer and c.available),
                "blocked": {c.candidate_id: c.availability_reason for c in self.candidates.values()
                            if c.layer == layer and not c.available},
            } for layer in LAYERS},
            "decisions": {k: asdict(v) for k, v in sorted(self.decisions.items())},
            "migration_slices": {k: asdict(v) for k, v in sorted(self.migration_slices.items())},
            "integrity": self.verify(),
            "nonclaims": [
                "local benchmark results are not production superiority",
                "structurally distinct author labels are not verified external independence",
                "unavailable candidates were not scored as failures",
                "a Pareto frontier is not permission for whole-layer migration",
            ],
        }

    def verify(self) -> dict:
        problems = []
        audit = self.audit.verify()
        if not audit.get("valid"):
            problems.append("audit chain invalid")
        if self.audit.events and self.audit.events[-1].type == "snapshot":
            event = self.audit.events[-1]
            snapshot = self.audit.snapshots.get(event.payload.get("snapshot_seq"))
            if snapshot is None or _digest(snapshot) != _digest(self._state_without_audit()):
                problems.append("persisted state differs from terminal audit snapshot")
        if self.host_process != "arc5a" or not self.process_profile_digest:
            problems.append("missing ARC-5A process-profile binding")
        for candidate in self.candidates.values():
            try:
                candidate.validate()
            except ValueError as exc:
                problems.append(f"candidate:{candidate.candidate_id}:{exc}")
        for workload in self.workloads.values():
            try:
                workload.validate()
            except ValueError as exc:
                problems.append(f"workload:{workload.workload_id}:{exc}")
        for benchmark in self.benchmarks.values():
            try:
                benchmark.validate()
            except ValueError as exc:
                problems.append(f"benchmark:{benchmark.benchmark_id}:{exc}")
            if benchmark.workload_id not in self.workloads:
                problems.append(f"benchmark:{benchmark.benchmark_id}:missing workload")
            if any(cid not in self.candidates for cid in benchmark.candidate_ids):
                problems.append(f"benchmark:{benchmark.benchmark_id}:missing candidate")
        for observation in self.observations.values():
            try:
                observation.validate()
            except ValueError as exc:
                problems.append(f"observation:{observation.observation_id}:{exc}")
            benchmark = self.benchmarks.get(observation.benchmark_id)
            if not benchmark or benchmark.commitment_digest != observation.benchmark_commitment_digest:
                problems.append(f"observation:{observation.observation_id}:unbound commitment")
        for contract in self.formal_contracts.values():
            try:
                contract.validate()
            except ValueError as exc:
                problems.append(f"formal:{contract.contract_id}:{exc}")
        for record in self.refinements.values():
            try:
                record.validate()
            except ValueError as exc:
                problems.append(f"refinement:{record.refinement_id}:{exc}")
        return {"valid": not problems, "problems": problems,
                "events": audit.get("events", 0),
                "state_digest": _digest(self._state_without_audit())}

    def _state_without_audit(self) -> dict:
        return {
            "campaign_id": self.campaign_id, "purpose": self.purpose,
            "host_process": self.host_process,
            "process_profile_digest": self.process_profile_digest,
            "author": self.author, "created_at": self.created_at,
            "candidates": {k: asdict(v) for k, v in self.candidates.items()},
            "workloads": {k: asdict(v) for k, v in self.workloads.items()},
            "benchmarks": {k: asdict(v) for k, v in self.benchmarks.items()},
            "observations": {k: asdict(v) for k, v in self.observations.items()},
            "formal_contracts": {k: asdict(v) for k, v in self.formal_contracts.items()},
            "refinements": {k: asdict(v) for k, v in self.refinements.items()},
            "allocations": {k: asdict(v) for k, v in self.allocations.items()},
            "assessments": {k: asdict(v) for k, v in self.assessments.items()},
            "decisions": {k: asdict(v) for k, v in self.decisions.items()},
            "migration_slices": {k: asdict(v) for k, v in self.migration_slices.items()},
            "external_evidence": self.external_evidence,
        }

    def to_dict(self) -> dict:
        return {**self._state_without_audit(), "audit": self.audit.to_dict()}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "SubstrateCampaign":
        obj = cls.__new__(cls)
        obj.campaign_id = str(raw["campaign_id"])
        obj.purpose = str(raw["purpose"])
        obj.host_process = str(raw["host_process"])
        obj.process_profile_digest = str(raw["process_profile_digest"])
        obj.author = str(raw["author"])
        obj.created_at = float(raw.get("created_at", 0.0))
        obj.candidates = {k: SubstrateCandidate(**_tuple_candidate(v)) for k, v in dict(raw.get("candidates", {})).items()}
        obj.workloads = {k: WorkloadContract(**_tuple_workload(v)) for k, v in dict(raw.get("workloads", {})).items()}
        obj.benchmarks = {k: BenchmarkCommitment(**_tuple_benchmark(v)) for k, v in dict(raw.get("benchmarks", {})).items()}
        obj.observations = {k: BenchmarkObservation(**dict(v)) for k, v in dict(raw.get("observations", {})).items()}
        obj.formal_contracts = {k: FormalContract(**_tuple_formal(v)) for k, v in dict(raw.get("formal_contracts", {})).items()}
        obj.refinements = {k: RefinementRecord(**dict(v)) for k, v in dict(raw.get("refinements", {})).items()}
        obj.allocations = {k: ExperimentAllocation(**dict(v)) for k, v in dict(raw.get("allocations", {})).items()}
        obj.assessments = {k: CandidateAssessment(**_tuple_assessment(v)) for k, v in dict(raw.get("assessments", {})).items()}
        obj.decisions = {k: LayerDecision(**_tuple_decision(v)) for k, v in dict(raw.get("decisions", {})).items()}
        obj.migration_slices = {k: MigrationSlice(**_tuple_migration(v)) for k, v in dict(raw.get("migration_slices", {})).items()}
        obj.external_evidence = {k: dict(v) for k, v in dict(raw.get("external_evidence", {})).items()}
        obj.audit = EventLog.from_dict(dict(raw.get("audit", {})))
        return obj

    def save(self, path: str | Path) -> None:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        state = self._state_without_audit()
        terminal_matches = False
        if self.audit.events and self.audit.events[-1].type == "snapshot":
            seq = self.audit.events[-1].payload.get("snapshot_seq")
            snapshot = self.audit.snapshots.get(seq)
            terminal_matches = snapshot is not None and _digest(snapshot) == _digest(state)
        if not terminal_matches:
            self.audit.snapshot(state)
        target.write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True, allow_nan=False))

    @classmethod
    def load(cls, path: str | Path) -> "SubstrateCampaign":
        return cls.from_dict(json.loads(Path(path).read_text()))


def _tuples(raw: Mapping[str, object], keys: Iterable[str]) -> dict:
    out = dict(raw)
    for key in keys:
        out[key] = tuple(out.get(key, ()))
    return out


def _tuple_candidate(raw: Mapping[str, object]) -> dict:
    return _tuples(raw, ("capabilities", "preconditions", "contraindications", "failure_modes", "evidence_roots"))


def _tuple_workload(raw: Mapping[str, object]) -> dict:
    return _tuples(raw, ("required_capabilities", "required_metrics", "hard_invariants", "representative_of", "exclusions"))


def _tuple_benchmark(raw: Mapping[str, object]) -> dict:
    return _tuples(raw, ("candidate_ids",))


def _tuple_formal(raw: Mapping[str, object]) -> dict:
    return _tuples(raw, ("model_scope", "candidate_ids"))


def _tuple_assessment(raw: Mapping[str, object]) -> dict:
    return _tuples(raw, ("measured_workloads", "missing_workloads", "failed_invariants", "failed_formal_contracts", "evidence_roots"))


def _tuple_decision(raw: Mapping[str, object]) -> dict:
    return _tuples(raw, ("candidate_ids", "frontier_ids", "retained_baseline_ids", "experimental_slice_ids", "rejected_ids"))


def _tuple_migration(raw: Mapping[str, object]) -> dict:
    return _tuples(raw, ("trigger_conditions", "rollback_conditions", "benchmark_ids"))
