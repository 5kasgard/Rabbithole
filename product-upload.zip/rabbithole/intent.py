"""Raw-input to provisional dual-POSIWID contract.

The interpreter is a *proposal faculty*, not an authority.  Its purpose is to
turn vague, precise, mistaken, or underspecified language into a falsifiable
starting contract so the ARC-5 search process has something to attack.  Search
and contact are allowed to revise or reject every proposed field.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Mapping, Sequence, Tuple

from .discovery import POSIWIDContract
from .faculties import FacultyReceipt, ProposalFaculty
from .wal import EventLog


@dataclass
class IntentProposal:
    raw_input: str
    contract: POSIWIDContract
    ambiguities: Tuple[str, ...]
    inferred_assumptions: Tuple[str, ...]
    candidate_claim_classes: Tuple[str, ...]
    search_seed_terms: Tuple[str, ...]
    user_decisions_required: Tuple[str, ...] = ()
    faculty_receipt_id: str = ""
    authority: float = 0.0
    iid: str = field(default_factory=lambda: f"INT{uuid.uuid4().hex[:12]}")

    def validate(self) -> None:
        if not self.raw_input.strip():
            raise ValueError("raw input is required")
        self.contract.validate()
        if self.authority != 0.0:
            raise ValueError("intent proposals cannot carry epistemic authority")


class IntentInterpreter:
    def __init__(self, faculty: ProposalFaculty):
        self.faculty = faculty
        self.proposals: dict[str, IntentProposal] = {}
        self.audit = EventLog()

    @staticmethod
    def schema() -> Mapping[str, object]:
        arr = {"type": "array", "items": {"type": "string"}}
        return {
            "type": "object", "additionalProperties": False,
            "properties": {
                "target": {"type": "string"},
                "local_current": arr, "local_goal": arr,
                "whole_current": arr, "whole_goal": arr,
                "constraints": arr, "anti_goals": arr,
                "success_observations": arr, "failure_observations": arr,
                "scope": {"type": "string"},
                "ambiguities": arr, "inferred_assumptions": arr,
                "candidate_claim_classes": arr, "search_seed_terms": arr,
                "user_decisions_required": arr,
            },
            "required": ["target", "local_current", "local_goal", "whole_current",
                         "whole_goal", "constraints", "anti_goals",
                         "success_observations", "failure_observations", "scope",
                         "ambiguities", "inferred_assumptions", "candidate_claim_classes",
                         "search_seed_terms", "user_decisions_required"],
        }

    def interpret(self, raw_input: str, *, whole_goal_context: Sequence[str] = (),
                  known_constraints: Sequence[str] = ()) -> IntentProposal:
        if not raw_input.strip():
            raise ValueError("raw input is required")
        receipt = self.faculty.propose_json(
            system=("Translate the input into a provisional behavioural contract. Do not select "
                    "architecture, answer the question, or claim truth. Separate observed current "
                    "effects from desired local and whole-system effects. State assumptions, "
                    "ambiguities, success observations, and failure observations so later search "
                    "can falsify the interpretation. All output is a zero-authority proposal."),
            user=json.dumps({"input": raw_input,
                             "whole_goal_context": list(whole_goal_context),
                             "known_constraints": list(known_constraints)}),
            schema=self.schema(),
        )
        raw = receipt.response
        def tup(key: str) -> Tuple[str, ...]:
            return tuple(str(x) for x in raw.get(key, ()))
        contract = POSIWIDContract(
            target=str(raw["target"]),
            local_current=tup("local_current"), local_goal=tup("local_goal"),
            whole_current=tup("whole_current"), whole_goal=tup("whole_goal"),
            constraints=tup("constraints"), anti_goals=tup("anti_goals"),
            success_observations=tup("success_observations"),
            failure_observations=tup("failure_observations"),
            scope=str(raw.get("scope", "")),
        )
        proposal = IntentProposal(
            raw_input=raw_input, contract=contract,
            ambiguities=tup("ambiguities"),
            inferred_assumptions=tup("inferred_assumptions"),
            candidate_claim_classes=tup("candidate_claim_classes"),
            search_seed_terms=tup("search_seed_terms"),
            user_decisions_required=tup("user_decisions_required"),
            faculty_receipt_id=receipt.rid,
        )
        proposal.validate()
        self.proposals[proposal.iid] = proposal
        self.audit.append("intent_proposed", {
            "proposal": asdict(proposal), "faculty_receipt": asdict(receipt),
        })
        return proposal
