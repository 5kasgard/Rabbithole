"""Immutable predeclared capability-gate plan and append-only outcomes."""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, Mapping, Tuple


def _canon(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


@dataclass(frozen=True)
class GateDefinition:
    gate_id: str
    name: str
    criterion: str


@dataclass(frozen=True)
class GateOutcome:
    gate_id: str
    status: str  # pass|fail|partial|blocked
    observed: str
    evidence_ids: Tuple[str, ...] = ()
    mutation_sensitive: bool = False
    scope: str = ""
    created_at: float = field(default_factory=time.time)


class FrozenGatePlan:
    def __init__(self, definitions: Tuple[GateDefinition, ...], *, source_digest: str = ""):
        if len({x.gate_id for x in definitions}) != len(definitions):
            raise ValueError("duplicate gate id")
        self.definitions: Dict[str, GateDefinition] = {x.gate_id: x for x in definitions}
        material = [asdict(self.definitions[k]) for k in sorted(self.definitions)]
        self.plan_digest = hashlib.sha256(_canon(material)).hexdigest()
        if source_digest and source_digest != self.plan_digest:
            raise ValueError("gate definition digest mismatch")
        self.outcomes: Dict[str, list[GateOutcome]] = {}

    @classmethod
    def from_stage3_json(cls, path: str | Path) -> "FrozenGatePlan":
        raw = json.loads(Path(path).read_text())
        definitions = tuple(GateDefinition(str(x["id"]), str(x["name"]), str(x["criterion"]))
                            for x in raw.get("gates", ()))
        return cls(definitions)

    def record(self, outcome: GateOutcome) -> None:
        if outcome.gate_id not in self.definitions:
            raise KeyError("outcome is not in the frozen gate plan")
        if outcome.status not in {"pass", "fail", "partial", "blocked"}:
            raise ValueError("invalid gate status")
        if outcome.status == "pass" and not outcome.evidence_ids:
            raise ValueError("a passed gate requires evidence")
        self.outcomes.setdefault(outcome.gate_id, []).append(outcome)

    def summary(self) -> dict:
        rows = []
        counts = {x: 0 for x in ("unrun", "pass", "fail", "partial", "blocked")}
        for gid in sorted(self.definitions, key=lambda x: int(x[1:]) if x[1:].isdigit() else x):
            definition = self.definitions[gid]
            history = self.outcomes.get(gid, ())
            latest = history[-1] if history else None
            status = latest.status if latest else "unrun"
            counts[status] += 1
            rows.append({"id": gid, "name": definition.name, "criterion": definition.criterion,
                         "status": status, "latest": asdict(latest) if latest else None})
        return {"plan_digest": self.plan_digest, "counts": counts, "gates": rows}

    def verify(self) -> dict:
        material = [asdict(self.definitions[k]) for k in sorted(self.definitions)]
        digest = hashlib.sha256(_canon(material)).hexdigest()
        invalid = [gid for gid, xs in self.outcomes.items()
                   if gid not in self.definitions or any(x.gate_id != gid for x in xs)]
        return {"valid": digest == self.plan_digest and not invalid,
                "plan_digest": self.plan_digest, "invalid": invalid,
                "definitions": len(self.definitions), "outcomes": sum(map(len, self.outcomes.values()))}

    def to_dict(self) -> dict:
        return {"definitions": [asdict(x) for x in self.definitions.values()],
                "plan_digest": self.plan_digest,
                "outcomes": {k: [asdict(x) for x in v] for k, v in self.outcomes.items()}}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "FrozenGatePlan":
        definitions = tuple(GateDefinition(**dict(x)) for x in raw.get("definitions", ()))
        obj = cls(definitions, source_digest=str(raw.get("plan_digest", "")) or None)
        for gid, rows in dict(raw.get("outcomes", {})).items():
            obj.outcomes[str(gid)] = []
            for row in rows:
                d = dict(row); d["evidence_ids"] = tuple(d.get("evidence_ids", ()))
                obj.outcomes[str(gid)].append(GateOutcome(**d))
        return obj
