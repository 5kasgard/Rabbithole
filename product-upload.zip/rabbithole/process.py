"""ARC-5 process controller.

The controller does not invent truth.  It enforces stage gates around an
external proposal faculty and auditable search providers.  Search widens;
deterministic coverage checks and contact reduce.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from .discovery import (
    AbstractionNode, DiscoveryArc, FunctionalDistinction, POSIWIDContract,
    SearchQuery,
)
from .faculties import FacultyReceipt, ProposalFaculty
from .search import ContentStore, SearchProvider, search_into_arc


@dataclass
class SearchEnvelope:
    domain_families: Tuple[str, ...]
    concrete_polarities: Tuple[str, ...] = ("for", "against", "failure", "boundary")
    abstract_polarities: Tuple[str, ...] = ("analogue", "anti_analogue", "counterexample", "boundary")
    min_independent_groups: int = 5
    min_search_waves: int = 2
    novelty_threshold: float = 0.05
    per_query_limit: int = 20
    max_queries: int = 200
    max_evidence_items: int = 2000
    required_followup_categories: Tuple[str, ...] = (
        "replication", "contradiction", "boundary", "hidden_assumption", "alternative"
    )

    def validate(self) -> None:
        if not self.domain_families:
            raise ValueError("search envelope requires domain families")
        if self.min_independent_groups < 1 or self.min_search_waves < 1:
            raise ValueError("coverage minima must be positive")
        if not (0 <= self.novelty_threshold <= 1):
            raise ValueError("novelty threshold must be in [0,1]")
        if not self.required_followup_categories:
            raise ValueError("at least one follow-up category is required")


@dataclass
class StageGate:
    stage: str
    passed: bool
    reasons: Tuple[str, ...]
    observations: Mapping[str, object] = field(default_factory=dict)


class ARC5Controller:
    def __init__(self, arc: DiscoveryArc, envelope: SearchEnvelope,
                 providers: Mapping[str, SearchProvider],
                 *, store: Optional[ContentStore] = None,
                 faculty: Optional[ProposalFaculty] = None):
        envelope.validate()
        self.arc = arc
        self.envelope = envelope
        self.providers = dict(providers)
        self.store = store
        self.faculty = faculty
        self.faculty_receipts: List[FacultyReceipt] = []

    @staticmethod
    def seed_queries(contract: POSIWIDContract) -> List[dict]:
        """Generate a minimum contrastive concrete search set.

        These templates do not replace semantic proposal.  They guarantee that
        every arc begins with solution, failure, boundary and counter-position
        searches rather than a single confirmation query.
        """
        target = contract.target
        goal = "; ".join(contract.local_goal + contract.whole_goal)
        current = "; ".join(contract.local_current + contract.whole_current)
        return [
            {"text": f"{target} mechanisms existing systems empirical evaluation", "polarity": "for"},
            {"text": f"{target} failures limitations negative results", "polarity": "failure"},
            {"text": f"alternatives to {target} critique counterexample", "polarity": "against"},
            {"text": f"{target} impossibility lower bounds boundary conditions", "polarity": "boundary"},
            {"text": f"systems currently doing: {current}", "polarity": "neutral"},
            {"text": f"systems producing observable effect: {goal}", "polarity": "for"},
        ]

    def run_search(self, *, provider: str, text: str, stage: str,
                   polarity: str, wave: int, domain_family: str = "",
                   abstraction_id: str = "", parent_query_id: str = "",
                   rationale: str = "") -> dict:
        if provider not in self.providers:
            raise KeyError(f"unknown search provider {provider!r}")
        if len(self.arc.queries) >= self.envelope.max_queries:
            raise RuntimeError("search query budget exhausted")
        if len(self.arc.evidence) >= self.envelope.max_evidence_items:
            raise RuntimeError("evidence item budget exhausted")
        return search_into_arc(
            self.arc, self.providers[provider], text=text, stage=stage,
            polarity=polarity, wave=wave, limit=self.envelope.per_query_limit,
            abstraction_id=abstraction_id, domain_family=domain_family,
            parent_query_id=parent_query_id, rationale=rationale, store=self.store,
        )

    def concrete_gate(self) -> StageGate:
        evidence = [e for e in self.arc.evidence.values() if e.state != "screened_out"]
        polarities = {e.polarity for e in evidence}
        groups = {e.independence_group for e in evidence}
        reasons = []
        missing = set(self.envelope.concrete_polarities) - polarities
        if missing:
            reasons.append(f"missing concrete polarities: {', '.join(sorted(missing))}")
        if len(groups) < self.envelope.min_independent_groups:
            reasons.append(f"only {len(groups)} independent evidence groups")
        concrete_queries = [q for q in self.arc.queries.values() if q.stage == "concrete"]
        if not concrete_queries:
            reasons.append("no concrete searches recorded")
        waves = {q.wave for q in concrete_queries if any(e.query_id == q.qid for e in evidence)}
        if len(waves) < self.envelope.min_search_waves:
            reasons.append(f"only {len(waves)} evidence-bearing concrete search waves")
        followup_categories = {q.rationale.split(":", 1)[0] for q in concrete_queries
                               if q.parent_query_id and ":" in q.rationale}
        if self.envelope.min_search_waves > 1:
            missing_followups = set(self.envelope.required_followup_categories) - followup_categories
            if missing_followups:
                reasons.append("missing concrete follow-up categories: " +
                               ", ".join(sorted(missing_followups)))
        return StageGate("concrete", not reasons, tuple(reasons), {
            "evidence": len(evidence), "polarities": sorted(polarities),
            "independent_groups": len(groups), "waves": sorted(waves),
            "followup_categories": sorted(followup_categories),
        })

    def propose_followups(self, stage: str, *, next_wave: int) -> FacultyReceipt:
        """Propose compounding searches for and against the current evidence field.

        This is the coverage-control correction to the original ARC gate.  The
        faculty may propose queries, but each must be rooted in an existing query
        and assigned a required adversarial category.  Provider execution remains
        separate and auditable.
        """
        if self.faculty is None:
            raise RuntimeError("no proposal faculty configured")
        if stage not in {"concrete", "abstract"}:
            raise ValueError("follow-ups are supported only for concrete/abstract search")
        existing = [e for e in self.arc.evidence.values()
                    if self.arc.queries[e.query_id].stage == stage and e.state != "screened_out"]
        if not existing:
            raise RuntimeError(f"no {stage} evidence exists for follow-up")
        categories = tuple(self.envelope.required_followup_categories)
        allowed_polarities = (self.envelope.concrete_polarities if stage == "concrete"
                              else self.envelope.abstract_polarities)
        schema = {
            "type": "object", "additionalProperties": False,
            "properties": {"queries": {"type": "array", "items": {
                "type": "object", "additionalProperties": False,
                "properties": {
                    "text": {"type": "string"},
                    "category": {"type": "string", "enum": list(categories)},
                    "polarity": {"type": "string", "enum": list(allowed_polarities)},
                    "parent_query_id": {"type": "string"},
                    "domain_family": {"type": "string"},
                    "abstraction_id": {"type": "string"},
                    "rationale": {"type": "string"},
                },
                "required": ["text", "category", "polarity", "parent_query_id",
                             "domain_family", "abstraction_id", "rationale"],
            }}}, "required": ["queries"],
        }
        evidence = [{"eid": e.eid, "query_id": e.query_id, "title": e.title,
                     "summary": e.summary, "polarity": e.polarity,
                     "domain": e.domain_family, "independence_group": e.independence_group}
                    for e in existing]
        receipt = self.faculty.propose_json(
            system=("Propose compounding search queries, not conclusions. Cover every required "
                    "category: replication, contradiction, boundary, hidden assumption, and "
                    "alternative. Root each query in an existing query id. Search for evidence "
                    "that could overturn the current framing. Avoid paraphrase-only queries."),
            user=json.dumps({"stage": stage, "wave": next_wave,
                             "required_categories": categories,
                             "allowed_polarities": allowed_polarities,
                             "evidence": evidence}), schema=schema)
        seen_categories = set()
        for raw in receipt.response.get("queries", []):
            parent = str(raw["parent_query_id"])
            if parent not in self.arc.queries:
                raise KeyError(f"unknown follow-up parent query {parent!r}")
            category = str(raw["category"])
            if category not in categories:
                raise ValueError(f"unsupported follow-up category {category!r}")
            abstraction_id = str(raw.get("abstraction_id", ""))
            if stage == "concrete":
                abstraction_id = ""
            self.arc.add_query(SearchQuery(
                text=str(raw["text"]), stage=stage, polarity=str(raw["polarity"]),
                provider="unassigned", wave=next_wave,
                abstraction_id=abstraction_id,
                domain_family=str(raw.get("domain_family", "")),
                parent_query_id=parent,
                rationale=f"{category}: {raw.get('rationale', '')}",
            ))
            seen_categories.add(category)
        missing = set(categories) - seen_categories
        if missing:
            raise ValueError("faculty omitted required follow-up categories: " +
                             ", ".join(sorted(missing)))
        self.faculty_receipts.append(receipt)
        self.arc.audit.append("faculty_proposed_followups", asdict(receipt) |
                              {"stage": stage, "wave": next_wave})
        return receipt

    def propose_exposure(self) -> FacultyReceipt:
        if self.faculty is None:
            raise RuntimeError("no proposal faculty configured")
        gate = self.concrete_gate()
        if not gate.passed:
            raise RuntimeError("concrete coverage gate failed: " + "; ".join(gate.reasons))
        evidence = [{"eid": e.eid, "title": e.title, "summary": e.summary,
                     "polarity": e.polarity, "domain": e.domain_family}
                    for e in self.arc.evidence.values() if e.state != "screened_out"]
        schema = {
            "type": "object", "additionalProperties": False,
            "properties": {"distinctions": {"type": "array", "items": {
                "type": "object", "additionalProperties": False,
                "properties": {
                    "collapsed_claim": {"type": "string"},
                    "dimensions": {"type": "array", "items": {"type": "string"}},
                    "functions": {"type": "array", "items": {"type": "string"}},
                    "interfaces": {"type": "array", "items": {"type": "string"}},
                    "authority_effects": {"type": "array", "items": {"type": "string"}},
                    "resource_flows": {"type": "array", "items": {"type": "string"}},
                    "failure_propagation": {"type": "array", "items": {"type": "string"}},
                    "evidence_ids": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["collapsed_claim", "dimensions", "functions", "interfaces",
                             "authority_effects", "resource_flows", "failure_propagation",
                             "evidence_ids"],
            }}}, "required": ["distinctions"],
        }
        receipt = self.faculty.propose_json(
            system=("You are a propose-only functional analyst. Expose independently failing "
                    "functions and interfaces. Do not choose architecture or claim truth. "
                    "Every distinction must cite supplied evidence ids."),
            user=json.dumps({"contract": asdict(self.arc.contract), "evidence": evidence}),
            schema=schema,
        )
        for raw in receipt.response.get("distinctions", []):
            self.arc.add_distinction(FunctionalDistinction(
                collapsed_claim=str(raw["collapsed_claim"]),
                dimensions=tuple(raw["dimensions"]), functions=tuple(raw["functions"]),
                interfaces=tuple(raw["interfaces"]),
                authority_effects=tuple(raw["authority_effects"]),
                resource_flows=tuple(raw["resource_flows"]),
                failure_propagation=tuple(raw["failure_propagation"]),
                evidence_ids=tuple(raw["evidence_ids"]),
            ))
        self.faculty_receipts.append(receipt)
        self.arc.audit.append("faculty_proposed_exposure", asdict(receipt))
        return receipt

    def exposure_gate(self) -> StageGate:
        reasons = []
        if not self.arc.distinctions:
            reasons.append("no functional distinctions recorded")
        for d in self.arc.distinctions.values():
            if not d.functions:
                reasons.append(f"distinction {d.did} has no functions")
            if not d.evidence_ids:
                reasons.append(f"distinction {d.did} is not evidence-linked")
        return StageGate("expose", not reasons, tuple(reasons), {
            "distinctions": len(self.arc.distinctions),
            "interfaces": sum(len(d.interfaces) for d in self.arc.distinctions.values()),
        })

    def abstraction_gate(self) -> StageGate:
        reasons = []
        levels = {a.level for a in self.arc.abstractions.values()}
        if len(levels) < 2:
            reasons.append("fewer than two abstraction levels")
        for a in self.arc.abstractions.values():
            if not a.translation_back or not a.failure_if_mistranslated:
                reasons.append(f"abstraction {a.aid} lacks translation-back falsifier")
        abstract_evidence = [e for e in self.arc.evidence.values()
                             if self.arc.queries[e.query_id].stage == "abstract"
                             and e.state != "screened_out"]
        polarities = {e.polarity for e in abstract_evidence}
        missing = set(self.envelope.abstract_polarities) - polarities
        if missing:
            reasons.append(f"missing abstract polarities: {', '.join(sorted(missing))}")
        domains = {e.domain_family for e in abstract_evidence if e.domain_family}
        absent_domains = set(self.envelope.domain_families) - domains
        if absent_domains:
            reasons.append(f"unsearched domain families: {', '.join(sorted(absent_domains))}")
        abstract_queries = [q for q in self.arc.queries.values() if q.stage == "abstract"]
        waves = {q.wave for q in abstract_queries if any(e.query_id == q.qid for e in abstract_evidence)}
        if len(waves) < self.envelope.min_search_waves:
            reasons.append(f"only {len(waves)} evidence-bearing abstract search waves")
        followup_categories = {q.rationale.split(":", 1)[0] for q in abstract_queries
                               if q.parent_query_id and ":" in q.rationale}
        if self.envelope.min_search_waves > 1:
            missing_followups = set(self.envelope.required_followup_categories) - followup_categories
            if missing_followups:
                reasons.append("missing abstract follow-up categories: " +
                               ", ".join(sorted(missing_followups)))
        return StageGate("abstract", not reasons, tuple(reasons), {
            "levels": sorted(levels), "abstract_evidence": len(abstract_evidence),
            "domains": sorted(domains), "polarities": sorted(polarities),
            "waves": sorted(waves), "followup_categories": sorted(followup_categories),
        })

    def reduction_gate(self) -> StageGate:
        reasons = []
        if not self.arc.mechanisms:
            reasons.append("no mechanism hypotheses")
        for m in self.arc.mechanisms.values():
            if not m.evidence_for or not m.evidence_against:
                reasons.append(f"mechanism {m.mid} lacks for/against evidence")
            if not m.work_relocated_to:
                reasons.append(f"mechanism {m.mid} has no work-relocation account")
            if not m.falsifier:
                reasons.append(f"mechanism {m.mid} has no falsifier")
            if not m.local_posiwid_effect or not m.whole_posiwid_effect:
                reasons.append(f"mechanism {m.mid} lacks dual POSIWID effects")
        if len(self.arc.systems) < 2:
            reasons.append("fewer than two competing system hypotheses")
        return StageGate("reduce", not reasons, tuple(reasons), {
            "mechanisms": len(self.arc.mechanisms), "systems": len(self.arc.systems),
        })

    def contact_gate(self) -> StageGate:
        reasons = []
        if not self.arc.tests:
            reasons.append("no discriminating tests")
        public = [t for t in self.arc.tests.values() if t.public_surface]
        if not public:
            reasons.append("no public-surface test")
        groups = {t.independence_group for t in self.arc.tests.values() if t.independence_group}
        if len(groups) < 2:
            reasons.append("tests lack independent contact paths")
        return StageGate("contact", not reasons, tuple(reasons), {
            "tests": len(self.arc.tests), "public_surface": len(public),
            "independent_test_groups": len(groups),
        })

    def process_status(self) -> dict:
        gates = [self.concrete_gate(), self.exposure_gate(), self.abstraction_gate(),
                 self.reduction_gate(), self.contact_gate()]
        return {"arc": self.arc.posiwid(),
                "gates": [asdict(g) for g in gates],
                "ready": all(g.passed for g in gates),
                "faculty_receipts": len(self.faculty_receipts)}

    def propose_abstractions(self) -> FacultyReceipt:
        if self.faculty is None:
            raise RuntimeError("no proposal faculty configured")
        gate = self.exposure_gate()
        if not gate.passed:
            raise RuntimeError("exposure gate failed: " + "; ".join(gate.reasons))
        schema = {
            "type": "object", "additionalProperties": False,
            "properties": {"abstractions": {"type": "array", "items": {
                "type": "object", "additionalProperties": False,
                "properties": {
                    "statement": {"type": "string"}, "level": {"type": "integer", "minimum": 0},
                    "parent_index": {"type": "integer", "minimum": -1},
                    "removed_incidentals": {"type": "array", "items": {"type": "string"}},
                    "retained_function": {"type": "string"},
                    "retained_constraints": {"type": "array", "items": {"type": "string"}},
                    "search_terms": {"type": "array", "items": {"type": "string"}},
                    "translation_back": {"type": "string"},
                    "failure_if_mistranslated": {"type": "string"},
                    "domain_queries": {"type": "array", "items": {
                        "type": "object", "additionalProperties": False,
                        "properties": {"domain": {"type": "string"},
                                       "polarity": {"type": "string"},
                                       "query": {"type": "string"}},
                        "required": ["domain", "polarity", "query"]}},
                },
                "required": ["statement", "level", "parent_index", "removed_incidentals",
                             "retained_function", "retained_constraints", "search_terms",
                             "translation_back", "failure_if_mistranslated", "domain_queries"],
            }}}, "required": ["abstractions"],
        }
        receipt = self.faculty.propose_json(
            system=("Build an abstraction lattice from function, not metaphor. Each abstraction "
                    "must state what incidental detail was removed, what causal function and "
                    "constraints remain, how it translates back, and how a false analogy would "
                    "fail. Generate positive and negative searches across heterogeneous domains."),
            user=json.dumps({"contract": asdict(self.arc.contract),
                             "distinctions": [asdict(x) for x in self.arc.distinctions.values()],
                             "domain_families": self.envelope.domain_families,
                             "allowed_polarities": self.envelope.abstract_polarities}),
            schema=schema,
        )
        raw_nodes = list(receipt.response.get("abstractions", []))
        ids: List[str] = []
        for i, raw in enumerate(raw_nodes):
            parent_index = int(raw.get("parent_index", -1))
            parent_id = ids[parent_index] if 0 <= parent_index < len(ids) else ""
            aid = self.arc.add_abstraction(AbstractionNode(
                statement=str(raw["statement"]), level=int(raw["level"]),
                parent_id=parent_id,
                removed_incidentals=tuple(raw["removed_incidentals"]),
                retained_function=str(raw["retained_function"]),
                retained_constraints=tuple(raw["retained_constraints"]),
                search_terms=tuple(raw["search_terms"]),
                translation_back=str(raw["translation_back"]),
                failure_if_mistranslated=str(raw["failure_if_mistranslated"]),
            ))
            ids.append(aid)
            for q in raw.get("domain_queries", []):
                polarity = str(q["polarity"])
                if polarity not in self.envelope.abstract_polarities:
                    raise ValueError(f"faculty proposed disallowed abstract polarity {polarity!r}")
                self.arc.add_query(SearchQuery(
                    text=str(q["query"]), stage="abstract", polarity=polarity,
                    provider="unassigned", wave=1, abstraction_id=aid,
                    domain_family=str(q["domain"]),
                    rationale="proposal awaiting provider execution",
                ))
        self.faculty_receipts.append(receipt)
        self.arc.audit.append("faculty_proposed_abstractions", asdict(receipt))
        return receipt

    def pending_queries(self) -> List[SearchQuery]:
        """Queries proposed by a faculty but not yet executed by a provider."""
        completed = {e.query_id for e in self.arc.evidence.values()}
        return [q for q in self.arc.queries.values()
                if q.provider == "unassigned" and q.qid not in completed]

    def execute_pending_query(self, qid: str, provider: str, *, wave: Optional[int] = None) -> dict:
        q = self.arc.queries[qid]
        if q.provider != "unassigned":
            raise ValueError("query is not pending provider assignment")
        # Preserve the proposal query as lineage and create an executable child.
        return self.run_search(provider=provider, text=q.text, stage=q.stage,
                               polarity=q.polarity, wave=q.wave if wave is None else wave,
                               domain_family=q.domain_family,
                               abstraction_id=q.abstraction_id,
                               parent_query_id=q.qid,
                               rationale="execution of faculty-proposed query")

    def propose_reduction(self) -> FacultyReceipt:
        """Propose examples, mechanisms, competing systems and decisive tests.

        The response is ingested as hypotheses only.  It cannot mark a mechanism
        surviving or record a test result.
        """
        if self.faculty is None:
            raise RuntimeError("no proposal faculty configured")
        gate = self.abstraction_gate()
        if not gate.passed:
            raise RuntimeError("abstraction gate failed: " + "; ".join(gate.reasons))
        schema = {
            "type": "object", "additionalProperties": False,
            "properties": {
                "examples": {"type": "array", "items": {"type": "object"}},
                "mechanisms": {"type": "array", "items": {"type": "object"}},
                "systems": {"type": "array", "items": {"type": "object"}},
                "tests": {"type": "array", "items": {"type": "object"}},
            }, "required": ["examples", "mechanisms", "systems", "tests"],
        }
        evidence = [{"eid": e.eid, "title": e.title, "summary": e.summary,
                     "polarity": e.polarity, "domain": e.domain_family,
                     "independence_group": e.independence_group}
                    for e in self.arc.evidence.values() if e.state != "screened_out"]
        receipt = self.faculty.propose_json(
            system=("Reduce, do not brainstorm. Cluster cases by causal operation, retain "
                    "conditional mechanisms only when supported by positive and negative cases, "
                    "state where work moves, construct at least two strongest competing system "
                    "compositions, and propose tests whose outcomes move weight between them. "
                    "Never report a contact result."),
            user=json.dumps({"contract": asdict(self.arc.contract),
                             "abstractions": [asdict(x) for x in self.arc.abstractions.values()],
                             "evidence": evidence,
                             "required_fields": {
                                 "example": ["abstraction_id", "name", "outcome", "context",
                                             "observed_mechanisms", "evidence_ids", "boundaries"],
                                 "mechanism": ["function", "mechanism", "contexts",
                                               "predicted_effects", "evidence_for", "evidence_against",
                                               "positive_example_indexes", "negative_example_indexes",
                                               "substitutes", "required_substrate", "work_relocated_to",
                                               "local_posiwid_effect", "whole_posiwid_effect",
                                               "failure_modes", "scope_limits", "falsifier"],
                                 "system": ["name", "mechanism_indexes", "composition",
                                            "local_predictions", "whole_predictions", "assumptions",
                                            "expected_failures", "substrate_assignments"],
                                 "test": ["target_type", "target_index", "question", "method",
                                          "outcome_if_a", "outcome_if_b", "contact_type",
                                          "independence_group", "expected_information_gain",
                                          "downstream_impact", "contact_quality", "cost",
                                          "reversible", "public_surface"]}}),
            schema=schema,
        )
        # Lazy imports keep the process model readable and avoid circularity.
        from .discovery import ExampleCase, MechanismHypothesis, SystemHypothesis, TestObligation
        example_ids: List[str] = []
        for raw in receipt.response.get("examples", []):
            xid = self.arc.add_example(ExampleCase(
                abstraction_id=str(raw["abstraction_id"]), name=str(raw["name"]),
                outcome=str(raw["outcome"]), context=tuple(raw.get("context", ())),
                observed_mechanisms=tuple(raw.get("observed_mechanisms", ())),
                evidence_ids=tuple(raw.get("evidence_ids", ())),
                boundary_conditions=tuple(raw.get("boundaries", ())),
                costs=dict(raw.get("costs", {})), notes=str(raw.get("notes", "")),
            ))
            example_ids.append(xid)
        mechanism_ids: List[str] = []
        for raw in receipt.response.get("mechanisms", []):
            positives = tuple(example_ids[i] for i in raw.get("positive_example_indexes", [])
                              if 0 <= int(i) < len(example_ids))
            negatives = tuple(example_ids[i] for i in raw.get("negative_example_indexes", [])
                              if 0 <= int(i) < len(example_ids))
            mid = self.arc.add_mechanism(MechanismHypothesis(
                function=str(raw["function"]), mechanism=str(raw["mechanism"]),
                contexts=tuple(raw.get("contexts", ())),
                predicted_effects=tuple(raw.get("predicted_effects", ())),
                evidence_for=tuple(raw.get("evidence_for", ())),
                evidence_against=tuple(raw.get("evidence_against", ())),
                positive_cases=positives, negative_cases=negatives,
                substitutes=tuple(raw.get("substitutes", ())),
                required_substrate=tuple(raw.get("required_substrate", ())),
                work_relocated_to=tuple(raw.get("work_relocated_to", ())),
                local_posiwid_effect=tuple(raw.get("local_posiwid_effect", ())),
                whole_posiwid_effect=tuple(raw.get("whole_posiwid_effect", ())),
                failure_modes=tuple(raw.get("failure_modes", ())),
                scope_limits=tuple(raw.get("scope_limits", ())),
                falsifier=str(raw.get("falsifier", "")), state="candidate",
            ))
            mechanism_ids.append(mid)
        system_ids: List[str] = []
        for raw in receipt.response.get("systems", []):
            mids = tuple(mechanism_ids[int(i)] for i in raw.get("mechanism_indexes", [])
                         if 0 <= int(i) < len(mechanism_ids))
            sid = self.arc.add_system_hypothesis(SystemHypothesis(
                name=str(raw["name"]), mechanism_ids=mids,
                composition=tuple(raw.get("composition", ())),
                local_predictions=tuple(raw.get("local_predictions", ())),
                whole_predictions=tuple(raw.get("whole_predictions", ())),
                assumptions=tuple(raw.get("assumptions", ())),
                expected_failures=tuple(raw.get("expected_failures", ())),
                substrate_assignments=dict(raw.get("substrate_assignments", {})),
            ))
            system_ids.append(sid)
        for raw in receipt.response.get("tests", []):
            typ = str(raw["target_type"])
            idx = int(raw["target_index"])
            targets = mechanism_ids if typ == "mechanism" else system_ids if typ == "system" else []
            if not 0 <= idx < len(targets):
                raise ValueError("test target index is invalid")
            self.arc.add_test(TestObligation(
                target_type=typ, target_id=targets[idx], question=str(raw["question"]),
                method=str(raw["method"]), outcome_if_a=str(raw["outcome_if_a"]),
                outcome_if_b=str(raw["outcome_if_b"]), contact_type=str(raw["contact_type"]),
                independence_group=str(raw["independence_group"]),
                expected_information_gain=float(raw["expected_information_gain"]),
                downstream_impact=float(raw["downstream_impact"]),
                contact_quality=float(raw["contact_quality"]),
                cost=dict(raw.get("cost", {})), reversible=bool(raw.get("reversible", True)),
                public_surface=str(raw.get("public_surface", "")),
            ))
        self.faculty_receipts.append(receipt)
        self.arc.audit.append("faculty_proposed_reduction", asdict(receipt))
        return receipt
