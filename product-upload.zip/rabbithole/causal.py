"""Causal-model contracts and conservative graphical identification.

Identification is not empirical support for an effect.  It establishes only
that an estimand is recoverable from a declared causal model and assumptions.
Effect estimation and external validation require separate contracts.
"""
from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Tuple

import networkx as nx


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:11]}"


@dataclass
class CausalModel:
    nodes: Tuple[str, ...]
    edges: Tuple[Tuple[str, str], ...]
    observed: Tuple[str, ...]
    assumptions: Tuple[str, ...] = ()
    population: str = ""
    valid_conditions: Mapping[str, object] = field(default_factory=dict)
    mid: str = field(default_factory=lambda: _id("CM"))


@dataclass
class CausalClaim:
    model_id: str
    treatment: str
    outcome: str
    adjustment: Tuple[str, ...] = ()
    intervention: str = "do"
    estimand: str = "average_treatment_effect"
    target_population: str = ""
    cid: str = field(default_factory=lambda: _id("CC"))


@dataclass
class IdentificationResult:
    claim_id: str
    identified: bool
    method: str
    adjustment: Tuple[str, ...]
    reasons: Tuple[str, ...]
    assumptions: Tuple[str, ...]
    formula: str
    epistemic_authority: float = 0.0


class CausalRegistry:
    def __init__(self):
        self.models: Dict[str, CausalModel] = {}
        self.results: Dict[str, IdentificationResult] = {}

    def register(self, model: CausalModel) -> str:
        graph = nx.DiGraph()
        graph.add_nodes_from(model.nodes)
        graph.add_edges_from(model.edges)
        if not nx.is_directed_acyclic_graph(graph):
            raise ValueError("causal model must be a DAG")
        if not set(model.observed) <= set(model.nodes):
            raise ValueError("observed variables must be model nodes")
        self.models[model.mid] = model
        return model.mid

    def identify_backdoor(self, claim: CausalClaim) -> IdentificationResult:
        if claim.model_id not in self.models:
            raise KeyError(claim.model_id)
        model = self.models[claim.model_id]
        graph = nx.DiGraph()
        graph.add_nodes_from(model.nodes)
        graph.add_edges_from(model.edges)
        reasons = []
        if claim.treatment not in model.nodes or claim.outcome not in model.nodes:
            raise KeyError("claim nodes are absent")
        if claim.treatment == claim.outcome:
            reasons.append("treatment and outcome are identical")
        adjustment = set(claim.adjustment)
        descendants = nx.descendants(graph, claim.treatment)
        if adjustment & descendants:
            reasons.append("adjustment contains a descendant of treatment")
        if not adjustment <= set(model.observed):
            reasons.append("adjustment contains unobserved variables")
        if claim.treatment not in model.observed or claim.outcome not in model.observed:
            reasons.append("treatment or outcome is not observed")
        # Back-door graph removes arrows leaving X. Z must d-separate X and Y.
        backdoor = graph.copy()
        backdoor.remove_edges_from(list(graph.out_edges(claim.treatment)))
        try:
            separated = nx.is_d_separator(backdoor, {claim.treatment}, {claim.outcome}, adjustment)
        except AttributeError:
            from networkx.algorithms.d_separation import is_d_separator
            separated = is_d_separator(backdoor, {claim.treatment}, {claim.outcome}, adjustment)
        if not separated:
            reasons.append("adjustment does not block every back-door path")
        if claim.target_population and model.population and claim.target_population != model.population:
            reasons.append("transport to the target population is not identified")
        identified = not reasons
        formula = ""
        if identified:
            z = ",".join(sorted(adjustment))
            formula = (f"sum_{{{z}}} E[{claim.outcome}|{claim.treatment},{z}] P({z})"
                       if adjustment else f"E[{claim.outcome}|{claim.treatment}]")
        result = IdentificationResult(
            claim.cid, identified, "back-door", tuple(sorted(adjustment)),
            tuple(reasons), tuple(model.assumptions), formula, 0.0,
        )
        self.results[claim.cid] = result
        return result

    def to_dict(self) -> dict:
        return {"models": [asdict(x) for x in self.models.values()],
                "results": [asdict(x) for x in self.results.values()]}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "CausalRegistry":
        obj = cls()
        for row in raw.get("models", []):
            d = dict(row)
            for key in ("nodes", "edges", "observed", "assumptions"):
                d[key] = tuple(tuple(x) if key == "edges" else x for x in d.get(key, ()))
            obj.models[d["mid"]] = CausalModel(**d)
        for row in raw.get("results", []):
            d = dict(row)
            for key in ("adjustment", "reasons", "assumptions"):
                d[key] = tuple(d.get(key, ()))
            obj.results[d["claim_id"]] = IdentificationResult(**d)
        return obj
