"""Auditable search fabric for ARC-5.

Search widens the evidence field.  It never grants epistemic authority.  Every
retrieved item is stored content-addressably, linked to the exact query and
provider, and assigned an explicit independence group so duplicate or derived
sources cannot masquerade as corroboration.

The module contains three real provider classes:

* :class:`LocalCorpusProvider` — dependency-free BM25 search over a directory;
* :class:`CrossrefProvider` — Crossref REST search for scholarly metadata;
* :class:`OpenAlexProvider` — OpenAlex REST search for scholarly metadata.

External providers fail loudly when the network is unavailable.  They are not
replaced by canned results.  HTTP transport is injectable so protocol behaviour
can be tested without claiming that a mocked response is external contact.
"""
from __future__ import annotations

import hashlib
import json
import math
import mimetypes
import os
import re
import time
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable, Dict, Iterable, Iterator, List, Mapping, Optional, Protocol, Sequence, Tuple

from .discovery import DiscoveryArc, EvidenceItem, SearchQuery


class SearchError(RuntimeError):
    """A provider could not execute the requested search."""


class NetworkUnavailable(SearchError):
    """A real external provider could not be reached."""


@dataclass
class SearchResult:
    title: str
    locator: str
    snapshot: str
    summary: str = ""
    authors: Tuple[str, ...] = ()
    published_at: str = ""
    source_type: str = "unknown"
    domain_family: str = ""
    independence_group: str = ""
    tags: Tuple[str, ...] = ()
    provider_metadata: Mapping[str, object] = field(default_factory=dict)
    score: float = 0.0

    @property
    def content_sha256(self) -> str:
        return hashlib.sha256(self.snapshot.encode("utf-8")).hexdigest()


class SearchProvider(Protocol):
    name: str

    def search(self, query: str, *, limit: int = 20) -> Sequence[SearchResult]:
        ...


class ContentStore:
    """Content-addressed immutable artifact store.

    Metadata is stored separately from the bytes.  Re-storing the same content
    returns the same digest, making deduplication independent of URLs and names.
    """

    def __init__(self, root: str | os.PathLike[str]):
        self.root = Path(root)
        self.blobs = self.root / "blobs"
        self.meta = self.root / "metadata"
        self.blobs.mkdir(parents=True, exist_ok=True)
        self.meta.mkdir(parents=True, exist_ok=True)

    def put(self, content: str, metadata: Optional[Mapping[str, object]] = None) -> str:
        digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
        blob = self.blobs / digest
        if blob.exists():
            if blob.read_text(errors="replace") != content:
                raise SearchError("content digest collision")
        else:
            tmp = blob.with_suffix(".tmp")
            tmp.write_text(content)
            os.replace(tmp, blob)
        if metadata is not None:
            path = self.meta / f"{digest}.json"
            old: list[object] = []
            if path.exists():
                raw = json.loads(path.read_text())
                old = raw if isinstance(raw, list) else [raw]
            record = dict(metadata)
            if record not in old:
                old.append(record)
                path.write_text(json.dumps(old, indent=2, sort_keys=True))
        return digest

    def get(self, digest: str) -> str:
        path = self.blobs / digest
        if not path.exists():
            raise KeyError(digest)
        content = path.read_text(errors="replace")
        actual = hashlib.sha256(content.encode("utf-8")).hexdigest()
        if actual != digest:
            raise SearchError(f"stored artifact {digest} failed digest verification")
        return content

    def verify(self) -> dict:
        invalid: list[str] = []
        count = 0
        for path in self.blobs.iterdir():
            if not path.is_file():
                continue
            count += 1
            content = path.read_text(errors="replace")
            if hashlib.sha256(content.encode("utf-8")).hexdigest() != path.name:
                invalid.append(path.name)
        return {"valid": not invalid, "blobs": count, "invalid": invalid}


_TOKEN = re.compile(r"[A-Za-z0-9_]+")


def _tokens(text: str) -> List[str]:
    return [x.lower() for x in _TOKEN.findall(text)]


@dataclass
class _LocalDoc:
    path: str
    title: str
    content: str
    tokens: List[str]
    tf: Counter


class LocalCorpusProvider:
    """Search a real local corpus using Okapi BM25.

    This is intended for project lineage, downloaded papers, source trees and
    offline corpora.  Binary files are skipped rather than silently OCRed or
    invented.  Large text files are indexed as complete documents; callers can
    pre-chunk when passage-level retrieval is required.
    """

    name = "local-corpus"

    def __init__(self, roots: Sequence[str | os.PathLike[str]], *,
                 extensions: Sequence[str] = (
                     ".txt", ".md", ".rst", ".py", ".json", ".jsonl", ".yaml", ".yml",
                     ".toml", ".xml", ".csv", ".tsv", ".html", ".htm", ".jsx", ".js",
                 ), max_bytes: int = 20_000_000,
                 exclude_patterns: Sequence[str] = (),
                 include_patterns: Sequence[str] = ()):
        self.roots = tuple(Path(x).resolve() for x in roots)
        self.extensions = {x.lower() for x in extensions}
        self.max_bytes = int(max_bytes)
        self.exclude_patterns = tuple(str(x).lower() for x in exclude_patterns)
        self.include_patterns = tuple(str(x).lower() for x in include_patterns)
        self._docs: List[_LocalDoc] = []
        self._df: Counter = Counter()
        self._avg_len = 0.0
        self._build()

    def _iter_paths(self) -> Iterator[Path]:
        seen: set[Path] = set()
        for root in self.roots:
            if root.is_file():
                paths = [root]
            elif root.exists():
                paths = (p for p in root.rglob("*") if p.is_file())
            else:
                continue
            for path in paths:
                try:
                    rp = path.resolve()
                    normalized = str(rp).replace("\\", "/").lower()
                    if rp in seen or path.suffix.lower() not in self.extensions:
                        continue
                    if self.exclude_patterns and any(x in normalized for x in self.exclude_patterns):
                        continue
                    if self.include_patterns and not any(x in normalized for x in self.include_patterns):
                        continue
                    if path.stat().st_size > self.max_bytes:
                        continue
                    seen.add(rp)
                    yield path
                except OSError:
                    continue

    def _build(self) -> None:
        for path in self._iter_paths():
            try:
                content = path.read_text(errors="replace")
            except OSError:
                continue
            toks = _tokens(content)
            if not toks:
                continue
            doc = _LocalDoc(str(path), path.name, content, toks, Counter(toks))
            self._docs.append(doc)
            self._df.update(set(toks))
        self._avg_len = (sum(len(d.tokens) for d in self._docs) / len(self._docs)
                         if self._docs else 0.0)

    def search(self, query: str, *, limit: int = 20) -> Sequence[SearchResult]:
        q = _tokens(query)
        if not q or not self._docs:
            return []
        n = len(self._docs)
        k1, b = 1.5, 0.75
        scored: List[Tuple[float, _LocalDoc]] = []
        for d in self._docs:
            score = 0.0
            dl = len(d.tokens)
            for term in q:
                df = self._df.get(term, 0)
                if not df:
                    continue
                idf = math.log(1.0 + (n - df + 0.5) / (df + 0.5))
                tf = d.tf.get(term, 0)
                denom = tf + k1 * (1 - b + b * dl / max(1.0, self._avg_len))
                score += idf * (tf * (k1 + 1) / denom if denom else 0.0)
            if score > 0:
                scored.append((score, d))
        scored.sort(key=lambda x: (-x[0], x[1].path))
        out = []
        for score, d in scored[:max(0, int(limit))]:
            # Store the exact source content, not an LLM-created summary.
            idx = min((d.content.lower().find(t) for t in q if t in d.content.lower()), default=-1)
            start = max(0, idx - 300) if idx >= 0 else 0
            summary = d.content[start:start + 900].replace("\x00", "")
            out.append(SearchResult(
                title=d.title,
                locator=f"file://{d.path}",
                snapshot=d.content,
                summary=summary,
                source_type="local-document",
                domain_family="project-lineage",
                independence_group=f"local-file:{hashlib.sha256(d.path.encode()).hexdigest()[:16]}",
                provider_metadata={"path": d.path},
                score=score,
            ))
        return out


class CatalogProvider:
    """Search a captured, replayable evidence catalog.

    The catalog is useful when external search happened in another trusted
    environment.  Each record must contain the retrieved metadata/snapshot and
    its original locator.  This provider does not claim live retrieval; it makes
    the prior contact replayable and content-addressable.
    """

    name = "evidence-catalog"

    def __init__(self, path: str | os.PathLike[str]):
        self.path = Path(path)
        raw = json.loads(self.path.read_text())
        records = raw.get("records", raw) if isinstance(raw, Mapping) else raw
        if not isinstance(records, list):
            raise ValueError("catalog must be a list or {'records': [...]} object")
        self.records = []
        for row in records:
            if not isinstance(row, Mapping):
                raise ValueError("catalog records must be objects")
            title = str(row.get("title", "")).strip()
            locator = str(row.get("locator", "")).strip()
            snapshot = str(row.get("snapshot", ""))
            if not title or not locator or not snapshot:
                raise ValueError("catalog record requires title, locator and snapshot")
            self.records.append(dict(row))

    def search(self, query: str, *, limit: int = 20) -> Sequence[SearchResult]:
        q = Counter(_tokens(query))
        scored = []
        for row in self.records:
            hay = " ".join(str(row.get(k, "")) for k in
                           ("title", "summary", "snapshot", "domain_family", "tags"))
            terms = Counter(_tokens(hay))
            score = sum(min(count, terms.get(term, 0)) for term, count in q.items())
            if score <= 0:
                continue
            scored.append((score, row))
        scored.sort(key=lambda x: (-x[0], str(x[1].get("title", ""))))
        out = []
        for score, row in scored[:max(0, int(limit))]:
            out.append(SearchResult(
                title=str(row["title"]), locator=str(row["locator"]),
                snapshot=str(row["snapshot"]), summary=str(row.get("summary", "")),
                authors=tuple(row.get("authors", ())),
                published_at=str(row.get("published_at", "")),
                source_type=str(row.get("source_type", "captured-source")),
                domain_family=str(row.get("domain_family", "")),
                independence_group=str(row.get("independence_group", row["locator"])),
                tags=tuple(row.get("tags", ())),
                provider_metadata={"catalog": str(self.path),
                                   **dict(row.get("provider_metadata", {}))},
                score=float(score),
            ))
        return out


HttpGet = Callable[[str, Mapping[str, str], float], bytes]


def _default_http_get(url: str, headers: Mapping[str, str], timeout: float) -> bytes:
    request = urllib.request.Request(url, headers=dict(headers))
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.read()
    except Exception as exc:  # network/environment errors remain explicit
        raise NetworkUnavailable(f"GET {url} failed: {exc}") from exc


class _JsonApiProvider:
    name = "json-api"

    def __init__(self, *, mailto: str = "", timeout: float = 25.0,
                 http_get: Optional[HttpGet] = None):
        self.mailto = mailto
        self.timeout = float(timeout)
        self.http_get = http_get or _default_http_get

    def _get_json(self, url: str) -> object:
        headers = {
            "Accept": "application/json",
            "User-Agent": f"TheField-ARC5/0.7 (+mailto:{self.mailto or 'unspecified'})",
        }
        raw = self.http_get(url, headers, self.timeout)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise SearchError(f"{self.name} returned invalid JSON") from exc


class CrossrefProvider(_JsonApiProvider):
    name = "crossref"

    def search(self, query: str, *, limit: int = 20) -> Sequence[SearchResult]:
        params = {"query.bibliographic": query, "rows": str(max(1, min(100, int(limit))))}
        if self.mailto:
            params["mailto"] = self.mailto
        url = "https://api.crossref.org/works?" + urllib.parse.urlencode(params)
        raw = self._get_json(url)
        items = ((raw or {}).get("message", {}) or {}).get("items", [])
        out: List[SearchResult] = []
        for item in items:
            title = " ".join(item.get("title") or ()) or "Untitled Crossref work"
            doi = str(item.get("DOI") or "")
            locator = f"https://doi.org/{doi}" if doi else str(item.get("URL") or "")
            authors = tuple(" ".join(x for x in (a.get("given", ""), a.get("family", "")) if x)
                            for a in item.get("author", []) if isinstance(a, dict))
            date_parts = (((item.get("published-print") or item.get("published-online") or
                            item.get("issued") or {}).get("date-parts") or [[]])[0])
            published = "-".join(str(x) for x in date_parts)
            container = " ".join(item.get("container-title") or ())
            abstract = re.sub(r"<[^>]+>", " ", str(item.get("abstract") or ""))
            snapshot_obj = {
                "provider": self.name,
                "DOI": doi, "title": title, "authors": authors,
                "published": published, "type": item.get("type", ""),
                "container": container, "abstract": abstract,
                "URL": item.get("URL", ""), "references_count": item.get("reference-count"),
                "is_referenced_by_count": item.get("is-referenced-by-count"),
            }
            snapshot = json.dumps(snapshot_obj, sort_keys=True)
            out.append(SearchResult(
                title=title, locator=locator or f"crossref:{doi}", snapshot=snapshot,
                summary=abstract or container, authors=authors, published_at=published,
                source_type=f"scholarly:{item.get('type', 'work')}",
                independence_group=f"doi:{doi.lower()}" if doi else f"crossref:{locator}",
                provider_metadata={"doi": doi, "container": container},
                score=float(item.get("score") or 0.0),
            ))
        return out


class OpenAlexProvider(_JsonApiProvider):
    name = "openalex"

    def search(self, query: str, *, limit: int = 20) -> Sequence[SearchResult]:
        params = {"search": query, "per-page": str(max(1, min(100, int(limit))))}
        if self.mailto:
            params["mailto"] = self.mailto
        url = "https://api.openalex.org/works?" + urllib.parse.urlencode(params)
        raw = self._get_json(url)
        out: List[SearchResult] = []
        for item in (raw or {}).get("results", []):
            title = str(item.get("display_name") or item.get("title") or "Untitled OpenAlex work")
            doi_url = str(item.get("doi") or "")
            doi = doi_url.removeprefix("https://doi.org/")
            locator = doi_url or str(item.get("id") or "")
            authors = tuple(str(x.get("author", {}).get("display_name", ""))
                            for x in item.get("authorships", []) if x.get("author"))
            abstract_index = item.get("abstract_inverted_index") or {}
            words: List[Tuple[int, str]] = []
            for word, positions in abstract_index.items():
                for pos in positions:
                    words.append((int(pos), str(word)))
            abstract = " ".join(w for _, w in sorted(words))
            source = ((item.get("primary_location") or {}).get("source") or {}).get("display_name", "")
            snapshot_obj = {
                "provider": self.name,
                "id": item.get("id"), "doi": doi, "title": title, "authors": authors,
                "publication_date": item.get("publication_date", ""),
                "type": item.get("type", ""), "source": source,
                "abstract": abstract, "cited_by_count": item.get("cited_by_count"),
                "is_retracted": item.get("is_retracted"),
            }
            snapshot = json.dumps(snapshot_obj, sort_keys=True)
            out.append(SearchResult(
                title=title, locator=locator, snapshot=snapshot,
                summary=abstract or str(source), authors=authors,
                published_at=str(item.get("publication_date") or ""),
                source_type=f"scholarly:{item.get('type', 'work')}",
                independence_group=f"doi:{doi.lower()}" if doi else f"openalex:{item.get('id')}",
                provider_metadata={"openalex_id": item.get("id"), "doi": doi, "source": source},
                score=float(item.get("relevance_score") or 0.0),
            ))
        return out


class CompositeProvider:
    """Run independent providers and retain provider failures explicitly."""

    name = "composite"

    def __init__(self, providers: Sequence[SearchProvider]):
        self.providers = tuple(providers)
        self.failures: List[dict] = []

    def search(self, query: str, *, limit: int = 20) -> Sequence[SearchResult]:
        out: List[SearchResult] = []
        self.failures = []
        for provider in self.providers:
            try:
                out.extend(provider.search(query, limit=limit))
            except SearchError as exc:
                self.failures.append({"provider": provider.name, "query": query, "error": str(exc)})
        # Cross-provider content dedup; preserve highest score.
        best: Dict[str, SearchResult] = {}
        for result in out:
            existing = best.get(result.content_sha256)
            if existing is None or result.score > existing.score:
                best[result.content_sha256] = result
        return sorted(best.values(), key=lambda x: (-x.score, x.title))[:max(0, int(limit))]


def search_into_arc(arc: DiscoveryArc, provider: SearchProvider, *, text: str,
                    stage: str, polarity: str, wave: int, limit: int = 20,
                    abstraction_id: str = "", domain_family: str = "",
                    parent_query_id: str = "", rationale: str = "",
                    store: Optional[ContentStore] = None) -> dict:
    """Execute one search and append its receipts to a discovery arc."""
    query = SearchQuery(text=text, stage=stage, polarity=polarity,
                        provider=provider.name, wave=wave,
                        abstraction_id=abstraction_id,
                        domain_family=domain_family,
                        parent_query_id=parent_query_id, rationale=rationale)
    qid = arc.add_query(query)
    results = provider.search(text, limit=limit)
    eids: List[str] = []
    for result in results:
        if store is not None:
            digest = store.put(result.snapshot, {
                "query_id": qid, "provider": provider.name,
                "locator": result.locator, "retrieved_at": time.time(),
            })
            if digest != result.content_sha256:
                raise SearchError("content store returned inconsistent digest")
        item = EvidenceItem(
            query_id=qid, title=result.title, locator=result.locator,
            provider=provider.name, snapshot=result.snapshot,
            summary=result.summary, authors=result.authors,
            published_at=result.published_at, source_type=result.source_type,
            polarity=polarity, domain_family=(result.domain_family or domain_family),
            independence_group=result.independence_group,
            tags=result.tags, quality={"provider_score": result.score},
        )
        eids.append(arc.add_evidence(item))
    arc.audit.append("search_completed", {
        "qid": qid, "provider": provider.name, "results": len(results),
        "unique_evidence_ids": len(set(eids)),
    })
    return {"qid": qid, "evidence_ids": eids, "results": len(results)}
