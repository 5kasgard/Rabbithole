"""Derivation-aware provenance graph.

A citation string is not enough to reason about independence.  This graph keeps
entities, activities and agents separate, records derivation and invalidation,
and computes root-source families so copies and downstream summaries cannot be
counted as independent corroboration.

The vocabulary is deliberately close to W3C PROV while remaining dependency-free.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Iterable, Mapping, Optional, Sequence, Set, Tuple

from .wal import EventLog


@dataclass
class ProvEntity:
    label: str
    content_sha256: str = ""
    locator: str = ""
    entity_type: str = "artifact"
    generated_by: str = ""
    derived_from: Tuple[str, ...] = ()
    attributed_to: Tuple[str, ...] = ()
    valid_from: float = field(default_factory=time.time)
    invalidated_at: float = 0.0
    invalidation_reason: str = ""
    eid: str = field(default_factory=lambda: f"PEN{uuid.uuid4().hex[:12]}")


@dataclass
class ProvActivity:
    activity_type: str
    used: Tuple[str, ...]
    associated_with: Tuple[str, ...]
    started_at: float
    ended_at: float
    plan: str = ""
    aid: str = field(default_factory=lambda: f"PAC{uuid.uuid4().hex[:12]}")


@dataclass
class ProvAgent:
    label: str
    agent_type: str
    external_id: str = ""
    agid: str = field(default_factory=lambda: f"PAG{uuid.uuid4().hex[:12]}")


class ProvenanceGraph:
    def __init__(self):
        self.entities: Dict[str, ProvEntity] = {}
        self.activities: Dict[str, ProvActivity] = {}
        self.agents: Dict[str, ProvAgent] = {}
        self.audit = EventLog()

    def add_agent(self, agent: ProvAgent) -> str:
        self.agents[agent.agid] = agent
        self.audit.append("prov_agent_added", asdict(agent))
        return agent.agid

    def add_activity(self, activity: ProvActivity) -> str:
        unknown_e = [x for x in activity.used if x not in self.entities]
        unknown_a = [x for x in activity.associated_with if x not in self.agents]
        if unknown_e or unknown_a:
            raise KeyError({"entities": unknown_e, "agents": unknown_a})
        if activity.ended_at < activity.started_at:
            raise ValueError("activity cannot end before it starts")
        self.activities[activity.aid] = activity
        self.audit.append("prov_activity_added", asdict(activity))
        return activity.aid

    def add_entity(self, entity: ProvEntity) -> str:
        unknown = [x for x in entity.derived_from if x not in self.entities]
        unknown_agents = [x for x in entity.attributed_to if x not in self.agents]
        if unknown or unknown_agents:
            raise KeyError({"entities": unknown, "agents": unknown_agents})
        if entity.generated_by and entity.generated_by not in self.activities:
            raise KeyError(entity.generated_by)
        self.entities[entity.eid] = entity
        self.audit.append("prov_entity_added", asdict(entity))
        return entity.eid

    def invalidate(self, eid: str, reason: str) -> None:
        e = self.entities[eid]
        if e.invalidated_at:
            return
        e.invalidated_at = time.time()
        e.invalidation_reason = reason
        self.audit.append("prov_entity_invalidated", {"eid": eid, "reason": reason,
                                                       "at": e.invalidated_at})

    def roots(self, eid: str) -> Set[str]:
        if eid not in self.entities:
            raise KeyError(eid)
        seen: Set[str] = set()

        def walk(x: str) -> Set[str]:
            if x in seen:
                return set()
            seen.add(x)
            parents = self.entities[x].derived_from
            if not parents:
                return {x}
            out: Set[str] = set()
            for p in parents:
                out |= walk(p)
            return out

        return walk(eid)

    def independent(self, a: str, b: str) -> bool:
        return self.roots(a).isdisjoint(self.roots(b))

    def descendants(self, eid: str, active_only: bool = False) -> Set[str]:
        out: Set[str] = set()
        changed = True
        while changed:
            changed = False
            for x, entity in self.entities.items():
                if x in out or x == eid:
                    continue
                if active_only and entity.invalidated_at:
                    continue
                if eid in entity.derived_from or set(entity.derived_from) & out:
                    out.add(x); changed = True
        return out

    def invalidation_impact(self, eid: str) -> dict:
        descendants = self.descendants(eid)
        return {"entity": eid, "direct_or_indirect_descendants": sorted(descendants),
                "count": len(descendants),
                "active_count": sum(not self.entities[x].invalidated_at for x in descendants)}

    def invalidate_cascade(self, eid: str, reason: str) -> dict:
        """Invalidate one entity and every active derivative without deletion.

        Invalidation is lineage maintenance, not a truth verdict: history remains
        inspectable and the reason is attached to each affected entity.  The
        deterministic descendant closure prevents a revoked source from leaving
        apparently live summaries, reports, or decisions downstream.
        """
        if eid not in self.entities:
            raise KeyError(eid)
        affected = [eid] + sorted(self.descendants(eid))
        newly_invalidated = []
        now = time.time()
        for target in affected:
            entity = self.entities[target]
            if entity.invalidated_at:
                continue
            entity.invalidated_at = now
            entity.invalidation_reason = reason if target == eid else f"upstream {eid} invalidated: {reason}"
            newly_invalidated.append(target)
            self.audit.append("prov_entity_invalidated", {
                "eid": target, "root": eid, "reason": entity.invalidation_reason, "at": now,
            })
        receipt = {
            "root": eid,
            "reason": reason,
            "affected": affected,
            "newly_invalidated": newly_invalidated,
            "count": len(newly_invalidated),
        }
        self.audit.append("prov_invalidation_cascade", receipt)
        return receipt

    def verify(self) -> dict:
        errors = []
        for eid, e in self.entities.items():
            for parent in e.derived_from:
                if parent not in self.entities:
                    errors.append(f"{eid} derives from missing {parent}")
            if e.generated_by and e.generated_by not in self.activities:
                errors.append(f"{eid} generated by missing {e.generated_by}")
        # Detect derivation cycles.
        for eid in self.entities:
            stack: Set[str] = set()
            done: Set[str] = set()
            def visit(x: str):
                if x in stack:
                    errors.append(f"derivation cycle at {x}"); return
                if x in done: return
                stack.add(x)
                for p in self.entities[x].derived_from:
                    if p in self.entities: visit(p)
                stack.remove(x); done.add(x)
            visit(eid)
        return {"valid": not errors and self.audit.verify().get("valid", False),
                "errors": errors, "entities": len(self.entities),
                "activities": len(self.activities), "agents": len(self.agents)}

    def to_dict(self) -> dict:
        return {"entities": [asdict(x) for x in self.entities.values()],
                "activities": [asdict(x) for x in self.activities.values()],
                "agents": [asdict(x) for x in self.agents.values()],
                "audit": self.audit.to_dict()}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "ProvenanceGraph":
        g = cls()
        g.entities = {}
        for x in raw.get("entities", []):
            d = dict(x)
            for key in ("derived_from", "attributed_to"):
                d[key] = tuple(d.get(key, ()))
            g.entities[d["eid"]] = ProvEntity(**d)
        g.activities = {}
        for x in raw.get("activities", []):
            d = dict(x)
            for key in ("used", "associated_with"):
                d[key] = tuple(d.get(key, ()))
            g.activities[d["aid"]] = ProvActivity(**d)
        g.agents = {x["agid"]: ProvAgent(**x) for x in raw.get("agents", [])}
        g.audit = EventLog.from_dict(raw.get("audit", {}))
        return g
