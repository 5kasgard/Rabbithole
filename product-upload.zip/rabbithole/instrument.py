"""Public orchestration surface for the currently real organism.

This class is deliberately narrower than the final vision.  It wires the organs
that presently have executable contracts:

* subtractive mechanism discovery (ARC-5);
* content-addressed acquisition/search;
* structured AKBC intake and reversible placement;
* heterogeneous claim verification;
* interval constraint settling;
* audit and organ mutation/coverage reporting.

A capability is absent rather than simulated when no organ can perform it.
"""
from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Mapping, Optional, Sequence

from .akbc import Carving, FieldSystem, metrology_seed
from .argument import ArgumentClaim, ArgumentEvidence, ArgumentGraph, ClaimRelation
from .actions import ActionRegistry, ActionSpec
from .assurance import AssuranceRegistry, CapabilityRequirement, CapabilityCase
from .ecology import EcologyMember, OrganEcology
from .presentation import PresentationInput, Presenter
from .ir import IRRegistry, IRRequirement, core_irs
from .intent import IntentInterpreter, IntentProposal
from .portfolio import MechanismPortfolio, MechanismProfile, PerformanceRecord, TaskShape
from .provenance import ProvActivity, ProvAgent, ProvEntity, ProvenanceGraph
from .discovery import DiscoveryArc, POSIWIDContract
from .faculties import ProposalFaculty
from .field import Field
from .organs import OrganRegistry, OrganSpec
from .process import ARC5Controller, SearchEnvelope
from .arc_kernel import (ARC5Kernel, EligibilityContract, SearchRequirement, ScreeningDecision,
                         EvidenceLineageProfile, TransferCase, MechanismCaseAssessment)
from .arc_campaign import ARC5Campaign
from .arc_adversarial import (ARC5AAdversarialKernel, HostileInterpretation, LaneSearchRequirement,
                              DecompositionPass, DecompositionDisagreement,
                              AbstractionRegistration, ArenaCandidate, ParetoDimension,
                              ParetoAssessment, AdversarialTestPair, DecisionSaturationWave,
                              ContactRecord, LANES, LANE_STAGE)
from .routing import HeterogeneousRouter
from .search import ContentStore, SearchProvider, LocalCorpusProvider, CatalogProvider, CrossrefProvider, OpenAlexProvider
from .scope import ApplicabilityDecision, ModelContract, ModelRegistry
from .verification import (
    Claim, RegisteredVerifier, VerificationContract, VerificationRegistry,
    VerificationRequest, VerificationResult, core_contracts,
)
from .wal import EventLog
from .acquisition import AcquisitionEngine, FetchPolicy
from .inquiry import InquiryEngine, InquiryRequest
from .waist import ContractStore
from .components import ComponentRegistry
from .goal import GoalGate, GoalRequest
from .calibration import CalibrationRegistry, CalibrationEvent
from .capability_graph import CapabilityGraph, GateResult, goal_seed
from .containment import DependencyField, DependencyEdge
from .causal import CausalRegistry, CausalModel, CausalClaim
from .experiment import ExperimentPlanner, Hypothesis, CandidateTest
from .ontology import OntologyRegistry, ConceptVersion, MappingHypothesis
from .federation import FederationLedger, FederationBundle
from .builtin_verifiers import (math_equality_verifier, software_command_verifier,
                                statistical_mean_verifier, documentary_verifier,
                                normative_approval_verifier, empirical_json_verifier,
                                causal_identification_verifier)
from .task import TaskRequest, TaskReport, TaskStage
from .gateplan import FrozenGatePlan, GateOutcome
from .drift import DriftBaseline, DriftMonitor
from .evaluation import EvaluatorBoundary
from .resources import ResourceLedger, ResourcePolicy
from .providers import ProviderRegistry, ProviderPolicy
from .campaign_search import SearchCampaignController, SearchCampaign, CampaignQuery
from .documents import DocumentIRRegistry
from .transformations import TransformationRegistry, TransformationContract
from .empirical import InstrumentRegistry, InstrumentSpec, CalibrationCertificate
from .mapping_precision import MappingPrecisionRegistry, TaskLossPolicy, MappingBenchmarkCase
from .regime_calibration import RegimeCalibration, CalibrationRegime, ForecastOutcome
from .design_registry import DomainDesignRegistry, DesignDialect
from .allocation import TestAllocationHarness, AllocationScenario
from .portfolio_benchmark import PortfolioBenchmark, PortfolioCase
from .ecology_runtime import SpecialistEcology, Specialist, ContributionExperiment
from .shift_portfolio import ShiftPortfolio, ShiftContract
from .environment import EnvironmentRegistry, EnvironmentSpec, EnvironmentTask
from .explanation_study import ExplanationStudyRegistry, ViewContract
from .mutation_campaign import MutationCampaign, MutationOperator
from .scenario_profiles import ScenarioAssurance, ScenarioProfile
from .process_portfolio import (ProcessPortfolio, ProcessTaskProfile, ProcessCandidate,
                                seeded_process_portfolio)


@dataclass
class PublicResult:
    request_id: str
    capability: str
    result: object
    organ_trace_start: int
    organ_trace_end: int
    audit_valid: bool
    contract_object_id: str = ""


class FieldInstrument:
    VERSION = "0.17.0"

    def __init__(self, root: str | os.PathLike[str]):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "arcs").mkdir(exist_ok=True)
        (self.root / "arc_kernels").mkdir(exist_ok=True)
        (self.root / "arc_campaigns").mkdir(exist_ok=True)
        (self.root / "arc5a_kernels").mkdir(exist_ok=True)
        self.content = ContentStore(self.root / "content")
        self.organs = OrganRegistry()
        self.resources = ResourceLedger()
        self.organs.resource_hook = self.resources.record_mapping
        self.components = ComponentRegistry()
        self.calibration = CalibrationRegistry()
        self.verification = VerificationRegistry(components=self.components, calibration=self.calibration)
        for contract in core_contracts():
            self.verification.register_contract(contract)
        self.waist = ContractStore()
        self.goal_gate = GoalGate()
        self.capability_graph = goal_seed()
        self.dependencies = DependencyField()
        self.causal = CausalRegistry()
        self.experiments = ExperimentPlanner()
        self.ontology = OntologyRegistry()
        self.federation = FederationLedger()
        gate_path = Path(__file__).parents[1] / "stage3" / "PREDECLARED_REALITY_GATES.json"
        self.gate_plan = FrozenGatePlan.from_stage3_json(gate_path)
        self.drift_baselines: Dict[str, DriftBaseline] = {}
        self.evaluator = EvaluatorBoundary(self.root / "evaluation")
        self.providers = ProviderRegistry(self.content)
        self.search_campaigns = SearchCampaignController()
        self.documents = DocumentIRRegistry()
        self.transformations = TransformationRegistry()
        self.instruments = InstrumentRegistry(self.root / "instruments")
        self.mapping_precision = MappingPrecisionRegistry(self.ontology)
        self.regime_calibration = RegimeCalibration()
        self.designs = DomainDesignRegistry()
        self.allocation = TestAllocationHarness()
        self.portfolio_benchmark = PortfolioBenchmark()
        self.specialists = SpecialistEcology()
        self.shifts = ShiftPortfolio()
        self.environments = EnvironmentRegistry()
        self.explanations = ExplanationStudyRegistry()
        self.mutations = MutationCampaign()
        self.scenarios = ScenarioAssurance()
        self.process_portfolio = seeded_process_portfolio()
        knowledge_path = self.root / "knowledge.json"
        self.knowledge = (FieldSystem.load(str(knowledge_path)) if knowledge_path.exists()
                          else FieldSystem("instrument-knowledge", kinds=metrology_seed()))
        self.router = HeterogeneousRouter()
        self.arguments = ArgumentGraph()
        self.ir = IRRegistry()
        for contract in core_irs():
            self.ir.register(contract)
        self.portfolio = MechanismPortfolio()
        self.actions = ActionRegistry()
        self.intent_proposals: Dict[str, dict] = {}
        self.provenance = ProvenanceGraph()
        self.assurance = AssuranceRegistry()
        self.models = ModelRegistry()
        self.ecology = OrganEcology()
        self.acquisition = AcquisitionEngine(self.root / "acquisition")
        self.audit = EventLog()
        runtime_path = self.root / "runtime.json"
        if runtime_path.exists():
            self._load_runtime(runtime_path)
            self._register_organs()  # additive version migration: never leave new organs absent
            self._seed_ecology()
            self._save_runtime()
        else:
            self._register_organs()
            self._seed_ecology()
            self._save_runtime()
        self._register_builtin_verifiers()
        self._seed_stage4c_runtime()
        self.organs.resource_hook = self.resources.record_mapping
        self._save_runtime()


    def _register_builtin_verifiers(self) -> None:
        """Register narrow executable contacts and attest their implementation bytes."""
        module_path = Path(__file__).with_name("builtin_verifiers.py")
        existing = next((c for c in self.components.components.values()
                         if c.name == "builtin-verifiers" and c.source == str(module_path.resolve())), None)
        if existing is None:
            component = self.components.attest_path(
                "builtin-verifiers", "verification-library", self.VERSION, module_path,
                ("verify",), scope={"contracts": ["math-proof", "software-property",
                                                   "statistical-generalisation", "documentary-fact",
                                                   "normative-judgment", "empirical-measurement",
                                                   "causal-identification"]})
            component_id = component.component_id
        else:
            component_id = existing.component_id
        specs = (
            RegisteredVerifier("sympy-equality", "proof_checker", "formal", 1.0,
                               "builtin-independent-checker", math_equality_verifier,
                               component_id=component_id, task_family="mathematical_proposition",
                               independence_group="sympy-safe-ast"),
            RegisteredVerifier("software-command", "test_runner", "execution", 0.8,
                               "builtin-independent-checker", software_command_verifier,
                               component_id=component_id, task_family="software_behaviour",
                               independence_group="subprocess-runtime"),
            RegisteredVerifier("statistical-mean", "statistical_test", "dataset", 0.65,
                               "builtin-independent-checker", statistical_mean_verifier,
                               component_id=component_id, task_family="statistical_generalisation",
                               independence_group="python-statistics"),
            RegisteredVerifier("documentary-record", "document_inspector", "primary_source", 0.7,
                               "builtin-independent-checker", documentary_verifier,
                               component_id=component_id, task_family="documentary_fact",
                               independence_group="local-record-inspection"),
            RegisteredVerifier("normative-approval", "human_decision", "human", 1.0,
                               "accountable-human-record", normative_approval_verifier,
                               component_id=component_id, task_family="normative_claim",
                               independence_group="human-decision-record"),
            RegisteredVerifier("empirical-json", "instrument", "instrument", 0.75,
                               "external-measurement-record", empirical_json_verifier,
                               component_id=component_id, task_family="empirical_quantity",
                               independence_group="json-measurement-transport"),
            RegisteredVerifier("causal-backdoor", "causal_analysis", "dataset", 0.75,
                               "graphical-identification-checker", causal_identification_verifier,
                               component_id=component_id, task_family="causal_claim",
                               independence_group="networkx-d-separation"),
        )
        for verifier in specs:
            if verifier.verifier_id not in self.verification.verifiers:
                self.verification.register_verifier(verifier)


    def _seed_stage4c_runtime(self) -> None:
        """Attach deterministic Stage 4C runtimes without asserting external contacts."""
        # Provider policies survive restarts; deployments remain explicit.
        for policy in (
            ProviderPolicy("local", "local-index", ("local-document",), "caller-controlled-local-files", network_required=False),
            ProviderPolicy("catalog", "captured-catalog", ("captured-source",), "captured-source-license-record", network_required=False),
            ProviderPolicy("crossref", "scholarly-index", ("scholarly-metadata",), "Crossref metadata terms", network_required=True),
            ProviderPolicy("openalex", "scholarly-index", ("scholarly-metadata",), "OpenAlex data terms", network_required=True),
        ):
            if policy.provider_id not in self.providers.policies:
                self.providers.register(policy)

        self.transformations.register_comparator("exact-json", lambda a, b: a == b) if "exact-json" not in self.transformations.comparators else None
        def _register_transform(contract, fn):
            if contract.transform_id not in self.transformations.contracts:
                self.transformations.register(contract, fn)
            else:
                self.transformations.attach(contract.transform_id, fn)
        _register_transform(TransformationContract(
            "json-identity", "json", "json",
            ("entity_identity", "scope", "source_regions", "uncertainty", "ordering"), (),
            reversible=True, inverse_id="json-identity", comparator_id="exact-json"), lambda x: json.loads(json.dumps(x)))
        _register_transform(TransformationContract(
            "table-to-records", "table", "records",
            ("cell_values", "row_order", "column_order", "table_shape"), ("visual_layout",),
            reversible=False), lambda x: [dict(zip(x[0], row)) for row in x[1:]] if isinstance(x, list) and x else [])
        _register_transform(TransformationContract(
            "records-to-table", "records", "table",
            ("cell_values", "row_order", "column_order"), ("original_table_shape", "visual_layout"),
            reversible=False), lambda x: ([list(x[0].keys())] + [[row.get(k) for k in x[0].keys()] for row in x]) if isinstance(x, list) and x else [])

        def interval_generate(goal):
            bounds = dict(goal.get("bounds", {})); config = {}
            for name, pair in bounds.items():
                lo, hi = float(pair[0]), float(pair[1]); config[name] = (lo + hi) / 2.0
            return (config,)
        def interval_validate(goal, config):
            bounds = dict(goal.get("bounds", {})); violations = [k for k, pair in bounds.items() if not float(pair[0]) <= float(config.get(k, float("nan"))) <= float(pair[1])]
            return {"valid": not violations, "violations": violations, "validator": "interval-bounds"}
        def discrete_generate(goal):
            return tuple({"choice": x} for x in goal.get("options", ()))
        def discrete_validate(goal, config):
            valid = config.get("choice") in goal.get("options", ()) and config.get("choice") not in goal.get("forbidden", ())
            return {"valid": valid, "validator": "discrete-membership"}
        def graph_generate(goal):
            from collections import deque
            edges = [tuple(x) for x in goal.get("edges", ())]; start, end = goal.get("start"), goal.get("end")
            adj = {}
            for a, b in edges: adj.setdefault(a, []).append(b)
            queue = deque([(start, [start])]); seen = {start}
            while queue:
                node, path = queue.popleft()
                if node == end: return ({"path": path},)
                for nxt in adj.get(node, ()):
                    if nxt not in seen: seen.add(nxt); queue.append((nxt, path + [nxt]))
            return ()
        def graph_validate(goal, config):
            path = list(config.get("path", ())); edges = {tuple(x) for x in goal.get("edges", ())}
            valid = bool(path) and path[0] == goal.get("start") and path[-1] == goal.get("end") and all((a, b) in edges for a, b in zip(path, path[1:]))
            return {"valid": valid, "validator": "graph-path"}
        for dialect, generator, validator in (
            (DesignDialect("interval-box", "bounded-numerical", "interval-field", ("bounds",), (), "interval-bounds"), interval_generate, interval_validate),
            (DesignDialect("discrete-choice", "configuration-selection", "finite-set", ("options",), ("forbidden",), "discrete-membership"), discrete_generate, discrete_validate),
            (DesignDialect("graph-path", "network-routing", "directed-graph", ("edges", "start", "end"), (), "graph-path"), graph_generate, graph_validate),
        ):
            if dialect.dialect_id not in self.designs.dialects:
                self.designs.register(dialect, generator, validator)
            else:
                self.designs.generators[dialect.dialect_id] = generator; self.designs.validators[dialect.validator_id] = validator

        if "placement-default" not in self.mapping_precision.policies:
            self.mapping_precision.register_policy(TaskLossPolicy(
                "placement-default", false_merge_cost=10.0, false_split_cost=2.0, abstention_cost=1.0,
                temporal_mismatch_cost=5.0, allowed_relations=tuple(sorted(self.ontology.RELATIONS))))
        for contract in (
            ViewContract("operator-view", "operator", "decision",
                         ("result", "uncertainty", "scope", "next_contact"),
                         ("uncertainty", "scope"), 800),
            ViewContract("audit-view", "auditor", "assurance",
                         ("result", "sources", "transformations", "verifiers", "uncertainty", "limitations", "resources", "revocations"),
                         ("sources", "uncertainty", "limitations"), 5000),
        ):
            if contract.contract_id not in self.explanations.contracts:
                self.explanations.register(contract)
        for contract in (
            ShiftContract("numeric-mean", "generic-numeric", "mean_z", 2.5, "reduce_scope_and_re-ground", {"declared": True}),
            ShiftContract("category-novelty", "generic-category", "category_novelty", 0.2, "abstain_and_re-ground", {"declared": True}),
        ):
            if contract.monitor_id not in self.shifts.contracts:
                self.shifts.register(contract)

        mutation_targets = {
            "search-coverage": "search-campaign", "multimodal-carving": "document-ir",
            "representation-loss": "transformation", "placement-precision": "placement-precision",
            "test-allocation": "allocation-benchmark", "solver-portfolio": "portfolio-benchmark",
            "holobiont-ecology": "specialist-governance", "resource-honesty": "resource-ledger",
            "architectural-mutation": "mutation-campaign", "profiled-assurance": "scenario-assurance",
        }
        for capability, target in mutation_targets.items():
            mid = f"disable:{target}"
            if mid not in self.mutations.operators:
                self.mutations.register(MutationOperator(mid, capability, target, "disable-organ",
                                                         f"organ {target!r} unavailable", f"REQ:{capability}"))

    def _save_runtime(self) -> None:
        raw = {
            "version": self.VERSION,
            "organs": self.organs.to_dict(),
            "audit": self.audit.to_dict(),
            "verification_results": [asdict(x) for x in self.verification.results.values()],
            "router_history": [asdict(x) for x in self.router.history],
            "arguments": self.arguments.to_dict(),
            "ir": self.ir.to_dict(),
            "portfolio": self.portfolio.to_dict(),
            "action_receipts": [asdict(x) for x in self.actions.receipts.values()],
            "intent_proposals": self.intent_proposals,
            "provenance": self.provenance.to_dict(),
            "assurance": self.assurance.to_dict(),
            "models": self.models.to_dict(),
            "ecology": self.ecology.to_dict(),
            "acquisition": self.acquisition.to_dict(),
            "waist": self.waist.to_dict(),
            "components": self.components.to_dict(),
            "calibration": self.calibration.to_dict(),
            "capability_graph": self.capability_graph.to_dict(),
            "dependencies": self.dependencies.to_dict(),
            "causal": self.causal.to_dict(),
            "ontology": self.ontology.to_dict(),
            "federation": self.federation.to_dict(),
            "gate_plan": self.gate_plan.to_dict(),
            "drift_baselines": {k: asdict(v) for k, v in self.drift_baselines.items()},
            "evaluator": self.evaluator.to_dict(),
            "resources": self.resources.to_dict(),
            "providers": self.providers.to_dict(),
            "search_campaigns": self.search_campaigns.to_dict(),
            "documents": self.documents.to_dict(),
            "transformations": self.transformations.to_dict(),
            "instruments": self.instruments.to_dict(),
            "mapping_precision": self.mapping_precision.to_dict(),
            "regime_calibration": self.regime_calibration.to_dict(),
            "designs": self.designs.to_dict(),
            "allocation": self.allocation.to_dict(),
            "portfolio_benchmark": self.portfolio_benchmark.to_dict(),
            "specialists": self.specialists.to_dict(),
            "shifts": self.shifts.to_dict(),
            "environments": self.environments.to_dict(),
            "explanations": self.explanations.to_dict(),
            "mutations": self.mutations.to_dict(),
            "scenarios": self.scenarios.to_dict(),
            "process_portfolio": self.process_portfolio.to_dict(),
        }
        path = self.root / "runtime.json"
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(raw, indent=2, sort_keys=True))
        os.replace(tmp, path)

    def _load_runtime(self, path: Path) -> None:
        raw = json.loads(path.read_text())
        self.organs = OrganRegistry.from_dict(raw.get("organs", {}))
        self.audit = EventLog.from_dict(raw.get("audit", {}))
        from .verification import VerificationResult
        self.verification.results = {}
        for x in raw.get("verification_results", []):
            d = dict(x)
            d["artifacts"] = tuple(d.get("artifacts", ()))
            result = VerificationResult(**d)
            self.verification.results[result.result_id] = result
        from .routing import RouteRecord
        self.router.history = [RouteRecord(**x) for x in raw.get("router_history", [])]
        self.arguments = ArgumentGraph.from_dict(raw.get("arguments", {}))
        self.ir = IRRegistry.from_dict(raw.get("ir", {})) if raw.get("ir") else IRRegistry()
        if not self.ir.contracts:
            for contract in core_irs():
                self.ir.register(contract)
        self.portfolio = MechanismPortfolio.from_dict(raw.get("portfolio", {}))
        from .actions import ActionReceipt
        self.actions.receipts = {}
        for x in raw.get("action_receipts", []):
            receipt = ActionReceipt(**x)
            self.actions.receipts[receipt.rid] = receipt
        self.intent_proposals = dict(raw.get("intent_proposals", {}))
        self.provenance = ProvenanceGraph.from_dict(raw.get("provenance", {}))
        self.assurance = AssuranceRegistry.from_dict(raw.get("assurance", {}))
        self.models = ModelRegistry.from_dict(raw.get("models", {}))
        self.ecology = OrganEcology.from_dict(raw.get("ecology", {}))
        self.acquisition = AcquisitionEngine.from_dict(self.root / "acquisition", raw.get("acquisition", {}))
        self.waist = ContractStore.from_dict(raw.get("waist", {}))
        self.components = ComponentRegistry.from_dict(raw.get("components", {}))
        self.calibration = CalibrationRegistry.from_dict(raw.get("calibration", {}))
        self.verification.components = self.components
        self.verification.calibration = self.calibration
        self.capability_graph = CapabilityGraph.from_dict(raw.get("capability_graph", {})) if raw.get("capability_graph") else goal_seed()
        self.dependencies = DependencyField.from_dict(raw.get("dependencies", {}))
        self.causal = CausalRegistry.from_dict(raw.get("causal", {}))
        self.ontology = OntologyRegistry.from_dict(raw.get("ontology", {}))
        self.federation = FederationLedger.from_dict(raw.get("federation", {}))
        if raw.get("gate_plan"):
            self.gate_plan = FrozenGatePlan.from_dict(raw.get("gate_plan", {}))
        self.drift_baselines = {str(k): DriftBaseline(**dict(v))
                                for k, v in dict(raw.get("drift_baselines", {})).items()}
        self.evaluator = EvaluatorBoundary.from_dict(self.root / "evaluation", raw.get("evaluator", {}))
        self.resources = ResourceLedger.from_dict(raw.get("resources", {}))
        self.organs.resource_hook = self.resources.record_mapping
        self.providers = ProviderRegistry.from_dict(self.content, raw.get("providers", {}))
        self.search_campaigns = SearchCampaignController.from_dict(raw.get("search_campaigns", {}))
        self.documents = DocumentIRRegistry.from_dict(raw.get("documents", {}))
        self.transformations = TransformationRegistry.from_dict(raw.get("transformations", {}))
        self.instruments = InstrumentRegistry.from_dict(self.root / "instruments", raw.get("instruments", {}))
        self.mapping_precision = MappingPrecisionRegistry.from_dict(self.ontology, raw.get("mapping_precision", {}))
        self.regime_calibration = RegimeCalibration.from_dict(raw.get("regime_calibration", {}))
        self.designs = DomainDesignRegistry.from_dict(raw.get("designs", {}))
        self.allocation = TestAllocationHarness.from_dict(raw.get("allocation", {}))
        self.portfolio_benchmark = PortfolioBenchmark.from_dict(raw.get("portfolio_benchmark", {}))
        self.specialists = SpecialistEcology.from_dict(raw.get("specialists", {}))
        self.shifts = ShiftPortfolio.from_dict(raw.get("shifts", {}))
        self.environments = EnvironmentRegistry.from_dict(raw.get("environments", {}))
        self.explanations = ExplanationStudyRegistry.from_dict(raw.get("explanations", {}))
        self.mutations = MutationCampaign.from_dict(raw.get("mutations", {}))
        self.scenarios = ScenarioAssurance.from_dict(raw.get("scenarios", {}))
        self.process_portfolio = (ProcessPortfolio.from_dict(raw.get("process_portfolio", {}))
                                  if raw.get("process_portfolio") else seeded_process_portfolio())

    def _register_organs(self) -> None:
        specs = (
            OrganSpec("coordination", "carry one raw request through every currently available public organ and stop at the first ungated boundary",
                      ("one typed terminal state and captured chain of custody are returned",),
                      dependencies=("goal-contract", "search", "presentation", "provenance", "audit"),
                      public_capabilities=("inquire", "task"), substrate="CPU orchestration",
                      authority_effect="none; cannot raise child authority"),
            OrganSpec("intent", "translate raw input into a falsifiable zero-authority starting contract",
                      ("ambiguities, assumptions, success and failure observations are explicit",),
                      public_capabilities=("interpret", "discover-text"),
                      substrate="LLM faculty + CPU schema gate", authority_effect="zero"),
            OrganSpec("arc5-kernel", "enforce human-gated subtractive discovery with frozen dual searches and tests",
                      ("contract, search plans and test definitions are immutable between approved amendments",
                       "failed contact reopens the causally implicated stage"),
                      dependencies=("goal-contract", "search", "expose", "abstraction", "reduction", "contact"),
                      public_capabilities=("arc-start", "arc-step", "arc-search", "arc-status"),
                      substrate="append-only state machine + human approvals",
                      authority_effect="zero; governs process and preserves contact boundaries"),
            OrganSpec("arc5a-kernel", "force independently bifurcated adversarial discovery and strongest-selection",
                      ("constructive and destructive fields remain independently authored and frozen",
                       "five strongest-selection roles survive Pareto and dual-authored contact"),
                      dependencies=("goal-contract", "search", "expose", "abstraction", "reduction", "contact"),
                      public_capabilities=("arc5a-start", "arc5a-step", "arc5a-search", "arc5a-status"),
                      substrate="append-only adversarial state machine + human approvals",
                      authority_effect="zero; cannot certify search, analogy, candidate or contact"),
            OrganSpec("process-portfolio", "select a task-proportionate discovery process without declaring one universal method",
                      ("method preconditions, failure modes and evidence roots remain explicit",
                       "task-specific process candidates remain Pareto-separated until contact"),
                      dependencies=("arc5a-kernel", "assurance", "resource-ledger"),
                      public_capabilities=("process-task", "process-select", "process-status"),
                      substrate="typed process contracts + Pareto selection",
                      authority_effect="zero; structural mechanism-fit is not longitudinal superiority"),
            OrganSpec("goal-contract", "state local and whole observable effects",
                      ("dual POSIWID contract is persisted",),
                      public_capabilities=("discover", "discover-text", "inquire"), substrate="human+LLM/CPU"),
            OrganSpec("search", "retrieve and preserve positive and negative source artifacts",
                      ("query lineage and content digests exist",),
                      dependencies=("goal-contract",), public_capabilities=("discover", "inquire", "arc-search", "arc5a-search"),
                      substrate="IR/API/local index", authority_effect="zero; candidate evidence"),
            OrganSpec("expose", "separate independently failing functions and interfaces",
                      ("evidence-linked functional distinctions exist",),
                      dependencies=("search",), public_capabilities=("discover",),
                      substrate="LLM proposal + CPU schema gate", authority_effect="zero"),
            OrganSpec("abstraction", "search heterogeneous instances of retained causal functions",
                      ("translation-bounded abstraction lattice and analogue receipts exist",),
                      dependencies=("expose", "search"), public_capabilities=("discover",),
                      substrate="LLM proposal + heterogeneous search", authority_effect="zero"),
            OrganSpec("reduction", "eliminate mechanisms using contrast and competing systems",
                      ("mechanisms have for/against evidence, work ledger and falsifier",),
                      dependencies=("abstraction",), public_capabilities=("discover",),
                      substrate="graph/CPU + LLM proposal", authority_effect="zero until contact"),
            OrganSpec("contact", "rank and record discriminating reality contacts",
                      ("test obligations and contact outcomes are auditable",),
                      dependencies=("reduction",), public_capabilities=("discover", "verify", "record-contact"),
                      substrate="registered heterogeneous executors", authority_effect="bounded by contract"),
            OrganSpec("acquisition", "retrieve and parse immutable source artifacts under an explicit policy",
                      ("exact bytes, digest, parser and warnings are persisted",),
                      public_capabilities=("investigate",), substrate="filesystem/HTTP + typed parser",
                      authority_effect="zero; acquisition proves bytes and transformation only"),
            OrganSpec("carving", "extract bounded proposal-only structure from parsed artifacts",
                      ("extractor receipt and abstention are explicit",), dependencies=("acquisition",),
                      public_capabilities=("investigate",), substrate="deterministic parser or proposal faculty",
                      authority_effect="zero"),
            OrganSpec("akbc", "retain observations and infer reversible placement",
                      ("carving, measurand, observation and identity hypothesis stay distinct",),
                      public_capabilities=("ingest", "investigate"), substrate="Python/CPU",
                      authority_effect="zero before grounding"),
            OrganSpec("verification", "route claims to typed verification contracts",
                      ("result state, contact and authority ceiling are recorded",),
                      dependencies=("contact",), public_capabilities=("verify",),
                      substrate="heterogeneous registered executors",
                      authority_effect="contract-bounded"),
            OrganSpec("scope", "refuse models outside explicit applicability envelopes",
                      ("unknown or violated scope blocks model-backed authority",),
                      public_capabilities=("scope", "settle"), substrate="CPU contract evaluation",
                      authority_effect="caps model authority"),
            OrganSpec("settling", "prune variable domains under registered constraints",
                      ("settled domains or explicit contradiction are returned",),
                      dependencies=("scope",),
                      public_capabilities=("settle",), substrate="Python/CPU or explicit native",
                      authority_effect="pruning only"),
            OrganSpec("ir-selection", "select a representation that preserves task distinctions",
                      ("selected IR declares retained and lost structure",),
                      public_capabilities=("represent",), substrate="CPU contract matching",
                      authority_effect="none"),
            OrganSpec("argument", "preserve non-numeric support, attack and dependency structure",
                      ("correlated evidence counts once and live disagreement remains explicit",),
                      public_capabilities=("argue",), substrate="graph/CPU",
                      authority_effect="status only; no truth scalar"),
            OrganSpec("portfolio", "select mechanisms from empirical task-shape performance",
                      ("incompatible mechanisms are vetoed before cost optimization",),
                      public_capabilities=("route",), substrate="CPU statistics",
                      authority_effect="none"),
            OrganSpec("action", "execute capability-scoped tools with approval and reversibility policy",
                      ("action receipt records permission, dry-run and outcome",),
                      public_capabilities=("act",), substrate="registered external executor",
                      authority_effect="changes world state, not truth authority"),
            OrganSpec("assurance", "trace goal effects to public workloads and deletion-sensitive organs",
                      ("claimed capabilities have scoped baseline and mutation evidence",),
                      public_capabilities=("assure", "audit"), substrate="CPU mutation/trace analysis",
                      authority_effect="evidence about this implementation only"),
            OrganSpec("ecology", "measure contribution, replaceability and correlated failure roots",
                      ("diversity is reported by failure-domain independence rather than component count",),
                      dependencies=("assurance",), public_capabilities=("ecology", "audit"),
                      substrate="dependency graph + mutation evidence", authority_effect="none"),
            OrganSpec("contract-waist", "preserve typed, scoped, versioned contracts without imposing a universal ontology",
                      ("objects are content sealed, dependency linked and revocable",),
                      public_capabilities=("goal", "calibrate", "causal", "plan-test", "ontology", "federate", "task", "audit", "invalidate-object"), substrate="append-only typed store",
                      authority_effect="none; preserves contracts and lineage"),
            OrganSpec("component-trust", "attest executable component identity, bytes and admitted operations",
                      ("changed or quarantined verifier bytes cannot execute",),
                      public_capabilities=("verify", "component", "audit"), substrate="hash registry/CPU",
                      authority_effect="integrity admission only; never semantic truth"),
            OrganSpec("calibration", "measure context-specific historical performance without deciding individual claims",
                      ("independence-group outcomes cap configured quality",),
                      public_capabilities=("calibrate", "verify", "audit"), substrate="statistics/CPU",
                      authority_effect="caps contact quality only"),
            OrganSpec("causal-identification", "separate graphical identification from effect support",
                      ("non-identifiable causal claims are refused with assumptions",),
                      public_capabilities=("causal", "task"), substrate="DAG algorithms/CPU",
                      authority_effect="zero; identification is not empirical support"),
            OrganSpec("experiment-allocation", "rank discriminating contacts under cost, latency and risk",
                      ("ranked tests expose expected discrimination and resource tradeoffs",),
                      public_capabilities=("plan-test", "task"), substrate="information theory/CPU",
                      authority_effect="none"),
            OrganSpec("ontology-evolution", "retain versioned concepts and reversible typed mappings",
                      ("evolution preserves history and vetoed mappings cannot be accepted",),
                      public_capabilities=("ontology", "task"), substrate="versioned graph/CPU",
                      authority_effect="zero until mapping contract is satisfied"),
            OrganSpec("federation", "exchange append-only signed bundles without overwriting semantic conflict",
                      ("integrity, sequence gaps and divergent versions remain explicit",),
                      public_capabilities=("federate", "task"), substrate="signed event bundles/CPU",
                      authority_effect="none"),
            OrganSpec("containment", "propagate invalidation and expose dependency blast radius",
                      ("revocation affects descendants without deleting history",),
                      public_capabilities=("invalidate-object", "task", "audit"), substrate="dependency graph/CPU",
                      authority_effect="removes active authority only"),
            OrganSpec("goal-gate", "refuse underspecified, contradictory or unauthorized consequential goals",
                      ("minimum clarification or explicit refusal is returned",),
                      public_capabilities=("goal", "task"), substrate="deterministic policy/CPU",
                      authority_effect="none; protects decision ownership"),
            OrganSpec("drift-monitor", "detect declared numeric context shift and trigger scope reduction",
                      ("shift does not preserve stale confidence",),
                      public_capabilities=("drift", "task", "audit"), substrate="statistics/CPU",
                      authority_effect="reduces scope; never proves in-distribution truth"),
            OrganSpec("presentation", "render one underlying state at multiple resolutions without raising authority",
                      ("support, contest, unknowns, scope and next tests remain visible",),
                      dependencies=("provenance",), public_capabilities=("report", "inquire"),
                      substrate="deterministic CPU projection", authority_effect="none"),
            OrganSpec("provenance", "preserve derivation, attribution, invalidation and source independence",
                      ("derived artifacts retain root-source families and invalidation impact",),
                      public_capabilities=("interpret", "discover", "ingest", "verify", "scope", "settle", "represent",
                                           "argue", "route", "act", "assure", "ecology", "report", "inquire", "investigate", "arc-import", "record-contact", "invalidate", "invalidate-object", "goal", "calibrate", "component", "causal", "plan-test", "ontology", "federate", "drift", "task", "audit",
                                           "arc-start", "arc-step", "arc-search", "arc-status",
                                           "arc5a-start", "arc5a-step", "arc5a-search", "arc5a-status"),
                      substrate="PROV-shaped graph/CPU", authority_effect="none; evidence about lineage"),
            OrganSpec("audit", "preserve chain of custody and runtime organ traces",
                      ("hash-chain, content store and runtime trace verify",),
                      dependencies=("provenance",),
                      public_capabilities=("discover", "ingest", "verify", "scope", "settle", "represent",
                                           "argue", "route", "act", "assure", "ecology", "report", "inquire", "investigate", "arc-import", "record-contact", "invalidate", "invalidate-object", "goal", "calibrate", "component", "causal", "plan-test", "ontology", "federate", "drift", "task", "audit",
                                           "arc-start", "arc-step", "arc-search", "arc-status"),
                      substrate="append-only CPU storage", authority_effect="none"),
        )
        for spec in specs:
            if spec.name not in self.organs.specs:
                self.organs.register(spec)
        extras = (
            OrganSpec("evaluator-boundary", "commit a release and import one-time external challenges without self-certifying independence", ("release and challenge digests are frozen",), public_capabilities=("evaluation", "scenario"), substrate="content digests + external evaluator", authority_effect="none; external validation required"),
            OrganSpec("provider-registry", "bind retrieval routes to policy, licensing, study grouping and replay", ("provider and retrieval receipts are replayable",), dependencies=("evaluator-boundary",), public_capabilities=("provider", "search-campaign", "scenario"), substrate="provider plugins + content store", authority_effect="zero"),
            OrganSpec("resource-ledger", "measure resource dimensions without scalar collapse", ("wall/cpu/io and unknown external dimensions are recorded",), dependencies=("evaluator-boundary",), public_capabilities=("resource", "search-campaign", "design", "allocate", "portfolio-benchmark", "scenario", "task"), substrate="OS counters + external receipts", authority_effect="none"),
            OrganSpec("mutation-campaign", "execute requirement-specific architectural mutations and review survivors", ("load-bearing capability has killed mutants",), dependencies=("evaluator-boundary",), public_capabilities=("mutation", "scenario"), substrate="isolated organ controls", authority_effect="implementation evidence only"),
            OrganSpec("search-campaign", "execute opposition-aware multi-route searches with source-class coverage and novelty", ("for/against/failure/boundary routes and receipts exist",), dependencies=("provider-registry", "resource-ledger"), public_capabilities=("search-campaign", "scenario"), substrate="provider portfolio + controller", authority_effect="zero"),
            OrganSpec("document-ir", "preserve pages, blocks, tables, images and exact source regions", ("carvings trace to source regions or abstain",), dependencies=("acquisition", "search-campaign"), public_capabilities=("document", "scenario"), substrate="format parsers + typed document IR", authority_effect="zero"),
            OrganSpec("transformation", "apply typed dialect transformations with required-distinction loss checks", ("lossy transformations are refused or declared",), dependencies=("document-ir",), public_capabilities=("transform", "scenario"), substrate="registered transformations + comparators", authority_effect="zero"),
            OrganSpec("placement-precision", "maintain task-loss-aware competing mappings and temporal identity", ("false merge, false split and abstention costs remain explicit",), dependencies=("ontology-evolution", "transformation"), public_capabilities=("placement-benchmark", "scenario"), substrate="versioned mapping graph", authority_effect="zero"),
            OrganSpec("instrument-registry", "preserve raw empirical bytes and calibration status", ("uncalibrated contacts retain zero authority",), dependencies=("provider-registry", "transformation"), public_capabilities=("instrument", "scenario"), substrate="physical adapter protocol", authority_effect="calibration-bounded external contact"),
            OrganSpec("regime-calibration", "evaluate forward-time outcomes by declared regime", ("authority remains zero without independent future outcomes",), dependencies=("instrument-registry", "evaluator-boundary"), public_capabilities=("regime-calibration", "scenario"), substrate="time-forward statistics", authority_effect="caps future use only"),
            OrganSpec("domain-design", "perform inverse design only in registered dialects with independent validators", ("unsupported domains refuse",), dependencies=("transformation", "placement-precision", "regime-calibration"), public_capabilities=("design", "scenario"), substrate="heterogeneous generators + validators", authority_effect="validator-bounded"),
            OrganSpec("allocation-benchmark", "compare test allocation against replayable baselines", ("decision quality, regret, false confidence and safety are measured",), dependencies=("search-campaign", "regime-calibration", "resource-ledger"), public_capabilities=("allocate", "scenario"), substrate="information theory + replay", authority_effect="none"),
            OrganSpec("portfolio-benchmark", "time-forward benchmark mechanism routing and safe fallback", ("best-fixed and oracle baselines remain visible",), dependencies=("regime-calibration", "resource-ledger"), public_capabilities=("portfolio-benchmark", "scenario"), substrate="empirical portfolio", authority_effect="none"),
            OrganSpec("specialist-governance", "measure contribution, correlated roots, quotas, quarantine and replacement", ("negative marginal or dysbiotic specialists can be removed",), dependencies=("portfolio-benchmark", "mutation-campaign", "resource-ledger"), public_capabilities=("specialist", "scenario"), substrate="conflict-aware ecology", authority_effect="none"),
            OrganSpec("shift-portfolio", "detect only declared shift families and reduce scope", ("undeclared shifts remain outside the claim",), dependencies=("regime-calibration", "portfolio-benchmark"), public_capabilities=("shift", "scenario"), substrate="calibrated monitor portfolio", authority_effect="scope reduction only"),
            OrganSpec("environment-protocol", "run reproducible stateful environment adapters while preserving external administration boundary", ("internal protocol runs are not external passes",), dependencies=("provider-registry", "document-ir", "allocation-benchmark", "specialist-governance"), public_capabilities=("environment", "scenario"), substrate="stateful adapter protocol", authority_effect="environment contact only"),
            OrganSpec("explanation-study", "prepare role/task views, explanation mutations and blinded study packages", ("comprehension remains externally validated",), dependencies=("shift-portfolio", "mutation-campaign"), public_capabilities=("explanation-study", "scenario"), substrate="evidence projections + user study protocol", authority_effect="none"),
            OrganSpec("scenario-assurance", "maintain scoped whole-system profiles instead of a universal completion certificate", ("capabilities, external contacts, mutations, resources and limitations remain explicit",), dependencies=("evaluator-boundary", "mutation-campaign", "environment-protocol", "explanation-study"), public_capabilities=("scenario",), substrate="assurance graph", authority_effect="scoped evidence only"),
        )
        for spec in extras:
            if spec.name not in self.organs.specs:
                self.organs.register(spec)
        new_caps = {c for spec in extras for c in spec.public_capabilities}
        for name in ("provenance", "audit"):
            if name in self.organs.specs:
                current = set(self.organs.specs[name].public_capabilities); self.organs.specs[name].public_capabilities = tuple(sorted(current | new_caps))

    def _seed_ecology(self) -> None:
        roots = {
            "coordination": ("orchestration-runtime", "public-contract"),
            "intent": ("proposal-faculty", "schema-runtime"),
            "goal-contract": ("goal-specification",),
            "search": ("search-provider", "source-corpus", "network-or-index"),
            "acquisition": ("transport-runtime", "parser-runtime", "artifact-policy"),
            "carving": ("extractor-runtime", "kind-registry", "schema-gate"),
            "expose": ("proposal-faculty", "schema-runtime", "evidence-field"),
            "abstraction": ("proposal-faculty", "search-provider", "analogy-gate"),
            "reduction": ("proposal-faculty", "evidence-field", "graph-runtime"),
            "contact": ("test-executor", "test-contract"),
            "akbc": ("placement-runtime", "kind-registry"),
            "verification": ("verifier-executor", "verification-contract"),
            "scope": ("model-contract",),
            "settling": ("interval-kernel", "constraint-model"),
            "ir-selection": ("ir-registry",),
            "argument": ("argument-graph",),
            "portfolio": ("performance-history", "task-features"),
            "action": ("action-executor", "capability-policy"),
            "assurance": ("test-suite", "organ-registry"),
            "ecology": ("organ-registry", "mutation-evidence"),
            "contract-waist": ("typed-contract-store", "hash-chain"),
            "component-trust": ("component-bytes", "attestation-policy"),
            "calibration": ("outcome-history", "independence-groups"),
            "causal-identification": ("causal-dag", "identification-assumptions"),
            "experiment-allocation": ("hypothesis-distributions", "cost-model"),
            "ontology-evolution": ("concept-versions", "mapping-vetoes"),
            "federation": ("bundle-signature", "producer-lineage"),
            "containment": ("dependency-graph", "revocation-root"),
            "goal-gate": ("goal-contract", "authority-boundary"),
            "drift-monitor": ("baseline-data", "feature-contract"),
            "presentation": ("presenter-runtime", "underlying-report"),
            "provenance": ("provenance-store",),
            "audit": ("append-only-store", "hash-chain"),
        }
        for name, spec in self.organs.specs.items():
            if name in self.ecology.members:
                continue
            self.ecology.register(EcologyMember(
                organ=name, capabilities=tuple(spec.public_capabilities or ("internal",)),
                failure_domains=tuple(roots.get(name, (f"organ:{name}",))),
                lineage=f"field-{self.VERSION}"))

    @staticmethod
    def _request_id() -> str:
        return f"REQ{uuid.uuid4().hex[:12]}"

    def _arc_path(self, arc_id: str) -> Path:
        return self.root / "arcs" / f"{arc_id}.json"

    def _arc_kernel_path(self, arc_id: str) -> Path:
        return self.root / "arc_kernels" / f"{arc_id}.json"

    def _arc_campaign_path(self, campaign_id: str) -> Path:
        return self.root / "arc_campaigns" / f"{campaign_id}.json"

    def save_arc_campaign(self, campaign: ARC5Campaign) -> None:
        campaign.save(self._arc_campaign_path(campaign.campaign_id))
        self.audit.append("arc5_campaign_saved", {"campaign_id": campaign.campaign_id, "status": campaign.status()})
        self._save_runtime()

    def load_arc_campaign(self, campaign_id: str) -> ARC5Campaign:
        path = self._arc_campaign_path(campaign_id)
        if not path.exists():
            raise KeyError(f"unknown ARC-5 campaign {campaign_id!r}")
        return ARC5Campaign.load(path)

    def arc_campaign_status(self, campaign_id: str) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        campaign = self.load_arc_campaign(campaign_id)
        result = campaign.status()
        return PublicResult(request_id, "arc-campaign-status", result, start,
                            len(self.organs.traces), result["integrity"]["valid"])

    def _provider_agent(self, label: str) -> str:
        external = f"provider:{label}"
        for agent in self.provenance.agents.values():
            if agent.external_id == external:
                return agent.agid
        return self.provenance.add_agent(ProvAgent(label=label, agent_type="software-or-service",
                                                    external_id=external))

    def _entity_by_locator_digest(self, locator: str, digest: str) -> str:
        for entity in self.provenance.entities.values():
            if entity.locator == locator and entity.content_sha256 == digest:
                return entity.eid
        return ""

    def _sync_arc_provenance(self, arc: DiscoveryArc) -> None:
        """Project the complete ARC derivation into the provenance graph.

        Evidence is only the root. Functional distinctions, abstractions,
        comparison cases, mechanisms, competing systems, and tests are versioned
        entities derived from the artifacts that justify them. This makes source
        invalidation load-bearing: revoking one captured source can identify and
        invalidate every downstream proposal that actually depended on it.
        Provenance remains lineage evidence, never truth authority.
        """
        import hashlib

        object_entities: Dict[str, str] = {}
        query_activity: Dict[str, str] = {}
        for q in arc.queries.values():
            provider_agent = self._provider_agent(q.provider)
            existing = next((a.aid for a in self.provenance.activities.values()
                             if a.plan == f"arc:{arc.arc_id}:query:{q.qid}"), "")
            if existing:
                query_activity[q.qid] = existing
                continue
            now = time.time()
            query_activity[q.qid] = self.provenance.add_activity(ProvActivity(
                activity_type="search", used=(), associated_with=(provider_agent,),
                started_at=now, ended_at=now,
                plan=f"arc:{arc.arc_id}:query:{q.qid}"))

        for e in arc.evidence.values():
            existing = self._entity_by_locator_digest(e.locator, e.content_sha256)
            if existing:
                object_entities[e.eid] = existing
                continue
            provider_agent = self._provider_agent(e.provider)
            object_entities[e.eid] = self.provenance.add_entity(ProvEntity(
                label=e.title, content_sha256=e.content_sha256, locator=e.locator,
                entity_type=e.source_type, generated_by=query_activity.get(e.query_id, ""),
                attributed_to=(provider_agent,)))

        analyst = self._provider_agent("field-instrument")

        def ensure_internal(object_id: str, entity_type: str, label: str,
                            payload: object, used: Sequence[str]) -> str:
            content = json.dumps(payload, sort_keys=True, default=str, separators=(",", ":"))
            digest = hashlib.sha256(content.encode("utf-8")).hexdigest()
            locator = f"arc://{arc.arc_id}/{entity_type}/{object_id}"
            existing = self._entity_by_locator_digest(locator, digest)
            if existing:
                object_entities[object_id] = existing
                return existing
            resolved = tuple(dict.fromkeys(object_entities[x] for x in used
                                           if x in object_entities))
            now = time.time()
            activity = self.provenance.add_activity(ProvActivity(
                activity_type=entity_type, used=resolved, associated_with=(analyst,),
                started_at=now, ended_at=now,
                plan=f"arc:{arc.arc_id}:{entity_type}:{object_id}:{digest[:12]}"))
            eid = self.provenance.add_entity(ProvEntity(
                label=label, content_sha256=digest, locator=locator,
                entity_type=entity_type, generated_by=activity,
                derived_from=resolved, attributed_to=(analyst,)))
            object_entities[object_id] = eid
            return eid

        ensure_internal(arc.contract.cid, "posiwid-contract", arc.contract.target,
                        asdict(arc.contract), ())

        for d in arc.distinctions.values():
            ensure_internal(d.did, "functional-distinction", d.collapsed_claim,
                            asdict(d), d.evidence_ids)

        distinction_ids = tuple(arc.distinctions)
        for a in sorted(arc.abstractions.values(), key=lambda x: (x.level, x.aid)):
            parents = ((a.parent_id,) if a.parent_id else distinction_ids)
            ensure_internal(a.aid, "abstraction", a.statement, asdict(a), parents)

        for x in arc.examples.values():
            ensure_internal(x.xid, "comparison-case", x.name, asdict(x),
                            (x.abstraction_id,) + tuple(x.evidence_ids))

        for m in arc.mechanisms.values():
            used = (tuple(m.evidence_for) + tuple(m.evidence_against) +
                    tuple(m.positive_cases) + tuple(m.negative_cases))
            ensure_internal(m.mid, "mechanism-hypothesis", m.function, asdict(m), used)

        for system in arc.systems.values():
            ensure_internal(system.sid, "system-hypothesis", system.name,
                            asdict(system), system.mechanism_ids)

        for test in arc.tests.values():
            target = test.target_id if test.target_type != "goal" else arc.contract.cid
            ensure_internal(test.tid, "test-obligation", test.question,
                            asdict(test), (target,) + tuple(test.evidence_ids))

    def _record_result_entity(self, *, label: str, entity_type: str,
                              request_id: str, used: Sequence[str] = (),
                              associated_agent: str = "field-instrument",
                              content: str = "") -> str:
        agent = self._provider_agent(associated_agent)
        now = time.time()
        activity = self.provenance.add_activity(ProvActivity(
            activity_type=entity_type, used=tuple(x for x in used if x in self.provenance.entities),
            associated_with=(agent,), started_at=now, ended_at=now,
            plan=f"request:{request_id}:{entity_type}"))
        import hashlib
        digest = hashlib.sha256(content.encode("utf-8")).hexdigest() if content else ""
        eid = self.provenance.add_entity(ProvEntity(
            label=label, content_sha256=digest, entity_type=entity_type,
            generated_by=activity, derived_from=tuple(x for x in used if x in self.provenance.entities),
            attributed_to=(agent,)))
        dependency_ids = tuple(f"prov:{x}" for x in used if x in self.provenance.entities)
        object_type = entity_type if entity_type in {"artifact", "representation", "carving", "observation", "claim", "hypothesis", "model", "goal", "constraint", "mapping", "transformation", "test", "result", "decision", "action", "resource", "amendment", "revocation", "report"} else "report"
        self.waist.append(
            object_type, {"label": label, "entity_type": entity_type,
                          "content_sha256": digest, "provenance_entity": eid},
            logical_id=f"prov:{eid}", representation="prov+json",
            dependency_ids=dependency_ids, status="active",
            authority_ceiling=0.0, resource={"request_id": request_id})
        for dep in used:
            try:
                self.dependencies.add(DependencyEdge(f"prov:{dep}", f"prov:{eid}", "derived_from"))
            except ValueError:
                pass
        return eid


    def inquire(self, raw_input: str, envelope: SearchEnvelope,
                providers: Mapping[str, SearchProvider], *, concrete_provider: str,
                faculty: Optional[ProposalFaculty] = None,
                execute_abstract_with: Optional[Mapping[str, str]] = None,
                whole_goal_context: Sequence[str] = ()) -> PublicResult:
        """Run one raw request as far as configured organs and contacts permit.

        With no proposal faculty, the request is preserved literally and used to
        open a contrastive search arc; the instrument stops at exposure with an
        explicit zero-authority limitation state. With a configured faculty it
        may progress farther, but it still cannot synthesize a supported answer
        without recorded claim-appropriate contact.
        """
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "coordination", "inquire", "run available request spine"):
            if faculty is not None:
                discovery = self.discover_text(
                    raw_input, envelope, providers, concrete_provider=concrete_provider,
                    faculty=faculty, execute_abstract_with=execute_abstract_with,
                    whole_goal_context=whole_goal_context)
            else:
                contract = POSIWIDContract(
                    target=raw_input.strip() or "empty input",
                    local_current=("the submitted input has not been searched or decomposed",),
                    local_goal=("contrastive evidence receipts are retained",
                                "the first ungated boundary is explicit"),
                    whole_current=("the instrument has no grounded result for this request",),
                    whole_goal=tuple(whole_goal_context) or (
                        "return a scoped supported result or an explicit typed limitation state with receipts",),
                    constraints=("no semantic interpretation is inferred without a configured proposal faculty",),
                    anti_goals=("fluent completion without contact",),
                    success_observations=("search receipts persisted", "terminal limitation state returned"),
                    failure_observations=("a substantive answer appears without contact",),
                    scope="literal-input conservative fallback",
                )
                discovery = self.discover(contract, envelope, providers,
                                          concrete_provider=concrete_provider, faculty=None)
            arc_id = str(discovery.result["arc_id"])
            arc = self.load_arc(arc_id)
            gates = discovery.result["status"]["gates"]
            failed_gates = [g for g in gates if not g["passed"]]
            evidence = [e for e in arc.evidence.values() if e.state != "screened_out"]
            contact_tests = [t for t in arc.tests.values()
                             if t.state in {"passed", "failed", "inconclusive"}]
            terminal = "insufficient-contact" if evidence else "unresolved"
            if contact_tests and all(t.state == "failed" for t in contact_tests):
                terminal = "falsified"
            unknowns = tuple(
                f"{g['stage']}: " + ("; ".join(g["reasons"]) or "gate not passed")
                for g in failed_gates
            )
            next_tests = tuple({
                "test_id": t.tid, "question": t.question, "method": t.method,
                "priority": t.priority(),
            } for t in arc.ranked_tests()[:5])
            if not next_tests and faculty is None:
                next_tests = ({
                    "test": "configure an independent proposal faculty and abstract search providers",
                    "purpose": "expose functions and search abstraction instances without promoting proposals to authority",
                },)
            presentation = PresentationInput(
                title=raw_input.strip()[:120] or "Empty input",
                answer=("No grounded substantive answer is available. The request was preserved and "
                        f"{len(evidence)} candidate evidence artifacts were captured; processing stopped "
                        "at the first ungated boundary."),
                status=terminal,
                unknowns=unknowns or ("no claim-appropriate contact has decided the request",),
                assumptions=("search artifacts are candidates, not support",),
                scope=(arc.contract.scope, f"arc:{arc_id}"),
                next_tests=next_tests,
                provenance=tuple({"evidence_id": e.eid, "locator": e.locator,
                                  "sha256": e.content_sha256} for e in evidence[:20]),
                authority_ceiling=0.0,
            )
            report = self.present(presentation, "standard")
        used = tuple(self._entity_by_locator_digest(e.locator, e.content_sha256)
                     for e in evidence)
        used = tuple(x for x in used if x)
        with self.organs.operation(request_id, "provenance", "inquire", "record inquiry derivation"):
            output_entity = self._record_result_entity(
                label=f"inquiry:{raw_input[:80]}", entity_type="inquiry-result",
                request_id=request_id, used=used,
                content=json.dumps({"arc_id": arc_id, "terminal_state": terminal,
                                    "report": report.result}, sort_keys=True))
        with self.organs.operation(request_id, "audit", "inquire", "verify inquiry chain"):
            integrity = self.verify_integrity()
        payload = {
            "arc_id": arc_id, "terminal_state": terminal, "evidence_count": len(evidence),
            "report": report.result, "result_entity": output_entity,
            "process_status": discovery.result["status"],
        }
        self.audit.append("inquiry_completed", {"request_id": request_id, **payload})
        self._save_runtime()
        return PublicResult(request_id, "inquire", payload, start,
                            len(self.organs.traces), integrity["valid"])

    def interpret(self, raw_input: str, faculty: ProposalFaculty, *,
                  whole_goal_context: Sequence[str] = (),
                  known_constraints: Sequence[str] = ()) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "intent", "interpret", "propose dual POSIWID contract"):
            interpreter = IntentInterpreter(faculty)
            proposal = interpreter.interpret(raw_input,
                                             whole_goal_context=whole_goal_context,
                                             known_constraints=known_constraints)
            payload = asdict(proposal)
            self.intent_proposals[proposal.iid] = payload
        with self.organs.operation(request_id, "provenance", "interpret", "record intent derivation"):
            self._record_result_entity(label=f"intent:{proposal.contract.target}",
                                       entity_type="intent-proposal", request_id=request_id,
                                       content=json.dumps(payload, sort_keys=True))
        self.audit.append("intent_completed", {"request_id": request_id, "proposal": payload})
        self._save_runtime()
        integrity = self.verify_integrity()
        return PublicResult(request_id, "interpret", payload, start,
                            len(self.organs.traces), integrity["valid"])

    def discover_text(self, raw_input: str, envelope: SearchEnvelope,
                      providers: Mapping[str, SearchProvider], *, concrete_provider: str,
                      faculty: ProposalFaculty,
                      execute_abstract_with: Optional[Mapping[str, str]] = None,
                      whole_goal_context: Sequence[str] = (),
                      known_constraints: Sequence[str] = ()) -> PublicResult:
        """Interpret raw input, then run the normal discovery surface.

        The interpretation remains a zero-authority proposal and is immediately
        exposed to contrastive search; it is not silently promoted to the goal.
        """
        interpretation = self.interpret(raw_input, faculty,
                                        whole_goal_context=whole_goal_context,
                                        known_constraints=known_constraints)
        contract_raw = dict(interpretation.result["contract"])
        for key in ("local_current", "local_goal", "whole_current", "whole_goal",
                    "constraints", "anti_goals", "success_observations", "failure_observations"):
            contract_raw[key] = tuple(contract_raw.get(key, ()))
        contract_raw["resource_budget"] = dict(contract_raw.get("resource_budget", {}))
        contract = POSIWIDContract(**contract_raw)
        return self.discover(contract, envelope, providers,
                             concrete_provider=concrete_provider, faculty=faculty,
                             execute_abstract_with=execute_abstract_with)

    def create_arc(self, contract: POSIWIDContract, envelope: SearchEnvelope) -> DiscoveryArc:
        rid = self._request_id()
        with self.organs.operation(rid, "goal-contract", "discover", "create"):
            arc = DiscoveryArc(contract)
            arc.audit.append("search_envelope_declared", asdict(envelope))
            arc.save(str(self._arc_path(arc.arc_id)))
            self._record_result_entity(label=f"POSIWID contract: {contract.target}",
                                       entity_type="goal-contract", request_id=rid,
                                       content=json.dumps(asdict(contract), sort_keys=True))
            self.audit.append("arc_created", {"request_id": rid, "arc_id": arc.arc_id,
                                              "contract": asdict(contract),
                                              "envelope": asdict(envelope)})
            self._save_runtime()
        return arc

    def load_arc(self, arc_id: str) -> DiscoveryArc:
        path = self._arc_path(arc_id)
        if not path.exists():
            raise KeyError(f"unknown arc {arc_id!r}")
        return DiscoveryArc.load(str(path))

    def discover(self, contract: POSIWIDContract, envelope: SearchEnvelope,
                 providers: Mapping[str, SearchProvider], *,
                 concrete_provider: str, faculty: Optional[ProposalFaculty] = None,
                 execute_abstract_with: Optional[Mapping[str, str]] = None) -> PublicResult:
        """Run as far as configured contacts genuinely permit.

        Without a proposal faculty, the method executes broad concrete search and
        stops at the exposure boundary.  It does not fabricate distinctions.
        With a faculty, proposed distinctions/abstractions/reductions are schema-
        checked and remain hypotheses.  Abstract searches are executed only when
        a real provider mapping is supplied.
        """
        rid = self._request_id()
        trace_start = len(self.organs.traces)
        arc = self.create_arc(contract, envelope)
        controller = ARC5Controller(arc, envelope, providers, store=self.content, faculty=faculty)
        with self.organs.operation(rid, "search", "discover", "concrete search"):
            for spec in controller.seed_queries(contract):
                controller.run_search(provider=concrete_provider, text=spec["text"],
                                      stage="concrete", polarity=spec["polarity"], wave=0,
                                      domain_family="concrete-problem")
        if faculty is not None:
            # Concrete compounding waves are mandatory when requested by the
            # search envelope.  Each wave searches for replication, contradiction,
            # boundaries, hidden assumptions, and alternatives.
            for wave in range(1, envelope.min_search_waves):
                with self.organs.operation(rid, "search", "discover", f"concrete follow-up wave {wave}"):
                    controller.propose_followups("concrete", next_wave=wave)
                    for q in [x for x in controller.pending_queries()
                              if x.stage == "concrete" and x.wave == wave]:
                        controller.execute_pending_query(q.qid, concrete_provider)
            with self.organs.operation(rid, "expose", "discover", "functional decomposition"):
                controller.propose_exposure()
            with self.organs.operation(rid, "abstraction", "discover", "abstraction lattice"):
                controller.propose_abstractions()
                mapping = dict(execute_abstract_with or {})
                for q in [x for x in controller.pending_queries() if x.stage == "abstract"]:
                    provider_name = mapping.get(q.domain_family) or mapping.get("*")
                    if provider_name:
                        controller.execute_pending_query(q.qid, provider_name)
                for wave in range(2, envelope.min_search_waves + 1):
                    controller.propose_followups("abstract", next_wave=wave)
                    for q in [x for x in controller.pending_queries()
                              if x.stage == "abstract" and x.wave == wave]:
                        provider_name = mapping.get(q.domain_family) or mapping.get("*")
                        if provider_name:
                            controller.execute_pending_query(q.qid, provider_name)
            # Reduction is forbidden unless the abstraction coverage gate passes.
            if controller.abstraction_gate().passed:
                with self.organs.operation(rid, "reduction", "discover", "mechanism reduction"):
                    controller.propose_reduction()
        self._sync_arc_provenance(arc)
        arc.save(str(self._arc_path(arc.arc_id)))
        status = controller.process_status()
        self.audit.append("discover_completed", {"request_id": rid, "arc_id": arc.arc_id,
                                                 "status": status})
        with self.organs.operation(rid, "provenance", "discover", "record source derivation"):
            self._sync_arc_provenance(arc)
        with self.organs.operation(rid, "audit", "discover", "verify receipts"):
            integrity = self.verify_integrity()
        self._save_runtime()
        return PublicResult(rid, "discover", {"arc_id": arc.arc_id, "status": status,
                                               "integrity": integrity},
                            trace_start, len(self.organs.traces), integrity["valid"])


    # ---------------------------------------------------------- ARC-5 kernel v4A
    def _save_arc_kernel(self, kernel: ARC5Kernel) -> None:
        kernel.save(self._arc_kernel_path(kernel.arc.arc_id))
        kernel.arc.save(self._arc_path(kernel.arc.arc_id))
        self._sync_arc_provenance(kernel.arc)

    def load_arc_kernel(self, arc_id: str) -> ARC5Kernel:
        path = self._arc_kernel_path(arc_id)
        if not path.exists():
            raise KeyError(f"unknown ARC-5 process kernel {arc_id!r}")
        return ARC5Kernel.load(path)

    def start_arc_kernel(self, contract: POSIWIDContract, envelope: SearchEnvelope,
                         eligibility: EligibilityContract, *, name: str = "") -> PublicResult:
        """Create one human-gated ARC-5 process without advancing it."""
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "arc5-kernel", "arc-start", "create queued process"):
            arc = DiscoveryArc(contract, name=name)
            kernel = ARC5Kernel(arc, envelope, eligibility)
            self._save_arc_kernel(kernel)
        with self.organs.operation(request_id, "provenance", "arc-start", "record process contract"):
            obj = self.waist.append(
                "goal", {"arc_id": arc.arc_id, "contract": asdict(contract),
                         "eligibility": asdict(eligibility), "envelope": asdict(envelope)},
                logical_id=f"arc5:{arc.arc_id}", representation="arc5-process+json",
                status="proposed", authority_ceiling=0.0)
        self.audit.append("arc5_kernel_started", {"request_id": request_id, "arc_id": arc.arc_id})
        self._save_runtime()
        integrity = self.verify_integrity()
        return PublicResult(request_id, "arc-start", {
            "arc_id": arc.arc_id, "status": kernel.status(),
        }, start, len(self.organs.traces), integrity["valid"], obj.logical_id)

    def arc_kernel_status(self, arc_id: str) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        kernel = self.load_arc_kernel(arc_id)
        with self.organs.operation(request_id, "arc5-kernel", "arc-status", "read process state"):
            result = {"status": kernel.status(), "integrity": kernel.verify()}
        return PublicResult(request_id, "arc-status", result, start,
                            len(self.organs.traces), result["integrity"]["valid"])

    def execute_arc_search(self, arc_id: str, track: str,
                           providers: Mapping[str, SearchProvider], *,
                           provider_map: Mapping[str, str]) -> PublicResult:
        """Execute frozen planned searches; provider contact remains explicit."""
        request_id, start = self._request_id(), len(self.organs.traces)
        kernel = self.load_arc_kernel(arc_id)
        if track not in {"concrete", "abstract"}:
            raise ValueError("track must be concrete or abstract")
        if kernel.current_stage != track:
            raise RuntimeError(
                f"cannot execute {track} search while ARC is at {kernel.current_stage}")
        plan = kernel.search_plans[track]
        if not plan.verify():
            raise RuntimeError(f"{track} search plan is not frozen or was mutated")
        controller = ARC5Controller(kernel.arc, kernel.envelope, providers, store=self.content)
        outcomes = []
        with self.organs.operation(request_id, "search", "arc-search", f"execute frozen {track} plan"):
            for req in sorted(plan.requirements.values(), key=lambda x: (x.wave, x.rid)):
                if req.status != "planned":
                    continue
                provider_name = provider_map.get(req.domain_family) or provider_map.get("*")
                if not provider_name:
                    kernel.mark_search_failed(req.rid, "no provider mapped for domain family")
                    outcomes.append({"requirement_id": req.rid, "status": "failed",
                                     "reason": req.failure})
                    continue
                if provider_name not in providers:
                    kernel.mark_search_failed(req.rid, f"unknown provider {provider_name}")
                    outcomes.append({"requirement_id": req.rid, "status": "failed",
                                     "reason": req.failure})
                    continue
                parent_query = ""
                if req.parent_requirement_id:
                    parent = plan.requirements.get(req.parent_requirement_id)
                    parent_query = parent.query_id if parent else ""
                try:
                    receipt = controller.run_search(
                        provider=provider_name, text=req.text, stage=track,
                        polarity=req.polarity, wave=req.wave,
                        domain_family=req.domain_family,
                        abstraction_id=req.abstraction_id,
                        parent_query_id=parent_query,
                        rationale=f"{req.category}: {req.rationale}")
                    kernel.mark_search_executed(req.rid, str(receipt["qid"]),
                                                int(receipt["results"]))
                    outcomes.append({"requirement_id": req.rid, "status": "executed", **receipt})
                except Exception as exc:
                    kernel.mark_search_failed(req.rid, f"{type(exc).__name__}: {exc}")
                    outcomes.append({"requirement_id": req.rid, "status": "failed",
                                     "reason": req.failure})
        self._save_arc_kernel(kernel)
        self.audit.append("arc5_search_executed", {
            "request_id": request_id, "arc_id": arc_id, "track": track,
            "outcomes": outcomes})
        self._save_runtime()
        integrity = self.verify_integrity()
        return PublicResult(request_id, "arc-search", {
            "arc_id": arc_id, "track": track, "outcomes": outcomes,
            "gate": asdict(kernel.coverage_gate(track)),
        }, start, len(self.organs.traces), integrity["valid"])

    def apply_arc_operation(self, arc_id: str, operation: Mapping[str, object]) -> PublicResult:
        """Apply one explicit human or structured process operation.

        This is intentionally granular.  It prevents an LLM or caller from
        silently running the entire discovery arc in one self-confirming pass.
        """
        request_id, start = self._request_id(), len(self.organs.traces)
        kernel = self.load_arc_kernel(arc_id)
        op = str(operation.get("op", "")).strip()
        if not op:
            raise ValueError("operation requires an 'op' field")
        from .discovery import (FunctionalDistinction, AbstractionNode, ExampleCase,
                                MechanismHypothesis, SystemHypothesis, TestObligation)

        # The public surface is a human-gated state machine.  Low-level kernel
        # methods remain testable in isolation, but callers cannot skip a stage
        # by issuing later operations through ``arc-step``.
        allowed_by_stage = {
            "contract": {"freeze_contract", "approve", "amend", "enqueue", "work_state"},
            "concrete": {"seed_concrete_plan", "seed_followup_plan",
                         "add_search_requirement", "freeze_search_plan",
                         "screen_evidence", "add_lineage", "approve",
                         "amend", "enqueue", "work_state"},
            "expose": {"add_distinction", "approve", "amend", "enqueue", "work_state"},
            "abstract": {"add_abstraction", "seed_abstract_plan",
                         "seed_followup_plan", "add_search_requirement",
                         "freeze_search_plan", "screen_evidence", "add_lineage",
                         "add_transfer", "approve", "amend", "enqueue", "work_state"},
            "reduce": {"add_example", "add_mechanism", "add_case_assessment",
                       "infer_mechanism", "add_system", "add_test", "freeze_tests",
                       "approve", "amend", "enqueue", "work_state"},
            "contact": {"record_contact", "approve", "amend", "enqueue", "work_state"},
            "complete": {"approve", "amend", "enqueue", "work_state"},
        }
        if op not in allowed_by_stage[kernel.current_stage]:
            raise RuntimeError(
                f"operation {op!r} is not allowed while ARC is at "
                f"{kernel.current_stage!r}; complete or reopen the proper stage")
        if op == "approve" and str(operation.get("stage", "")) != kernel.current_stage:
            raise RuntimeError("approval stage must equal the current human-gated stage")
        if op == "seed_followup_plan" and str(operation.get("track")) != kernel.current_stage:
            raise RuntimeError("follow-up search track must match the current stage")
        if op == "freeze_search_plan" and str(operation.get("track")) != kernel.current_stage:
            raise RuntimeError("search-plan track must match the current stage")

        with self.organs.operation(request_id, "arc5-kernel", "arc-step", op):
            if op == "freeze_contract":
                result = {"digest": kernel.freeze_contract(str(operation["actor"]))}
            elif op == "seed_concrete_plan":
                result = {"requirement_ids": kernel.seed_concrete_plan()}
            elif op == "seed_followup_plan":
                result = {"requirement_ids": kernel.seed_followup_plan(
                    str(operation["track"]), int(operation["wave"]))}
            elif op == "seed_abstract_plan":
                result = {"requirement_ids": kernel.seed_abstract_plan()}
            elif op == "add_search_requirement":
                raw = dict(operation["requirement"])
                result = {"requirement_id": kernel.add_search_requirement(SearchRequirement(**raw))}
            elif op == "freeze_search_plan":
                result = {"digest": kernel.freeze_search_plan(str(operation["track"]),
                                                               str(operation["actor"]))}
            elif op == "screen_evidence":
                raw = dict(operation["decision"]); raw["criteria"] = tuple(raw.get("criteria", ()))
                result = {"screening_id": kernel.screen_evidence(ScreeningDecision(**raw))}
            elif op == "add_lineage":
                raw = dict(operation["profile"])
                for key in ("study_ids", "dataset_ids", "model_families", "institutions",
                            "author_groups", "funding_sources", "raw_source_ids", "other_roots"):
                    raw[key] = tuple(raw.get(key, ()))
                result = {"lineage_id": kernel.add_lineage(EvidenceLineageProfile(**raw))}
            elif op == "add_distinction":
                raw = dict(operation["distinction"])
                for key in ("dimensions", "functions", "interfaces", "authority_effects",
                            "resource_flows", "failure_propagation", "evidence_ids"):
                    raw[key] = tuple(raw.get(key, ()))
                result = {"distinction_id": kernel.arc.add_distinction(FunctionalDistinction(**raw))}
            elif op == "add_abstraction":
                raw = dict(operation["abstraction"])
                for key in ("removed_incidentals", "retained_constraints", "search_terms"):
                    raw[key] = tuple(raw.get(key, ()))
                result = {"abstraction_id": kernel.arc.add_abstraction(AbstractionNode(**raw))}
            elif op == "add_transfer":
                raw = dict(operation["transfer"])
                for key in ("retained_causal_structure", "retained_constraints",
                            "contextual_mismatches", "anti_analogy", "translation_prediction",
                            "evidence_ids"):
                    raw[key] = tuple(raw.get(key, ()))
                result = {"transfer_id": kernel.add_transfer(TransferCase(**raw))}
            elif op == "add_example":
                raw = dict(operation["example"])
                for key in ("context", "observed_mechanisms", "evidence_ids", "boundary_conditions"):
                    raw[key] = tuple(raw.get(key, ()))
                result = {"example_id": kernel.arc.add_example(ExampleCase(**raw))}
            elif op == "add_mechanism":
                raw = dict(operation["mechanism"])
                for key in ("contexts", "predicted_effects", "evidence_for", "evidence_against",
                            "positive_cases", "negative_cases", "substitutes", "required_substrate",
                            "work_relocated_to", "local_posiwid_effect", "whole_posiwid_effect",
                            "failure_modes", "scope_limits"):
                    raw[key] = tuple(raw.get(key, ()))
                result = {"mechanism_id": kernel.arc.add_mechanism(MechanismHypothesis(**raw))}
            elif op == "add_case_assessment":
                raw = dict(operation["assessment"])
                for key in ("confounders", "evidence_ids"):
                    raw[key] = tuple(raw.get(key, ()))
                result = {"assessment_id": kernel.add_case_assessment(MechanismCaseAssessment(**raw))}
            elif op == "infer_mechanism":
                result = asdict(kernel.infer_mechanism(str(operation["mechanism_id"])))
            elif op == "add_system":
                raw = dict(operation["system"])
                for key in ("mechanism_ids", "composition", "local_predictions", "whole_predictions",
                            "assumptions", "expected_failures"):
                    raw[key] = tuple(raw.get(key, ()))
                result = {"system_id": kernel.arc.add_system_hypothesis(SystemHypothesis(**raw))}
            elif op == "add_test":
                if kernel.test_plan_digest:
                    raise RuntimeError("cannot add tests after test-plan freeze")
                raw = dict(operation["test"]); raw["evidence_ids"] = tuple(raw.get("evidence_ids", ()))
                result = {"test_id": kernel.arc.add_test(TestObligation(**raw))}
            elif op == "freeze_tests":
                result = {"digest": kernel.freeze_tests(str(operation["actor"]))}
            elif op == "approve":
                result = asdict(kernel.approve(str(operation["stage"]),
                                               str(operation["decision"]),
                                               str(operation["actor"]),
                                               str(operation["rationale"])))
            elif op == "record_contact":
                diagnosis = kernel.record_contact(
                    str(operation["test_id"]), str(operation["state"]),
                    str(operation["observed"]), result=str(operation.get("result", "")),
                    failure_layer=str(operation.get("failure_layer", "")),
                    evidence_ids=tuple(operation.get("evidence_ids", ())))
                result = {"test": asdict(kernel.arc.tests[str(operation["test_id"])]),
                          "diagnosis": asdict(diagnosis) if diagnosis else None}
            elif op == "amend":
                result = asdict(kernel.amend(
                    str(operation["reopen_stage"]), str(operation["reason"]),
                    dict(operation.get("changes", {})), actor=str(operation["actor"]),
                    approval_ref=str(operation["approval_ref"])))
            elif op == "enqueue":
                result = {"work_id": kernel.enqueue(
                    str(operation["stage"]), str(operation["reason"]),
                    source_id=str(operation.get("source_id", "")),
                    priority=float(operation.get("priority", 1.0)),
                    blocked_by=tuple(operation.get("blocked_by", ())))}
            elif op == "work_state":
                kernel.set_work_state(str(operation["work_id"]), str(operation["state"]))
                result = {"work_id": str(operation["work_id"]), "state": str(operation["state"])}
            else:
                raise ValueError(f"unsupported ARC-5 kernel operation {op!r}")
            kernel.arc.audit.append("arc5_public_operation", {"operation": op, "result": result})
            self._save_arc_kernel(kernel)
        self.audit.append("arc5_operation_applied", {
            "request_id": request_id, "arc_id": arc_id, "operation": op,
            "result": result})
        self._save_runtime()
        integrity = self.verify_integrity()
        return PublicResult(request_id, "arc-step", {
            "arc_id": arc_id, "operation": op, "result": result,
            "status": kernel.status(),
        }, start, len(self.organs.traces), integrity["valid"])

    # ------------------------------------------------ ARC-5A adversarial kernel
    def _arc5a_path(self, arc_id: str) -> Path:
        return self.root / "arc5a_kernels" / f"{arc_id}.json"

    def _save_arc5a_kernel(self, kernel: ARC5AAdversarialKernel) -> None:
        kernel.save(self._arc5a_path(kernel.arc.arc_id))
        kernel.arc.save(self._arc_path(kernel.arc.arc_id))
        self._sync_arc_provenance(kernel.arc)

    def load_arc5a_kernel(self, arc_id: str) -> ARC5AAdversarialKernel:
        path = self._arc5a_path(arc_id)
        if not path.exists():
            raise KeyError(f"unknown ARC-5A adversarial kernel {arc_id!r}")
        return ARC5AAdversarialKernel.load(path)

    def start_arc5a_kernel(self, contract: POSIWIDContract, envelope: SearchEnvelope,
                           eligibility: EligibilityContract, hostile: HostileInterpretation,
                           *, name: str = "") -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "arc5a-kernel", "arc5a-start", "create adversarial queued process"):
            arc = DiscoveryArc(contract, name=name)
            kernel = ARC5AAdversarialKernel(arc, envelope, eligibility, hostile)
            self._save_arc5a_kernel(kernel)
        with self.organs.operation(request_id, "provenance", "arc5a-start", "record bifurcated contracts"):
            obj = self.waist.append(
                "goal", {"arc_id": arc.arc_id, "contract": asdict(contract),
                         "hostile": asdict(hostile), "eligibility": asdict(eligibility),
                         "envelope": asdict(envelope)},
                logical_id=f"arc5a:{arc.arc_id}", representation="arc5a-process+json",
                status="proposed", authority_ceiling=0.0)
        self.audit.append("arc5a_started", {"request_id": request_id, "arc_id": arc.arc_id})
        self._save_runtime(); integrity = self.verify_integrity()
        return PublicResult(request_id, "arc5a-start", {
            "arc_id": arc.arc_id, "status": kernel.status(),
        }, start, len(self.organs.traces), integrity["valid"], obj.logical_id)

    def arc5a_status(self, arc_id: str) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        kernel = self.load_arc5a_kernel(arc_id)
        with self.organs.operation(request_id, "arc5a-kernel", "arc5a-status", "read adversarial process"):
            result = {"status": kernel.status(), "integrity": kernel.verify()}
        return PublicResult(request_id, "arc5a-status", result, start,
                            len(self.organs.traces), result["integrity"]["valid"])

    def execute_arc5a_search(self, arc_id: str, lane: str,
                             providers: Mapping[str, SearchProvider], *,
                             provider_map: Mapping[str, str]) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        kernel = self.load_arc5a_kernel(arc_id)
        if lane not in LANES:
            raise ValueError("unknown ARC-5A search lane")
        required_stage = LANE_STAGE[lane]
        if kernel.current_stage != required_stage:
            raise RuntimeError(f"cannot execute {lane} while ARC-5A is at {kernel.current_stage}")
        plan = kernel.search_plans[lane]
        if not plan.verify():
            raise RuntimeError(f"{lane} plan is not frozen or was mutated")
        controller = ARC5Controller(kernel.arc, kernel.envelope, providers, store=self.content)
        outcomes = []
        with self.organs.operation(request_id, "search", "arc5a-search", f"execute frozen {lane}"):
            for req in sorted(plan.requirements.values(), key=lambda x: (x.wave, x.rid)):
                if req.status != "planned":
                    continue
                provider_name = provider_map.get(req.domain_family) or provider_map.get("*")
                if not provider_name or provider_name not in providers:
                    kernel.mark_search_failed(req.rid, "no available provider mapped")
                    outcomes.append({"requirement_id": req.rid, "status": "failed", "reason": req.failure})
                    continue
                parent_query = ""
                if req.parent_requirement_id:
                    parent = plan.requirements.get(req.parent_requirement_id)
                    parent_query = parent.query_id if parent else ""
                try:
                    receipt = controller.run_search(
                        provider=provider_name, text=req.text, stage=required_stage,
                        polarity=req.polarity, wave=req.wave,
                        domain_family=req.domain_family,
                        abstraction_id=req.abstraction_id,
                        parent_query_id=parent_query,
                        rationale=f"arc5a:{lane}:{req.category}: {req.rationale}")
                    kernel.mark_search_executed(req.rid, str(receipt["qid"]), int(receipt["results"]))
                    outcomes.append({"requirement_id": req.rid, "status": "executed", **receipt})
                except Exception as exc:
                    kernel.mark_search_failed(req.rid, f"{type(exc).__name__}: {exc}")
                    outcomes.append({"requirement_id": req.rid, "status": "failed", "reason": req.failure})
        self._save_arc5a_kernel(kernel)
        self.audit.append("arc5a_search_executed", {
            "request_id": request_id, "arc_id": arc_id, "lane": lane, "outcomes": outcomes})
        self._save_runtime(); integrity = self.verify_integrity()
        return PublicResult(request_id, "arc5a-search", {
            "arc_id": arc_id, "lane": lane, "outcomes": outcomes,
            "gate": asdict(kernel.coverage_gate(lane)),
        }, start, len(self.organs.traces), integrity["valid"])

    def apply_arc5a_operation(self, arc_id: str, operation: Mapping[str, object]) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        kernel = self.load_arc5a_kernel(arc_id)
        op = str(operation.get("op", "")).strip()
        if not op:
            raise ValueError("operation requires an 'op' field")
        from .discovery import AbstractionNode, TestObligation

        allowed = {
            "contract": {"freeze_contracts", "approve"},
            "concrete": {"seed_concrete_plans", "seed_followups", "add_search_requirement",
                         "freeze_search_plan", "screen_evidence", "add_lineage", "approve"},
            "expose": {"add_decomposition", "add_decomposition_disagreement", "approve"},
            "abstract": {"register_abstraction", "seed_abstract_plans", "seed_followups",
                         "add_search_requirement", "freeze_search_plan", "screen_evidence",
                         "add_lineage", "approve"},
            "arena": {"add_candidate", "add_pareto_dimension", "add_pareto_assessment",
                      "compute_pareto", "add_test", "pair_tests", "add_saturation_wave",
                      "freeze_tests", "approve"},
            "contact": {"record_contact", "approve"},
            "complete": {"approve"},
        }
        if op not in allowed[kernel.current_stage]:
            raise RuntimeError(f"operation {op!r} is not allowed at {kernel.current_stage!r}")
        with self.organs.operation(request_id, "arc5a-kernel", "arc5a-step", op):
            if op == "freeze_contracts":
                result = {"digest": kernel.freeze_contracts(str(operation["actor"]))}
            elif op == "seed_concrete_plans":
                result = kernel.seed_concrete_plans(str(operation["constructive_author"]),
                                                    str(operation["destructive_author"]))
            elif op == "seed_followups":
                result = {"requirement_ids": kernel.seed_followups(
                    str(operation["lane"]), int(operation["wave"]), str(operation["author"]))}
            elif op == "add_search_requirement":
                result = {"requirement_id": kernel.add_search_requirement(
                    LaneSearchRequirement(**dict(operation["requirement"]))) }
            elif op == "freeze_search_plan":
                result = {"digest": kernel.freeze_search_plan(str(operation["lane"]), str(operation["actor"]))}
            elif op == "screen_evidence":
                raw = dict(operation["decision"]); raw["criteria"] = tuple(raw.get("criteria", ()))
                result = {"screening_id": kernel.screen_evidence(ScreeningDecision(**raw))}
            elif op == "add_lineage":
                raw = dict(operation["profile"])
                for key in ("study_ids", "dataset_ids", "model_families", "institutions",
                            "author_groups", "funding_sources", "raw_source_ids", "other_roots"):
                    raw[key] = tuple(raw.get(key, ()))
                result = {"lineage_id": kernel.add_lineage(EvidenceLineageProfile(**raw))}
            elif op == "add_decomposition":
                raw = dict(operation["decomposition"])
                for key in ("starting_observations", "causal_steps", "interfaces",
                            "hidden_resources_or_authority", "predicted_failure_propagation", "evidence_ids"):
                    raw[key] = tuple(raw.get(key, ()))
                result = {"decomposition_id": kernel.add_decomposition(DecompositionPass(**raw))}
            elif op == "add_decomposition_disagreement":
                result = {"disagreement_id": kernel.add_decomposition_disagreement(
                    DecompositionDisagreement(**dict(operation["disagreement"]))) }
            elif op == "register_abstraction":
                nraw = dict(operation["abstraction"])
                for key in ("removed_incidentals", "retained_constraints", "search_terms"):
                    nraw[key] = tuple(nraw.get(key, ()))
                rraw = dict(operation["registration"]); rraw["excluded_framings"] = tuple(rraw.get("excluded_framings", ()))
                result = {"abstraction_id": kernel.register_abstraction(
                    AbstractionNode(**nraw), AbstractionRegistration(**rraw))}
            elif op == "seed_abstract_plans":
                result = kernel.seed_abstract_plans(str(operation["function_author"]),
                                                    str(operation["counterfactual_author"]))
            elif op == "add_candidate":
                raw = dict(operation["candidate"])
                for key in ("mechanism_ids", "composition", "local_posiwid", "whole_posiwid",
                            "assumptions", "resource_relocations", "failure_modes",
                            "security_authority_consequences", "support_evidence_ids", "attack_evidence_ids"):
                    raw[key] = tuple(raw.get(key, ()))
                result = {"candidate_id": kernel.add_candidate(ArenaCandidate(**raw))}
            elif op == "add_pareto_dimension":
                result = {"dimension_id": kernel.add_pareto_dimension(
                    ParetoDimension(**dict(operation["dimension"]))) }
            elif op == "add_pareto_assessment":
                raw = dict(operation["assessment"]); raw["evidence_ids"] = tuple(raw.get("evidence_ids", ()))
                result = {"assessment_id": kernel.add_pareto_assessment(ParetoAssessment(**raw))}
            elif op == "compute_pareto":
                result = kernel.compute_pareto_frontier()
            elif op == "add_test":
                raw = dict(operation["test"]); raw["evidence_ids"] = tuple(raw.get("evidence_ids", ()))
                result = {"test_id": kernel.add_test(TestObligation(**raw))}
            elif op == "pair_tests":
                result = {"pair_id": kernel.pair_tests(
                    AdversarialTestPair(**dict(operation["pair"]))) }
            elif op == "add_saturation_wave":
                raw = dict(operation["wave"]); raw["evidence_ids"] = tuple(raw.get("evidence_ids", ()))
                result = {"wave_id": kernel.add_saturation_wave(DecisionSaturationWave(**raw))}
            elif op == "freeze_tests":
                result = {"digest": kernel.freeze_tests(str(operation["actor"]))}
            elif op == "record_contact":
                raw = dict(operation["contact"]); raw["evidence_ids"] = tuple(raw.get("evidence_ids", ()))
                reopened = kernel.record_contact(ContactRecord(**raw),
                                                 failure_layer=str(operation.get("failure_layer", "")))
                result = {"reopened_stage": reopened}
            elif op == "approve":
                result = asdict(kernel.approve(str(operation["stage"]), str(operation["decision"]),
                                               str(operation["actor"]), str(operation["rationale"])))
            else:
                raise ValueError(f"unsupported ARC-5A operation {op!r}")
            kernel.arc.audit.append("arc5a_public_operation", {"operation": op, "result": result})
            self._save_arc5a_kernel(kernel)
        self.audit.append("arc5a_operation_applied", {
            "request_id": request_id, "arc_id": arc_id, "operation": op, "result": result})
        self._save_runtime(); integrity = self.verify_integrity()
        return PublicResult(request_id, "arc5a-step", {
            "arc_id": arc_id, "operation": op, "result": result, "status": kernel.status(),
        }, start, len(self.organs.traces), integrity["valid"])


    def register_process_task(self, task: Mapping[str, object]) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        raw = dict(task)
        for key in ("required_capabilities", "mandatory_capabilities",
                    "success_observations", "failure_observations"):
            raw[key] = tuple(raw.get(key, ()))
        profile = ProcessTaskProfile(**raw)
        with self.organs.operation(request_id, "process-portfolio", "process-task",
                                   "register process-selection task and strongest-selection arena"):
            task_id = self.process_portfolio.register_task(profile)
            candidate_ids = self.process_portfolio.seed_task_candidates(task_id, profile.author)
        self.audit.append("process_task_registered", {
            "request_id": request_id, "task_id": task_id,
            "candidate_ids": list(candidate_ids)})
        self._save_runtime(); integrity = self.verify_integrity()
        return PublicResult(request_id, "process-task", {
            "task_id": task_id, "candidate_ids": candidate_ids,
            "task": asdict(profile)}, start, len(self.organs.traces), integrity["valid"])

    def select_process(self, task_id: str, *, actor: str = "human-process-selector") -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        if task_id not in self.process_portfolio.tasks:
            raise KeyError(task_id)
        with self.organs.operation(request_id, "process-portfolio", "process-select",
                                   "evaluate process candidates and preserve Pareto frontier"):
            candidates = [c for c in self.process_portfolio.candidates.values()
                          if c.task_id == task_id]
            assessments = []
            for candidate in candidates:
                assessments.append(self.process_portfolio.assess(
                    candidate.candidate_id, evaluator=f"structural:{actor}"))
            decision = self.process_portfolio.decide(task_id, actor)
        self.audit.append("process_selected", {
            "request_id": request_id, "task_id": task_id,
            "decision_id": decision.decision_id,
            "frontier": list(decision.frontier_ids),
            "execution_profile": list(decision.execution_profile_ids)})
        self._save_runtime(); integrity = self.verify_integrity()
        return PublicResult(request_id, "process-select", {
            "task_id": task_id,
            "assessments": [asdict(x) for x in assessments],
            "decision": asdict(decision),
            "nonclaim": "structural mechanism-fit is not longitudinal superiority",
        }, start, len(self.organs.traces), integrity["valid"])

    def process_status(self) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "process-portfolio", "process-status",
                                   "read process-method portfolio and decisions"):
            result = {
                "methods": {k: asdict(v) for k, v in sorted(self.process_portfolio.methods.items())},
                "tasks": {k: asdict(v) for k, v in sorted(self.process_portfolio.tasks.items())},
                "candidates": {k: asdict(v) for k, v in sorted(self.process_portfolio.candidates.items())},
                "assessments": {k: asdict(v) for k, v in sorted(self.process_portfolio.assessments.items())},
                "decisions": {k: asdict(v) for k, v in sorted(self.process_portfolio.decisions.items())},
                "integrity": self.process_portfolio.verify(),
            }
        return PublicResult(request_id, "process-status", result, start,
                            len(self.organs.traces), result["integrity"]["valid"])


    def import_arc(self, source: str | os.PathLike[str]) -> PublicResult:
        """Import one complete, audit-valid discovery arc into the instrument.

        Importing does not endorse its hypotheses. It preserves the arc, projects
        its derivation graph, and makes its proposed contacts executable through
        the normal public surface.
        """
        request_id, start = self._request_id(), len(self.organs.traces)
        arc = DiscoveryArc.load(str(source))
        audit = arc.audit.verify()
        if not audit.get("valid", False):
            raise ValueError("cannot import an arc with an invalid audit chain")
        with self.organs.operation(request_id, "provenance", "arc-import", "import arc derivation"):
            arc.save(str(self._arc_path(arc.arc_id)))
            self._sync_arc_provenance(arc)
        with self.organs.operation(request_id, "audit", "arc-import", "record arc import"):
            integrity = self.verify_integrity()
        result = {"arc_id": arc.arc_id, "posiwid": arc.posiwid(), "arc_audit": audit}
        self.audit.append("arc_imported", {"request_id": request_id, **result})
        self._save_runtime()
        return PublicResult(request_id, "arc-import", result, start,
                            len(self.organs.traces), integrity["valid"])

    def record_arc_test(self, arc_id: str, test_id: str, *, state: str, observed: str,
                        result: str = "", failure_layer: str = "",
                        evidence_ids: Sequence[str] = ()) -> PublicResult:
        """Record one real contact result against a proposed ARC test obligation."""
        request_id, start = self._request_id(), len(self.organs.traces)
        arc = self.load_arc(arc_id)
        with self.organs.operation(request_id, "contact", "record-contact", "record discriminating contact"):
            arc.record_test(test_id, state, observed, result=result,
                            failure_layer=failure_layer, evidence_ids=evidence_ids)
            arc.save(str(self._arc_path(arc.arc_id)))
        with self.organs.operation(request_id, "provenance", "record-contact", "project contact derivation"):
            self._sync_arc_provenance(arc)
        with self.organs.operation(request_id, "audit", "record-contact", "verify contact receipt"):
            integrity = self.verify_integrity()
        payload = {"arc_id": arc_id, "test": asdict(arc.tests[test_id]),
                   "arc_posiwid": arc.posiwid()}
        self.audit.append("arc_test_recorded", {"request_id": request_id, **payload})
        self._save_runtime()
        return PublicResult(request_id, "record-contact", payload, start,
                            len(self.organs.traces), integrity["valid"])

    def ingest(self, carving: Carving) -> PublicResult:
        rid, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(rid, "akbc", "ingest", "place carving"):
            decision = self.knowledge.ingest(carving)
        with self.organs.operation(rid, "provenance", "ingest", "record carving lineage"):
            self._record_result_entity(label=f"carving:{carving.label}", entity_type="carving",
                                       request_id=rid, content=json.dumps(asdict(carving), sort_keys=True))
        with self.organs.operation(rid, "audit", "ingest", "persist knowledge"):
            self.knowledge.save(str(self.root / "knowledge.json"))
            integrity = self.verify_integrity()
        self.audit.append("ingest_completed", {"request_id": rid, "decision": asdict(decision)})
        self._save_runtime()
        return PublicResult(rid, "ingest", asdict(decision), start,
                            len(self.organs.traces), integrity["valid"])

    def register_grounding_executor(self, kind: str, executor, *, contact: str,
                                    quality: float, resource: str = "") -> None:
        """Register an external contact without granting it self-declared authority."""
        self.knowledge.harness.register(
            kind, executor, contact=contact, capability_resource=resource or None,
            epistemic_weight=quality,
        )
        self.audit.append("grounding_executor_registered", {
            "kind": kind, "contact": contact, "quality": quality,
            "resource": resource,
        })
        self._save_runtime()

    def ground_observation(self, observation_id: str, test) -> PublicResult:
        """Run a registered contact against one existing observation."""
        rid, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(rid, "contact", "verify", "execute observation grounding contact"):
            verdict = self.knowledge.ground_observation(observation_id, test)
        with self.organs.operation(rid, "akbc", "ingest", "project grounded observation state"):
            report = self.knowledge.posiwid()
        self.audit.append("observation_grounded", {
            "request_id": rid, "observation_id": observation_id,
            "verdict": asdict(verdict),
        })
        self.knowledge.save(str(self.root / "knowledge.json"))
        self._save_runtime()
        return PublicResult(rid, "verify", {
            "verdict": asdict(verdict), "knowledge": report,
        }, start, len(self.organs.traces), self.verify_integrity()["valid"])

    def investigate(self, request: InquiryRequest,
                    faculty: Optional[ProposalFaculty] = None) -> PublicResult:
        """Acquire real artifacts and run the bounded public AKBC spine.

        This capability is deliberately narrower than arbitrary research. It
        retrieves user- or search-supplied artifacts, preserves exact bytes,
        parses them, extracts only bounded proposal structure, and performs
        reversible placement. It returns an abstention rather than a substantive
        answer whenever verification or semantics are not available.
        """
        rid, start = request.request_id, len(self.organs.traces)
        with self.organs.operation(rid, "acquisition", "investigate", "retrieve and parse artifacts"):
            engine = InquiryEngine(self.acquisition, self.knowledge, self.arguments)
            with self.organs.operation(rid, "carving", "investigate", "extract proposal-only carvings"):
                with self.organs.operation(rid, "akbc", "investigate", "place observations reversibly"):
                    report = engine.run(request, faculty)

        # Build a derivation chain over exact acquired bytes, parse transforms,
        # extraction receipts, observations and the final inquiry report. This
        # makes source revocation operational rather than decorative.
        artifact_entities: dict[str, str] = {}
        parse_entities: dict[str, str] = {}
        extraction_entities: dict[str, str] = {}
        with self.organs.operation(rid, "provenance", "investigate", "record complete artifact derivation"):
            source_agent = self._provider_agent("artifact-acquisition")
            for row in report.artifacts:
                ar = row["artifact"]
                pr = row["parse"]
                existing = self._entity_by_locator_digest(ar["locator"], ar["content_sha256"])
                if existing:
                    aeid = existing
                else:
                    now = time.time()
                    act = self.provenance.add_activity(ProvActivity(
                        activity_type="acquisition", used=(), associated_with=(source_agent,),
                        started_at=now, ended_at=now,
                        plan=f"inquiry:{rid}:acquire:{ar['artifact_id']}"))
                    aeid = self.provenance.add_entity(ProvEntity(
                        label=f"artifact:{Path(ar['locator']).name or ar['locator']}",
                        content_sha256=ar["content_sha256"], locator=ar["locator"],
                        entity_type="source-artifact", generated_by=act,
                        attributed_to=(source_agent,)))
                artifact_entities[ar["artifact_id"]] = aeid
                now = time.time()
                pact = self.provenance.add_activity(ProvActivity(
                    activity_type="parse", used=(aeid,), associated_with=(source_agent,),
                    started_at=now, ended_at=now,
                    plan=f"inquiry:{rid}:parse:{pr['parse_id']}:{pr['parser']}:{pr['parser_version']}"))
                peid = self.provenance.add_entity(ProvEntity(
                    label=f"parse:{pr['parse_id']}", content_sha256=pr["text_sha256"],
                    locator=f"parse://{pr['parse_id']}", entity_type="parsed-artifact",
                    generated_by=pact, derived_from=(aeid,), attributed_to=(source_agent,)))
                parse_entities[pr["parse_id"]] = peid

            analyst = self._provider_agent("field-instrument")
            for er in report.extraction_receipts:
                used = tuple(x for x in (
                    artifact_entities.get(er["artifact_id"]),
                    parse_entities.get(er["parse_id"]),
                ) if x)
                content = json.dumps(er, sort_keys=True)
                digest = __import__("hashlib").sha256(content.encode()).hexdigest()
                now = time.time()
                eact = self.provenance.add_activity(ProvActivity(
                    activity_type="extraction", used=used, associated_with=(analyst,),
                    started_at=now, ended_at=now,
                    plan=f"inquiry:{rid}:extract:{er['extraction_id']}"))
                eeid = self.provenance.add_entity(ProvEntity(
                    label=f"extraction:{er['extractor']}", content_sha256=digest,
                    locator=f"extract://{er['extraction_id']}", entity_type="extraction-receipt",
                    generated_by=eact, derived_from=used, attributed_to=(analyst,)))
                extraction_entities[er["extraction_id"]] = eeid

            used = tuple(dict.fromkeys((*artifact_entities.values(), *parse_entities.values(),
                                        *extraction_entities.values())))
            report_entity = self._record_result_entity(
                label=f"inquiry:{request.question[:80]}", entity_type="inquiry-report",
                request_id=rid, used=used,
                content=json.dumps(asdict(report), sort_keys=True),
            )
            # Observation nodes are explicit descendants of the extraction
            # evidence available for this request. Placement does not grant them
            # truth authority.
            extraction_used = tuple(extraction_entities.values())
            for placement in report.placements:
                self._record_result_entity(
                    label=f"observation:{placement['observation_id']}",
                    entity_type="akbc-observation", request_id=rid,
                    used=extraction_used,
                    content=json.dumps(placement, sort_keys=True),
                )

        with self.organs.operation(rid, "audit", "investigate", "persist and verify inquiry"):
            self.knowledge.save(str(self.root / "knowledge.json"))
            integrity = self.verify_integrity()
        self.audit.append("investigation_completed", {
            "request_id": rid, "report": asdict(report),
        })
        self._save_runtime()
        return PublicResult(rid, "investigate", asdict(report), start,
                            len(self.organs.traces), integrity["valid"])

    def register_contract(self, contract: VerificationContract) -> None:
        self.verification.register_contract(contract)

    def register_verifier(self, verifier: RegisteredVerifier) -> None:
        self.verification.register_verifier(verifier)

    def verify_claim(self, request: VerificationRequest,
                     *, capability: Optional[dict] = None) -> PublicResult:
        rid, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(rid, "contact", "verify", "execute contact"):
            with self.organs.operation(rid, "verification", "verify", "apply contract"):
                result = self.verification.verify(request, capability=capability)
        with self.organs.operation(rid, "provenance", "verify", "record verification derivation"):
            self._record_result_entity(label=f"verification:{request.claim.statement[:80]}",
                                       entity_type="verification-result", request_id=rid,
                                       content=json.dumps(asdict(result), sort_keys=True))
        with self.organs.operation(rid, "audit", "verify", "record verification"):
            integrity = self.verify_integrity()
        self.audit.append("verification_completed", {"request_id": rid,
                                                       "result": asdict(result)})
        self._save_runtime()
        return PublicResult(rid, "verify", asdict(result), start,
                            len(self.organs.traces), integrity["valid"])

    def settle(self, field: Field, *, need_event_trace: bool = False,
               model_id: str = "", model_context: Optional[Mapping[str, object]] = None) -> PublicResult:
        rid, start = self._request_id(), len(self.organs.traces)
        applicability = None
        with self.organs.operation(rid, "scope", "settle", "check model applicability"):
            if model_id:
                applicability = self.models.require_applicable(model_id, dict(model_context or {}))
        with self.organs.operation(rid, "settling", "settle", "constraint propagation"):
            report, route = self.router.settle(field, need_event_trace=need_event_trace)
        with self.organs.operation(rid, "provenance", "settle", "record settlement derivation"):
            self._record_result_entity(label=f"settlement:{field.name}", entity_type="settlement",
                                       request_id=rid, content=json.dumps(asdict(report), sort_keys=True))
        with self.organs.operation(rid, "audit", "settle", "record route"):
            integrity = self.verify_integrity()
        result = {"report": asdict(report), "route": asdict(route),
                  "model_applicability": asdict(applicability) if applicability else None,
                  "model_basis": "registered_applicable" if applicability else "caller_declared"}
        self.audit.append("settle_completed", {"request_id": rid, **result})
        self._save_runtime()
        return PublicResult(rid, "settle", result, start,
                            len(self.organs.traces), integrity["valid"])

    def register_model(self, model: ModelContract) -> None:
        self.models.register(model)
        self._save_runtime()

    def check_model(self, model_id: str, context: Mapping[str, object]) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "scope", "scope", "evaluate applicability"):
            decision = self.models.evaluate(model_id, context)
        with self.organs.operation(request_id, "provenance", "scope", "record scope decision"):
            self._record_result_entity(label=f"scope:{model_id}", entity_type="scope-decision",
                                       request_id=request_id,
                                       content=json.dumps(asdict(decision), sort_keys=True))
        self.audit.append("model_scope_completed", {"request_id": request_id,
                                                    "decision": asdict(decision)})
        self._save_runtime()
        integrity = self.verify_integrity()
        return PublicResult(request_id, "scope", asdict(decision), start,
                            len(self.organs.traces), integrity["valid"])

    def select_ir(self, requirement: IRRequirement) -> PublicResult:
        rid, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(rid, "ir-selection", "represent", "select representation"):
            selection = self.ir.select(requirement)
        with self.organs.operation(rid, "provenance", "represent", "record representation selection"):
            self._record_result_entity(label=f"IR selection:{requirement.claim_class}",
                                       entity_type="ir-selection", request_id=rid,
                                       content=json.dumps(asdict(selection), sort_keys=True))
        self.audit.append("ir_selection_completed", {"request_id": rid,
                                                      "requirement": asdict(requirement),
                                                      "selection": asdict(selection)})
        self._save_runtime()
        return PublicResult(rid, "represent", asdict(selection), start,
                            len(self.organs.traces), self.verify_integrity()["valid"])

    def add_argument_claim(self, claim: ArgumentClaim) -> PublicResult:
        rid, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(rid, "argument", "argue", "add claim"):
            cid = self.arguments.add_claim(claim)
            report = self.arguments.report(cid)
        with self.organs.operation(rid, "provenance", "argue", "record argument claim"):
            self._record_result_entity(label=f"argument:{claim.text[:80]}", entity_type="argument-claim",
                                       request_id=rid, content=json.dumps(asdict(claim), sort_keys=True))
        self.audit.append("argument_claim_completed", {"request_id": rid, "claim_id": cid})
        self._save_runtime()
        return PublicResult(rid, "argue", asdict(report), start,
                            len(self.organs.traces), self.verify_integrity()["valid"])

    def add_argument_evidence(self, evidence: ArgumentEvidence) -> PublicResult:
        rid, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(rid, "argument", "argue", "add evidence"):
            self.arguments.add_evidence(evidence)
            report = self.arguments.report(evidence.claim_id)
        with self.organs.operation(rid, "provenance", "argue", "record argument evidence"):
            self._record_result_entity(label=f"argument-evidence:{evidence.eid}",
                                       entity_type="argument-evidence", request_id=rid,
                                       content=json.dumps(asdict(evidence), sort_keys=True))
        self.audit.append("argument_evidence_completed", {"request_id": rid,
                                                           "evidence_id": evidence.eid})
        self._save_runtime()
        return PublicResult(rid, "argue", asdict(report), start,
                            len(self.organs.traces), self.verify_integrity()["valid"])

    def register_mechanism(self, profile: MechanismProfile) -> None:
        self.portfolio.register(profile)
        self._save_runtime()

    def record_mechanism_performance(self, record: PerformanceRecord) -> None:
        self.portfolio.record(record)
        self._save_runtime()

    def route(self, task: TaskShape) -> PublicResult:
        rid, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(rid, "portfolio", "route", "select mechanism"):
            selection = self.portfolio.select(task)
        with self.organs.operation(rid, "provenance", "route", "record mechanism selection"):
            self._record_result_entity(label=f"mechanism-route:{task.operation}",
                                       entity_type="mechanism-route", request_id=rid,
                                       content=json.dumps(asdict(selection), sort_keys=True))
        self.audit.append("portfolio_route_completed", {"request_id": rid,
                                                         "task": asdict(task),
                                                         "selection": asdict(selection)})
        self._save_runtime()
        return PublicResult(rid, "route", asdict(selection), start,
                            len(self.organs.traces), self.verify_integrity()["valid"])

    def register_action(self, spec: ActionSpec) -> None:
        self.actions.register(spec)

    def act(self, action_id: str, request: Mapping[str, object], *, holder: str,
            capability: dict, dry_run: bool = True, approval: str = "none") -> PublicResult:
        rid, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(rid, "action", "act", "execute action"):
            receipt = self.actions.run(action_id, request, holder=holder,
                                       capability=capability, dry_run=dry_run,
                                       approval=approval)
        with self.organs.operation(rid, "provenance", "act", "record action lineage"):
            self._record_result_entity(label=f"action:{action_id}", entity_type="action-receipt",
                                       request_id=rid, content=json.dumps(asdict(receipt), sort_keys=True))
        self.audit.append("action_completed", {"request_id": rid,
                                                "receipt": asdict(receipt)})
        self._save_runtime()
        return PublicResult(rid, "act", asdict(receipt), start,
                            len(self.organs.traces), self.verify_integrity()["valid"])

    def register_capability_requirement(self, requirement: CapabilityRequirement) -> str:
        rid = self.assurance.register(requirement)
        self._save_runtime()
        return rid

    def assure(self, requirement_id: str, invoke, observe, **kwargs) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "assurance", "assure", "capability mutation case"):
            case = self.assurance.evaluate(requirement_id, self.organs, invoke, observe, **kwargs)
        with self.organs.operation(request_id, "provenance", "assure", "record assurance case"):
            self._record_result_entity(label=f"assurance:{case.requirement.capability}",
                                       entity_type="assurance-case", request_id=request_id,
                                       content=json.dumps(case.report(), sort_keys=True))
        for mutation in case.mutations:
            self.ecology.record_mutation(mutation)
        self.audit.append("assurance_completed", {"request_id": request_id,
                                                   "case": case.report()})
        self._save_runtime()
        integrity = self.verify_integrity()
        return PublicResult(request_id, "assure", case.report(), start,
                            len(self.organs.traces), integrity["valid"])

    def ecology_report(self, capability: str) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "ecology", "ecology", "assess failure-domain ecology"):
            report = self.ecology.assess(self.organs, capability)
        with self.organs.operation(request_id, "provenance", "ecology", "record ecology assessment"):
            self._record_result_entity(label=f"ecology:{capability}", entity_type="ecology-report",
                                       request_id=request_id, content=json.dumps(asdict(report), sort_keys=True))
        self.audit.append("ecology_completed", {"request_id": request_id, "report": asdict(report)})
        self._save_runtime()
        return PublicResult(request_id, "ecology", asdict(report), start,
                            len(self.organs.traces), self.verify_integrity()["valid"])

    def present(self, item: PresentationInput, resolution: str = "standard") -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "presentation", "report", "render resolution projection"):
            report = Presenter.render(item, resolution)
        with self.organs.operation(request_id, "provenance", "report", "record presentation derivation"):
            self._record_result_entity(label=f"presentation:{item.title}", entity_type="presentation-report",
                                       request_id=request_id, content=json.dumps(asdict(report), sort_keys=True))
        self.audit.append("presentation_completed", {"request_id": request_id,
                                                       "report": asdict(report)})
        self._save_runtime()
        return PublicResult(request_id, "report", asdict(report), start,
                            len(self.organs.traces), self.verify_integrity()["valid"])


    def evaluate_goal(self, goal: GoalRequest) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "goal-gate", "goal", "evaluate minimum behavioral and authority contract"):
            decision = self.goal_gate.evaluate(goal)
        with self.organs.operation(request_id, "contract-waist", "goal", "persist goal decision"):
            obj = self.waist.append(
                "goal", {"request": asdict(goal), "decision": asdict(decision)},
                logical_id=f"goal:{goal.request_id}", representation="goal-contract+json",
                status="active" if decision.state == "ready" else "rejected",
                authority_ceiling=0.0,
                permissions=(goal.authorized_by,) if goal.authorized_by else ())
        with self.organs.operation(request_id, "provenance", "goal", "record goal derivation"):
            self._record_result_entity(label=f"goal:{goal.text[:80]}", entity_type="goal",
                                       request_id=request_id,
                                       content=json.dumps(asdict(decision), sort_keys=True))
        self.audit.append("goal_evaluated", {"request_id": request_id, "decision": asdict(decision)})
        self._save_runtime()
        return PublicResult(request_id, "goal", asdict(decision), start,
                            len(self.organs.traces), self.verify_integrity()["valid"], obj.logical_id)

    def component_status(self) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "component-trust", "component", "verify admitted component bytes and scope"):
            result = self.components.verify()
        self.audit.append("components_checked", {"request_id": request_id, **result})
        self._save_runtime()
        return PublicResult(request_id, "component", result, start,
                            len(self.organs.traces), self.verify_integrity()["valid"])

    def record_calibration(self, event: CalibrationEvent) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "calibration", "calibrate", "record independent outcome"):
            eid = self.calibration.record(event)
            report = self.calibration.report(event.actor, event.task_family)
        with self.organs.operation(request_id, "contract-waist", "calibrate", "persist calibration event"):
            obj = self.waist.append("observation", asdict(event), logical_id=f"calibration:{eid}",
                                    representation="calibration-event+json", status="active",
                                    independence_group=event.independence_group,
                                    authority_ceiling=0.0,
                                    resource={"cost": event.cost, "latency": event.latency})
        self.audit.append("calibration_recorded", {"request_id": request_id, "event": asdict(event),
                                                    "report": asdict(report)})
        self._save_runtime()
        return PublicResult(request_id, "calibrate", {"event_id": eid, "report": asdict(report)}, start,
                            len(self.organs.traces), self.verify_integrity()["valid"], obj.logical_id)

    def register_causal_model(self, model: CausalModel) -> str:
        mid = self.causal.register(model)
        self.waist.append("model", asdict(model), logical_id=f"causal-model:{mid}",
                          representation="causal-dag", status="active", authority_ceiling=0.0,
                          applicability=model.valid_conditions)
        self._save_runtime()
        return mid

    def identify_causal(self, claim: CausalClaim) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "causal-identification", "causal", "check graphical identification assumptions"):
            result = self.causal.identify_backdoor(claim)
        with self.organs.operation(request_id, "contract-waist", "causal", "persist zero-authority identification result"):
            obj = self.waist.append(
                "result", {"claim": asdict(claim), "identification": asdict(result)},
                logical_id=f"causal-claim:{claim.cid}", representation="causal-identification+json",
                dependency_ids=(f"causal-model:{claim.model_id}",),
                status="supported" if result.identified else "rejected", authority_ceiling=0.0)
        self.audit.append("causal_identified", {"request_id": request_id, "result": asdict(result)})
        self._save_runtime()
        return PublicResult(request_id, "causal", asdict(result), start,
                            len(self.organs.traces), self.verify_integrity()["valid"], obj.logical_id)

    def plan_tests(self, hypotheses: Sequence[Hypothesis], tests: Sequence[CandidateTest]) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "experiment-allocation", "plan-test", "rank discriminating contacts"):
            ranking = self.experiments.rank(tuple(hypotheses), tuple(tests))
        payload = {"rankings": [asdict(x) for x in ranking],
                   "hypotheses": [asdict(x) for x in hypotheses],
                   "tests": [asdict(x) for x in tests]}
        with self.organs.operation(request_id, "contract-waist", "plan-test", "persist test allocation"):
            obj = self.waist.append("decision", payload, representation="experiment-plan+json",
                                    status="active", authority_ceiling=0.0,
                                    resource={"tests_considered": len(tests)})
        self.audit.append("tests_ranked", {"request_id": request_id, **payload})
        self._save_runtime()
        return PublicResult(request_id, "plan-test", payload, start,
                            len(self.organs.traces), self.verify_integrity()["valid"], obj.logical_id)

    def add_concept(self, concept: ConceptVersion) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "ontology-evolution", "ontology", "add versioned concept"):
            vid = self.ontology.add(concept)
        obj = self.waist.append("representation", asdict(concept), logical_id=f"concept:{vid}",
                               representation="ontology-concept+json", status="active" if concept.status == "active" else "proposed",
                               authority_ceiling=0.0, scope=concept.scope)
        self.audit.append("concept_added", {"request_id": request_id, "concept": asdict(concept)})
        self._save_runtime()
        return PublicResult(request_id, "ontology", {"concept_id": vid}, start,
                            len(self.organs.traces), self.verify_integrity()["valid"], obj.logical_id)

    def map_concepts(self, mapping: MappingHypothesis) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "ontology-evolution", "ontology", "record reversible typed mapping"):
            mid = self.ontology.map(mapping)
        obj = self.waist.append("mapping", asdict(mapping), logical_id=f"mapping:{mid}",
                               representation="ontology-mapping+json", status="active" if mapping.status == "accepted" else "proposed",
                               authority_ceiling=0.0,
                               dependency_ids=(f"concept:{mapping.source_id}", f"concept:{mapping.target_id}"),
                               scope=mapping.scope)
        self.audit.append("concepts_mapped", {"request_id": request_id, "mapping": asdict(mapping)})
        self._save_runtime()
        return PublicResult(request_id, "ontology", {"mapping_id": mid, "status": mapping.status}, start,
                            len(self.organs.traces), self.verify_integrity()["valid"], obj.logical_id)

    def evolve_concepts(self, predecessors: Sequence[str], *, label: str, concept_type: str,
                        properties: Mapping[str, object], reason: str,
                        scope: Optional[Mapping[str, object]] = None) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "ontology-evolution", "ontology", "evolve ontology without history deletion"):
            successor = self.ontology.evolve(tuple(predecessors), label, concept_type, properties, reason,
                                             scope=scope)
        obj = self.waist.append("representation", asdict(successor), logical_id=f"concept:{successor.vid}",
                               representation="ontology-concept+json", status="active", authority_ceiling=0.0,
                               dependency_ids=tuple(f"concept:{x}" for x in predecessors), scope=successor.scope)
        self.audit.append("concepts_evolved", {"request_id": request_id, "successor": asdict(successor),
                                               "reason": reason})
        self._save_runtime()
        return PublicResult(request_id, "ontology", {"successor": asdict(successor)}, start,
                            len(self.organs.traces), self.verify_integrity()["valid"], obj.logical_id)

    def import_federation(self, bundle: FederationBundle, *, key: bytes = b"") -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "federation", "federate", "verify and retain remote versions and conflicts"):
            result = self.federation.import_bundle(bundle, key)
        obj = self.waist.append("artifact", {"bundle": asdict(bundle), "import": result},
                               logical_id=f"federation:{bundle.digest}", representation="federation-bundle+json",
                               status="active", authority_ceiling=0.0,
                               independence_group=f"producer:{bundle.producer}")
        self.audit.append("federation_imported", {"request_id": request_id, "bundle": bundle.digest, **result})
        self._save_runtime()
        return PublicResult(request_id, "federate", result, start,
                            len(self.organs.traces), self.verify_integrity()["valid"], obj.logical_id)

    def invalidate_object(self, logical_id: str, *, reason: str, actor: str = "") -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "containment", "invalidate-object", "cascade dependency invalidation"):
            invalidation = self.dependencies.invalidate(logical_id, reason, actor)
            waist_versions = self.waist.revoke(logical_id, reason, actor=actor) if logical_id in self.waist.versions else ()
        payload = {"invalidation": asdict(invalidation),
                   "waist_versions": [asdict(x) for x in waist_versions]}
        self.audit.append("object_invalidated", {"request_id": request_id, **payload})
        self._save_runtime()
        return PublicResult(request_id, "invalidate-object", payload, start,
                            len(self.organs.traces), self.verify_integrity()["valid"])

    def fit_drift_baseline(self, feature: str, values: Sequence[float], *, threshold_z: float = 2.0) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "drift-monitor", "drift", "freeze a numeric feature baseline"):
            baseline = DriftMonitor.fit(feature, values, threshold_z)
            self.drift_baselines[feature] = baseline
        obj = self.waist.append("model", asdict(baseline), logical_id=f"drift:{feature}",
                               representation="drift-baseline+json", status="active", authority_ceiling=0.0)
        self.audit.append("drift_baseline_fitted", {"request_id": request_id, "baseline": asdict(baseline)})
        self._save_runtime()
        return PublicResult(request_id, "drift", asdict(baseline), start,
                            len(self.organs.traces), self.verify_integrity()["valid"], obj.logical_id)

    def evaluate_drift(self, feature: str, values: Sequence[float]) -> PublicResult:
        if feature not in self.drift_baselines:
            raise KeyError(feature)
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "drift-monitor", "drift", "evaluate scope shift"):
            result = DriftMonitor.evaluate(self.drift_baselines[feature], values)
        obj = self.waist.append("result", asdict(result), representation="drift-report+json",
                               dependency_ids=(f"drift:{feature}",),
                               status="inconclusive" if result.state == "shift_detected" else "active",
                               authority_ceiling=0.0)
        self.audit.append("drift_evaluated", {"request_id": request_id, "report": asdict(result)})
        self._save_runtime()
        return PublicResult(request_id, "drift", asdict(result), start,
                            len(self.organs.traces), self.verify_integrity()["valid"], obj.logical_id)

    def record_reality_gate(self, outcome: GateOutcome) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "assurance", "audit", "record outcome against frozen gate definition"):
            self.gate_plan.record(outcome)
        obj = self.waist.append("result", asdict(outcome), logical_id=f"gate:{outcome.gate_id}",
                               representation="reality-gate+json", status="supported" if outcome.status == "pass" else "inconclusive",
                               authority_ceiling=0.0, dependency_ids=tuple(outcome.evidence_ids))
        self.audit.append("reality_gate_recorded", {"request_id": request_id, "outcome": asdict(outcome),
                                                     "plan_digest": self.gate_plan.plan_digest})
        self._save_runtime()
        return PublicResult(request_id, "audit", {"outcome": asdict(outcome), "summary": self.gate_plan.summary()}, start,
                            len(self.organs.traces), self.verify_integrity()["valid"], obj.logical_id)

    def record_capability_gate(self, gate: GateResult) -> PublicResult:
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "assurance", "audit", "record predeclared capability gate"):
            self.capability_graph.record_gate(gate)
        self.audit.append("capability_gate_recorded", {"request_id": request_id, "gate": asdict(gate)})
        self._save_runtime()
        return PublicResult(request_id, "audit", {"gate": asdict(gate), "capability": self.capability_graph.capabilities[gate.capability].state}, start,
                            len(self.organs.traces), self.verify_integrity()["valid"])

    def execute_task(self, request: TaskRequest, *, faculty: Optional[ProposalFaculty] = None) -> PublicResult:
        """Execute a bounded mixed-domain task and stop at the first ungated boundary."""
        request_id, start = request.task_id, len(self.organs.traces)
        stages: list[TaskStage] = []
        unresolved: list[str] = []
        object_ids: list[str] = []
        with self.organs.operation(request_id, "coordination", "task", "execute bounded public task"):
            with self.organs.operation(request_id, "goal-gate", "task", "evaluate goal"):
                goal_decision = self.goal_gate.evaluate(request.goal)
            goal_obj = self.waist.append("goal", {"request": asdict(request.goal), "decision": asdict(goal_decision)},
                                         logical_id=f"goal:{request.goal.request_id}", representation="goal-contract+json",
                                         status="active" if goal_decision.state == "ready" else "rejected",
                                         permissions=(request.goal.authorized_by,) if request.goal.authorized_by else ())
            object_ids.append(goal_obj.logical_id)
            stages.append(TaskStage("goal", goal_decision.state, asdict(goal_decision)))
            if goal_decision.state != "ready":
                unresolved.extend(goal_decision.clarifications or (goal_decision.reason,))
                report = TaskReport(request.task_id, "clarification_required", tuple(stages), tuple(unresolved), tuple(object_ids))
            else:
                investigation_payload = None
                if request.source_locators:
                    inquiry = InquiryRequest(request.question, tuple(request.source_locators),
                                             allow_private_network=request.fetch_policy.allow_private_network,
                                             use_faculty_extraction=faculty is not None,
                                             request_id=f"{request.task_id}-INQ")
                    investigation_payload = self.investigate(inquiry, faculty).result
                    stages.append(TaskStage("acquisition-carving-placement",
                                            str(investigation_payload.get("result_state", "unknown")),
                                            investigation_payload))
                else:
                    unresolved.append("no source artifacts were supplied; external acquisition was not performed")
                    stages.append(TaskStage("acquisition-carving-placement", "not_requested", {}))
                verification_rows = []
                for job in request.verifications:
                    vr = VerificationRequest(job.claim, job.contract_id, job.verifier_id,
                                             dict(job.inputs), requested_by="field-task")
                    result = self.verify_claim(vr).result
                    verification_rows.append(result)
                    stages.append(TaskStage(f"verification:{job.contract_id}", str(result.get("state", "unknown")), result))
                    if result.get("state") in {"inconclusive", "untestable", "execution_failed", "undecidable"}:
                        unresolved.append(f"verification {job.contract_id} did not decide the claim")
                action_row = None
                if request.action is not None:
                    action_row = self.act(request.action.action_id, request.action.request,
                                          holder=request.action.holder,
                                          capability=dict(request.action.capability),
                                          dry_run=request.action.dry_run,
                                          approval=request.action.approval).result
                    stages.append(TaskStage("action", str(action_row.get("status", "unknown")), action_row))
                    if action_row.get("status") not in {"dry_run", "executed"}:
                        unresolved.append("requested action did not complete")
                terminal = "completed" if not unresolved and (verification_rows or investigation_payload is not None or action_row is not None) else "bounded_partial"
                report = TaskReport(request.task_id, terminal, tuple(stages), tuple(unresolved), tuple(object_ids))
        with self.organs.operation(request_id, "contract-waist", "task", "persist task report"):
            task_obj = self.waist.append("report", asdict(report), logical_id=f"task:{request.task_id}",
                                         representation="task-report+json", dependency_ids=tuple(object_ids),
                                         status="active" if report.terminal_state == "completed" else "inconclusive",
                                         authority_ceiling=0.0)
        with self.organs.operation(request_id, "provenance", "task", "record task derivation"):
            self._record_result_entity(label=f"task:{request.question[:80]}", entity_type="report",
                                       request_id=request_id, content=json.dumps(asdict(report), sort_keys=True))
        self.audit.append("task_completed", {"request_id": request_id, "report": asdict(report)})
        self._save_runtime()
        return PublicResult(request_id, "task", asdict(report), start,
                            len(self.organs.traces), self.verify_integrity()["valid"], task_obj.logical_id)

    def stage4c_operation(self, operation: str, payload: Mapping[str, object]) -> PublicResult:
        """Execute one Stage 4C operation through the normal instrument surface.

        External infrastructure is represented by explicit adapters and
        zero-authority receipts.  This dispatcher never fabricates an external
        evaluator, instrument, environment, future outcome, or user study.
        """
        rid, start = self._request_id(), len(self.organs.traces)
        op = str(operation)
        data = dict(payload)
        result: object
        capability = op.split(".", 1)[0]

        if op == "evaluation.commit":
            with self.organs.operation(rid, "evaluator-boundary", "evaluation", "freeze release commitment"):
                release_root = str(data.get("release_root") or Path(__file__).parents[1])
                c = self.evaluator.commit(
                    release_root, release_version=str(data.get("release_version", self.VERSION)),
                    gate_plan=str(data.get("gate_plan", Path(__file__).parents[1] / "stage3/PREDECLARED_REALITY_GATES.json")),
                    campaign=str(data.get("campaign", Path(__file__).parents[1] / "stage4b/STAGE_4B_CAMPAIGN.json")),
                    actor=str(data.get("actor", "human-approved-builder")),
                    exclusions=tuple(data.get("exclusions", (".git", "__pycache__", ".pytest_cache", "MANIFEST.sha256"))),
                )
                result = {"commitment": asdict(c), "external_gate_state": "independent_contact_required"}
        elif op == "evaluation.import":
            with self.organs.operation(rid, "evaluator-boundary", "evaluation", "import one-time challenge"):
                raw = Path(str(data["payload_path"])).read_bytes()
                c = self.evaluator.import_challenge(str(data["commitment_id"]), raw,
                    evaluator_id=str(data["evaluator_id"]), one_time_token=str(data["one_time_token"]),
                    seed_commitment=str(data.get("seed_commitment", "")), metadata=dict(data.get("metadata", {})))
                result = {"challenge": asdict(c), "external_gate_state": "imported_not_adjudicated"}
        elif op == "evaluation.consume":
            with self.organs.operation(rid, "evaluator-boundary", "evaluation", "consume one-time evaluator challenge"):
                raw = self.evaluator.consume(str(data["challenge_id"]), str(data["one_time_token"]))
                import hashlib
                result = {"challenge_id": str(data["challenge_id"]), "payload_sha256": hashlib.sha256(raw).hexdigest(),
                          "payload_bytes": len(raw), "external_gate_state": "challenge_consumed_not_adjudicated"}
        elif op == "evaluation.record":
            with self.organs.operation(rid, "evaluator-boundary", "evaluation", "record evaluator result digest"):
                raw = Path(str(data["result_path"])).read_bytes() if data.get("result_path") else str(data.get("result", "")).encode()
                result = {"challenge_id": str(data["challenge_id"]),
                          "result_digest": self.evaluator.record_result(str(data["challenge_id"]), raw),
                          "external_gate_state": "external_result_recorded_not_self_certified"}
        elif op == "evaluation.status":
            with self.organs.operation(rid, "evaluator-boundary", "evaluation", "report evaluator boundary"):
                result = self.evaluator.status(str(data.get("commitment_id", "")))

        elif op == "search.run":
            with self.organs.operation(rid, "provider-registry", "search-campaign", "attach declared providers"):
                for row in data.get("providers", ()):
                    cfg = dict(row); pid = str(cfg["provider_id"]); kind = str(cfg["kind"])
                    if kind == "local": provider = LocalCorpusProvider(tuple(cfg.get("roots", ())))
                    elif kind == "catalog": provider = CatalogProvider(str(cfg["path"]))
                    elif kind == "crossref": provider = CrossrefProvider(mailto=str(cfg.get("mailto", "")))
                    elif kind == "openalex": provider = OpenAlexProvider(mailto=str(cfg.get("mailto", "")))
                    else: raise ValueError(f"unknown provider kind {kind!r}")
                    if pid not in self.providers.policies:
                        self.providers.register(ProviderPolicy(pid, kind, tuple(cfg.get("source_classes", (kind,))), str(cfg.get("license_policy", "caller-declared")), network_required=kind in {"crossref", "openalex"}))
                    self.providers.attach(pid, provider)
            with self.organs.operation(rid, "search-campaign", "search-campaign", "execute opposition-aware campaign"):
                cdata = dict(data["campaign"])
                queries = tuple(CampaignQuery(str(q["text"]), str(q["polarity"]), str(q["source_class"]), tuple(q["provider_ids"]), int(q.get("limit", 20)), str(q.get("qid", "")) or CampaignQuery("x","for","x",("x",)).qid) for q in cdata.get("queries", ()))
                campaign = SearchCampaign(str(cdata["name"]), tuple(cdata["required_polarities"]), tuple(cdata["required_source_classes"]), queries, bool(cdata.get("reviewer_required", False)), str(cdata.get("campaign_id", "")) or SearchCampaign("x",(),(),()).campaign_id)
                self.search_campaigns.register(campaign); result = self.search_campaigns.execute(campaign.campaign_id, self.providers)
                if data.get("review"):
                    rev = dict(data["review"]); result["review"] = self.search_campaigns.review(campaign.campaign_id, reviewer=str(rev["reviewer"]), decision=str(rev["decision"]), rationale=str(rev["rationale"]))
                    result.update(self.search_campaigns.coverage(campaign.campaign_id))
        elif op == "search.coverage":
            with self.organs.operation(rid, "search-campaign", "search-campaign", "report search coverage"):
                result = self.search_campaigns.coverage(str(data["campaign_id"]))
        elif op == "search.compare":
            with self.organs.operation(rid, "search-campaign", "search-campaign", "compare search campaign with baselines"):
                result = self.search_campaigns.compare_baselines(str(data["campaign_id"]), tuple(data["relevant_study_keys"]), self.providers)

        elif op == "document.ingest":
            with self.organs.operation(rid, "acquisition", "investigate", "acquire source artifact"):
                policy_raw = dict(data.get("fetch_policy", {}))
                for key in ("allowed_schemes", "allowed_file_roots", "allowed_media_prefixes"):
                    if key in policy_raw: policy_raw[key] = tuple(policy_raw[key])
                parsed = self.acquisition.acquire(str(data["locator"]), FetchPolicy(**policy_raw) if policy_raw else FetchPolicy())
            with self.organs.operation(rid, "document-ir", "document", "build representation-preserving document IR"):
                doc = self.documents.build(parsed); proposals = []
                for row in data.get("proposals", ()):
                    q = dict(row); proposals.append(asdict(self.documents.propose(doc.document_id, str(q.get("claim_text", "")), str(q.get("claim_class", "unknown")), tuple(q.get("region_ids", ())), scope=dict(q.get("scope", {})), extractor_id=str(q.get("extractor_id", "caller-proposal")))))
                abstentions = [asdict(x) for x in self.documents.abstain_unparsed_images(doc.document_id)]
                result = {"artifact": asdict(parsed.artifact), "parse": asdict(parsed.parse), "document": asdict(doc), "proposals": proposals, "abstentions": abstentions}

        elif op == "transform.apply":
            with self.organs.operation(rid, "transformation", "transform", "apply typed representation transformation"):
                out, receipt = self.transformations.apply(str(data["transform_id"]), data.get("value"), required_distinctions=tuple(data.get("required_distinctions", ())))
                result = {"output": out, "receipt": asdict(receipt)}
        elif op == "transform.mutate-loss":
            with self.organs.operation(rid, "transformation", "transform", "test information-loss mutation"):
                result = self.transformations.loss_mutation(str(data["transform_id"]), dict(data["value"]), str(data["required_field"]))

        elif op == "mapping.policy":
            with self.organs.operation(rid, "placement-precision", "placement-benchmark", "register placement loss policy"):
                raw = dict(data); raw["allowed_relations"] = tuple(raw.get("allowed_relations", ())); policy = TaskLossPolicy(**raw); self.mapping_precision.register_policy(policy); result = asdict(policy)
        elif op == "mapping.propose":
            with self.organs.operation(rid, "placement-precision", "placement-benchmark", "propose competing mappings"):
                candidates = [(str(x["target_id"]), str(x["relation"]), float(x.get("confidence", 0)), tuple(x.get("vetoes", ())), dict(x.get("scope", {}))) for x in data.get("candidates", ())]
                result = asdict(self.mapping_precision.propose_competing(str(data["source_id"]), candidates, str(data.get("policy_id", "placement-default"))))
        elif op == "mapping.resolve":
            with self.organs.operation(rid, "placement-precision", "placement-benchmark", "resolve one mapping under task loss"):
                result = self.mapping_precision.resolve(str(data["set_id"]), str(data["mapping_id"]), str(data.get("reason", "contact satisfied")))
        elif op == "mapping.retract":
            with self.organs.operation(rid, "placement-precision", "placement-benchmark", "retract mapping and reopen dependent competition"):
                result = self.mapping_precision.retract(str(data["mapping_id"]), str(data.get("reason", "new contact")))
        elif op == "mapping.benchmark":
            with self.organs.operation(rid, "placement-precision", "placement-benchmark", "score mapping cases"):
                cases = tuple(MappingBenchmarkCase(**dict(x)) for x in data.get("cases", ())); result = self.mapping_precision.benchmark(str(data.get("policy_id", "placement-default")), cases)

        elif op == "instrument.register":
            with self.organs.operation(rid, "instrument-registry", "instrument", "register empirical adapter contract"):
                raw = dict(data); raw["measurement_classes"] = tuple(raw.get("measurement_classes", ())); raw["unit_families"] = tuple(raw.get("unit_families", ())); spec = InstrumentSpec(**raw); self.instruments.register(spec); result = {"instrument": asdict(spec), "authority_ceiling": 0.0, "external_attachment_required": True}
        elif op == "instrument.calibration":
            with self.organs.operation(rid, "instrument-registry", "instrument", "register calibration certificate"):
                cert = CalibrationCertificate(**dict(data)); result = {"certificate_id": self.instruments.add_calibration(cert), "certificate": asdict(cert)}
        elif op == "instrument.measure":
            with self.organs.operation(rid, "instrument-registry", "instrument", "execute attached empirical contact"):
                receipt = self.instruments.measure(str(data["instrument_id"]), str(data["measurement_class"]), dict(data.get("request", {})), calibration_id=str(data.get("calibration_id", "")))
                result = asdict(receipt)
        elif op == "instrument.revoke-calibration":
            with self.organs.operation(rid, "instrument-registry", "instrument", "revoke calibration and dependent authority"):
                result = self.instruments.revoke_calibration(str(data["certificate_id"]), str(data.get("reason", "revoked")))
        elif op == "instrument.status":
            with self.organs.operation(rid, "instrument-registry", "instrument", "report empirical interface"):
                result = self.instruments.verify() | {"external_contact_required": True}

        elif op == "calibration.regime":
            with self.organs.operation(rid, "regime-calibration", "regime-calibration", "register calibration regime"):
                r = CalibrationRegime(**dict(data)); self.regime_calibration.register(r); result = asdict(r)
        elif op == "calibration.predict":
            with self.organs.operation(rid, "regime-calibration", "regime-calibration", "record pre-outcome prediction"):
                e = ForecastOutcome(**dict(data)); self.regime_calibration.record_prediction(e); result = asdict(e)
        elif op == "calibration.outcome":
            with self.organs.operation(rid, "regime-calibration", "regime-calibration", "attach future outcome"):
                self.regime_calibration.attach_outcome(str(data["event_id"]), float(data["outcome"]), float(data["outcome_time"]), external=bool(data.get("external", False)), independence_group=str(data.get("independence_group", ""))); result = self.regime_calibration.report(str(data["actor"]), str(data["regime_id"]))
        elif op == "calibration.report":
            with self.organs.operation(rid, "regime-calibration", "regime-calibration", "report regime calibration"):
                result = self.regime_calibration.report(str(data["actor"]), str(data["regime_id"]))

        elif op == "design.run":
            with self.organs.operation(rid, "domain-design", "design", "run registered inverse design"):
                result = {"candidates": [asdict(x) for x in self.designs.design(str(data["dialect_id"]), dict(data["goal"]))], "claim_scope": "registered dialect only"}
        elif op == "design.benchmark":
            with self.organs.operation(rid, "domain-design", "design", "benchmark heterogeneous design dialects"):
                result = self.designs.benchmark(tuple(data.get("cases", ())))

        elif op == "allocation.benchmark":
            with self.organs.operation(rid, "allocation-benchmark", "allocate", "compare test allocation policies"):
                scenarios = []
                for row in data.get("scenarios", ()):
                    h = tuple(Hypothesis(**dict(x)) for x in row.get("hypotheses", ()))
                    tests = []
                    for x in row.get("tests", ()):
                        d = dict(x); d["outcomes"] = tuple(d.get("outcomes", ())); tests.append(CandidateTest(**d))
                    scenarios.append(AllocationScenario(h, tuple(tests), str(row["true_hypothesis_id"]), dict(row["outcomes"]), dict(row.get("decision_values", {})), str(row.get("sid", "")) or AllocationScenario((),(),"",{}).sid))
                result = self.allocation.benchmark(tuple(scenarios), int(data.get("seed", 0)))

        elif op == "portfolio.benchmark":
            with self.organs.operation(rid, "portfolio-benchmark", "portfolio-benchmark", "run time-forward routing benchmark"):
                cases = []
                for row in data.get("cases", ()):
                    t = dict(row["task"]); t["required_properties"] = tuple(t.get("required_properties", ())); task = TaskShape(**t)
                    cases.append(PortfolioCase(task, dict(row["outcomes"]), float(row["timestamp"]), str(row.get("case_id", "")) or PortfolioCase(task,{},0).case_id))
                result = self.portfolio_benchmark.evaluate(self.portfolio, tuple(cases), float(data["cutoff"]))

        elif op == "specialist.register":
            with self.organs.operation(rid, "specialist-governance", "specialist", "register specialist ecology member"):
                d = dict(data)
                for key in ("capabilities", "failure_roots", "replacement_ids"): d[key] = tuple(d.get(key, ()))
                x = Specialist(**d); self.specialists.register(x); result = asdict(x)
        elif op == "specialist.experiment":
            with self.organs.operation(rid, "specialist-governance", "specialist", "record marginal contribution"):
                x = ContributionExperiment(**dict(data)); self.specialists.record_experiment(x); result = asdict(x) | {"marginal_value": x.marginal_value}
        elif op == "specialist.assess":
            with self.organs.operation(rid, "specialist-governance", "specialist", "assess dysbiosis and failure roots"):
                result = self.specialists.assess(str(data["capability"]))
        elif op == "specialist.quota":
            with self.organs.operation(rid, "specialist-governance", "specialist", "enforce resource quota"):
                result = self.specialists.enforce_quota(str(data["specialist_id"]), dict(data["usage"]))
        elif op == "specialist.quarantine":
            with self.organs.operation(rid, "specialist-governance", "specialist", "quarantine specialist"):
                result = self.specialists.quarantine(str(data["specialist_id"]), str(data.get("reason", "dysbiosis")))
        elif op == "specialist.replace":
            with self.organs.operation(rid, "specialist-governance", "specialist", "replace dysbiotic specialist"):
                result = self.specialists.replace(str(data["specialist_id"]), str(data["replacement_id"]), str(data.get("reason", "replacement")))

        elif op == "shift.fit":
            with self.organs.operation(rid, "shift-portfolio", "shift", "fit declared shift baseline"):
                result = asdict(self.shifts.fit(str(data["monitor_id"]), tuple(data["values"])))
        elif op == "shift.evaluate":
            with self.organs.operation(rid, "shift-portfolio", "shift", "evaluate declared or unknown shift"):
                result = asdict(self.shifts.evaluate(str(data["baseline_id"]), tuple(data["values"]), observed_family=str(data.get("observed_family", ""))))

        elif op == "environment.register":
            with self.organs.operation(rid, "environment-protocol", "environment", "register external environment contract"):
                s = EnvironmentSpec(**dict(data)); self.environments.register(s); result = {"environment": asdict(s), "external_adapter_required": True}
        elif op == "environment.run":
            with self.organs.operation(rid, "environment-protocol", "environment", "run attached stateful environment"):
                d = dict(data["task"]); d["fault_schedule"] = tuple(d.get("fault_schedule", ())); task = EnvironmentTask(**d)
                trace = self.environments.run(task, tuple(data.get("actions", ())), externally_administered=bool(data.get("externally_administered", False)))
                result = {"trace": asdict(trace), "gate": self.environments.gate_status(trace.trace_id)}
        elif op == "environment.status":
            with self.organs.operation(rid, "environment-protocol", "environment", "report external environment boundary"):
                result = {"specs": [asdict(x) for x in self.environments.specs.values()], "traces": [asdict(x) for x in self.environments.traces.values()], "external_gate_state": "externally_administered_run_required"}

        elif op == "explanation.prepare":
            with self.organs.operation(rid, "explanation-study", "explanation-study", "prepare evidence-native view"):
                result = asdict(self.explanations.prepare(str(data["contract_id"]), dict(data["sections"]), tuple(data.get("source_object_ids", ()))))
        elif op == "explanation.mutate":
            with self.organs.operation(rid, "explanation-study", "explanation-study", "run explanation omission mutation"):
                result = self.explanations.mutate(str(data["artifact_id"]), str(data["remove_section"]))
        elif op == "explanation.package":
            with self.organs.operation(rid, "explanation-study", "explanation-study", "package blinded external study"):
                p = self.explanations.package_study(str(data["contract_id"]), tuple(data["artifact_ids"]), tuple(data["outcome_measures"]), str(data["consent_text"]), str(data["random_seed_commitment"])); result = self.explanations.status(p.package_id)

        elif op == "mutation.coverage":
            with self.organs.operation(rid, "mutation-campaign", "mutation", "report architectural mutation coverage"):
                result = self.mutations.coverage(tuple(data["required_capabilities"]))
        elif op == "resource.totals":
            with self.organs.operation(rid, "resource-ledger", "resource", "report multidimensional resource totals"):
                result = self.resources.totals(str(data.get("request_id", "")))
        elif op == "resource.score":
            with self.organs.operation(rid, "resource-ledger", "resource", "score one retained resource record under explicit policy"):
                record = self.resources.records[str(data["record_id"])]
                policy = ResourcePolicy(weights=dict(data.get("weights", {})) or ResourcePolicy().weights, unknown_penalty=float(data.get("unknown_penalty", 1000.0)), policy_id=str(data.get("policy_id", "")) or ResourcePolicy().policy_id)
                result = {"record_id": record.rid, "policy": asdict(policy), "score": self.resources.score(record, policy), "original_dimensions": asdict(record)}
        elif op == "resource.reconcile":
            with self.organs.operation(rid, "resource-ledger", "resource", "reconcile external resource meters"):
                result = self.resources.reconcile(str(data["request_id"]), dict(data["external"]), source=str(data["source"]), tolerance=float(data.get("tolerance", 0.1)))

        elif op == "scenario.register":
            with self.organs.operation(rid, "scenario-assurance", "scenario", "register scoped scenario profile"):
                d = dict(data)
                for key in ("required_capabilities", "required_external_contacts", "success_observations", "failure_observations"): d[key] = tuple(d.get(key, ()))
                p = ScenarioProfile(**d); self.scenarios.register(p); result = asdict(p)
        elif op == "scenario.record":
            with self.organs.operation(rid, "scenario-assurance", "scenario", "record scoped whole-system evidence"):
                x = self.scenarios.record(str(data["profile_id"]), str(data["release_commitment_id"]), dict(data["capability_results"]), tuple(data.get("external_contacts", ())), tuple(data.get("mutation_case_ids", ())), dict(data.get("resource_totals", {})), tuple(data.get("observations", ())), tuple(data.get("limitations", ()))); result = asdict(x)
        elif op == "scenario.graph":
            with self.organs.operation(rid, "scenario-assurance", "scenario", "render maintained assurance graph"):
                result = self.scenarios.assurance_graph()
        else:
            raise ValueError(f"unknown Stage 4C operation {op!r}")

        with self.organs.operation(rid, "provenance", capability if capability in self.organs.specs["provenance"].public_capabilities else "audit", "record Stage 4C result"):
            self._record_result_entity(label=f"stage4c:{op}", entity_type="stage4c-result", request_id=rid,
                                       content=json.dumps(result, sort_keys=True, default=str))
        self.audit.append("stage4c_operation_completed", {"request_id": rid, "operation": op, "result": result})
        self._save_runtime()
        return PublicResult(rid, op, result, start, len(self.organs.traces), self.verify_integrity()["valid"])

    def invalidate_source(self, *, locator: str, content_sha256: str, reason: str) -> PublicResult:
        """Invalidate one captured source and every derived artifact.

        The source is addressed by locator and digest so a URL/path reuse cannot
        revoke the wrong version.  No artifact is deleted; the active derivation
        view changes and the complete invalidation receipt is persisted.
        """
        request_id, start = self._request_id(), len(self.organs.traces)
        with self.organs.operation(request_id, "provenance", "invalidate", "resolve source version and cascade invalidation"):
            eid = self._entity_by_locator_digest(locator, content_sha256)
            if not eid:
                raise KeyError("no provenance entity matches locator and digest")
            receipt = self.provenance.invalidate_cascade(eid, reason)
        with self.organs.operation(request_id, "audit", "invalidate", "record invalidation receipt"):
            integrity = self.verify_integrity()
        self.audit.append("source_invalidated", {"request_id": request_id, **receipt})
        self._save_runtime()
        return PublicResult(request_id, "invalidate", receipt, start,
                            len(self.organs.traces), integrity["valid"])

    def verify_integrity(self) -> dict:
        kernel_rows = []
        for path in sorted((self.root / "arc_kernels").glob("*.json")):
            try:
                kernel = ARC5Kernel.load(path)
                kernel_rows.append({"arc_id": kernel.arc.arc_id, **kernel.verify()})
            except Exception as exc:
                kernel_rows.append({"path": str(path), "valid": False,
                                    "errors": [f"{type(exc).__name__}: {exc}"]})
        arc5a_rows = []
        for path in sorted((self.root / "arc5a_kernels").glob("*.json")):
            try:
                kernel = ARC5AAdversarialKernel.load(path)
                arc5a_rows.append({"arc_id": kernel.arc.arc_id, **kernel.verify()})
            except Exception as exc:
                arc5a_rows.append({"path": str(path), "valid": False,
                                   "errors": [f"{type(exc).__name__}: {exc}"]})
        campaign_rows = []
        for path in sorted((self.root / "arc_campaigns").glob("*.json")):
            try:
                campaign = ARC5Campaign.load(path)
                campaign_rows.append({"campaign_id": campaign.campaign_id, **campaign.verify()})
            except Exception as exc:
                campaign_rows.append({"path": str(path), "valid": False,
                                      "errors": [f"{type(exc).__name__}: {exc}"]})
        checks = {
            "arc5_kernels": {"valid": all(x.get("valid", False) for x in kernel_rows),
                             "kernels": kernel_rows},
            "arc5a_kernels": {"valid": all(x.get("valid", False) for x in arc5a_rows),
                              "kernels": arc5a_rows},
            "arc5_campaigns": {"valid": all(x.get("valid", False) for x in campaign_rows),
                                "campaigns": campaign_rows},
            "instrument_audit": self.audit.verify(),
            "organ_audit": self.organs.audit.verify(),
            "verification_audit": self.verification.audit.verify(),
            "knowledge_audit": self.knowledge.audit.verify(),
            "knowledge_receipts": self.knowledge.verify_receipts(),
            "content_store": self.content.verify(),
            "argument_audit": self.arguments.audit.verify(),
            "ir_audit": self.ir.audit.verify(),
            "portfolio_audit": self.portfolio.audit.verify(),
            "action_audit": self.actions.audit.verify(),
            "provenance_graph": self.provenance.verify(),
            "assurance_audit": self.assurance.audit.verify(),
            "model_scope_audit": self.models.audit.verify(),
            "acquisition": self.acquisition.verify(),
            "contract_waist": self.waist.verify(),
            "components": self.components.verify(),
            "capability_graph": {"valid": self.capability_graph.posiwid().get("valid", False),
                                  "report": self.capability_graph.posiwid()},
            "dependencies": {"valid": all(e.source and e.target and e.source != e.target for e in self.dependencies.edges.values()),
                             "edges": len(self.dependencies.edges), "invalid": len(self.dependencies.invalid)},
            "federation": {"valid": all(b.verify() for b in self.federation.bundles.values()),
                           "bundles": len(self.federation.bundles), "conflicts": len(self.federation.conflicts)},
            "gate_plan": self.gate_plan.verify(),
            "drift_baselines": {"valid": all(v.n >= 2 and v.std > 0 for v in self.drift_baselines.values()),
                                "baselines": len(self.drift_baselines)},
            "evaluator_boundary": self.evaluator.verify(),
            "resource_ledger": {"valid": self.resources.audit.verify().get("valid", False), "records": len(self.resources.records)},
            "provider_registry": self.providers.verify(),
            "search_campaigns": {"valid": self.search_campaigns.audit.verify().get("valid", False), "campaigns": len(self.search_campaigns.campaigns)},
            "document_ir": {"valid": self.documents.audit.verify().get("valid", False), "documents": len(self.documents.documents), "carvings": len(self.documents.carvings)},
            "transformations": {"valid": self.transformations.audit.verify().get("valid", False), "contracts": len(self.transformations.contracts), "receipts": len(self.transformations.receipts)},
            "instrument_registry": self.instruments.verify(),
            "mapping_precision": {"valid": self.mapping_precision.audit.verify().get("valid", False), "policies": len(self.mapping_precision.policies), "competitions": len(self.mapping_precision.competitions)},
            "regime_calibration": {"valid": self.regime_calibration.audit.verify().get("valid", False), "regimes": len(self.regime_calibration.regimes), "events": len(self.regime_calibration.events)},
            "domain_design": {"valid": self.designs.audit.verify().get("valid", False), "dialects": len(self.designs.dialects), "candidates": len(self.designs.candidates)},
            "allocation_harness": {"valid": self.allocation.audit.verify().get("valid", False), "results": len(self.allocation.results)},
            "portfolio_benchmark": {"valid": self.portfolio_benchmark.audit.verify().get("valid", False)},
            "specialist_ecology": {"valid": self.specialists.audit.verify().get("valid", False), "specialists": len(self.specialists.specialists)},
            "shift_portfolio": {"valid": self.shifts.audit.verify().get("valid", False), "contracts": len(self.shifts.contracts), "baselines": len(self.shifts.baselines)},
            "environment_protocol": {"valid": self.environments.audit.verify().get("valid", False), "specs": len(self.environments.specs), "traces": len(self.environments.traces)},
            "explanation_studies": {"valid": self.explanations.audit.verify().get("valid", False), "contracts": len(self.explanations.contracts), "packages": len(self.explanations.packages)},
            "mutation_campaign": {"valid": self.mutations.audit.verify().get("valid", False), "operators": len(self.mutations.operators), "executions": len(self.mutations.executions)},
            "scenario_assurance": {"valid": self.scenarios.audit.verify().get("valid", False), "profiles": len(self.scenarios.profiles), "runs": len(self.scenarios.runs)},
            "process_portfolio": self.process_portfolio.verify(),
        }
        valid = all(x.get("valid", False) for x in checks.values())
        return {"valid": valid, "checks": checks}

    def status(self) -> dict:
        arcs = []
        for path in sorted((self.root / "arcs").glob("*.json")):
            try:
                arc = DiscoveryArc.load(str(path))
                arcs.append({"arc_id": arc.arc_id, "name": arc.name, "posiwid": arc.posiwid()})
            except Exception as exc:
                arcs.append({"path": str(path), "error": f"{type(exc).__name__}: {exc}"})
        kernels = []
        for path in sorted((self.root / "arc_kernels").glob("*.json")):
            try:
                kernel = ARC5Kernel.load(path)
                kernels.append({"arc_id": kernel.arc.arc_id, "status": kernel.process_posiwid(),
                                "integrity": kernel.verify()})
            except Exception as exc:
                kernels.append({"path": str(path), "error": f"{type(exc).__name__}: {exc}"})
        adversarial_kernels = []
        for path in sorted((self.root / "arc5a_kernels").glob("*.json")):
            try:
                kernel = ARC5AAdversarialKernel.load(path)
                adversarial_kernels.append({"arc_id": kernel.arc.arc_id,
                                            "status": kernel.process_posiwid(),
                                            "integrity": kernel.verify()})
            except Exception as exc:
                adversarial_kernels.append({"path": str(path), "error": f"{type(exc).__name__}: {exc}"})
        campaigns = []
        for path in sorted((self.root / "arc_campaigns").glob("*.json")):
            try:
                campaign = ARC5Campaign.load(path)
                campaigns.append(campaign.status())
            except Exception as exc:
                campaigns.append({"path": str(path), "error": f"{type(exc).__name__}: {exc}"})
        return {
            "version": self.VERSION,
            "arcs": arcs,
            "arc5_kernels": kernels,
            "arc5a_kernels": adversarial_kernels,
            "arc5_campaigns": campaigns,
            "intent_proposals": len(self.intent_proposals),
            "knowledge": self.knowledge.posiwid(),
            "verification": self.verification.coverage(),
            "arguments": self.arguments.posiwid(),
            "intermediate_representations": sorted(self.ir.contracts),
            "portfolio": {"mechanisms": sorted(self.portfolio.profiles),
                          "performance_records": len(self.portfolio.records)},
            "process_portfolio": {"methods": sorted(self.process_portfolio.methods),
                                  "tasks": len(self.process_portfolio.tasks),
                                  "decisions": len(self.process_portfolio.decisions),
                                  "integrity": self.process_portfolio.verify()},
            "actions": {"registered": sorted(self.actions.actions),
                        "receipts": len(self.actions.receipts)},
            "assurance": self.assurance.coverage(),
            "models": {"registered": sorted(self.models.models),
                       "decisions": len(self.models.decisions)},
            "ecology": {"members": len(self.ecology.members),
                         "mutation_records": len(self.ecology.mutations)},
            "acquisition": self.acquisition.verify(),
            "contract_waist": self.waist.verify(),
            "components": self.components.verify(),
            "calibration_events": len(self.calibration.events),
            "capability_graph": self.capability_graph.posiwid(),
            "dependency_field": {"edges": len(self.dependencies.edges), "invalid": sorted(self.dependencies.invalid)},
            "causal": {"models": len(self.causal.models), "results": len(self.causal.results)},
            "ontology": {"concepts": len(self.ontology.concepts), "mappings": len(self.ontology.mappings)},
            "federation": {"bundles": len(self.federation.bundles), "objects": len(self.federation.versions),
                           "conflicts": len(self.federation.conflicts)},
            "reality_gates": self.gate_plan.summary(),
            "drift_baselines": sorted(self.drift_baselines),
            "stage4c": {
                "evaluator_commitments": len(self.evaluator.commitments),
                "provider_policies": len(self.providers.policies),
                "search_campaigns": len(self.search_campaigns.campaigns),
                "documents": len(self.documents.documents),
                "transformations": len(self.transformations.contracts),
                "instruments": len(self.instruments.specs),
                "mapping_competitions": len(self.mapping_precision.competitions),
                "calibration_regimes": len(self.regime_calibration.regimes),
                "design_dialects": len(self.designs.dialects),
                "specialists": len(self.specialists.specialists),
                "shift_monitors": len(self.shifts.contracts),
                "environment_specs": len(self.environments.specs),
                "scenario_profiles": len(self.scenarios.profiles),
                "universal_completion_claim": False,
            },
            "provenance": {"entities": len(self.provenance.entities),
                           "activities": len(self.provenance.activities),
                           "agents": len(self.provenance.agents),
                           "integrity": self.provenance.verify()},
            "organ_coverage": self.organs.coverage(),
            "capability_paths": {c: self.organs.dependency_path(c)
                                 for c in ("inquire", "interpret", "discover", "discover-text", "arc-start", "arc-step", "arc-search", "arc-status", "arc5a-start", "arc5a-step", "arc5a-search", "arc5a-status", "process-task", "process-select", "process-status", "investigate", "ingest", "verify", "scope", "settle", "represent",
                                           "argue", "route", "act", "assure", "ecology", "report", "arc-import", "record-contact", "invalidate", "invalidate-object", "goal", "calibrate", "component", "causal", "plan-test", "ontology", "federate", "drift", "task", "audit",
                                           "evaluation", "provider", "search-campaign", "document", "transform", "placement-benchmark", "instrument", "regime-calibration", "design", "allocate", "portfolio-benchmark", "specialist", "shift", "environment", "explanation-study", "mutation", "resource", "scenario")},
            "integrity": self.verify_integrity(),
        }
