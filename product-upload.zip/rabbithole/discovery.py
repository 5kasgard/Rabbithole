"""Subtractive discovery process (ARC-5) for The Field.

This module operationalises the process that produced the v5 ARC discoveries.
It is intentionally *not* a brainstormer. Search widens the evidence field; all
later operations reduce it through distinctions, contrastive mechanism analysis,
competing explanations, and reality contact.

The five moves are:

1. concrete search;
2. expose collapsed distinctions using dual POSIWID;
3. build an abstraction lattice, search its positive and negative instances,
   and extract context-bounded candidate invariants;
4. adversarially reduce competing mechanisms and heterogeneous compositions;
5. locate and record the most discriminating affordable contact, then recurse.

Every output is a proposal until contact. The process is itself auditable and
subject to mutation/deletion tests through the organ registry.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from .wal import EventLog


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


POLARITIES = {
    "for", "against", "failure", "counterexample", "boundary",
    "analogue", "anti_analogue", "null", "neutral",
}
STAGES = {"concrete", "expose", "abstract", "reduce", "contact"}
EVIDENCE_STATES = {"candidate", "screened_in", "screened_out", "withdrawn"}
MECHANISM_STATES = {"candidate", "surviving", "falsified", "superseded", "unresolved"}
TEST_STATES = {"proposed", "scheduled", "passed", "failed", "inconclusive", "unrunnable"}


@dataclass
class POSIWIDContract:
    """Dual local/whole-system observable contract.

    Text is deliberately behavioural. Architecture names do not satisfy it.
    ``success_observations`` and ``failure_observations`` make the goal itself
    falsifiable and prevent a self-sealing vision.
    """

    target: str
    local_current: Tuple[str, ...]
    local_goal: Tuple[str, ...]
    whole_current: Tuple[str, ...]
    whole_goal: Tuple[str, ...]
    constraints: Tuple[str, ...] = ()
    anti_goals: Tuple[str, ...] = ()
    success_observations: Tuple[str, ...] = ()
    failure_observations: Tuple[str, ...] = ()
    resource_budget: Mapping[str, float] = field(default_factory=dict)
    scope: str = ""
    cid: str = field(default_factory=lambda: _id("C"))

    def validate(self) -> None:
        if not self.target.strip():
            raise ValueError("POSIWID target is required")
        if not self.local_goal or not self.whole_goal:
            raise ValueError("both local and whole-system goal effects are required")
        for key, value in self.resource_budget.items():
            if not math.isfinite(float(value)) or float(value) < 0:
                raise ValueError(f"resource budget {key!r} must be finite and non-negative")


@dataclass
class SearchQuery:
    text: str
    stage: str
    polarity: str
    provider: str
    wave: int
    abstraction_id: str = ""
    domain_family: str = ""
    parent_query_id: str = ""
    rationale: str = ""
    created_at: float = field(default_factory=time.time)
    qid: str = field(default_factory=lambda: _id("Q"))

    def validate(self) -> None:
        if self.stage not in STAGES:
            raise ValueError(f"unknown search stage {self.stage!r}")
        if self.polarity not in POLARITIES:
            raise ValueError(f"unknown search polarity {self.polarity!r}")
        if not self.text.strip():
            raise ValueError("query text is required")
        if self.wave < 0:
            raise ValueError("search wave cannot be negative")


@dataclass
class EvidenceItem:
    """A retrieved carving, not an authority claim."""

    query_id: str
    title: str
    locator: str
    provider: str
    snapshot: str
    summary: str = ""
    authors: Tuple[str, ...] = ()
    published_at: str = ""
    source_type: str = "unknown"
    polarity: str = "neutral"
    domain_family: str = ""
    independence_group: str = ""
    quality: Mapping[str, float] = field(default_factory=dict)
    tags: Tuple[str, ...] = ()
    state: str = "candidate"
    exclusion_reason: str = ""
    duplicate_of: str = ""
    retrieved_at: float = field(default_factory=time.time)
    eid: str = field(default_factory=lambda: _id("E"))
    content_sha256: str = ""

    def __post_init__(self) -> None:
        if not self.content_sha256:
            self.content_sha256 = _sha(self.snapshot)
        if not self.independence_group:
            # Provider+locator is a conservative default. Callers should replace
            # it with DOI family, dataset lineage, institution, model family, etc.
            self.independence_group = f"{self.provider}:{self.locator}"

    def validate(self) -> None:
        if self.polarity not in POLARITIES:
            raise ValueError(f"unknown evidence polarity {self.polarity!r}")
        if self.state not in EVIDENCE_STATES:
            raise ValueError(f"unknown evidence state {self.state!r}")
        if not self.title.strip() or not self.locator.strip():
            raise ValueError("evidence requires title and locator")
        if _sha(self.snapshot) != self.content_sha256:
            raise ValueError("evidence snapshot digest mismatch")
        for key, value in self.quality.items():
            if not math.isfinite(float(value)):
                raise ValueError(f"quality score {key!r} must be finite")


@dataclass
class FunctionalDistinction:
    collapsed_claim: str
    dimensions: Tuple[str, ...]
    functions: Tuple[str, ...]
    interfaces: Tuple[str, ...] = ()
    authority_effects: Tuple[str, ...] = ()
    resource_flows: Tuple[str, ...] = ()
    failure_propagation: Tuple[str, ...] = ()
    evidence_ids: Tuple[str, ...] = ()
    did: str = field(default_factory=lambda: _id("D"))


@dataclass
class AbstractionNode:
    statement: str
    level: int
    parent_id: str = ""
    removed_incidentals: Tuple[str, ...] = ()
    retained_function: str = ""
    retained_constraints: Tuple[str, ...] = ()
    search_terms: Tuple[str, ...] = ()
    translation_back: str = ""
    failure_if_mistranslated: str = ""
    aid: str = field(default_factory=lambda: _id("A"))

    def validate(self) -> None:
        if self.level < 0:
            raise ValueError("abstraction level cannot be negative")
        if not self.statement.strip() or not self.retained_function.strip():
            raise ValueError("abstraction requires statement and retained function")


@dataclass
class ExampleCase:
    abstraction_id: str
    name: str
    outcome: str  # success|failure|mixed|unknown
    context: Tuple[str, ...]
    observed_mechanisms: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    boundary_conditions: Tuple[str, ...] = ()
    costs: Mapping[str, float] = field(default_factory=dict)
    notes: str = ""
    xid: str = field(default_factory=lambda: _id("X"))


@dataclass
class MechanismHypothesis:
    function: str
    mechanism: str
    contexts: Tuple[str, ...]
    predicted_effects: Tuple[str, ...]
    evidence_for: Tuple[str, ...] = ()
    evidence_against: Tuple[str, ...] = ()
    positive_cases: Tuple[str, ...] = ()
    negative_cases: Tuple[str, ...] = ()
    substitutes: Tuple[str, ...] = ()
    required_substrate: Tuple[str, ...] = ()
    work_relocated_to: Tuple[str, ...] = ()
    local_posiwid_effect: Tuple[str, ...] = ()
    whole_posiwid_effect: Tuple[str, ...] = ()
    failure_modes: Tuple[str, ...] = ()
    scope_limits: Tuple[str, ...] = ()
    necessary_status: str = "unknown"  # unknown|necessary|not_necessary|conditional
    sufficient_status: str = "unknown"  # unknown|sufficient|not_sufficient|conditional
    state: str = "candidate"
    falsifier: str = ""
    mechanism_class: str = ""
    introduced_wave: int = -1
    mid: str = field(default_factory=lambda: _id("MEC"))

    def validate(self) -> None:
        if self.state not in MECHANISM_STATES:
            raise ValueError(f"unknown mechanism state {self.state!r}")
        if not self.function.strip() or not self.mechanism.strip():
            raise ValueError("mechanism function and operation are required")


@dataclass
class SystemHypothesis:
    name: str
    mechanism_ids: Tuple[str, ...]
    composition: Tuple[str, ...]
    local_predictions: Tuple[str, ...]
    whole_predictions: Tuple[str, ...]
    assumptions: Tuple[str, ...] = ()
    expected_failures: Tuple[str, ...] = ()
    substrate_assignments: Mapping[str, str] = field(default_factory=dict)
    state: str = "candidate"
    sid: str = field(default_factory=lambda: _id("SYS"))


@dataclass
class TestObligation:
    __test__ = False
    target_type: str  # mechanism|system|abstraction|goal|implementation
    target_id: str
    question: str
    method: str
    outcome_if_a: str
    outcome_if_b: str
    contact_type: str
    independence_group: str
    expected_information_gain: float
    downstream_impact: float
    contact_quality: float
    cost: Mapping[str, float]
    reversible: bool = True
    public_surface: str = ""
    state: str = "proposed"
    result: str = ""
    observed: str = ""
    failure_layer: str = ""
    evidence_ids: Tuple[str, ...] = ()
    tid: str = field(default_factory=lambda: _id("T"))

    def validate(self) -> None:
        if self.state not in TEST_STATES:
            raise ValueError(f"unknown test state {self.state!r}")
        for name, value in (
            ("expected_information_gain", self.expected_information_gain),
            ("downstream_impact", self.downstream_impact),
            ("contact_quality", self.contact_quality),
        ):
            if not math.isfinite(float(value)) or float(value) < 0:
                raise ValueError(f"{name} must be finite and non-negative")
        for key, value in self.cost.items():
            if not math.isfinite(float(value)) or float(value) < 0:
                raise ValueError(f"cost {key!r} must be finite and non-negative")

    def priority(self) -> float:
        # Work is conserved. The denominator makes its location explicit rather
        # than pretending testing is free. A small epsilon avoids infinite rank.
        total_cost = sum(float(v) for v in self.cost.values())
        reversibility_bonus = 1.15 if self.reversible else 1.0
        return (self.expected_information_gain * self.downstream_impact *
                self.contact_quality * reversibility_bonus) / (total_cost + 1e-9)


@dataclass
class SaturationReport:
    wave: int
    new_mechanism_classes: int
    total_mechanism_classes: int
    domain_families_covered: Tuple[str, ...]
    polarities_covered: Tuple[str, ...]
    independent_groups: int
    unsupported_mechanisms: Tuple[str, ...]
    missing_domain_families: Tuple[str, ...]
    mechanism_novelty_rate: float
    saturated: bool
    reason: str


class DiscoveryArc:
    """Persistent, auditable state for one subtractive discovery arc."""

    def __init__(self, contract: POSIWIDContract, name: str = ""):
        contract.validate()
        self.name = name or contract.target
        self.arc_id = _id("ARC")
        self.contract = contract
        self.queries: Dict[str, SearchQuery] = {}
        self.evidence: Dict[str, EvidenceItem] = {}
        self.distinctions: Dict[str, FunctionalDistinction] = {}
        self.abstractions: Dict[str, AbstractionNode] = {}
        self.examples: Dict[str, ExampleCase] = {}
        self.mechanisms: Dict[str, MechanismHypothesis] = {}
        self.systems: Dict[str, SystemHypothesis] = {}
        self.tests: Dict[str, TestObligation] = {}
        self.audit = EventLog()
        self.created_at = time.time()
        self.audit.append("arc_created", {"contract": asdict(contract), "name": self.name})

    # --------------------------------------------------------------- search field
    def add_query(self, query: SearchQuery) -> str:
        query.validate()
        if query.abstraction_id and query.abstraction_id not in self.abstractions:
            raise KeyError(f"unknown abstraction {query.abstraction_id}")
        if query.parent_query_id and query.parent_query_id not in self.queries:
            raise KeyError(f"unknown parent query {query.parent_query_id}")
        self.queries[query.qid] = query
        self.audit.append("query_added", asdict(query))
        return query.qid

    def add_evidence(self, item: EvidenceItem) -> str:
        item.validate()
        if item.query_id not in self.queries:
            raise KeyError(f"unknown query {item.query_id}")
        # The artifact is content-addressed, but retrieval context is not.
        # Preserve every query->artifact edge (including its polarity and
        # abstraction level) while marking duplicate bytes.  Independence is
        # counted by independence_group, never by retrieval count.
        duplicate = next((e for e in self.evidence.values()
                          if e.content_sha256 == item.content_sha256), None)
        if duplicate:
            item.duplicate_of = duplicate.eid
            self.audit.append("evidence_duplicate", {
                "incoming": item.eid, "existing": duplicate.eid,
                "query": item.query_id, "sha256": item.content_sha256,
            })
        self.evidence[item.eid] = item
        self.audit.append("evidence_added", asdict(item))
        return item.eid

    def screen(self, eid: str, include: bool, reason: str) -> None:
        item = self.evidence[eid]
        item.state = "screened_in" if include else "screened_out"
        item.exclusion_reason = "" if include else reason
        self.audit.append("evidence_screened", {
            "eid": eid, "state": item.state, "reason": reason,
        })

    # --------------------------------------------------------------- expose/abstract
    def add_distinction(self, distinction: FunctionalDistinction) -> str:
        unknown = [eid for eid in distinction.evidence_ids if eid not in self.evidence]
        if unknown:
            raise KeyError(f"unknown evidence ids {unknown}")
        self.distinctions[distinction.did] = distinction
        self.audit.append("distinction_added", asdict(distinction))
        return distinction.did

    def add_abstraction(self, abstraction: AbstractionNode) -> str:
        abstraction.validate()
        if abstraction.parent_id and abstraction.parent_id not in self.abstractions:
            raise KeyError(f"unknown parent abstraction {abstraction.parent_id}")
        self.abstractions[abstraction.aid] = abstraction
        self.audit.append("abstraction_added", asdict(abstraction))
        return abstraction.aid

    def add_example(self, example: ExampleCase) -> str:
        if example.abstraction_id not in self.abstractions:
            raise KeyError(f"unknown abstraction {example.abstraction_id}")
        unknown = [eid for eid in example.evidence_ids if eid not in self.evidence]
        if unknown:
            raise KeyError(f"unknown evidence ids {unknown}")
        self.examples[example.xid] = example
        self.audit.append("example_added", asdict(example))
        return example.xid

    # --------------------------------------------------------------- reduce
    def add_mechanism(self, mechanism: MechanismHypothesis) -> str:
        mechanism.validate()
        for eid in mechanism.evidence_for + mechanism.evidence_against:
            if eid not in self.evidence:
                raise KeyError(f"unknown evidence {eid}")
        for xid in mechanism.positive_cases + mechanism.negative_cases:
            if xid not in self.examples:
                raise KeyError(f"unknown example {xid}")
        if not mechanism.mechanism_class:
            normalized = re.sub(r"[^a-z0-9]+", "-", mechanism.mechanism.lower()).strip("-")
            mechanism.mechanism_class = normalized[:120] or mechanism.mid
        if mechanism.introduced_wave < 0:
            waves = [self.queries[self.evidence[eid].query_id].wave
                     for eid in mechanism.evidence_for + mechanism.evidence_against
                     if eid in self.evidence]
            mechanism.introduced_wave = max(waves, default=-1)
        self.mechanisms[mechanism.mid] = mechanism
        self.audit.append("mechanism_added", asdict(mechanism))
        return mechanism.mid

    def update_mechanism(self, mid: str, *, state: Optional[str] = None,
                         necessary_status: Optional[str] = None,
                         sufficient_status: Optional[str] = None,
                         reason: str = "") -> None:
        m = self.mechanisms[mid]
        if state is not None:
            if state not in MECHANISM_STATES:
                raise ValueError(f"unknown mechanism state {state!r}")
            m.state = state
        if necessary_status is not None:
            m.necessary_status = necessary_status
        if sufficient_status is not None:
            m.sufficient_status = sufficient_status
        self.audit.append("mechanism_updated", {
            "mid": mid, "state": m.state,
            "necessary_status": m.necessary_status,
            "sufficient_status": m.sufficient_status,
            "reason": reason,
        })

    def add_system_hypothesis(self, system: SystemHypothesis) -> str:
        unknown = [mid for mid in system.mechanism_ids if mid not in self.mechanisms]
        if unknown:
            raise KeyError(f"unknown mechanism ids {unknown}")
        self.systems[system.sid] = system
        self.audit.append("system_hypothesis_added", asdict(system))
        return system.sid

    # --------------------------------------------------------------- contact
    def add_test(self, test: TestObligation) -> str:
        test.validate()
        if test.target_type == "mechanism" and test.target_id not in self.mechanisms:
            raise KeyError(f"unknown mechanism {test.target_id}")
        if test.target_type == "system" and test.target_id not in self.systems:
            raise KeyError(f"unknown system {test.target_id}")
        if test.target_type == "abstraction" and test.target_id not in self.abstractions:
            raise KeyError(f"unknown abstraction {test.target_id}")
        self.tests[test.tid] = test
        self.audit.append("test_added", {**asdict(test), "priority": test.priority()})
        return test.tid

    def ranked_tests(self, unresolved_only: bool = True) -> List[TestObligation]:
        candidates = [t for t in self.tests.values()
                      if not unresolved_only or t.state in {"proposed", "scheduled"}]
        return sorted(candidates, key=lambda t: (-t.priority(), t.tid))

    def record_test(self, tid: str, state: str, observed: str,
                    result: str = "", failure_layer: str = "",
                    evidence_ids: Sequence[str] = ()) -> None:
        if state not in TEST_STATES - {"proposed", "scheduled"}:
            raise ValueError(f"invalid terminal test state {state!r}")
        for eid in evidence_ids:
            if eid not in self.evidence:
                raise KeyError(f"unknown evidence {eid}")
        t = self.tests[tid]
        t.state = state
        t.observed = observed
        t.result = result
        t.failure_layer = failure_layer
        t.evidence_ids = tuple(evidence_ids)
        self.audit.append("test_recorded", asdict(t))

    # --------------------------------------------------------------- coverage/saturation
    def saturation(self, wave: Optional[int] = None,
                   required_domain_families: Sequence[str] = (),
                   min_polarities: Sequence[str] = ("for", "against", "failure"),
                   novelty_threshold: float = 0.05,
                   min_independent_groups: int = 3) -> SaturationReport:
        if wave is None:
            wave = max((q.wave for q in self.queries.values()), default=0)
        current_query_ids = {q.qid for q in self.queries.values() if q.wave == wave}
        current_evidence = [e for e in self.evidence.values()
                            if e.query_id in current_query_ids and e.state != "screened_out"]
        # Novelty is the share of distinct causal mechanism classes first
        # supported by the current search wave.  Merely attaching new citations to
        # an existing class does not reset saturation.
        all_classes = {m.mechanism_class or m.mid for m in self.mechanisms.values()}
        new_classes = {m.mechanism_class or m.mid for m in self.mechanisms.values()
                       if m.introduced_wave == wave}
        total = len(all_classes)
        novelty = len(new_classes) / max(1, total)
        domains = tuple(sorted({e.domain_family for e in self.evidence.values()
                                if e.domain_family and e.state != "screened_out"}))
        polarities = tuple(sorted({e.polarity for e in self.evidence.values()
                                   if e.state != "screened_out"}))
        groups = len({e.independence_group for e in self.evidence.values()
                      if e.state != "screened_out"})
        unsupported = tuple(sorted(m.mid for m in self.mechanisms.values()
                                   if not m.evidence_for and not m.evidence_against))
        missing_domains = tuple(sorted(set(required_domain_families) - set(domains)))
        missing_polarities = set(min_polarities) - set(polarities)
        saturated = (wave > 0 and novelty <= novelty_threshold and not missing_domains
                     and not missing_polarities and groups >= min_independent_groups
                     and not unsupported)
        reasons = []
        if wave == 0:
            reasons.append("only one search wave exists")
        if novelty > novelty_threshold:
            reasons.append(f"mechanism novelty {novelty:.3f} exceeds threshold")
        if missing_domains:
            reasons.append(f"missing domain families: {', '.join(missing_domains)}")
        if missing_polarities:
            reasons.append(f"missing polarities: {', '.join(sorted(missing_polarities))}")
        if groups < min_independent_groups:
            reasons.append(f"only {groups} independent evidence groups")
        if unsupported:
            reasons.append(f"unsupported mechanism hypotheses: {len(unsupported)}")
        if not reasons:
            reasons.append("declared saturation envelope satisfied")
        return SaturationReport(
            wave=wave, new_mechanism_classes=len(new_classes),
            total_mechanism_classes=total,
            domain_families_covered=domains, polarities_covered=polarities,
            independent_groups=groups, unsupported_mechanisms=unsupported,
            missing_domain_families=missing_domains,
            mechanism_novelty_rate=novelty, saturated=saturated,
            reason="; ".join(reasons),
        )

    def posiwid(self) -> dict:
        surviving = [m for m in self.mechanisms.values()
                     if m.state in {"surviving", "unresolved", "candidate"}]
        return {
            "target": self.contract.target,
            "observed_effects": {
                "queries_recorded": len(self.queries),
                "evidence_snapshots_retained": len(self.evidence),
                "independent_evidence_groups": len({e.independence_group for e in self.evidence.values()}),
                "distinctions_exposed": len(self.distinctions),
                "abstraction_levels": len({a.level for a in self.abstractions.values()}),
                "examples_compared": len(self.examples),
                "mechanism_hypotheses": len(self.mechanisms),
                "mechanisms_remaining": len(surviving),
                "competing_systems": len(self.systems),
                "tests_defined": len(self.tests),
                "tests_with_contact": sum(t.state in {"passed", "failed", "inconclusive"}
                                          for t in self.tests.values()),
                "public_surface_tests": sum(bool(t.public_surface) for t in self.tests.values()),
            },
            "next_tests": [{"tid": t.tid, "question": t.question,
                            "priority": t.priority(), "method": t.method}
                           for t in self.ranked_tests()[:10]],
            "audit_valid": self.audit.verify(),
        }

    # --------------------------------------------------------------- persistence
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "arc_id": self.arc_id,
            "created_at": self.created_at,
            "contract": asdict(self.contract),
            "queries": [asdict(x) for x in self.queries.values()],
            "evidence": [asdict(x) for x in self.evidence.values()],
            "distinctions": [asdict(x) for x in self.distinctions.values()],
            "abstractions": [asdict(x) for x in self.abstractions.values()],
            "examples": [asdict(x) for x in self.examples.values()],
            "mechanisms": [asdict(x) for x in self.mechanisms.values()],
            "systems": [asdict(x) for x in self.systems.values()],
            "tests": [asdict(x) for x in self.tests.values()],
            "audit": self.audit.to_dict(),
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "DiscoveryArc":
        c = dict(raw["contract"])
        for key in (
            "local_current", "local_goal", "whole_current", "whole_goal",
            "constraints", "anti_goals", "success_observations", "failure_observations",
        ):
            c[key] = tuple(c.get(key, ()))
        arc = cls(POSIWIDContract(**c), name=str(raw.get("name", "")))
        arc.arc_id = str(raw.get("arc_id", arc.arc_id))
        arc.created_at = float(raw.get("created_at", time.time()))
        arc.queries = {x["qid"]: SearchQuery(**x) for x in raw.get("queries", [])}
        arc.evidence = {}
        for x in raw.get("evidence", []):
            d = dict(x)
            for key in ("authors", "tags"):
                d[key] = tuple(d.get(key, ()))
            arc.evidence[d["eid"]] = EvidenceItem(**d)
        arc.distinctions = {}
        for x in raw.get("distinctions", []):
            d = dict(x)
            for key in ("dimensions", "functions", "interfaces", "authority_effects",
                        "resource_flows", "failure_propagation", "evidence_ids"):
                d[key] = tuple(d.get(key, ()))
            arc.distinctions[d["did"]] = FunctionalDistinction(**d)
        arc.abstractions = {}
        for x in raw.get("abstractions", []):
            d = dict(x)
            for key in ("removed_incidentals", "retained_constraints", "search_terms"):
                d[key] = tuple(d.get(key, ()))
            arc.abstractions[d["aid"]] = AbstractionNode(**d)
        arc.examples = {}
        for x in raw.get("examples", []):
            d = dict(x)
            for key in ("context", "observed_mechanisms", "evidence_ids", "boundary_conditions"):
                d[key] = tuple(d.get(key, ()))
            arc.examples[d["xid"]] = ExampleCase(**d)
        arc.mechanisms = {}
        tuple_fields = (
            "contexts", "predicted_effects", "evidence_for", "evidence_against",
            "positive_cases", "negative_cases", "substitutes", "required_substrate",
            "work_relocated_to", "local_posiwid_effect", "whole_posiwid_effect",
            "failure_modes", "scope_limits",
        )
        for x in raw.get("mechanisms", []):
            d = dict(x)
            for key in tuple_fields:
                d[key] = tuple(d.get(key, ()))
            arc.mechanisms[d["mid"]] = MechanismHypothesis(**d)
        arc.systems = {}
        for x in raw.get("systems", []):
            d = dict(x)
            for key in ("mechanism_ids", "composition", "local_predictions", "whole_predictions",
                        "assumptions", "expected_failures"):
                d[key] = tuple(d.get(key, ()))
            arc.systems[d["sid"]] = SystemHypothesis(**d)
        arc.tests = {}
        for x in raw.get("tests", []):
            d = dict(x)
            d["evidence_ids"] = tuple(d.get("evidence_ids", ()))
            arc.tests[d["tid"]] = TestObligation(**d)
        arc.audit = EventLog.from_dict(raw.get("audit", {}))
        return arc

    def save(self, path: str) -> None:
        data = self.to_dict()
        self.audit.snapshot(data)
        Path(path).write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True))

    @classmethod
    def load(cls, path: str) -> "DiscoveryArc":
        return cls.from_dict(json.loads(Path(path).read_text()))

    def export_prov_jsonld(self) -> dict:
        """Export a small W3C PROV-shaped JSON-LD view.

        The internal representation stays richer; this is an interoperability
        projection, not a claim of full PROV-O conformance.
        """
        graph = []
        for q in self.queries.values():
            graph.append({
                "@id": f"urn:field:{q.qid}", "@type": "prov:Activity",
                "rdfs:label": q.text, "field:stage": q.stage,
                "field:polarity": q.polarity, "field:provider": q.provider,
            })
        for e in self.evidence.values():
            graph.append({
                "@id": f"urn:field:{e.eid}", "@type": "prov:Entity",
                "rdfs:label": e.title, "prov:atLocation": e.locator,
                "field:sha256": e.content_sha256,
                "prov:wasGeneratedBy": {"@id": f"urn:field:{e.query_id}"},
            })
        for t in self.tests.values():
            graph.append({
                "@id": f"urn:field:{t.tid}", "@type": "prov:Activity",
                "rdfs:label": t.question, "field:state": t.state,
                "field:contactType": t.contact_type,
            })
        return {
            "@context": {
                "prov": "http://www.w3.org/ns/prov#",
                "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
                "field": "https://example.org/the-field/",
            },
            "@graph": graph,
        }
