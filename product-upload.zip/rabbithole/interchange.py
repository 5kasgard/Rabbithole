"""Experimental Field Interchange Protocol (FIP) draft.

FIP is a mechanical interchange envelope, not a semantic truth layer.  A valid
FIP object proves only that independent implementations can parse the same
bounded structure, compute the same digest, and enforce dependency/revocation
rules.  It never raises epistemic authority.

The core profile and attack model are derived from the lineage-and-vision audit
contact campaign.  The protocol remains experimental until independent clean-
room implementations and deployed compatibility history exist.
"""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping, MutableMapping, Sequence

MAX_BYTES = 1_000_000
MAX_DEPTH = 32
MAX_KEYS = 256
MAX_ARRAY = 1024
MAX_DEPS = 256
SAFE_INTEGER = 2**53 - 1
PROTOCOL = "field/1"
KNOWN_CRITICAL_EXTENSIONS = {"x-field-revocation-v1"}
CONTACTED_PROFILES = {"evidence", "akbc", "action", "federation"}
EXPERIMENTAL_PROFILES = {"contract", "decision", "capability", "arc", "outward-loop"}


class FIPError(ValueError):
    """Raised when a FIP envelope violates mechanical conformance."""


def parse_json(raw: str) -> Any:
    if len(raw.encode("utf-8")) > MAX_BYTES:
        raise FIPError("oversized")

    def hook(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for key, value in pairs:
            if key in out:
                raise FIPError("duplicate_key")
            out[key] = value
        return out

    try:
        return json.loads(
            raw,
            object_pairs_hook=hook,
            parse_constant=lambda _x: (_ for _ in ()).throw(FIPError("nonfinite")),
        )
    except FIPError:
        raise
    except Exception as exc:  # pragma: no cover - defensive normalization
        raise FIPError("invalid_json") from exc


def _escape(value: str) -> str:
    out = ['"']
    for ch in value:
        cp = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == "\\":
            out.append("\\\\")
        elif ch == "\b":
            out.append("\\b")
        elif ch == "\f":
            out.append("\\f")
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\r":
            out.append("\\r")
        elif ch == "\t":
            out.append("\\t")
        elif 0x20 <= cp <= 0x7E:
            out.append(ch)
        elif cp <= 0xFFFF:
            out.append(f"\\u{cp:04x}")
        else:
            cp -= 0x10000
            hi = 0xD800 + (cp >> 10)
            lo = 0xDC00 + (cp & 0x3FF)
            out.append(f"\\u{hi:04x}\\u{lo:04x}")
    out.append('"')
    return "".join(out)


def canonical(value: Any, depth: int = 0) -> str:
    """Return the language-neutral canonical JSON form used by FIP.

    Numbers are intentionally narrow.  Integral floats canonicalize as integers;
    non-integral quantities must be represented by profile-defined decimal
    strings to avoid cross-runtime ambiguity.
    """
    if depth > MAX_DEPTH:
        raise FIPError("depth")
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int) and not isinstance(value, bool):
        if abs(value) > SAFE_INTEGER:
            raise FIPError("unsafe_integer")
        return str(value)
    if isinstance(value, float):
        if not math.isfinite(value):
            raise FIPError("nonfinite")
        if value.is_integer() and abs(value) <= SAFE_INTEGER:
            return str(int(value))
        raise FIPError("nonintegral_number_requires_decimal_string")
    if isinstance(value, str):
        return _escape(value)
    if isinstance(value, list):
        if len(value) > MAX_ARRAY:
            raise FIPError("array_too_large")
        return "[" + ",".join(canonical(item, depth + 1) for item in value) + "]"
    if isinstance(value, dict):
        if len(value) > MAX_KEYS:
            raise FIPError("object_too_large")
        if not all(isinstance(key, str) for key in value):
            raise FIPError("nonstring_key")
        keys = sorted(value, key=lambda key: key.encode("utf-8"))
        return "{" + ",".join(
            _escape(key) + ":" + canonical(value[key], depth + 1) for key in keys
        ) + "}"
    raise FIPError("unsupported_type")


def canonical_bytes(value: Any) -> bytes:
    return canonical(value).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _sorted_unique(values: Sequence[str]) -> bool:
    return list(values) == sorted(set(values), key=lambda x: x.encode("utf-8"))


@dataclass(frozen=True)
class ProfileSpec:
    name: str
    version: int = 1
    status: str = "experimental"
    semantic_validator: Callable[[Mapping[str, Any]], None] | None = field(
        default=None, compare=False, repr=False
    )


class ProfileRegistry:
    """Registry for plural semantic profiles above the mechanical waist."""

    def __init__(self) -> None:
        self._profiles: dict[tuple[str, int], ProfileSpec] = {}
        for name in sorted(CONTACTED_PROFILES):
            self.register(ProfileSpec(name, 1, "contacted_local"))
        for name in sorted(EXPERIMENTAL_PROFILES):
            self.register(ProfileSpec(name, 1, "experimental_local"))

    def register(self, spec: ProfileSpec) -> None:
        if not spec.name or spec.version < 1:
            raise FIPError("profile")
        key = (spec.name, spec.version)
        if key in self._profiles:
            raise FIPError("profile_already_registered")
        self._profiles[key] = spec

    def get(self, name: str, version: int) -> ProfileSpec:
        try:
            return self._profiles[(name, version)]
        except KeyError as exc:
            raise FIPError("unsupported_profile") from exc

    def status(self) -> list[dict[str, Any]]:
        return [
            {"name": spec.name, "version": spec.version, "status": spec.status}
            for spec in sorted(self._profiles.values(), key=lambda s: (s.name, s.version))
        ]


DEFAULT_PROFILES = ProfileRegistry()


def material(obj: Mapping[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in obj.items() if key != "digest"}


def validate_shape(
    obj: Mapping[str, Any],
    *,
    verify_digest: bool = True,
    profiles: ProfileRegistry = DEFAULT_PROFILES,
) -> dict[str, Any]:
    required = {
        "fip", "profile", "identity", "object_type", "dependencies",
        "authority", "revocation", "payload", "extensions", "critical_extensions",
    }
    if not isinstance(obj, Mapping) or not required.issubset(obj):
        raise FIPError("missing_fields")
    if obj["fip"] != PROTOCOL:
        raise FIPError("unsupported_protocol")
    profile = obj["profile"]
    if not isinstance(profile, Mapping):
        raise FIPError("unsupported_profile")
    name = profile.get("name")
    version = profile.get("version")
    if not isinstance(name, str) or not isinstance(version, int):
        raise FIPError("unsupported_profile")
    profile_spec = profiles.get(name, version)
    if obj["object_type"] != name:
        raise FIPError("profile_type_mismatch")
    if not isinstance(obj["identity"], str) or not obj["identity"]:
        raise FIPError("identity")

    deps = obj["dependencies"]
    if (
        not isinstance(deps, list)
        or len(deps) > MAX_DEPS
        or not all(isinstance(value, str) for value in deps)
        or not _sorted_unique(deps)
    ):
        raise FIPError("dependencies")

    authority = obj["authority"]
    if (
        not isinstance(authority, Mapping)
        or not isinstance(authority.get("ceiling"), int)
        or not 0 <= authority["ceiling"] <= 4
        or not isinstance(authority.get("issuer"), str)
    ):
        raise FIPError("authority")
    scopes = authority.get("scopes", [])
    if (
        not isinstance(scopes, list)
        or not all(isinstance(value, str) for value in scopes)
        or not _sorted_unique(scopes)
    ):
        raise FIPError("authority_scopes")

    revocation = obj["revocation"]
    if (
        not isinstance(revocation, Mapping)
        or revocation.get("status") not in {"active", "revoked"}
        or not isinstance(revocation.get("sequence"), int)
        or revocation["sequence"] < 0
    ):
        raise FIPError("revocation")

    extensions = obj["extensions"]
    if (
        not isinstance(extensions, Mapping)
        or not all(isinstance(key, str) and key.startswith("x-") for key in extensions)
    ):
        raise FIPError("extensions")

    critical = obj["critical_extensions"]
    if (
        not isinstance(critical, list)
        or not all(isinstance(value, str) for value in critical)
        or not _sorted_unique(critical)
    ):
        raise FIPError("critical_extensions")
    if any(value not in KNOWN_CRITICAL_EXTENSIONS for value in critical):
        raise FIPError("unsupported_critical_extension")

    canonical(material(dict(obj)))
    if verify_digest:
        digest = obj.get("digest")
        if not isinstance(digest, str):
            raise FIPError("missing_digest")
        expected = canonical_sha256(material(dict(obj)))
        if digest != expected:
            raise FIPError("digest_mismatch")

    if profile_spec.semantic_validator is not None:
        profile_spec.semantic_validator(obj)
    return {
        "transport_valid": True,
        "semantic_authority": False,
        "profile": {"name": profile_spec.name, "version": profile_spec.version},
        "profile_status": profile_spec.status,
        "digest": str(obj.get("digest", "")),
    }


def seal(
    obj: Mapping[str, Any], *, profiles: ProfileRegistry = DEFAULT_PROFILES
) -> dict[str, Any]:
    out = dict(obj)
    out.pop("digest", None)
    validate_shape(out, verify_digest=False, profiles=profiles)
    out["digest"] = canonical_sha256(out)
    return out


def graph_validate(
    objects: Sequence[Mapping[str, Any]], *, profiles: ProfileRegistry = DEFAULT_PROFILES
) -> dict[str, Any]:
    latest: dict[str, Mapping[str, Any]] = {}
    for raw in objects:
        obj = dict(raw)
        validate_shape(obj, profiles=profiles)
        identity = obj["identity"]
        sequence = obj["revocation"]["sequence"]
        if identity in latest:
            old = latest[identity]
            if sequence <= old["revocation"]["sequence"]:
                raise FIPError("stale_revocation")
            if (
                old["revocation"]["status"] == "revoked"
                and obj["revocation"]["status"] == "active"
            ):
                raise FIPError("revocation_reactivation")
        latest[identity] = obj

    graph = {
        identity: [dep for dep in obj["dependencies"] if dep in latest]
        for identity, obj in latest.items()
    }
    for identity, obj in latest.items():
        if obj["revocation"]["status"] == "active" and any(
            latest[dep]["revocation"]["status"] == "revoked" for dep in graph[identity]
        ):
            raise FIPError("revoked_dependency")

    visiting: set[str] = set()
    done: set[str] = set()

    def visit(node: str) -> None:
        if node in visiting:
            raise FIPError("dependency_cycle")
        if node in done:
            return
        visiting.add(node)
        for dep in graph[node]:
            visit(dep)
        visiting.remove(node)
        done.add(node)

    for identity in graph:
        visit(identity)
    return {
        "valid": True,
        "objects": len(objects),
        "logical_objects": len(latest),
        "semantic_authority": False,
    }


def make_envelope(
    *,
    profile: str,
    identity: str,
    payload: Mapping[str, Any],
    dependencies: Iterable[str] = (),
    authority_ceiling: int = 0,
    issuer: str = "",
    scopes: Iterable[str] = (),
    revocation_status: str = "active",
    revocation_sequence: int = 0,
    extensions: Mapping[str, Any] | None = None,
    critical_extensions: Iterable[str] = (),
    profiles: ProfileRegistry = DEFAULT_PROFILES,
) -> dict[str, Any]:
    obj = {
        "fip": PROTOCOL,
        "profile": {"name": profile, "version": 1},
        "identity": identity,
        "object_type": profile,
        "dependencies": sorted(set(dependencies), key=lambda x: x.encode("utf-8")),
        "authority": {
            "ceiling": int(authority_ceiling),
            "issuer": issuer,
            "scopes": sorted(set(scopes), key=lambda x: x.encode("utf-8")),
        },
        "revocation": {"status": revocation_status, "sequence": int(revocation_sequence)},
        "payload": dict(payload),
        "extensions": dict(extensions or {}),
        "critical_extensions": sorted(
            set(critical_extensions), key=lambda x: x.encode("utf-8")
        ),
    }
    return seal(obj, profiles=profiles)


def _fip_safe(value: Any) -> Any:
    """Convert Python values into the narrow cross-runtime FIP number domain."""
    if isinstance(value, float):
        if not math.isfinite(value):
            raise FIPError("nonfinite_contract_value")
        if value.is_integer() and abs(value) <= SAFE_INTEGER:
            return int(value)
        return format(value, ".17g")
    if isinstance(value, tuple):
        return [_fip_safe(item) for item in value]
    if isinstance(value, list):
        return [_fip_safe(item) for item in value]
    if isinstance(value, Mapping):
        return {str(key): _fip_safe(item) for key, item in value.items()}
    return value


def contract_to_fip(contract: Any, *, issuer: str = "field-contract-store") -> dict[str, Any]:
    """Convert a ContractObject-like value to an experimental FIP profile.

    This adapter preserves the contract object's own authority ceiling inside
    the payload.  The FIP envelope itself receives no semantic authority.
    """
    raw = contract.material() if hasattr(contract, "material") else dict(contract)
    raw = _fip_safe(raw)
    logical_id = str(raw.get("logical_id", ""))
    if not logical_id:
        raise FIPError("contract_identity")
    version = int(raw.get("version", 1))
    status = str(raw.get("status", "proposed"))
    ceiling = float(raw.get("authority_ceiling", 0.0))
    mechanical_ceiling = max(0, min(4, int(math.floor(ceiling * 4 + 1e-12))))
    return make_envelope(
        profile="contract",
        identity=f"{logical_id}:v{version}",
        payload=raw,
        dependencies=tuple(str(x) for x in raw.get("dependency_ids", ())),
        authority_ceiling=mechanical_ceiling,
        issuer=issuer,
        scopes=(str(raw.get("object_type", "contract")), status),
        revocation_status="revoked" if status == "revoked" else "active",
        revocation_sequence=max(0, version - 1),
        critical_extensions=("x-field-revocation-v1",),
    )


def verify_lines(raw_lines: Iterable[str]) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for raw in raw_lines:
        try:
            obj = parse_json(raw)
            result = validate_shape(obj)
            results.append(
                {
                    "ok": True,
                    "canonical_sha256": canonical_sha256(obj),
                    "digest": result["digest"],
                    "semantic_authority": False,
                    "profile_status": result["profile_status"],
                }
            )
        except Exception as exc:
            results.append({"ok": False, "error": str(exc), "semantic_authority": False})
    return results
