"""RabbitHole — the grounding kernel.

A personal constraint field: heterogeneous factors (walls, weights,
clamps) over interval domains, settled by local propagation. Pruning,
never generation. Any direction. Full provenance. Zero dependencies.
"""

from .core import BASE, Dim, Interval, UNITS, unit
from .field import (
    BeliefReport,
    BoundFactor,
    ConflictReport,
    DimensionalWall,
    Evidence,
    Field,
    GroundingRequest,
    LinearFactor,
    NearestFeasible,
    PowerFactor,
    ProductFactor,
    Provenance,
    SettleReport,
    SumFactor,
    Variable,
    ship_core,
)
from .wal import Event, EventLog, kernel_version
from .tether import (CONTACT_DEFAULT_QUALITY, CONTACT_TYPES, GroundingLoop, GroundingTest, Measurement,
                     RealityHarness, SourceLedger, Verdict)
from .epistemic import (Commitment, CommitmentIntegrityError, CoverageReport,
                        allocate, commit, coverage, resolve_commitment)
from .bridge import (BRIDGE_SPEC, BridgeError, BridgeProposal, explain_for_bridge,
                     ingest, propose, report_test, validate_spec)
from .routing import HeterogeneousRouter, RouteRecord
from .capabilities import CapabilityError, CapabilityIssuer
from .akbc import (Carving, ConstraintProposal, FieldSystem, IdentityHypothesis,
                   KindRegistry, Measurand, Observation, PlacementDecision,
                   QuantityKind, Scope, SourceReceipt, metrology_seed)
from .discovery import (AbstractionNode, DiscoveryArc, EvidenceItem, ExampleCase,
                        FunctionalDistinction, MechanismHypothesis, POSIWIDContract,
                        SaturationReport, SearchQuery, SystemHypothesis, TestObligation)
from .scope import ApplicabilityDecision, ModelContract, ModelRegistry, ScopeCondition
from .search import (CatalogProvider, CompositeProvider, ContentStore, CrossrefProvider,
                     LocalCorpusProvider, NetworkUnavailable, OpenAlexProvider,
                     SearchError, SearchResult, search_into_arc)
from .faculties import (FacultyError, FacultyReceipt, OllamaFaculty,
                        OpenAICompatibleFaculty, ProposalFaculty, SubprocessFaculty)
from .process import ARC5Controller, SearchEnvelope, StageGate
from .arc_kernel import (ARC5Kernel, EligibilityContract, SearchRequirement, SearchTrackPlan,
                         ScreeningDecision, EvidenceLineageProfile, TransferCase,
                         MechanismCaseAssessment, MechanismInference, ApprovalRecord,
                         WorkItem, FailureDiagnosis, ArcAmendment)
from .arc_campaign import (ARC5Campaign, CapabilityTarget, TargetRun, CapabilityDisposition, CampaignApproval)
from .arc_adversarial import (ARC5AAdversarialKernel, HostileInterpretation, LaneSearchRequirement,
                              LaneSearchPlan, DecompositionPass, DecompositionDisagreement,
                              AbstractionRegistration, ArenaCandidate, ParetoDimension,
                              ParetoAssessment, AdversarialTestPair, DecisionSaturationWave,
                              ContactRecord, AdversarialApprovalRecord, AdversarialWorkItem)
from .organs import (MutationResult, OrganRegistry, OrganSpec, OrganTrace,
                     OrganUnavailable)
from .verification import (Claim, RegisteredVerifier, VerificationContract,
                           VerificationRegistry, VerificationRequest,
                           VerificationResult, core_contracts)
from .assurance import (AssuranceRegistry, CapabilityCase, CapabilityObservation, CapabilityRequirement)
from .argument import (ArgumentClaim, ArgumentEvidence, ArgumentGraph, DialecticalReport, ClaimRelation)
from .actions import ActionReceipt, ActionRegistry, ActionSpec
from .intent import IntentInterpreter, IntentProposal
from .ir import IRContract, IRRegistry, IRRequirement, IRSelection, core_irs
from .portfolio import (MechanismPortfolio, MechanismProfile, PerformanceRecord,
                        Selection, TaskShape)
from .process_portfolio import (ProcessAssessment, ProcessCandidate, ProcessDecision,
                                ProcessMethod, ProcessPortfolio, ProcessTaskProfile,
                                default_process_methods, seeded_process_portfolio)
from .substrate_campaign import (BenchmarkCommitment, BenchmarkObservation, CandidateAssessment,
                                     ExperimentAllocation, FormalContract, LayerDecision,
                                     MigrationSlice, RefinementRecord, SubstrateCampaign,
                                     SubstrateCandidate, WorkloadContract)
from .longitudinal_validation import (AnalysisResult, ArmCommitment, ArmPrediction,
                                      ChallengeCommitment, ChallengeOutcome,
                                      EvaluatorAttestation, ExternalReviewAttestation,
                                      LongitudinalValidationStudy, MaintenanceEvent,
                                      ValidationProtocol)
from .provenance import ProvActivity, ProvAgent, ProvEntity, ProvenanceGraph
from .corpus import extract_repomix, iter_repomix_files
from .analogy import AnalogyAssessment, AnalogyGate, AnalogyHypothesis
from .benchmark import ARC5MethodBenchmark, MethodBenchmarkReport, RecoveryResult, RecoveryTarget
from .ecology import EcologyMember, EcologyReport, OrganEcology
from .presentation import PresentationInput, Presenter, ResolutionReport
from .instrument import FieldInstrument, PublicResult
from .waist import ContractObject, ContractStore, DependencyLink
from .components import ComponentAttestation, ComponentRegistry
from .goal import GoalDecision, GoalGate, GoalRequest
from .calibration import CalibrationEvent, CalibrationRegistry, CalibrationReport
from .capability_graph import CapabilityGraph, CapabilityNode, GateResult, InterfaceNode
from .containment import DependencyEdge, DependencyField, Invalidation
from .causal import CausalClaim, CausalModel, CausalRegistry, IdentificationResult
from .experiment import CandidateTest, ExperimentPlanner, Hypothesis, TestRanking
from .ontology import ConceptVersion, MappingHypothesis, OntologyRegistry
from .federation import FederationBundle, FederationLedger, MergeConflict, ObjectVersion
from .task import TaskAction, TaskReport, TaskRequest, TaskStage, TaskVerification
from .gateplan import FrozenGatePlan, GateDefinition, GateOutcome
from .drift import DriftBaseline, DriftMonitor, DriftReport
from .acquisition import (AcquisitionEngine, AcquisitionError, ArtifactReceipt, FetchPolicy, ParsedArtifact, ParseReceipt)
from .extraction import (DeterministicQuantityExtractor, ExtractionBundle, ExtractionReceipt, FacultyClaimExtractor, GenericClaimCarving)
from .inquiry import InquiryEngine, InquiryReport, InquiryRequest, StageReceipt
from .security import ArtifactRiskScanner, RiskAssessment, RiskFinding
from .executors import FileHashPredicate, HTTPJSONMeasurement

from .interchange import (FIPError, ProfileRegistry, ProfileSpec, canonical, canonical_bytes,
                          canonical_sha256, contract_to_fip, graph_validate, make_envelope,
                          parse_json as parse_fip_json, seal as seal_fip, validate_shape as validate_fip)
from .master_registry import MasterRegistry, RegistryIssue
from .outward_loop import (AcquisitionResult, ActionResult, ExternalObjective, FileIntegrityProfile,
                           LoopCycleReceipt, MonitorResult, OutwardLoopEngine, ReplanResult,
                           VerificationResult, file_integrity_engine)

from .perpetual_runtime import (HandlerResult, ResidentRuntime, RuntimePolicy, ScheduledWork)
from .target_profile import (IdentityHypothesis as ProfileIdentityHypothesis, ProfileAssertion, TargetProfile)
from .transport_registry import (FileDropFIPTransport, InProcessFIPTransport, TransportCapability, TransportReceipt)
from .utility_accounting import (UtilityContract, UtilityReceipt, account_utility, binary_entropy, categorical_entropy)


__version__ = "0.18.0rc3"
__all__ = [
    "BASE", "Dim", "Interval", "UNITS", "unit",
    "BeliefReport", "BoundFactor", "ConflictReport", "DimensionalWall",
    "Evidence", "Field", "GroundingRequest", "NearestFeasible",
    "LinearFactor", "PowerFactor", "ProductFactor", "Provenance", "SettleReport",
    "SumFactor", "Variable", "ship_core",
    "BRIDGE_SPEC", "BridgeError", "BridgeProposal", "explain_for_bridge",
    "ingest", "propose", "report_test", "validate_spec",
    "Carving", "ConstraintProposal", "FieldSystem", "IdentityHypothesis",
    "KindRegistry", "Measurand", "Observation", "PlacementDecision",
    "QuantityKind", "Scope", "SourceReceipt", "metrology_seed",
    "HeterogeneousRouter", "RouteRecord",
    "CapabilityError", "CapabilityIssuer",
    "Event", "EventLog", "kernel_version",
    "CONTACT_DEFAULT_QUALITY", "CONTACT_TYPES", "GroundingLoop", "GroundingTest", "Measurement", "RealityHarness",
    "SourceLedger", "Verdict",
    "Commitment", "CommitmentIntegrityError", "CoverageReport",
    "allocate", "commit", "coverage", "resolve_commitment",

    "AbstractionNode", "DiscoveryArc", "EvidenceItem", "ExampleCase",
    "FunctionalDistinction", "MechanismHypothesis", "POSIWIDContract",
    "SaturationReport", "SearchQuery", "SystemHypothesis", "TestObligation",
    "ApplicabilityDecision", "ModelContract", "ModelRegistry", "ScopeCondition",
    "CatalogProvider", "CompositeProvider", "ContentStore", "CrossrefProvider", "LocalCorpusProvider",
    "NetworkUnavailable", "OpenAlexProvider", "SearchError", "SearchResult",
    "search_into_arc", "FacultyError", "FacultyReceipt", "OllamaFaculty",
    "OpenAICompatibleFaculty", "ProposalFaculty", "SubprocessFaculty",
    "ARC5Controller", "SearchEnvelope", "StageGate",
    "ARC5Kernel", "EligibilityContract", "SearchRequirement", "SearchTrackPlan",
    "ScreeningDecision", "EvidenceLineageProfile", "TransferCase",
    "MechanismCaseAssessment", "MechanismInference", "ApprovalRecord",
    "WorkItem", "FailureDiagnosis", "ArcAmendment",
    "ARC5Campaign", "CapabilityTarget", "TargetRun", "CapabilityDisposition", "CampaignApproval",
    "ARC5AAdversarialKernel", "HostileInterpretation", "LaneSearchRequirement", "LaneSearchPlan",
    "DecompositionPass", "DecompositionDisagreement", "AbstractionRegistration", "ArenaCandidate",
    "ParetoDimension", "ParetoAssessment", "AdversarialTestPair", "DecisionSaturationWave",
    "ContactRecord", "AdversarialApprovalRecord", "AdversarialWorkItem", "MutationResult",
    "OrganRegistry", "OrganSpec", "OrganTrace", "OrganUnavailable", "Claim",
    "RegisteredVerifier", "VerificationContract", "VerificationRegistry",
    "VerificationRequest", "VerificationResult", "core_contracts",
    "FieldInstrument", "PublicResult",
    "AssuranceRegistry", "CapabilityCase", "CapabilityObservation", "CapabilityRequirement",
    "ArgumentClaim", "ArgumentEvidence", "ArgumentGraph", "DialecticalReport", "ClaimRelation",
    "ActionReceipt", "ActionRegistry", "ActionSpec",
    "IntentInterpreter", "IntentProposal",
    "IRContract", "IRRegistry", "IRRequirement", "IRSelection", "core_irs",
    "MechanismPortfolio", "MechanismProfile", "PerformanceRecord", "Selection", "TaskShape",
    "ProcessMethod", "ProcessTaskProfile", "ProcessCandidate", "ProcessAssessment",
    "ProcessDecision", "ProcessPortfolio", "default_process_methods", "seeded_process_portfolio",
    "SubstrateCampaign", "SubstrateCandidate", "WorkloadContract", "BenchmarkCommitment",
    "BenchmarkObservation", "FormalContract", "RefinementRecord", "ExperimentAllocation",
    "CandidateAssessment", "LayerDecision", "MigrationSlice",
    "ValidationProtocol", "ArmCommitment", "EvaluatorAttestation", "ExternalReviewAttestation",
    "ChallengeCommitment", "ArmPrediction", "ChallengeOutcome", "MaintenanceEvent",
    "AnalysisResult", "LongitudinalValidationStudy",
    "ProvActivity", "ProvAgent", "ProvEntity", "ProvenanceGraph",
    "extract_repomix", "iter_repomix_files",
    "AnalogyAssessment", "AnalogyGate", "AnalogyHypothesis",
    "ARC5MethodBenchmark", "MethodBenchmarkReport", "RecoveryResult", "RecoveryTarget",
    "EcologyMember", "EcologyReport", "OrganEcology",
    "PresentationInput", "Presenter", "ResolutionReport",
    "AcquisitionEngine", "AcquisitionError", "ArtifactReceipt", "FetchPolicy",
    "ParsedArtifact", "ParseReceipt", "DeterministicQuantityExtractor",
    "ExtractionBundle", "ExtractionReceipt", "FacultyClaimExtractor",
    "GenericClaimCarving", "InquiryEngine", "InquiryReport", "InquiryRequest",
    "StageReceipt", "ArtifactRiskScanner", "RiskAssessment", "RiskFinding",
    "FileHashPredicate", "HTTPJSONMeasurement",
    "ContractObject", "ContractStore", "DependencyLink",
    "ComponentAttestation", "ComponentRegistry", "GoalDecision", "GoalGate", "GoalRequest",
    "CalibrationEvent", "CalibrationRegistry", "CalibrationReport",
    "CapabilityGraph", "CapabilityNode", "GateResult", "InterfaceNode",
    "DependencyEdge", "DependencyField", "Invalidation",
    "CausalClaim", "CausalModel", "CausalRegistry", "IdentificationResult",
    "CandidateTest", "ExperimentPlanner", "Hypothesis", "TestRanking",
    "ConceptVersion", "MappingHypothesis", "OntologyRegistry",
    "FederationBundle", "FederationLedger", "MergeConflict", "ObjectVersion",
    "TaskAction", "TaskReport", "TaskRequest", "TaskStage", "TaskVerification",
    "FrozenGatePlan", "GateDefinition", "GateOutcome",
    "DriftBaseline", "DriftMonitor", "DriftReport",
    "FIPError", "ProfileRegistry", "ProfileSpec", "canonical", "canonical_bytes",
    "canonical_sha256", "contract_to_fip", "graph_validate", "make_envelope",
    "parse_fip_json", "seal_fip", "validate_fip", "MasterRegistry", "RegistryIssue",
    "AcquisitionResult", "ActionResult", "ExternalObjective", "FileIntegrityProfile",
    "LoopCycleReceipt", "MonitorResult", "OutwardLoopEngine", "ReplanResult",
    "VerificationResult", "file_integrity_engine",
    "HandlerResult", "ResidentRuntime", "RuntimePolicy", "ScheduledWork",
    "ProfileIdentityHypothesis", "ProfileAssertion", "TargetProfile",
    "FileDropFIPTransport", "InProcessFIPTransport", "TransportCapability", "TransportReceipt",
    "UtilityContract", "UtilityReceipt", "account_utility", "binary_entropy", "categorical_entropy",
]