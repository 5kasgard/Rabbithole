"""Heterogeneous routing by task shape and epistemic authority.

This is intentionally small.  It does not pretend to optimize arbitrary work;
it makes the current real paths explicit and measurable:

* irregular placement and audit work -> Python/CPU;
* large regular constraint graphs -> packed native C when available;
* semantic interpretation -> proposer only;
* grounding -> registered external executor;
* unknown work -> refusal, not an invented route.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Callable, Optional

from .fast import available as native_available, settle_fast
from .field import Field, SettleReport


@dataclass
class RouteRecord:
    task: str
    mechanism: str
    substrate: str
    reason: str
    estimated_cost: float
    elapsed_ms: float = 0.0
    authority_effect: str = "none"


class HeterogeneousRouter:
    def __init__(self, native_factor_threshold: int = 10_000,
                 allow_approximate_native: bool = False):
        self.native_factor_threshold = int(native_factor_threshold)
        # The packed C engine is a throughput substrate.  It currently uses
        # ordinary binary64 operations rather than directed outward rounding,
        # so it is never selected by default for epistemically sound settling.
        # Callers must opt into the approximation explicitly.
        self.allow_approximate_native = bool(allow_approximate_native)
        self.history: list[RouteRecord] = []

    def settle(self, field: Field, need_event_trace: bool = False) -> tuple[SettleReport, RouteRecord]:
        n = len(field.factors)
        use_native = (self.allow_approximate_native and not need_event_trace
                      and n >= self.native_factor_threshold and native_available())
        if use_native:
            rec = RouteRecord("settle", "packed interval contractors", "native C/CPU",
                              (f"explicit approximate-native opt-in; regular graph with "
                               f"{n} factors exceeds threshold"),
                              estimated_cost=float(n), authority_effect="approximate pruning only")
            t0 = time.perf_counter()
            report = settle_fast(field)
        else:
            if need_event_trace:
                why = "per-factor trace requested"
            elif n >= self.native_factor_threshold and native_available() and not self.allow_approximate_native:
                why = ("sound mode: native C lacks directed outward rounding; "
                       "using Python interval oracle")
            else:
                why = f"irregular/small graph ({n} factors) below native threshold"
            rec = RouteRecord("settle", "object interval contractors", "Python/CPU",
                              why, estimated_cost=float(n), authority_effect="prunes only")
            t0 = time.perf_counter()
            report = field.settle()
        rec.elapsed_ms = (time.perf_counter() - t0) * 1000.0
        self.history.append(rec)
        return report, rec

    def proposal(self, kind: str = "semantic") -> RouteRecord:
        rec = RouteRecord("proposal", f"{kind} candidate generator", "LLM/GPU or local model",
                          "dense translation is useful here but has zero authority",
                          estimated_cost=5.0, authority_effect="zero until gated")
        self.history.append(rec)
        return rec

    def deterministic_gate(self, gate: str) -> RouteRecord:
        rec = RouteRecord("gate", gate, "CPU",
                          "cheap locally checkable invariant before richer reasoning",
                          estimated_cost=0.1, authority_effect="veto only")
        self.history.append(rec)
        return rec

    def external_contact(self, executor_kind: str, estimated_cost: float = 10.0) -> RouteRecord:
        rec = RouteRecord("ground", executor_kind, "registered external executor",
                          "only reality contact can move epistemic authority",
                          estimated_cost=float(estimated_cost), authority_effect="may move authority")
        self.history.append(rec)
        return rec

    def refuse(self, task: str, reason: str) -> RouteRecord:
        rec = RouteRecord(task, "refuse", "none", reason, 0.0, authority_effect="none")
        self.history.append(rec)
        return rec

    def efficiency(self) -> list[dict]:
        return [{"task": r.task, "mechanism": r.mechanism, "substrate": r.substrate,
                 "estimated_cost": r.estimated_cost, "elapsed_ms": r.elapsed_ms,
                 "authority_effect": r.authority_effect}
                for r in self.history]
