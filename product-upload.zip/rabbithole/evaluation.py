"""Evaluator boundary and anti-contamination commitments.

The builder can prepare a committed release and a one-time challenge-import
protocol.  It cannot prove that an evaluator or challenge is independent.  The
module therefore never emits a passed external-validation gate on its own.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, Mapping, Optional, Sequence, Tuple

from .wal import EventLog


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def tree_manifest(root: Path, *, exclude: Sequence[str] = ()) -> tuple[str, tuple[dict, ...]]:
    rows = []
    excluded = tuple(exclude)
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        rel = path.relative_to(root).as_posix()
        if any(rel == x or rel.startswith(x.rstrip("/") + "/") for x in excluded):
            continue
        rows.append({"path": rel, "sha256": _sha(path), "size": path.stat().st_size})
    body = json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(body).hexdigest(), tuple(rows)


@dataclass
class BuildCommitment:
    release_version: str
    tree_digest: str
    files: Tuple[Mapping[str, object], ...]
    gate_plan_digest: str
    campaign_digest: str
    actor: str
    exclusions: Tuple[str, ...]
    created_at: float = field(default_factory=time.time)
    commitment_id: str = field(default_factory=lambda: _id("BLD"))


@dataclass
class ChallengeImport:
    commitment_id: str
    evaluator_id: str
    token_digest: str
    challenge_digest: str
    payload_path: str
    seed_commitment: str
    metadata: Mapping[str, object] = field(default_factory=dict)
    imported_at: float = field(default_factory=time.time)
    consumed_at: float = 0.0
    result_digest: str = ""
    cid: str = field(default_factory=lambda: _id("CHL"))

    @property
    def consumed(self) -> bool:
        return self.consumed_at > 0


class EvaluatorBoundary:
    def __init__(self, root: str | os.PathLike[str]):
        self.root = Path(root)
        self.payloads = self.root / "challenges"
        self.payloads.mkdir(parents=True, exist_ok=True)
        self.commitments: Dict[str, BuildCommitment] = {}
        self.challenges: Dict[str, ChallengeImport] = {}
        self.used_tokens: set[str] = set()
        self.audit = EventLog()

    @staticmethod
    def _token_digest(token: str) -> str:
        if not token:
            raise ValueError("one-time token is required")
        return hashlib.sha256(token.encode()).hexdigest()

    def commit(self, release_root: str | os.PathLike[str], *, release_version: str,
               gate_plan: str | os.PathLike[str] = "", campaign: str | os.PathLike[str] = "",
               actor: str, exclusions: Sequence[str] = (".git", "__pycache__", ".pytest_cache")) -> BuildCommitment:
        root = Path(release_root).resolve()
        digest, rows = tree_manifest(root, exclude=exclusions)
        gp = _sha(Path(gate_plan)) if gate_plan and Path(gate_plan).exists() else ""
        cp = _sha(Path(campaign)) if campaign and Path(campaign).exists() else ""
        commitment = BuildCommitment(release_version, digest, rows, gp, cp, actor,
                                     tuple(exclusions))
        self.commitments[commitment.commitment_id] = commitment
        self.audit.append("build_committed", asdict(commitment))
        return commitment

    def verify_commitment(self, commitment_id: str, release_root: str | os.PathLike[str]) -> dict:
        c = self.commitments[commitment_id]
        digest, rows = tree_manifest(Path(release_root).resolve(), exclude=c.exclusions)
        current = {str(x["path"]): str(x["sha256"]) for x in rows}
        expected = {str(x["path"]): str(x["sha256"]) for x in c.files}
        changed = sorted(k for k in set(current) | set(expected) if current.get(k) != expected.get(k))
        return {"valid": digest == c.tree_digest, "expected": c.tree_digest,
                "actual": digest, "changed_files": changed}

    def import_challenge(self, commitment_id: str, payload: bytes, *, evaluator_id: str,
                         one_time_token: str, seed_commitment: str,
                         metadata: Optional[Mapping[str, object]] = None) -> ChallengeImport:
        if commitment_id not in self.commitments:
            raise KeyError(commitment_id)
        td = self._token_digest(one_time_token)
        if td in self.used_tokens:
            raise ValueError("one-time challenge token has already been used")
        digest = hashlib.sha256(payload).hexdigest()
        path = self.payloads / digest
        if path.exists() and path.read_bytes() != payload:
            raise RuntimeError("challenge digest collision")
        if not path.exists():
            tmp = path.with_suffix(".tmp"); tmp.write_bytes(payload); os.replace(tmp, path)
        challenge = ChallengeImport(commitment_id, evaluator_id, td, digest, str(path),
                                    seed_commitment, dict(metadata or {}))
        self.used_tokens.add(td)
        self.challenges[challenge.cid] = challenge
        self.audit.append("challenge_imported", asdict(challenge))
        return challenge

    def consume(self, challenge_id: str, one_time_token: str) -> bytes:
        challenge = self.challenges[challenge_id]
        if challenge.consumed:
            raise ValueError("challenge has already been consumed")
        if self._token_digest(one_time_token) != challenge.token_digest:
            raise PermissionError("challenge token mismatch")
        data = Path(challenge.payload_path).read_bytes()
        if hashlib.sha256(data).hexdigest() != challenge.challenge_digest:
            raise RuntimeError("challenge payload digest mismatch")
        challenge.consumed_at = time.time()
        self.audit.append("challenge_consumed", {"challenge_id": challenge_id,
                                                   "commitment_id": challenge.commitment_id})
        return data

    def record_result(self, challenge_id: str, result: bytes) -> str:
        challenge = self.challenges[challenge_id]
        if not challenge.consumed:
            raise ValueError("challenge must be consumed before result recording")
        digest = hashlib.sha256(result).hexdigest()
        challenge.result_digest = digest
        self.audit.append("challenge_result_recorded", {"challenge_id": challenge_id,
                                                         "result_digest": digest})
        return digest

    def status(self, commitment_id: str = "") -> dict:
        cs = [c for c in self.commitments.values() if not commitment_id or c.commitment_id == commitment_id]
        rows = []
        for c in cs:
            linked = [x for x in self.challenges.values() if x.commitment_id == c.commitment_id]
            rows.append({"commitment": asdict(c), "challenges": [asdict(x) for x in linked],
                         "external_gate_state": "independent_contact_required"})
        return {"commitments": rows, "audit_valid": self.audit.verify().get("valid", False),
                "self_certifies_unseen": False}

    def verify(self) -> dict:
        invalid = []
        for ch in self.challenges.values():
            path = Path(ch.payload_path)
            if not path.exists() or _sha(path) != ch.challenge_digest:
                invalid.append(ch.cid)
        return {"valid": not invalid and self.audit.verify().get("valid", False),
                "invalid_challenges": invalid, "commitments": len(self.commitments),
                "challenges": len(self.challenges)}

    def to_dict(self) -> dict:
        return {"commitments": [asdict(x) for x in self.commitments.values()],
                "challenges": [asdict(x) for x in self.challenges.values()],
                "used_tokens": sorted(self.used_tokens), "audit": self.audit.to_dict()}

    @classmethod
    def from_dict(cls, root: str | os.PathLike[str], raw: Mapping[str, object]) -> "EvaluatorBoundary":
        obj = cls(root)
        for row in raw.get("commitments", []):
            d = dict(row); d["files"] = tuple(d.get("files", ())); d["exclusions"] = tuple(d.get("exclusions", ()))
            c = BuildCommitment(**d); obj.commitments[c.commitment_id] = c
        for row in raw.get("challenges", []):
            ch = ChallengeImport(**dict(row)); obj.challenges[ch.cid] = ch
        obj.used_tokens = set(raw.get("used_tokens", ()))
        obj.audit = EventLog.from_dict(raw.get("audit", {}))
        return obj
