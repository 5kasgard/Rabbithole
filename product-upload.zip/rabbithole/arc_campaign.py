"""Campaign-level queue for applying ARC-5 across many capability gaps.

Stage 4A made one discovery arc persistent and human-gated.  Stage 4B needs an
additional layer that can coordinate many independent arcs without collapsing
or silently prioritising them.  This module keeps the target set immutable,
records dependencies and dispositions, and preserves the human gate before a
campaign may be consumed by a reconstruction stage.

The campaign does not decide truth.  It only records which ARC-5 process was
applied to each target, what survived, what kind of contact remains, and which
later work depends on that result.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

from .wal import EventLog


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:14]}"


def _canon(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, default=str).encode("utf-8")


def _digest(value: object) -> str:
    return hashlib.sha256(_canon(value)).hexdigest()


TARGET_STATES = {
    "queued", "active", "research_complete", "ready_for_contact",
    "requires_external_contact", "ready_for_reconstruction", "rejected",
    "superseded", "complete",
}
DECISION_CLASSES = {
    "internal_mechanism", "external_infrastructure", "external_validation",
    "narrow_claim", "retain_current", "remove_capability", "merge_capability",
}
CAMPAIGN_STATES = {"draft", "frozen", "active", "awaiting_human", "approved", "reopened"}


@dataclass(frozen=True)
class CapabilityTarget:
    target_id: str
    gate_id: str
    name: str
    prior_status: str
    criterion: str
    observed: str
    local_current: Tuple[str, ...]
    local_goal: Tuple[str, ...]
    whole_current: Tuple[str, ...]
    whole_goal: Tuple[str, ...]
    constraints: Tuple[str, ...] = ()
    anti_goals: Tuple[str, ...] = ()
    dependencies: Tuple[str, ...] = ()
    priority: float = 1.0
    risk: float = 0.0
    created_at: float = field(default_factory=time.time)

    def validate(self) -> None:
        if not self.target_id or not self.gate_id or not self.name.strip():
            raise ValueError("campaign target requires ids and name")
        if not self.local_goal or not self.whole_goal:
            raise ValueError("campaign target requires local and whole goals")
        if self.priority < 0 or self.risk < 0:
            raise ValueError("priority and risk must be non-negative")
        if self.target_id in self.dependencies:
            raise ValueError("target cannot depend on itself")


@dataclass
class TargetRun:
    target_id: str
    arc_id: str = ""
    arc_path: str = ""
    arc_digest: str = ""
    state: str = "queued"
    wave: int = -1
    blockers: Tuple[str, ...] = ()
    updated_at: float = field(default_factory=time.time)

    def validate(self) -> None:
        if self.state not in TARGET_STATES:
            raise ValueError(f"invalid target state {self.state!r}")
        if self.wave < -1:
            raise ValueError("campaign wave cannot be less than -1")


@dataclass(frozen=True)
class CapabilityDisposition:
    target_id: str
    decision_class: str
    surviving_mechanisms: Tuple[str, ...]
    rejected_mechanisms: Tuple[str, ...]
    rationale: str
    stage4c_action: str
    decisive_contact: str
    external_dependencies: Tuple[str, ...] = ()
    evidence_ids: Tuple[str, ...] = ()
    risk_if_wrong: Tuple[str, ...] = ()
    confidence_scope: str = ""
    actor: str = ""
    created_at: float = field(default_factory=time.time)
    disposition_id: str = field(default_factory=lambda: _id("DSP"))

    def validate(self) -> None:
        if self.decision_class not in DECISION_CLASSES:
            raise ValueError("invalid campaign decision class")
        if not self.rationale.strip() or not self.stage4c_action.strip():
            raise ValueError("disposition requires rationale and later action")
        if not self.decisive_contact.strip():
            raise ValueError("disposition requires a decisive contact")
        if not self.actor.strip():
            raise ValueError("disposition requires accountable actor")


@dataclass(frozen=True)
class CampaignApproval:
    decision: str
    actor: str
    rationale: str
    material_digest: str
    created_at: float = field(default_factory=time.time)
    approval_id: str = field(default_factory=lambda: _id("CAP"))

    def validate(self) -> None:
        if self.decision not in {"approve", "hold", "reopen", "reject"}:
            raise ValueError("invalid campaign approval")
        if not self.actor.strip() or not self.rationale.strip():
            raise ValueError("campaign approval requires actor and rationale")


class ARC5Campaign:
    """Immutable target plan plus mutable, auditable multi-arc queue."""

    def __init__(self, name: str, goal: str, *, campaign_id: str = ""):
        if not name.strip() or not goal.strip():
            raise ValueError("campaign requires name and goal")
        self.campaign_id = campaign_id or _id("CMP")
        self.name = name
        self.goal = goal
        self.state = "draft"
        self.targets: Dict[str, CapabilityTarget] = {}
        self.runs: Dict[str, TargetRun] = {}
        self.dispositions: Dict[str, CapabilityDisposition] = {}
        self.approvals: List[CampaignApproval] = []
        self.target_plan_digest = ""
        self.target_plan_frozen_at = 0.0
        self.target_plan_frozen_by = ""
        self._base_dir: Path | None = None
        self.audit = EventLog()
        self.audit.append("campaign_created", {
            "campaign_id": self.campaign_id, "name": name, "goal": goal,
        })

    @property
    def frozen(self) -> bool:
        return bool(self.target_plan_digest)

    def add_target(self, target: CapabilityTarget) -> str:
        if self.frozen:
            raise RuntimeError("campaign target plan is frozen")
        target.validate()
        if target.target_id in self.targets:
            raise ValueError("duplicate campaign target")
        self.targets[target.target_id] = target
        self.runs[target.target_id] = TargetRun(target.target_id)
        self.audit.append("campaign_target_added", asdict(target))
        return target.target_id

    def target_material(self) -> list[dict]:
        return [asdict(self.targets[k]) for k in sorted(self.targets)]

    def freeze_targets(self, actor: str) -> str:
        if self.frozen:
            if not self.verify_target_plan():
                raise RuntimeError("frozen campaign target plan was mutated")
            return self.target_plan_digest
        if not actor.strip():
            raise ValueError("freezing campaign requires actor")
        if not self.targets:
            raise ValueError("cannot freeze empty campaign")
        self._validate_dependencies()
        self.target_plan_digest = _digest(self.target_material())
        self.target_plan_frozen_at = time.time()
        self.target_plan_frozen_by = actor
        self.state = "frozen"
        waves = self.dependency_waves()
        for wave, ids in enumerate(waves):
            for target_id in ids:
                run = self.runs[target_id]
                run.wave = wave
                run.blockers = self.targets[target_id].dependencies
        self.audit.append("campaign_targets_frozen", {
            "digest": self.target_plan_digest, "actor": actor,
            "waves": waves,
        })
        return self.target_plan_digest

    def verify_target_plan(self) -> bool:
        return bool(self.target_plan_digest) and _digest(self.target_material()) == self.target_plan_digest

    def _validate_dependencies(self) -> None:
        missing = sorted({dep for t in self.targets.values() for dep in t.dependencies
                          if dep not in self.targets})
        if missing:
            raise ValueError("unknown campaign dependencies: " + ", ".join(missing))
        self.dependency_waves()  # cycle check

    def dependency_waves(self) -> Tuple[Tuple[str, ...], ...]:
        remaining = set(self.targets)
        done: set[str] = set()
        waves: List[Tuple[str, ...]] = []
        while remaining:
            ready = sorted(tid for tid in remaining
                           if set(self.targets[tid].dependencies).issubset(done))
            if not ready:
                raise ValueError("campaign dependency graph contains a cycle")
            waves.append(tuple(ready))
            done.update(ready)
            remaining.difference_update(ready)
        return tuple(waves)

    def _resolve_arc_path(self, path: str | Path) -> Path:
        p = Path(path)
        if p.is_absolute() or self._base_dir is None:
            return p
        return (self._base_dir / p).resolve()

    def attach_arc(self, target_id: str, arc_id: str, path: str | Path) -> None:
        if not self.verify_target_plan():
            raise RuntimeError("freeze and verify campaign plan first")
        if target_id not in self.targets:
            raise KeyError(target_id)
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(p)
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        run = self.runs[target_id]
        run.arc_id = arc_id
        run.arc_path = str(p)
        run.arc_digest = digest
        run.state = "research_complete"
        run.updated_at = time.time()
        self.state = "active"
        self.audit.append("campaign_arc_attached", {
            "target_id": target_id, "arc_id": arc_id,
            "arc_path": str(p), "arc_digest": digest,
        })

    def set_run_state(self, target_id: str, state: str, *, blockers: Sequence[str] = ()) -> None:
        if state not in TARGET_STATES:
            raise ValueError("invalid target state")
        run = self.runs[target_id]
        run.state = state
        run.blockers = tuple(blockers)
        run.updated_at = time.time()
        self.audit.append("campaign_target_state", {
            "target_id": target_id, "state": state, "blockers": list(blockers),
        })

    def record_disposition(self, disposition: CapabilityDisposition) -> str:
        disposition.validate()
        if disposition.target_id not in self.targets:
            raise KeyError(disposition.target_id)
        self.dispositions[disposition.target_id] = disposition
        run = self.runs[disposition.target_id]
        if disposition.decision_class in {"external_infrastructure", "external_validation"}:
            run.state = "requires_external_contact"
        elif disposition.decision_class in {"remove_capability", "narrow_claim"}:
            run.state = "ready_for_reconstruction"
        else:
            run.state = "ready_for_reconstruction"
        run.updated_at = time.time()
        self.audit.append("campaign_disposition_recorded", asdict(disposition))
        return disposition.disposition_id

    def material(self) -> dict:
        return {
            "campaign_id": self.campaign_id,
            "name": self.name,
            "goal": self.goal,
            "target_plan_digest": self.target_plan_digest,
            "targets": self.target_material(),
            "runs": [asdict(self.runs[k]) for k in sorted(self.runs)],
            "dispositions": [asdict(self.dispositions[k]) for k in sorted(self.dispositions)],
        }

    def approve(self, decision: str, actor: str, rationale: str) -> CampaignApproval:
        if len(self.dispositions) != len(self.targets) and decision == "approve":
            raise RuntimeError("cannot approve campaign before every target has a disposition")
        if not self.verify().get("valid", False) and decision == "approve":
            raise RuntimeError("cannot approve invalid campaign")
        record = CampaignApproval(decision, actor, rationale, _digest(self.material()))
        record.validate()
        self.approvals.append(record)
        if decision == "approve":
            self.state = "approved"
        elif decision == "reopen":
            self.state = "reopened"
        elif decision in {"hold", "reject"}:
            self.state = "awaiting_human"
        self.audit.append("campaign_approval", asdict(record))
        return record

    def verify(self) -> dict:
        errors: List[str] = []
        if not self.verify_target_plan():
            errors.append("campaign target plan is not frozen or was mutated")
        try:
            self._validate_dependencies()
        except Exception as exc:
            errors.append(f"dependency graph: {exc}")
        for tid, run in self.runs.items():
            try:
                run.validate()
            except Exception as exc:
                errors.append(f"run {tid}: {exc}")
            if run.arc_path:
                p = self._resolve_arc_path(run.arc_path)
                if not p.exists():
                    errors.append(f"run {tid}: missing arc file")
                elif hashlib.sha256(p.read_bytes()).hexdigest() != run.arc_digest:
                    errors.append(f"run {tid}: arc digest mismatch")
        for tid, disposition in self.dispositions.items():
            try:
                disposition.validate()
            except Exception as exc:
                errors.append(f"disposition {tid}: {exc}")
        audit = self.audit.verify()
        if not audit.get("valid", False):
            errors.append("campaign audit invalid")
        return {
            "valid": not errors,
            "errors": errors,
            "targets": len(self.targets),
            "attached_arcs": sum(bool(x.arc_id) for x in self.runs.values()),
            "dispositions": len(self.dispositions),
            "state": self.state,
            "waves": self.dependency_waves() if self.targets else (),
            "audit": audit,
        }

    def status(self) -> dict:
        counts: Dict[str, int] = {}
        for run in self.runs.values():
            counts[run.state] = counts.get(run.state, 0) + 1
        next_targets = []
        for wave in self.dependency_waves() if self.targets else ():
            rows = [tid for tid in wave if self.runs[tid].state not in {"complete", "superseded"}]
            if rows:
                next_targets = rows
                break
        return {
            "campaign_id": self.campaign_id,
            "name": self.name,
            "goal": self.goal,
            "state": self.state,
            "frozen": self.verify_target_plan(),
            "counts": counts,
            "next_targets": next_targets,
            "targets": {
                tid: {
                    "gate_id": self.targets[tid].gate_id,
                    "name": self.targets[tid].name,
                    "wave": self.runs[tid].wave,
                    "state": self.runs[tid].state,
                    "blockers": self.runs[tid].blockers,
                    "arc_id": self.runs[tid].arc_id,
                    "decision_class": self.dispositions[tid].decision_class if tid in self.dispositions else "",
                    "stage4c_action": self.dispositions[tid].stage4c_action if tid in self.dispositions else "",
                }
                for tid in sorted(self.targets)
            },
            "integrity": self.verify(),
        }

    def to_dict(self) -> dict:
        return {
            "campaign_id": self.campaign_id,
            "name": self.name,
            "goal": self.goal,
            "state": self.state,
            "targets": {k: asdict(v) for k, v in self.targets.items()},
            "runs": {k: asdict(v) for k, v in self.runs.items()},
            "dispositions": {k: asdict(v) for k, v in self.dispositions.items()},
            "approvals": [asdict(x) for x in self.approvals],
            "target_plan_digest": self.target_plan_digest,
            "target_plan_frozen_at": self.target_plan_frozen_at,
            "target_plan_frozen_by": self.target_plan_frozen_by,
            "audit": self.audit.to_dict(),
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "ARC5Campaign":
        obj = cls(str(raw["name"]), str(raw["goal"]), campaign_id=str(raw["campaign_id"]))
        obj.state = str(raw.get("state", "draft"))
        obj.targets = {}
        for key, value in dict(raw.get("targets", {})).items():
            row = dict(value)
            for field_name in ("local_current", "local_goal", "whole_current", "whole_goal",
                               "constraints", "anti_goals", "dependencies"):
                row[field_name] = tuple(row.get(field_name, ()))
            obj.targets[str(key)] = CapabilityTarget(**row)
        obj.runs = {str(k): TargetRun(**dict(v)) for k, v in dict(raw.get("runs", {})).items()}
        obj.dispositions = {}
        for key, value in dict(raw.get("dispositions", {})).items():
            row = dict(value)
            for field_name in ("surviving_mechanisms", "rejected_mechanisms", "external_dependencies",
                               "evidence_ids", "risk_if_wrong"):
                row[field_name] = tuple(row.get(field_name, ()))
            obj.dispositions[str(key)] = CapabilityDisposition(**row)
        obj.approvals = [CampaignApproval(**dict(x)) for x in raw.get("approvals", [])]
        obj.target_plan_digest = str(raw.get("target_plan_digest", ""))
        obj.target_plan_frozen_at = float(raw.get("target_plan_frozen_at", 0.0))
        obj.target_plan_frozen_by = str(raw.get("target_plan_frozen_by", ""))
        obj.audit = EventLog.from_dict(raw.get("audit", {}))
        return obj

    def save(self, path: str | Path) -> None:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        base = p.parent.resolve()
        # Rebase every attached arc to the campaign file. This keeps campaign
        # verification portable after an archive is extracted elsewhere.
        for run in self.runs.values():
            if run.arc_path:
                resolved = self._resolve_arc_path(run.arc_path).resolve()
                run.arc_path = os.path.relpath(resolved, base)
        self._base_dir = base
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True, default=str))
        tmp.replace(p)

    @classmethod
    def load(cls, path: str | Path) -> "ARC5Campaign":
        p = Path(path)
        obj = cls.from_dict(json.loads(p.read_text()))
        obj._base_dir = p.parent.resolve()
        return obj
