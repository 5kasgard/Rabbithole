"""Empirical calibration for verifiers, extractors, routes, and specialists.

Calibration is context-specific evidence about future performance.  It caps a
configured mechanism; it never establishes an individual claim merely because a
source or verifier performed well historically.
"""
from __future__ import annotations

import math
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Sequence, Tuple


def _id() -> str:
    return f"CAL{uuid.uuid4().hex[:12]}"


@dataclass
class CalibrationEvent:
    actor: str
    task_family: str
    predicted: float
    outcome: float
    cost: float = 0.0
    latency: float = 0.0
    independence_group: str = ""
    context: Mapping[str, object] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    eid: str = field(default_factory=_id)

    def __post_init__(self) -> None:
        if not 0 <= self.predicted <= 1 or not 0 <= self.outcome <= 1:
            raise ValueError("predicted and outcome must be in [0,1]")
        if self.cost < 0 or self.latency < 0:
            raise ValueError("cost and latency cannot be negative")
        if not self.actor or not self.task_family:
            raise ValueError("actor and task family are required")


@dataclass
class CalibrationReport:
    actor: str
    task_family: str
    n: int
    independent_groups: int
    brier: float
    log_loss: float
    mean_prediction: float
    empirical_rate: float
    calibration_gap: float
    wilson_lower: float
    authority_cap: float
    state: str


class CalibrationRegistry:
    def __init__(self):
        self.events: Dict[str, CalibrationEvent] = {}

    def record(self, event: CalibrationEvent) -> str:
        if event.eid in self.events:
            raise ValueError("calibration event already exists")
        self.events[event.eid] = event
        return event.eid

    def report(self, actor: str, task_family: str = "*", *,
               minimum_groups: int = 3) -> CalibrationReport:
        xs = [e for e in self.events.values()
              if e.actor == actor and (task_family == "*" or e.task_family == task_family)]
        if not xs:
            return CalibrationReport(actor, task_family, 0, 0, 1.0, float("inf"),
                                     0.0, 0.0, 1.0, 0.0, 0.0, "uncalibrated")
        n = len(xs)
        groups = len({e.independence_group or e.eid for e in xs})
        brier = sum((e.predicted - e.outcome) ** 2 for e in xs) / n
        eps = 1e-12
        log_loss = -sum(e.outcome * math.log(max(eps, e.predicted)) +
                        (1 - e.outcome) * math.log(max(eps, 1 - e.predicted)) for e in xs) / n
        mean_prediction = sum(e.predicted for e in xs) / n
        empirical_rate = sum(e.outcome for e in xs) / n
        gap = abs(mean_prediction - empirical_rate)
        m = max(1, groups)
        z = 1.96
        denom = 1 + z * z / m
        centre = empirical_rate + z * z / (2 * m)
        radius = z * math.sqrt(empirical_rate * (1 - empirical_rate) / m + z * z / (4 * m * m))
        lower = max(0.0, (centre - radius) / denom)
        # Calibration caps configured contact quality; it is not a source of claim evidence.
        cap = min(lower, max(0.0, 1.0 - brier), max(0.0, 1.0 - gap)) if groups >= minimum_groups else 0.0
        state = "calibrated" if groups >= minimum_groups else "insufficient_independent_outcomes"
        return CalibrationReport(actor, task_family, n, groups, brier, log_loss,
                                 mean_prediction, empirical_rate, gap, lower, cap, state)

    def to_dict(self) -> dict:
        return {"events": [asdict(e) for e in self.events.values()]}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "CalibrationRegistry":
        obj = cls()
        for row in raw.get("events", []):
            obj.record(CalibrationEvent(**dict(row)))
        return obj
