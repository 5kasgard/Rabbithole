"""RabbitHole tether — the reality-contact organ.

Ported from the precursor's gated design (Change 1 + Change 3), adapted to
the interval substrate. Three roles, strictly separated:

  PROPOSER   (untrusted; may be an LLM): emits a GroundingTest — a
             machine-checkable SPEC. A proposer that returns a verdict
             ("PASS", True, ...) instead of a test grounds NOTHING.
  HARNESS    (trusted; small; auditable): runs ONLY registered executor
             kinds. Shell is opt-in. Unknown kinds are refused. An
             erroring test is UNTESTABLE — never a forged failure.
  LOOP       (the tether): dispatch -> verdict -> record. The ONLY path
             by which evidence becomes tested and authority moves. Every
             contact is appended to the field's WAL.

Contact taxonomy (D3): every verdict carries how reality was touched —
  direct | instrument | derived | model | human
An executor's contact type is fixed at registration; a test cannot claim
a stronger contact than its executor provides.

Self-authorship: a GroundingTest records its author. A source that
authors the predicates that grade its own claims is not blocked — it is
COUNTED, and the ledger makes the rate visible ("a source that authors
its own predicates grades its own homework" — the precursor's second
contact-produced requirement).

SourceLedger: trust is READ OFF how a source's claims survive contact —
never assigned, never inferred from fluency. pass/fail move belief;
untestable moves nothing but is counted (a fluent, ungroundable source
shows a high unfalsifiability rate without being punished as false).
Optional decay of trust EVIDENCE preserves direction: a stale fail
fades; a repeated fail does not; silence grows uncertainty, never
distrust.
"""

from __future__ import annotations

import math
import subprocess
import time
from collections import defaultdict
from dataclasses import dataclass, field as dc_field
from typing import Callable, Dict, List, Optional

from .capabilities import CapabilityIssuer

from .field import Field, GroundingRequest
from .core import UNITS, unit as unit_lookup

CONTACT_TYPES = ("direct", "instrument", "secondary", "derived", "model", "human")
CONTACT_DEFAULT_QUALITY = {
    "direct": 1.0, "instrument": 1.0, "secondary": 0.75,
    "derived": 0.60, "human": 0.50, "model": 0.25,
}


@dataclass
class GroundingTest:
    """The only currency a proposer may emit: a machine-checkable spec.
    kind: which registered executor runs it. spec: what it needs.
    author: who wrote the test (self-authorship is tracked, not hidden)."""
    kind: str
    spec: object = None
    author: str = "unknown"
    capability: Optional[dict] = None


@dataclass(frozen=True)
class Measurement:
    value: float
    sigma: float
    unit: str = ""


@dataclass
class Verdict:
    result: str            # 'pass' | 'fail' | 'untestable'
    contact: str           # contact type of the executor that ran it
    kind: str
    author: str
    value: Optional[float] = None    # measurement executors return a value
    sigma: Optional[float] = None
    reason: str = ""
    unit: str = ""
    quality: float = 0.0


class RealityHarness:
    """The verifier. Executes GroundingTests through REGISTERED executors
    only, and renders the only verdicts the system honors.

      - unknown test kinds are refused (no executor -> untestable)
      - shell execution is opt-in (allow_shell=False by default)
      - an executor that raises yields 'untestable', never 'fail' — a
        broken test is an absence of contact, not evidence against a claim
      - executors may return: bool (pass/fail), or (value, sigma) for a
        measurement, or None (untestable)
    """

    def __init__(self, predicates: Optional[Dict[str, Callable]] = None,
                 allow_shell: bool = False, shell_timeout: float = 15.0,
                 capability_issuer: Optional[CapabilityIssuer] = None,
                 require_capabilities: bool = False):
        self.predicates = dict(predicates or {})
        self.allow_shell = bool(allow_shell)
        self.shell_timeout = float(shell_timeout)
        self._executors: Dict[str, Callable] = {}
        self._contacts: Dict[str, str] = {}
        self._resources: Dict[str, str] = {}
        self._qualities: Dict[str, float] = {}
        self.capability_issuer = capability_issuer
        self.require_capabilities = bool(require_capabilities)
        # Generic in-process predicates are derived checks, not instruments.
        # Deployments should register domain-specific executors with the
        # contact type and calibration they can actually justify.
        self.register("predicate", self._run_predicate, contact="derived")
        self.register("equals", self._run_equals, contact="derived")
        self.register("measure", self._run_measure, contact="instrument")
        self.register("shell", self._run_shell, contact="derived")

    def register(self, kind: str, executor: Callable,
                 contact: str = "instrument",
                 capability_resource: Optional[str] = None,
                 epistemic_weight: Optional[float] = None) -> None:
        """Registration is the ONLY way a new test kind becomes runnable —
        the explicit trust boundary. The contact type is fixed here; a test
        cannot claim a stronger contact than its executor provides."""
        if contact not in CONTACT_TYPES:
            raise ValueError(f"unknown contact type '{contact}'")
        self._executors[str(kind)] = executor
        self._contacts[str(kind)] = contact
        self._resources[str(kind)] = capability_resource or f"executor:{kind}"
        q = CONTACT_DEFAULT_QUALITY[contact] if epistemic_weight is None else float(epistemic_weight)
        if not math.isfinite(q) or not (0.0 <= q <= 1.0):
            raise ValueError("epistemic_weight must be in [0,1]")
        self._qualities[str(kind)] = q

    # -- built-in executors ---------------------------------------------------
    def _run_predicate(self, spec):
        return bool(self.predicates[spec]())          # KeyError -> untestable

    def _run_equals(self, spec):
        return self.predicates[spec["compute"]]() == spec["expected"]

    def _run_measure(self, spec):
        """spec names a predicate returning Measurement, (value,sigma), or
        (value,sigma,unit). Unitless tuples inherit the target contract."""
        return self.predicates[spec]()

    def _run_shell(self, spec):
        if not self.allow_shell:
            raise PermissionError("shell tests are disabled (allow_shell=False)")
        r = subprocess.run(spec, shell=True, capture_output=True,
                           timeout=self.shell_timeout)
        return r.returncode == 0

    # -- the verdict ------------------------------------------------------------
    def run(self, test) -> Verdict:
        # PROPOSER ASYMMETRY (T2): only a GroundingTest is currency. A bare
        # verdict — "PASS", True, a fluent paragraph — grounds nothing.
        if not isinstance(test, GroundingTest):
            return Verdict("untestable", "model", "none", "unknown",
                           reason="proposer emitted a verdict, not a test")
        ex = self._executors.get(test.kind)
        contact = self._contacts.get(test.kind, "model")
        quality = self._qualities.get(test.kind, 0.0)
        if ex is None:
            return Verdict("untestable", contact, test.kind, test.author,
                           reason=f"no registered executor for kind '{test.kind}'")
        if self.require_capabilities:
            if self.capability_issuer is None:
                return Verdict("untestable", contact, test.kind, test.author,
                               reason="capability enforcement enabled without an issuer")
            resource = self._resources[test.kind]
            if not self.capability_issuer.check(test.capability, "execute", resource,
                                                holder=test.author):
                return Verdict("untestable", contact, test.kind, test.author,
                               reason=f"missing, invalid, revoked, or out-of-scope capability for {resource}")
        try:
            out = ex(test.spec)
        except Exception as e:                        # broken test != failed claim
            return Verdict("untestable", contact, test.kind, test.author,
                           reason=f"executor error: {type(e).__name__}: {e}")
        if isinstance(out, Measurement):
            measurement = out
        elif isinstance(out, tuple) and len(out) in (2, 3):
            measurement = Measurement(float(out[0]), float(out[1]),
                                      str(out[2]) if len(out) == 3 else "")
        else:
            measurement = None
        if measurement is not None:
            if (not math.isfinite(measurement.value) or
                    not math.isfinite(measurement.sigma) or measurement.sigma <= 0):
                return Verdict("untestable", contact, test.kind, test.author,
                               reason="measurement must have finite value and sigma > 0")
            if measurement.unit and measurement.unit not in UNITS:
                return Verdict("untestable", contact, test.kind, test.author,
                               reason=f"measurement returned unknown unit {measurement.unit!r}")
            return Verdict("pass", contact, test.kind, test.author,
                           value=measurement.value, sigma=measurement.sigma,
                           reason="measurement", unit=measurement.unit, quality=quality)
        if out is None:
            return Verdict("untestable", contact, test.kind, test.author,
                           reason="executor returned no contact")
        return Verdict("pass" if bool(out) else "fail", contact,
                       test.kind, test.author, quality=quality)


class SourceLedger:
    """Per-source survival bookkeeping across contacts. Trust is read off
    outcomes; reputation = 1 - disbelief under subjective logic (W=2):
    innocent until contact proves otherwise, and guilt requires evidence
    mass to accumulate."""

    W = 2.0  # non-informative prior weight

    def __init__(self, half_life: Optional[float] = None):
        self.counts = defaultdict(lambda: {"pass": 0.0, "fail": 0.0,
                                           "untestable": 0.0,
                                           "self_authored": 0.0})
        self.history: List[dict] = []      # append-only, tick-stamped
        self.t = 0                         # logical clock (rounds/sessions)
        self.half_life = None if half_life is None else float(half_life)

    def tick(self, n: int = 1) -> int:
        """Advance the logical clock. With half_life set, outcome mass
        recorded before this tick counts exponentially less. Both pass and
        fail fade by the SAME factor: direction is preserved — a stale
        fail fades; a repeated fail does not; silence grows uncertainty,
        never distrust."""
        if self.half_life:
            f = 2.0 ** (-float(n) / self.half_life)
            for c in self.counts.values():
                c["pass"] *= f
                c["fail"] *= f
                c["untestable"] *= f
        self.t += int(n)
        return self.t

    def record(self, source: str, claim_id: str, result: str,
               author: Optional[str] = None, note: str = "") -> None:
        if result not in ("pass", "fail", "untestable"):
            result = "untestable"
        c = self.counts[source]
        c[result] += 1.0
        if author is not None and author == source and result != "untestable":
            c["self_authored"] += 1.0
        entry = {"source": source, "claim": claim_id, "result": result,
                 "t": self.t, "author": author or "unknown"}
        if note:
            entry["note"] = note
        self.history.append(entry)

    def trust(self, source: str) -> dict:
        c = self.counts[source]
        graded = c["pass"] + c["fail"]
        total = graded + c["untestable"]
        b = c["pass"] / (graded + self.W)
        d = c["fail"] / (graded + self.W)
        u = self.W / (graded + self.W)
        return {
            "source": source,
            "reputation": 1.0 - d,          # innocent until contact says otherwise
            "belief": b, "disbelief": d, "uncertainty": u,
            "contacts": total,
            "unfalsifiability_rate": (c["untestable"] / total) if total else 0.0,
            "self_authored_rate": (c["self_authored"] / graded) if graded else 0.0,
        }

    def to_dict(self) -> dict:
        return {"t": self.t, "half_life": self.half_life,
                "counts": {k: dict(v) for k, v in self.counts.items()},
                "history": list(self.history)}

    @classmethod
    def from_dict(cls, d: dict) -> "SourceLedger":
        led = cls(half_life=d.get("half_life"))
        led.t = int(d.get("t", 0))
        for k, v in d.get("counts", {}).items():
            led.counts[k].update(v)
        led.history = list(d.get("history", []))
        return led


class GroundingLoop:
    """The tether: the ONLY path by which evidence becomes tested and
    authority moves. dispatch(target, test) -> harness verdict -> field +
    ledger + WAL, in one motion.

    Targets:
      - an evidence id ('E###'): pass grounds it (test_count += 1, fresh
        timestamp); fail records survival evidence against its source and
        leaves the claim's authority to time; untestable moves nothing.
      - a variable name with a measurement executor: the returned
        (value, sigma) enters as fresh, tested evidence with the
        executor's contact type.
    """

    def __init__(self, field: Field, harness: RealityHarness,
                 ledger: Optional[SourceLedger] = None):
        self.field = field
        self.harness = harness
        self.ledger = ledger if ledger is not None else SourceLedger()

    def dispatch(self, target: str, test, source: Optional[str] = None) -> Verdict:
        f = self.field
        v = self.harness.run(test)
        is_evidence = target in f.evidence
        src = source or (f.evidence[target].prov.source if is_evidence
                         else getattr(test, "author", "unknown"))
        claim = (f.evidence[target].prov.statement if is_evidence else target)

        if v.result == "pass" and v.value is not None and not is_evidence:
            # Measurement values may arrive in an explicit compatible unit.
            value, sigma = v.value, v.sigma
            target_unit = f.variables[target].unit_name
            if v.unit:
                incoming_dim, incoming_scale = unit_lookup(v.unit)
                if incoming_dim != f.variables[target].dim:
                    v = Verdict("untestable", v.contact, v.kind, v.author,
                                reason=(f"measurement unit {v.unit!r} is incompatible "
                                        f"with target unit {target_unit!r}"), unit=v.unit,
                                quality=0.0)
                else:
                    target_scale = f.variables[target].unit_scale
                    value = value * incoming_scale / target_scale
                    sigma = sigma * incoming_scale / target_scale
            if v.result == "pass":
                f.add_evidence(target, value, sigma, src, 0.9,
                               grounded_at=time.time(), tested=True,
                               contact=v.contact, author=v.author,
                               contact_quality=v.quality)
        elif v.result == "pass" and is_evidence:
            f.ground_evidence(target, contact_quality=v.quality)
            f.evidence[target].contact = v.contact
            f.evidence[target].author = v.author
        # fail: the claim's authority is not slashed by one contact — the
        # ledger remembers, decay does the rest, and the record is public.
        self.ledger.record(src, claim, v.result, author=v.author,
                           note=f"{v.kind}/{v.contact}")
        f._emit("test", {"target": target, "kind": v.kind, "author": v.author,
                         "contact": v.contact, "contact_quality": v.quality,
                         "result": v.result, "source": src, "reason": v.reason})
        return v

    def reground_stale(self, tests: Dict[str, GroundingTest],
                       threshold: float = 0.5) -> List[Verdict]:
        """Close the tether<->pruning loop: any tested evidence whose
        authority has decayed below threshold x confidence gets re-contacted
        if a test is supplied for it."""
        out = []
        now = time.time()
        for eid, ev in list(self.field.evidence.items()):
            p = ev.prov
            if p.test_count > 0 and ev.authority(now) < threshold * p.confidence \
                    and eid in tests:
                out.append(self.dispatch(eid, tests[eid]))
        return out