"""Epistemic-security checks for acquired artifacts and proposed tool output."""
from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Tuple

@dataclass(frozen=True)
class RiskFinding:
    category: str
    severity: str
    excerpt: str

@dataclass(frozen=True)
class RiskAssessment:
    untrusted: bool
    findings: Tuple[RiskFinding, ...]
    authority_ceiling: float

class ArtifactRiskScanner:
    PATTERNS = (
        ("prompt-injection", "high", re.compile(r"(?i)(ignore|disregard).{0,40}(previous|system|developer).{0,30}(instruction|message)")),
        ("authority-escalation", "high", re.compile(r"(?i)(mark|treat|declare).{0,40}(verified|trusted|authoritative|true)")),
        ("secret-request", "high", re.compile(r"(?i)(api key|password|secret token|private key)")),
        ("tool-coercion", "medium", re.compile(r"(?i)(execute|run|call).{0,40}(shell|terminal|tool|command)")),
    )

    @classmethod
    def scan(cls, text: str) -> RiskAssessment:
        findings = []
        for cat, sev, pat in cls.PATTERNS:
            for match in pat.finditer(text[:2_000_000]):
                s, e = max(0, match.start()-60), min(len(text), match.end()+100)
                findings.append(RiskFinding(cat, sev, text[s:e].replace("\n", " ")[:240]))
                if len(findings) >= 50: break
        ceiling = 0.0 if any(x.severity == "high" for x in findings) else (0.1 if findings else 0.25)
        return RiskAssessment(bool(findings), tuple(findings), ceiling)
