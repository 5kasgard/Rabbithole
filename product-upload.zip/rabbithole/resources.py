"""Multidimensional resource accounting for public and organ operations.

Costs are deliberately not collapsed into one scalar in storage.  Routing may
apply an explicit, versioned policy, but the original dimensions and whether a
value was measured, estimated, or unknown remain visible.
"""
from __future__ import annotations

import contextlib
import os
import resource
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Iterator, Mapping, Optional, Tuple

from .wal import EventLog


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


def _io() -> tuple[int, int]:
    try:
        values = {}
        with open("/proc/self/io", "r", encoding="utf-8") as fh:
            for line in fh:
                key, value = line.split(":", 1)
                values[key.strip()] = int(value.strip())
        return int(values.get("read_bytes", 0)), int(values.get("write_bytes", 0))
    except Exception:
        return 0, 0


@dataclass
class ResourceRecord:
    request_id: str
    capability: str
    operation: str
    organ: str = ""
    wall_seconds: float = 0.0
    cpu_seconds: float = 0.0
    peak_rss_bytes: int = 0
    read_bytes: int = 0
    write_bytes: int = 0
    retries: int = 0
    provider_calls: Mapping[str, int] = field(default_factory=dict)
    monetary_cost: Optional[float] = None
    energy_joules: Optional[float] = None
    human_seconds: Optional[float] = None
    external_experiment_cost: Optional[float] = None
    irreversible_risk: Optional[float] = None
    estimated_dimensions: Tuple[str, ...] = ()
    unknown_dimensions: Tuple[str, ...] = ()
    metadata: Mapping[str, object] = field(default_factory=dict)
    started_at: float = field(default_factory=time.time)
    ended_at: float = field(default_factory=time.time)
    rid: str = field(default_factory=lambda: _id("RES"))

    def validate(self) -> None:
        numeric = (self.wall_seconds, self.cpu_seconds, self.peak_rss_bytes,
                   self.read_bytes, self.write_bytes, self.retries)
        if any(float(x) < 0 for x in numeric):
            raise ValueError("resource values cannot be negative")
        for name in ("monetary_cost", "energy_joules", "human_seconds",
                     "external_experiment_cost", "irreversible_risk"):
            value = getattr(self, name)
            if value is not None and value < 0:
                raise ValueError(f"{name} cannot be negative")


@dataclass(frozen=True)
class ResourcePolicy:
    weights: Mapping[str, float] = field(default_factory=lambda: {
        "wall_seconds": 1.0,
        "cpu_seconds": 0.25,
        "monetary_cost": 10.0,
        "energy_joules": 0.000001,
        "human_seconds": 2.0,
        "external_experiment_cost": 10.0,
        "irreversible_risk": 100.0,
    })
    unknown_penalty: float = 1000.0
    policy_id: str = field(default_factory=lambda: _id("RPL"))


class ResourceLedger:
    def __init__(self):
        self.records: Dict[str, ResourceRecord] = {}
        self.external_reconciliations: list[dict] = []
        self.audit = EventLog()

    def record(self, record: ResourceRecord) -> str:
        record.validate()
        self.records[record.rid] = record
        self.audit.append("resource_recorded", asdict(record))
        return record.rid

    def record_mapping(self, raw: Mapping[str, object]) -> str:
        known = {f.name for f in ResourceRecord.__dataclass_fields__.values()}
        data = {k: v for k, v in dict(raw).items() if k in known}
        for key in ("estimated_dimensions", "unknown_dimensions"):
            data[key] = tuple(data.get(key, ()))
        return self.record(ResourceRecord(**data))

    @contextlib.contextmanager
    def measure(self, request_id: str, capability: str, operation: str, *, organ: str = "",
                metadata: Optional[Mapping[str, object]] = None) -> Iterator[dict]:
        started = time.time(); cpu0 = time.process_time(); r0, w0 = _io()
        ru0 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        supplement: dict = {}
        try:
            yield supplement
        finally:
            ended = time.time(); cpu1 = time.process_time(); r1, w1 = _io()
            ru1 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            # Linux reports KiB; macOS bytes.  This environment is Linux, but
            # retain a conservative conversion only when the value is small.
            peak = int(max(ru0, ru1))
            if os.name == "posix" and peak < 10_000_000:
                peak *= 1024
            record = ResourceRecord(
                request_id=request_id, capability=capability, operation=operation, organ=organ,
                wall_seconds=max(0.0, ended-started), cpu_seconds=max(0.0, cpu1-cpu0),
                peak_rss_bytes=peak, read_bytes=max(0, r1-r0), write_bytes=max(0, w1-w0),
                retries=int(supplement.get("retries", 0)),
                provider_calls=dict(supplement.get("provider_calls", {})),
                monetary_cost=supplement.get("monetary_cost"),
                energy_joules=supplement.get("energy_joules"),
                human_seconds=supplement.get("human_seconds"),
                external_experiment_cost=supplement.get("external_experiment_cost"),
                irreversible_risk=supplement.get("irreversible_risk"),
                estimated_dimensions=tuple(supplement.get("estimated_dimensions", ())),
                unknown_dimensions=tuple(supplement.get("unknown_dimensions", ())),
                metadata={**dict(metadata or {}), **dict(supplement.get("metadata", {}))},
                started_at=started, ended_at=ended,
            )
            self.record(record)

    def score(self, record: ResourceRecord, policy: ResourcePolicy) -> float:
        total = 0.0
        for name, weight in policy.weights.items():
            value = getattr(record, name, None)
            if value is None:
                total += policy.unknown_penalty * abs(float(weight))
            else:
                total += float(weight) * float(value)
        total += policy.unknown_penalty * len(record.unknown_dimensions)
        return total

    def totals(self, request_id: str = "") -> dict:
        rows = [r for r in self.records.values() if not request_id or r.request_id == request_id]
        def total(name: str):
            vals = [getattr(r, name) for r in rows if getattr(r, name) is not None]
            return sum(vals) if vals else None
        return {
            "records": len(rows),
            "wall_seconds": total("wall_seconds"), "cpu_seconds": total("cpu_seconds"),
            "read_bytes": total("read_bytes"), "write_bytes": total("write_bytes"),
            "monetary_cost": total("monetary_cost"), "energy_joules": total("energy_joules"),
            "human_seconds": total("human_seconds"),
            "external_experiment_cost": total("external_experiment_cost"),
            "irreversible_risk": total("irreversible_risk"),
            "unknown_dimensions": sorted({x for r in rows for x in r.unknown_dimensions}),
        }

    def reconcile(self, request_id: str, external: Mapping[str, float], *, source: str,
                  tolerance: float = 0.10) -> dict:
        internal = self.totals(request_id)
        differences = {}
        for key, value in external.items():
            iv = internal.get(key)
            if iv is None:
                differences[key] = {"internal": None, "external": float(value), "within_tolerance": False}
            else:
                scale = max(abs(float(value)), 1e-12)
                differences[key] = {"internal": float(iv), "external": float(value),
                                    "within_tolerance": abs(float(iv)-float(value))/scale <= tolerance}
        result = {"request_id": request_id, "source": source, "differences": differences,
                  "reconciled": bool(differences) and all(x["within_tolerance"] for x in differences.values())}
        self.external_reconciliations.append(result)
        self.audit.append("resource_reconciled", result)
        return result

    def to_dict(self) -> dict:
        return {"records": [asdict(x) for x in self.records.values()],
                "external_reconciliations": self.external_reconciliations,
                "audit": self.audit.to_dict()}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "ResourceLedger":
        obj = cls()
        for row in raw.get("records", []):
            d = dict(row)
            for key in ("estimated_dimensions", "unknown_dimensions"):
                d[key] = tuple(d.get(key, ()))
            rec = ResourceRecord(**d); obj.records[rec.rid] = rec
        obj.external_reconciliations = list(raw.get("external_reconciliations", []))
        obj.audit = EventLog.from_dict(raw.get("audit", {}))
        return obj
