"""Time-forward mechanism-portfolio benchmarks and safe fallback schedules."""
from __future__ import annotations
import time,uuid
from dataclasses import asdict,dataclass,field
from typing import Dict,Mapping,Sequence,Tuple
from .portfolio import MechanismPortfolio,TaskShape
from .wal import EventLog

def _id(p):return f"{p}{uuid.uuid4().hex[:12]}"
@dataclass(frozen=True)
class PortfolioCase:
    task:TaskShape
    outcomes:Mapping[str,Mapping[str,float]]  # success, latency_ms, fuel, sound
    timestamp:float
    case_id:str=field(default_factory=lambda:_id("PBC"))
class PortfolioBenchmark:
    def __init__(self):self.audit=EventLog()
    @staticmethod
    def _utility(row):
        if not bool(row.get("sound",True)):return -1e9
        return float(row.get("success",0))/(1+float(row.get("latency_ms",0))/1000+float(row.get("fuel",0)))
    def evaluate(self,portfolio:MechanismPortfolio,cases:Sequence[PortfolioCase],cutoff:float)->dict:
        train=[c for c in cases if c.timestamp<=cutoff];test=[c for c in cases if c.timestamp>cutoff]
        if not test:raise ValueError("time-forward holdout required")
        # Record training outcomes only.
        from .portfolio import PerformanceRecord
        for c in train:
            for mid,row in c.outcomes.items():
                if mid in portfolio.profiles:
                    portfolio.record(PerformanceRecord(mid,c.task.task_class,c.task.features,bool(row.get("success",0)),float(row.get("latency_ms",0)),float(row.get("fuel",0)),"benchmark",failure_type="" if row.get("success") else "benchmark_failure",created_at=c.timestamp,resource_values=dict(row.get("resources", {}))))
        mids=sorted(portfolio.profiles)
        fixed_scores={mid:sum(self._utility(c.outcomes.get(mid,{"sound":False})) for c in test)/len(test) for mid in mids}
        best_fixed=max(fixed_scores,key=fixed_scores.get)
        selected=[];oracle=[];fallbacks=[]
        for c in test:
            compatible=[]
            for mid,p in portfolio.profiles.items():
                ok,_=p.compatible(c.task)
                if ok:compatible.append(mid)
            ranked=sorted(compatible,key=lambda mid:-portfolio.select(TaskShape(c.task.task_class,c.task.features,c.task.required_properties,c.task.max_authority,c.task.cost_weights,c.task.tid)).score) if compatible else []
            try:sel=portfolio.select(c.task).mechanism_id
            except Exception:sel=""
            if sel and not bool(c.outcomes.get(sel,{}).get("sound",True)):
                # fallback to a compatible sound mechanism in deterministic order
                alternatives=[m for m in compatible if bool(c.outcomes.get(m,{}).get("sound",False))]
                fallbacks.append({"case_id":c.case_id,"from":sel,"to":alternatives[0] if alternatives else ""});sel=alternatives[0] if alternatives else ""
            selected.append(self._utility(c.outcomes.get(sel,{"sound":False})))
            oracle.append(max((self._utility(c.outcomes.get(m,{"sound":False})) for m in compatible),default=-1e9))
        mean=sum(selected)/len(selected);oracle_mean=sum(oracle)/len(oracle);result={"holdout":len(test),"portfolio_utility":mean,"best_fixed":best_fixed,"best_fixed_utility":fixed_scores[best_fixed],"oracle_utility":oracle_mean,"regret":oracle_mean-mean,"fallbacks":fallbacks,"beats_best_fixed":mean>fixed_scores[best_fixed],"soundness_regressions":sum(1 for x in selected if x<=-1e8)}
        self.audit.append("portfolio_benchmark",result);return result
    def to_dict(self): return {"audit": self.audit.to_dict()}
    @classmethod
    def from_dict(cls, raw):
        obj=cls(); obj.audit=EventLog.from_dict(raw.get("audit", {})); return obj
