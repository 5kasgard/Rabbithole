"""Intermediate-representation portfolio.

Natural-language-to-symbolic systems fail not only at translation but also when
the chosen representation cannot preserve the distinctions needed by the task.
This registry makes the IR an explicit selectable mechanism with declared loss,
operations, verifier compatibility and round-trip obligations.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Sequence, Tuple

from .wal import EventLog


@dataclass
class IRContract:
    ir_id: str
    representation: str
    preserves: Tuple[str, ...]
    loses: Tuple[str, ...]
    operations: Tuple[str, ...]
    claim_classes: Tuple[str, ...]
    verifier_kinds: Tuple[str, ...]
    machine_checkable: bool
    open_world: bool
    cost: Mapping[str, float] = field(default_factory=dict)


@dataclass
class IRRequirement:
    claim_class: str
    required_distinctions: Tuple[str, ...]
    required_operations: Tuple[str, ...]
    required_verifier_kinds: Tuple[str, ...] = ()
    open_world_required: bool = False
    machine_checkable_required: bool = True


@dataclass
class IRSelection:
    ir_id: str
    score: float
    retained: Tuple[str, ...]
    unavoidable_losses: Tuple[str, ...]
    reason: str


class IRRegistry:
    def __init__(self):
        self.contracts: Dict[str, IRContract] = {}
        self.audit = EventLog()

    def register(self, contract: IRContract) -> None:
        if contract.ir_id in self.contracts:
            raise ValueError(f"IR {contract.ir_id!r} already registered")
        self.contracts[contract.ir_id] = contract
        self.audit.append("ir_registered", asdict(contract))

    def select(self, req: IRRequirement) -> IRSelection:
        candidates = []
        for c in self.contracts.values():
            if req.claim_class not in c.claim_classes:
                continue
            if req.machine_checkable_required and not c.machine_checkable:
                continue
            if req.open_world_required and not c.open_world:
                continue
            missing_ops = set(req.required_operations) - set(c.operations)
            missing_verifiers = set(req.required_verifier_kinds) - set(c.verifier_kinds)
            if missing_ops or missing_verifiers:
                continue
            retained = set(req.required_distinctions) & set(c.preserves)
            lost = set(req.required_distinctions) - set(c.preserves)
            # Any declared loss of a required distinction is a hard veto.
            if set(req.required_distinctions) & set(c.loses):
                continue
            cost = sum(float(v) for v in c.cost.values())
            score = (len(retained) + 1) / (cost + 1)
            candidates.append(IRSelection(c.ir_id, score, tuple(sorted(retained)),
                                          tuple(sorted(lost)),
                                          "contract satisfies required operations and verifiers"))
        if not candidates:
            raise LookupError("no intermediate representation preserves the required distinctions")
        candidates.sort(key=lambda x: (-x.score, len(x.unavoidable_losses), x.ir_id))
        selected = candidates[0]
        self.audit.append("ir_selected", {"requirement": asdict(req),
                                          "selection": asdict(selected),
                                          "alternatives": [asdict(x) for x in candidates[1:]]})
        return selected

    def to_dict(self) -> dict:
        return {"contracts": [asdict(x) for x in self.contracts.values()],
                "audit": self.audit.to_dict()}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "IRRegistry":
        r = cls()
        r.contracts = {}
        for x in raw.get("contracts", []):
            d = dict(x)
            for key in ("preserves", "loses", "operations", "claim_classes", "verifier_kinds"):
                d[key] = tuple(d.get(key, ()))
            r.contracts[d["ir_id"]] = IRContract(**d)
        r.audit = EventLog.from_dict(raw.get("audit", {}))
        return r


def core_irs() -> Tuple[IRContract, ...]:
    return (
        IRContract("interval-field", "typed variables and interval factors",
                   ("physical_dimension", "uncertainty_interval", "equation_role", "provenance"),
                   ("natural_language_pragmatics", "unmodelled_causality"),
                   ("constraint_propagation", "inverse_solve", "conflict_extraction"),
                   ("empirical_quantity", "design_constraint"),
                   ("interval_solver", "dimensional_checker"), True, False,
                   {"translation": 3, "solve": 1}),
        IRContract("argument-graph", "claims, attacks, supports and dependencies",
                   ("claim_scope", "disagreement", "independence", "provenance"),
                   ("numeric_continuity",),
                   ("support_attack", "retraction", "dependency_analysis"),
                   ("documentary_fact", "design_claim", "causal_claim", "normative_claim"),
                   ("document_inspector", "human_decision", "causal_analysis"), True, True,
                   {"translation": 2, "solve": 2}),
        IRContract("temporal-logic", "state-transition temporal formulae",
                   ("ordering", "liveness", "safety", "quantified_time"),
                   ("open_world_entities", "informal_context"),
                   ("model_check", "counterexample_trace"),
                   ("software_behaviour",), ("model_checker",), True, False,
                   {"translation": 4, "solve": 3}),
        IRContract("rdf-shapes", "RDF graph plus structural shapes",
                   ("entity_identity", "typed_relations", "cardinality", "provenance"),
                   ("procedural_semantics",),
                   ("graph_query", "shape_validation", "schema_alignment"),
                   ("documentary_fact", "ontology_mapping"),
                   ("document_inspector", "database_query"), True, True,
                   {"translation": 3, "solve": 2}),
    )
