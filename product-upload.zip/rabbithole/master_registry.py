"""Machine-readable master authority, decision, capability and history registry."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()



def _digest_paths(root: Path, paths: Iterable[Path]) -> str:
    h = hashlib.sha256()
    for path in sorted({item.resolve() for item in paths if item.is_file()}):
        rel = path.relative_to(root.resolve()).as_posix()
        h.update(rel.encode("utf-8") + b"\0")
        h.update(path.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


def master_source_paths(root: str | Path | None = None) -> list[Path]:
    """Return current executable and normative inputs, excluding generated evidence.

    Historical archives, acceptance receipts, caches, wheels and runtime state are
    deliberately excluded.  Their identities are verified separately.
    """
    base = Path(root) if root else Path(__file__).resolve().parents[1]
    paths: list[Path] = [base / "pyproject.toml"]
    paths.extend(base.glob("*.py"))
    for directory in (
        "rabbithole", "stage3", "stage4a", "stage4b", "stage4c",
        "stage4d", "stage5", "stage6", "stage7",
    ):
        paths.extend((base / directory).glob("*.py"))
    for pattern in ("*.py", "*.js", "*.go"):
        paths.extend((base / "experimental" / "fip").glob(pattern))
    paths.extend((base / "master").glob("*.json"))
    paths.extend((base / "docs").glob("*.md"))
    paths.extend((base / "examples" / "master").glob("*.json"))
    paths.extend((base / "rabbithole" / "data").rglob("*"))
    return [path for path in paths if path.is_file()]


def master_source_digest(root: str | Path | None = None) -> str:
    base = Path(root) if root else Path(__file__).resolve().parents[1]
    return _digest_paths(base, master_source_paths(base))


def master_test_paths(root: str | Path | None = None) -> list[Path]:
    base = Path(root) if root else Path(__file__).resolve().parents[1]
    paths = list((base / "tests").glob("test_*.py"))
    paths.extend([base / "test_forager.py", base / "test_placement.py", base / "stress_test.py"])
    return [path for path in paths if path.is_file()]


def master_test_digest(root: str | Path | None = None) -> str:
    base = Path(root) if root else Path(__file__).resolve().parents[1]
    return _digest_paths(base, master_test_paths(base))

def _load(path: Path) -> Any:
    return json.loads(path.read_text())


@dataclass(frozen=True)
class RegistryIssue:
    code: str
    message: str
    path: str = ""
    severity: str = "error"


class MasterRegistry:
    """Verify that current documents and cross-cutting decisions agree.

    This registry does not prove real-world utility.  It proves that the current
    master has one explicit authority hierarchy and that every load-bearing
    decision points to known requirements, components and capabilities.
    """

    FILENAMES = {
        "standards": "MASTER_STANDARD_PROFILE.json",
        "decisions": "MASTER_DECISION_REGISTRY.json",
        "requirements": "MASTER_REQUIREMENT_REGISTRY.json",
        "components": "MASTER_COMPONENT_REGISTRY.json",
        "capabilities": "MASTER_CAPABILITY_REGISTRY.json",
        "drift": "MASTER_DRIFT_REGISTRY.json",
        "fip": "MASTER_FIP_DECISION.json",
        "development": "MASTER_DEVELOPMENT_SEQUENCE.json",
        "promotion": "MASTER_PROMOTION_CONTRACT.json",
        "verdict": "MASTER_LINEAGE_VERDICT.json",
        "documents": "MASTER_DOCUMENT_AUTHORITY.json",
        "origin_reuse": "MASTER_ORIGIN_REUSE_REGISTRY.json",
        "implementation_propagation": "MASTER_IMPLEMENTATION_PROPAGATION_MATRIX.json",
        "gap_closure": "MASTER_GAP_CLOSURE_LEDGER.json",
        "changelog": "MASTER_CHANGELOG_REGISTRY.json",
        "blind_spots": "MASTER_BLIND_SPOT_REGISTRY.json",
    }

    def __init__(self, root: str | Path | None = None):
        requested = Path(root) if root else Path(__file__).resolve().parents[1]
        if (requested / "master").is_dir():
            self.root = requested
            if (requested / "PRODUCT_DISTRIBUTION.json").is_file():
                self.distribution_scope = "product_repository"
                self.full_history_embedded = False
            else:
                self.distribution_scope = "full_archive"
                self.full_history_embedded = True
        else:
            embedded = Path(__file__).resolve().parent / "data"
            if not (embedded / "master").is_dir():
                raise FileNotFoundError("master authority bundle is unavailable")
            self.root = embedded
            self.distribution_scope = "wheel_runtime"
            self.full_history_embedded = False
        self.master_dir = self.root / "master"
        self.data = {
            name: _load(self.master_dir / filename)
            for name, filename in self.FILENAMES.items()
        }

    @staticmethod
    def _rows(payload: Any, candidates: Iterable[str]) -> list[Mapping[str, Any]]:
        if isinstance(payload, list):
            return [row for row in payload if isinstance(row, Mapping)]
        if isinstance(payload, Mapping):
            for key in candidates:
                value = payload.get(key)
                if isinstance(value, list):
                    return [row for row in value if isinstance(row, Mapping)]
        return []

    def requirements(self) -> list[Mapping[str, Any]]:
        return self._rows(
            self.data["requirements"],
            ("requirements", "rows", "requirement_alignment", "items"),
        )

    def components(self) -> list[Mapping[str, Any]]:
        return self._rows(
            self.data["components"],
            ("components", "rows", "component_posiwids", "items"),
        )

    def capabilities(self) -> list[Mapping[str, Any]]:
        return self._rows(
            self.data["capabilities"],
            ("capabilities", "rows", "capability_map", "items"),
        )

    def decisions(self) -> list[Mapping[str, Any]]:
        return self._rows(
            self.data["decisions"],
            ("decisions", "rows", "matrix", "items"),
        )

    @staticmethod
    def _ids(rows: Iterable[Mapping[str, Any]]) -> set[str]:
        keys = ("id", "requirement_id", "component_id", "capability_id")
        out: set[str] = set()
        for row in rows:
            for key in keys:
                value = row.get(key)
                if isinstance(value, str) and value:
                    out.add(value)
                    break
        return out

    def verify(self) -> dict[str, Any]:
        issues: list[RegistryIssue] = []
        for name, filename in self.FILENAMES.items():
            path = self.master_dir / filename
            if not path.is_file():
                issues.append(RegistryIssue("missing_registry", f"missing {name}", str(path)))

        requirements = self.requirements()
        components = self.components()
        capabilities = self.capabilities()
        decisions = self.decisions()
        req_ids = self._ids(requirements)
        comp_ids = self._ids(components)
        cap_ids = self._ids(capabilities)

        if not decisions:
            issues.append(RegistryIssue("empty_decision_registry", "no decisions found"))
        for row in decisions:
            decision_id = str(row.get("id", ""))
            if not decision_id:
                issues.append(RegistryIssue("decision_without_id", "decision has no id"))
                continue
            target_sets = {
                "target_requirements": req_ids,
                "target_components": comp_ids,
                "target_capabilities": cap_ids,
            }
            for key, known in target_sets.items():
                values = row.get(key, [])
                if not isinstance(values, list):
                    issues.append(RegistryIssue("invalid_target_list", f"{decision_id} {key} is not a list"))
                    continue
                for value in values:
                    if value not in known:
                        issues.append(RegistryIssue(
                            "unknown_decision_target",
                            f"{decision_id} references unknown {key}: {value}",
                        ))
            if row.get("must_propagate_before_claiming_whole_alignment") and not row.get("final_closure_state"):
                issues.append(RegistryIssue(
                    "missing_closure_state", f"{decision_id} lacks final closure state"
                ))

        # Exhaustive current implementation propagation and origin-reuse closure.
        propagation = self.data["implementation_propagation"]
        cells = propagation.get("matrix", []) if isinstance(propagation, Mapping) else []
        expected_pairs = len(decisions) * len(components)
        pair_keys = {(row.get("decision_id"), row.get("component_id")) for row in cells if isinstance(row, Mapping)}
        if len(cells) != expected_pairs or len(pair_keys) != expected_pairs:
            issues.append(RegistryIssue("implementation_propagation_incomplete", f"expected {expected_pairs} decision/component cells"))
        known_decisions = {str(row.get("id")) for row in decisions}
        for did, cid in pair_keys:
            if did not in known_decisions or cid not in comp_ids:
                issues.append(RegistryIssue("implementation_propagation_unknown_target", f"{did}/{cid}"))

        origin_rows = self._rows(self.data["origin_reuse"], ("entries", "rows", "items"))
        if len(origin_rows) < 20:
            issues.append(RegistryIssue("origin_reuse_incomplete", "origin reuse registry is unexpectedly small"))
        for row in origin_rows:
            if not row.get("id") or not row.get("disposition") or not row.get("current_locations"):
                issues.append(RegistryIssue("origin_reuse_shape", f"invalid origin row: {row.get('id', '')}"))

        gap_rows = self._rows(self.data["gap_closure"], ("gaps", "rows", "items"))
        if len(gap_rows) < 10:
            issues.append(RegistryIssue("gap_closure_incomplete", "gap closure ledger is unexpectedly small"))
        blind_rows = self._rows(self.data["blind_spots"], ("blind_spots", "rows", "items"))
        if len(blind_rows) < 10:
            issues.append(RegistryIssue("blind_spots_incomplete", "blind-spot ledger is unexpectedly small"))
        changelog_rows = self._rows(self.data["changelog"], ("versions", "rows", "items"))
        if len(changelog_rows) < 15:
            issues.append(RegistryIssue("master_changelog_incomplete", "master changelog does not span the lineage"))

        standards = self.data["standards"].get("standards", [])
        standard_ids = [row.get("id") for row in standards if isinstance(row, Mapping)]
        if len(standard_ids) != len(set(standard_ids)):
            issues.append(RegistryIssue("duplicate_standard_id", "standard ids are not unique"))
        if len(standards) < 10:
            issues.append(RegistryIssue("standards_incomplete", "master standards profile is unexpectedly small"))

        docs = self.data["documents"].get("precedence", [])
        ranks = [row.get("rank") for row in docs if isinstance(row, Mapping)]
        if ranks != sorted(ranks) or len(ranks) != len(set(ranks)):
            issues.append(RegistryIssue("document_precedence", "document ranks are invalid"))
        document_hashes: dict[str, str] = {}
        for row in docs:
            rel = row.get("document")
            if not isinstance(rel, str):
                continue
            path = self.root / rel
            if not path.exists():
                issues.append(RegistryIssue("missing_authoritative_document", rel, rel))
            elif path.is_file():
                document_hashes[rel] = _sha256(path)

        promotion = self.data["promotion"]
        if promotion.get("status") not in {
            "promotion contract; no release created",
            "master candidate; promotion blocked",
        }:
            issues.append(RegistryIssue("promotion_status", "promotion status is not explicitly blocked"))
        verdict = self.data["verdict"]
        if verdict.get("evidence_overlay") != "blocked_by_missing_evidence":
            issues.append(RegistryIssue(
                "external_boundary_lost", "master verdict no longer preserves missing-evidence boundary"
            ))

        history_index = self.root / "history" / "MASTER_LINEAGE_INDEX.json"
        if history_index.exists():
            history = _load(history_index)
            rows = history.get("artifacts", [])
            if history.get("artifact_count") != len(rows):
                issues.append(RegistryIssue("history_index_count", "history artifact count is inconsistent"))
            if self.full_history_embedded:
                for row in rows:
                    rel = row.get("path")
                    expected = row.get("sha256")
                    if not isinstance(rel, str) or not isinstance(expected, str):
                        issues.append(RegistryIssue("history_index_shape", "invalid history row"))
                        continue
                    path = self.root / rel
                    if not path.is_file():
                        issues.append(RegistryIssue("history_artifact_missing", rel, rel))
                    elif _sha256(path) != expected:
                        issues.append(RegistryIssue("history_digest_mismatch", rel, rel))
            else:
                summary_name = "PRODUCT_LINEAGE_SUMMARY.json" if self.distribution_scope == "product_repository" else "MASTER_WHEEL_EVIDENCE_SUMMARY.json"
                summary_path = self.root / "history" / summary_name
                if not summary_path.is_file():
                    issues.append(RegistryIssue("compact_history_summary_missing", f"{summary_name} missing"))
                else:
                    summary = _load(summary_path)
                    if summary.get("full_history_embedded") is not False:
                        issues.append(RegistryIssue("compact_history_scope", "compact distribution falsely claims embedded history"))
                    if summary.get("lineage_artifact_count") != len(rows):
                        issues.append(RegistryIssue("compact_history_count", "lineage index count mismatch"))
                    if summary.get("lineage_index_sha256") != _sha256(history_index):
                        issues.append(RegistryIssue("compact_history_digest", "lineage index digest mismatch"))
        else:
            issues.append(RegistryIssue("history_index_missing", "history index has not been generated"))

        errors = [issue for issue in issues if issue.severity == "error"]
        return {
            "valid": not errors,
            "release": str(self.data["standards"].get("release", "0.18.0rc3")),
            "status": "master_candidate_externally_unpromoted",
            "distribution_scope": self.distribution_scope,
            "full_history_embedded": self.full_history_embedded,
            "requirements": len(requirements),
            "components": len(components),
            "capabilities": len(capabilities),
            "decisions": len(decisions),
            "standards": len(standards),
            "document_hashes": document_hashes,
            "master_source_digest": master_source_digest(self.root),
            "master_test_digest": master_test_digest(self.root),
            "issues": [issue.__dict__ for issue in issues],
            "external_claims_closed": False,
        }

    def status(self) -> dict[str, Any]:
        verification = self.verify()
        return {
            "identity": {
                "version": str(self.data["standards"].get("release", "0.18.0rc3")),
                "reference_version": "0.17.0",
                "reference_sha256": "de17deb19cf94172a06faed997f32c2a5d70e17f58f719bf5ac3f87ad66fdca1",
                "promotion": "blocked until external gates",
                "distribution_scope": self.distribution_scope,
                "full_history_embedded": self.full_history_embedded,
            },
            "verdict": self.data["verdict"],
            "fip": self.data["fip"],
            "promotion_contract": self.data["promotion"],
            "verification": verification,
        }
