"""ARC-5A: adversarial bifurcated subtractive discovery.

ARC-5A strengthens ARC-5 without changing its epistemic direction.  Search still
widens the candidate field and reality contact still removes unsupported
mechanisms.  The correction is structural independence:

* constructive and destructive concrete searches are frozen separately;
* goal-backward and failure-forward decompositions are authored separately;
* function-preserving and counterfactual abstraction searches use independent
  abstraction lattices and plans;
* strongest-selection compares champion, challenger, simplifier, portfolio and
  null hypotheses rather than one favoured architecture and weak strawmen;
* candidates survive on a Pareto frontier until workload/risk-specific contact
  justifies elimination;
* champion and adversarial tests require different accountable authors;
* stopping requires decision saturation, not merely document saturation.

The kernel is intentionally human-gated and does not certify its own search,
analogy, evidence screening, decomposition, or candidate selection as correct.
"""
from __future__ import annotations

import hashlib
import json
import math
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Mapping, Optional, Sequence, Tuple

from .arc_kernel import (EligibilityContract, EvidenceLineageProfile, ScreeningDecision)
from .discovery import (AbstractionNode, DiscoveryArc, EvidenceItem, POSIWIDContract,
                        SearchQuery, TestObligation)
from .process import SearchEnvelope, StageGate
from .wal import EventLog


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:14]}"


def _canon(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, default=str).encode("utf-8")


def _digest(value: object) -> str:
    return hashlib.sha256(_canon(value)).hexdigest()


STAGES = ("contract", "concrete", "expose", "abstract", "arena", "contact", "complete")
LANES = (
    "concrete_constructive",
    "concrete_destructive",
    "abstract_function",
    "abstract_counterfactual",
)
LANE_STAGE = {
    "concrete_constructive": "concrete",
    "concrete_destructive": "concrete",
    "abstract_function": "abstract",
    "abstract_counterfactual": "abstract",
}
ROLES = {"champion", "challenger", "simplifier", "portfolio", "null"}
DIRECTIONS = {"max", "min"}
CANDIDATE_STATES = {"candidate", "frontier", "dominated", "killed", "surviving", "unresolved"}
TEST_STATES = {"proposed", "passed", "failed", "inconclusive", "unrunnable"}




@dataclass(frozen=True)
class AdversarialApprovalRecord:
    stage: str
    decision: str
    actor: str
    rationale: str
    gate_digest: str
    created_at: float = field(default_factory=time.time)
    approval_id: str = field(default_factory=lambda: _id("AAP"))

    def validate(self) -> None:
        if self.stage not in STAGES:
            raise ValueError("invalid ARC-5A approval stage")
        if self.decision not in {"approve", "hold", "reopen", "reject"}:
            raise ValueError("invalid ARC-5A approval decision")
        if not self.actor.strip() or not self.rationale.strip():
            raise ValueError("approval requires actor and rationale")


@dataclass
class AdversarialWorkItem:
    stage: str
    reason: str
    source_id: str = ""
    priority: float = 1.0
    state: str = "queued"
    blocked_by: Tuple[str, ...] = ()
    created_at: float = field(default_factory=time.time)
    wid: str = field(default_factory=lambda: _id("AWR"))

    def validate(self) -> None:
        if self.stage not in STAGES:
            raise ValueError("invalid ARC-5A work-item stage")
        if self.state not in {"queued", "active", "blocked", "done", "cancelled"}:
            raise ValueError("invalid ARC-5A work-item state")
        if not self.reason.strip():
            raise ValueError("work item requires reason")

@dataclass(frozen=True)
class HostileInterpretation:
    """Independently authored attack on the initial framing and goal."""

    target_may_be_unreal: Tuple[str, ...]
    alternative_goals: Tuple[str, ...]
    impossibility_or_unnecessity: Tuple[str, ...]
    whole_system_harms: Tuple[str, ...]
    simpler_problem_substitutes: Tuple[str, ...]
    disconfirming_observations: Tuple[str, ...]
    author: str
    created_at: float = field(default_factory=time.time)
    hid: str = field(default_factory=lambda: _id("HST"))

    def validate(self) -> None:
        if not self.author.strip():
            raise ValueError("hostile interpretation requires an accountable author")
        required = (
            self.target_may_be_unreal,
            self.alternative_goals,
            self.impossibility_or_unnecessity,
            self.whole_system_harms,
            self.simpler_problem_substitutes,
            self.disconfirming_observations,
        )
        if any(not values for values in required):
            raise ValueError("hostile interpretation must populate every attack surface")


@dataclass
class LaneSearchRequirement:
    lane: str
    text: str
    polarity: str
    category: str
    wave: int
    domain_family: str = ""
    abstraction_id: str = ""
    parent_requirement_id: str = ""
    rationale: str = ""
    author: str = ""
    status: str = "planned"
    query_id: str = ""
    evidence_count: int = 0
    failure: str = ""
    rid: str = field(default_factory=lambda: _id("AQR"))

    def validate(self) -> None:
        if self.lane not in LANES:
            raise ValueError("unknown ARC-5A search lane")
        if not self.text.strip() or not self.category.strip() or not self.author.strip():
            raise ValueError("search requirement needs text, category and author")
        if self.wave < 0:
            raise ValueError("search wave cannot be negative")
        if self.status not in {"planned", "executed", "failed", "cancelled"}:
            raise ValueError("invalid search requirement status")

    def definition(self) -> dict:
        return {
            "rid": self.rid,
            "lane": self.lane,
            "text": self.text,
            "polarity": self.polarity,
            "category": self.category,
            "wave": self.wave,
            "domain_family": self.domain_family,
            "abstraction_id": self.abstraction_id,
            "parent_requirement_id": self.parent_requirement_id,
            "rationale": self.rationale,
            "author": self.author,
        }


@dataclass
class LaneSearchPlan:
    lane: str
    requirements: Dict[str, LaneSearchRequirement] = field(default_factory=dict)
    frozen_digest: str = ""
    frozen_at: float = 0.0
    frozen_by: str = ""

    @property
    def frozen(self) -> bool:
        return bool(self.frozen_digest)

    def add(self, requirement: LaneSearchRequirement) -> str:
        if self.frozen:
            raise RuntimeError(f"{self.lane} plan is frozen")
        requirement.validate()
        if requirement.lane != self.lane:
            raise ValueError("requirement belongs to another lane")
        self.requirements[requirement.rid] = requirement
        return requirement.rid

    def material(self) -> list[dict]:
        return [self.requirements[k].definition() for k in sorted(self.requirements)]

    def freeze(self, actor: str) -> str:
        if not actor.strip():
            raise ValueError("search-plan freeze requires actor")
        if not self.requirements:
            raise ValueError("cannot freeze empty search plan")
        if self.frozen:
            if not self.verify():
                raise RuntimeError("frozen search plan was mutated")
            return self.frozen_digest
        self.frozen_digest = _digest(self.material())
        self.frozen_at = time.time()
        self.frozen_by = actor
        return self.frozen_digest

    def verify(self) -> bool:
        return bool(self.frozen_digest) and _digest(self.material()) == self.frozen_digest


@dataclass(frozen=True)
class DecompositionPass:
    mode: str  # goal_backward|failure_forward
    starting_observations: Tuple[str, ...]
    causal_steps: Tuple[str, ...]
    interfaces: Tuple[str, ...]
    hidden_resources_or_authority: Tuple[str, ...]
    predicted_failure_propagation: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    author: str
    created_at: float = field(default_factory=time.time)
    did: str = field(default_factory=lambda: _id("DEC"))

    def validate(self) -> None:
        if self.mode not in {"goal_backward", "failure_forward"}:
            raise ValueError("invalid decomposition mode")
        if not self.author.strip() or not self.starting_observations or not self.causal_steps:
            raise ValueError("decomposition requires author, observations and causal steps")
        if not self.interfaces or not self.predicted_failure_propagation:
            raise ValueError("decomposition must expose interfaces and propagation")


@dataclass(frozen=True)
class DecompositionDisagreement:
    goal_pass_id: str
    failure_pass_id: str
    disagreement: str
    discriminating_observation: str
    author: str
    created_at: float = field(default_factory=time.time)
    xid: str = field(default_factory=lambda: _id("DDG"))

    def validate(self) -> None:
        if not all((self.disagreement.strip(), self.discriminating_observation.strip(), self.author.strip())):
            raise ValueError("decomposition disagreement requires content, discriminator and author")


@dataclass(frozen=True)
class AbstractionRegistration:
    lane: str  # abstract_function|abstract_counterfactual
    abstraction_id: str
    thesis: str
    independent_author: str
    causal_question: str
    excluded_framings: Tuple[str, ...]
    created_at: float = field(default_factory=time.time)
    reg_id: str = field(default_factory=lambda: _id("ABR"))

    def validate(self) -> None:
        if self.lane not in {"abstract_function", "abstract_counterfactual"}:
            raise ValueError("invalid abstraction lane")
        if not self.thesis.strip() or not self.independent_author.strip() or not self.causal_question.strip():
            raise ValueError("abstraction registration requires thesis, author and causal question")
        if not self.excluded_framings:
            raise ValueError("abstraction must state excluded framings")


@dataclass
class ArenaCandidate:
    role: str
    name: str
    mechanism_ids: Tuple[str, ...]
    composition: Tuple[str, ...]
    local_posiwid: Tuple[str, ...]
    whole_posiwid: Tuple[str, ...]
    assumptions: Tuple[str, ...]
    resource_relocations: Tuple[str, ...]
    failure_modes: Tuple[str, ...]
    security_authority_consequences: Tuple[str, ...]
    support_evidence_ids: Tuple[str, ...]
    attack_evidence_ids: Tuple[str, ...]
    author: str
    state: str = "candidate"
    cid: str = field(default_factory=lambda: _id("CAN"))

    def validate(self) -> None:
        if self.role not in ROLES:
            raise ValueError("invalid strongest-selection role")
        if self.state not in CANDIDATE_STATES:
            raise ValueError("invalid candidate state")
        if not self.name.strip() or not self.author.strip():
            raise ValueError("candidate requires name and author")
        if not self.local_posiwid or not self.whole_posiwid:
            raise ValueError("candidate requires local and whole POSIWID")
        if not self.support_evidence_ids or not self.attack_evidence_ids:
            raise ValueError("candidate needs strongest support and strongest attack evidence")
        if self.role != "null" and not self.composition:
            raise ValueError("non-null candidate requires a composition")


@dataclass(frozen=True)
class ParetoDimension:
    name: str
    direction: str
    unit: str
    rationale: str
    author: str
    did: str = field(default_factory=lambda: _id("PDM"))

    def validate(self) -> None:
        if self.direction not in DIRECTIONS:
            raise ValueError("Pareto direction must be max or min")
        if not self.name.strip() or not self.rationale.strip() or not self.author.strip():
            raise ValueError("Pareto dimension requires name, rationale and author")


@dataclass(frozen=True)
class ParetoAssessment:
    candidate_id: str
    values: Mapping[str, float]
    evidence_ids: Tuple[str, ...]
    assessor: str
    created_at: float = field(default_factory=time.time)
    aid: str = field(default_factory=lambda: _id("PAS"))

    def validate(self) -> None:
        if not self.assessor.strip() or not self.values or not self.evidence_ids:
            raise ValueError("Pareto assessment requires assessor, values and evidence")
        for value in self.values.values():
            if not math.isfinite(float(value)):
                raise ValueError("Pareto values must be finite")


@dataclass(frozen=True)
class AdversarialTestPair:
    candidate_id: str
    champion_test_id: str
    adversarial_test_id: str
    champion_author: str
    adversarial_author: str
    rationale: str
    pid: str = field(default_factory=lambda: _id("TPR"))

    def validate(self) -> None:
        if not all((self.champion_author.strip(), self.adversarial_author.strip(), self.rationale.strip())):
            raise ValueError("test pair requires authors and rationale")
        if self.champion_author.strip().lower() == self.adversarial_author.strip().lower():
            raise ValueError("champion and adversarial tests require independent authors")
        if self.champion_test_id == self.adversarial_test_id:
            raise ValueError("champion and adversarial tests must differ")


@dataclass(frozen=True)
class DecisionSaturationWave:
    wave: int
    new_mechanism_classes: int
    new_abstraction_lattices: int
    new_failure_modes: int
    new_resource_relocations: int
    new_challengers: int
    new_simplifiers: int
    new_whole_system_harms: int
    pareto_frontier_changed: bool
    evidence_ids: Tuple[str, ...]
    reviewer: str
    created_at: float = field(default_factory=time.time)
    sid: str = field(default_factory=lambda: _id("SAT"))

    def validate(self) -> None:
        if self.wave < 0 or not self.reviewer.strip() or not self.evidence_ids:
            raise ValueError("saturation wave requires wave, reviewer and evidence")
        counts = (
            self.new_mechanism_classes, self.new_abstraction_lattices,
            self.new_failure_modes, self.new_resource_relocations,
            self.new_challengers, self.new_simplifiers,
            self.new_whole_system_harms,
        )
        if any(x < 0 for x in counts):
            raise ValueError("saturation counts cannot be negative")

    @property
    def changed_decision_space(self) -> bool:
        return self.pareto_frontier_changed or any((
            self.new_mechanism_classes, self.new_abstraction_lattices,
            self.new_failure_modes, self.new_resource_relocations,
            self.new_challengers, self.new_simplifiers,
            self.new_whole_system_harms,
        ))


@dataclass(frozen=True)
class ContactRecord:
    test_id: str
    candidate_id: str
    kind: str  # champion|adversarial
    state: str
    observed: str
    evidence_ids: Tuple[str, ...]
    actor: str
    created_at: float = field(default_factory=time.time)
    rid: str = field(default_factory=lambda: _id("CTR"))

    def validate(self) -> None:
        if self.kind not in {"champion", "adversarial"} or self.state not in TEST_STATES:
            raise ValueError("invalid contact record")
        if not self.observed.strip() or not self.actor.strip():
            raise ValueError("contact requires observation and actor")


class ARC5AAdversarialKernel:
    """Persistent adversarial ARC-5 process with four independent search lanes."""

    FAILURE_STAGE = {
        "goal": "contract", "criteria": "contract", "hostile_interpretation": "contract",
        "constructive_search": "concrete", "destructive_search": "concrete",
        "evidence": "concrete", "independence": "concrete",
        "goal_decomposition": "expose", "failure_decomposition": "expose",
        "function_abstraction": "abstract", "counterfactual_abstraction": "abstract",
        "analogy": "abstract", "counterfactual": "abstract",
        "candidate": "arena", "pareto": "arena", "test_authorship": "arena",
        "implementation": "contact", "integration": "contact", "verifier": "contact",
        "unknown": "contact",
    }

    def __init__(self, arc: DiscoveryArc, envelope: SearchEnvelope,
                 eligibility: EligibilityContract, hostile: HostileInterpretation):
        arc.contract.validate(); envelope.validate(); eligibility.validate(); hostile.validate()
        self.arc = arc
        self.envelope = envelope
        self.eligibility = eligibility
        self.hostile = hostile
        self.revision = 1
        self.current_stage = "contract"
        self.contract_digest = ""
        self.contract_frozen_by = ""
        self.contract_frozen_at = 0.0
        self.search_plans = {lane: LaneSearchPlan(lane) for lane in LANES}
        self.screening: Dict[str, ScreeningDecision] = {}
        self.lineages: Dict[str, EvidenceLineageProfile] = {}
        self.decompositions: Dict[str, DecompositionPass] = {}
        self.decomposition_disagreements: Dict[str, DecompositionDisagreement] = {}
        self.abstraction_registrations: Dict[str, AbstractionRegistration] = {}
        self.candidates: Dict[str, ArenaCandidate] = {}
        self.pareto_dimensions: Dict[str, ParetoDimension] = {}
        self.pareto_assessments: Dict[str, ParetoAssessment] = {}
        self.test_pairs: Dict[str, AdversarialTestPair] = {}
        self.saturation_waves: Dict[str, DecisionSaturationWave] = {}
        self.contacts: Dict[str, ContactRecord] = {}
        self.approvals: List[AdversarialApprovalRecord] = []
        self.work_queue: Dict[str, AdversarialWorkItem] = {}
        self.superseded_ids: set[str] = set()
        self.invalidated_ids: set[str] = set()
        self.test_plan_digest = ""
        self.test_plan_frozen_by = ""
        self.test_plan_frozen_at = 0.0
        self.audit = EventLog()
        self.enqueue("contract", "freeze constructive and hostile contracts", priority=100.0)
        self.audit.append("arc5a_created", {
            "arc_id": arc.arc_id,
            "hostile": asdict(hostile),
            "envelope": asdict(envelope),
            "eligibility": asdict(eligibility),
        })

    # ------------------------------- lifecycle and contracts
    def contract_material(self) -> dict:
        return {
            "posiwid": asdict(self.arc.contract),
            "hostile": asdict(self.hostile),
            "eligibility": asdict(self.eligibility),
            "envelope": asdict(self.envelope),
        }

    def freeze_contracts(self, actor: str) -> str:
        if not actor.strip():
            raise ValueError("contract freeze requires actor")
        if self.contract_digest:
            if not self.verify_contracts():
                raise RuntimeError("frozen ARC-5A contract was mutated")
            return self.contract_digest
        self.contract_digest = _digest(self.contract_material())
        self.contract_frozen_by = actor
        self.contract_frozen_at = time.time()
        self.audit.append("contracts_frozen", {"actor": actor, "digest": self.contract_digest})
        return self.contract_digest

    def verify_contracts(self) -> bool:
        return bool(self.contract_digest) and _digest(self.contract_material()) == self.contract_digest

    # ------------------------------- search planning and execution records
    def add_search_requirement(self, requirement: LaneSearchRequirement) -> str:
        if not self.verify_contracts():
            raise RuntimeError("freeze contracts before search planning")
        rid = self.search_plans[requirement.lane].add(requirement)
        self.audit.append("arc5a_search_requirement_added", asdict(requirement))
        return rid

    def seed_concrete_plans(self, constructive_author: str, destructive_author: str) -> dict:
        if self.current_stage != "concrete":
            raise RuntimeError("concrete plans may only be seeded in concrete stage")
        if constructive_author.strip().lower() == destructive_author.strip().lower():
            raise ValueError("constructive and destructive plans require independent authors")
        target = self.arc.contract.target
        current = "; ".join(self.arc.contract.local_current + self.arc.contract.whole_current)
        goal = "; ".join(self.arc.contract.local_goal + self.arc.contract.whole_goal)
        constructive = (
            (f"{target} best deployed systems measured performance", "for", "deployed"),
            (f"{target} strongest research results mechanism evaluation", "for", "research"),
            (f"{target} standards reference architectures interoperability", "for", "standards"),
            (f"mechanisms producing observable effect {goal}", "for", "goal-effect"),
            (f"systems improving current effect {current} toward {goal}", "for", "transition"),
            (f"{target} comparative benchmark strongest alternatives", "for", "comparison"),
        )
        destructive = (
            (f"{target} failed deployments postmortem negative results", "failure", "failure"),
            (f"{target} impossibility lower bounds undecidability", "boundary", "impossibility"),
            (f"{target} replication failure benchmark gaming hidden labor", "against", "replication"),
            (f"simpler substitutes making {target} unnecessary", "null", "simplifier"),
            (f"{target} security failure authority leakage whole system harm", "failure", "harm"),
            (f"alternative decomposition where {target} problem disappears", "counterexample", "reframe"),
        )
        result = {"concrete_constructive": [], "concrete_destructive": []}
        for text, polarity, category in constructive:
            result["concrete_constructive"].append(self.add_search_requirement(
                LaneSearchRequirement("concrete_constructive", text, polarity, category, 0,
                                      domain_family="concrete-problem", author=constructive_author,
                                      rationale="independent strongest constructive field")))
        for text, polarity, category in destructive:
            result["concrete_destructive"].append(self.add_search_requirement(
                LaneSearchRequirement("concrete_destructive", text, polarity, category, 0,
                                      domain_family="concrete-problem", author=destructive_author,
                                      rationale="independent strongest destructive field")))
        return {k: tuple(v) for k, v in result.items()}

    def seed_followups(self, lane: str, wave: int, author: str) -> Tuple[str, ...]:
        if lane not in LANES:
            raise ValueError("invalid lane")
        plan = self.search_plans[lane]
        if plan.frozen:
            raise RuntimeError("plan is frozen")
        if wave < 1:
            raise ValueError("wave must be positive")
        roots = [x for x in plan.requirements.values() if x.wave == wave - 1]
        if not roots:
            raise RuntimeError("no parent requirements")
        target = self.arc.contract.target
        if lane in {"concrete_constructive", "abstract_function"}:
            rows = (
                ("replication", f"independent replication of strongest mechanism for {target}", "for"),
                ("boundary", f"operating envelope and scale limits of strongest mechanism for {target}", "boundary"),
                ("comparison", f"head to head comparison strongest mechanism versus alternatives for {target}", "for"),
                ("hidden_work", f"hidden external work and maintenance cost in successful {target} systems", "failure"),
            )
        else:
            rows = (
                ("contradiction", f"evidence contradicting strongest claims for {target}", "against"),
                ("success_without", f"successful systems without proposed mechanism for {target}", "counterexample"),
                ("failure_with", f"failed systems containing proposed mechanism for {target}", "failure"),
                ("simpler", f"simpler lower cost substitute for {target}", "null"),
                ("harm", f"whole system harms from locally successful {target} mechanism", "failure"),
            )
        root = sorted(roots, key=lambda x: x.rid)[0]
        ids = []
        for category, text, polarity in rows:
            ids.append(self.add_search_requirement(LaneSearchRequirement(
                lane, text, polarity, category, wave, domain_family=root.domain_family,
                parent_requirement_id=root.rid, rationale="compounding adversarial follow-up",
                author=author)))
        return tuple(ids)

    def register_abstraction(self, node: AbstractionNode, registration: AbstractionRegistration) -> str:
        if self.current_stage != "abstract":
            raise RuntimeError("abstractions may only be registered in abstract stage")
        node.validate(); registration.validate()
        aid = self.arc.add_abstraction(node)
        if registration.abstraction_id and registration.abstraction_id != aid:
            raise ValueError("registration abstraction id mismatch")
        reg = AbstractionRegistration(
            registration.lane, aid, registration.thesis, registration.independent_author,
            registration.causal_question, registration.excluded_framings,
            registration.created_at, registration.reg_id)
        self.abstraction_registrations[reg.reg_id] = reg
        self.audit.append("arc5a_abstraction_registered", asdict(reg))
        return aid

    def seed_abstract_plans(self, function_author: str, counterfactual_author: str) -> dict:
        if self.current_stage != "abstract":
            raise RuntimeError("abstract plans may only be seeded in abstract stage")
        if function_author.strip().lower() == counterfactual_author.strip().lower():
            raise ValueError("abstraction search lanes require independent authors")
        result = {"abstract_function": [], "abstract_counterfactual": []}
        regs = list(self.abstraction_registrations.values())
        for lane, author in (("abstract_function", function_author),
                             ("abstract_counterfactual", counterfactual_author)):
            lane_regs = [r for r in regs if r.lane == lane]
            if not lane_regs:
                raise RuntimeError(f"no registered {lane} abstraction lattice")
            for reg in lane_regs:
                node = self.arc.abstractions[reg.abstraction_id]
                for domain in self.envelope.domain_families:
                    if lane == "abstract_function":
                        rows = (
                            ("analogue", f"{domain} systems achieving {node.retained_function} causal mechanism", "analogue"),
                            ("failure", f"{domain} failed systems attempting {node.retained_function}", "failure"),
                            ("boundary", f"{domain} scale and context boundaries for {node.retained_function}", "boundary"),
                            ("resource", f"{domain} hidden work relocated by {node.retained_function}", "failure"),
                        )
                    else:
                        rows = (
                            ("success_without", f"{domain} systems achieving target effect without {node.retained_function}", "counterexample"),
                            ("failure_with", f"{domain} systems containing {node.retained_function} but failing", "anti_analogue"),
                            ("alternate_abstraction", f"{domain} alternative abstraction of {self.arc.contract.target}", "against"),
                            ("reversal", f"{domain} contexts where {node.retained_function} reverses or harms outcome", "failure"),
                            ("monolith", f"{domain} homogeneous simpler system outperforming heterogeneous mechanism", "null"),
                        )
                    for category, text, polarity in rows:
                        result[lane].append(self.add_search_requirement(LaneSearchRequirement(
                            lane, text, polarity, category, 0, domain_family=domain,
                            abstraction_id=reg.abstraction_id, rationale=reg.causal_question,
                            author=author)))
        return {k: tuple(v) for k, v in result.items()}

    def freeze_search_plan(self, lane: str, actor: str) -> str:
        digest = self.search_plans[lane].freeze(actor)
        self.audit.append("arc5a_search_plan_frozen", {"lane": lane, "digest": digest, "actor": actor})
        return digest

    def mark_search_executed(self, rid: str, query_id: str, evidence_count: int) -> None:
        req = self.requirement(rid)
        plan = self.search_plans[req.lane]
        if not plan.verify():
            raise RuntimeError("search plan not frozen or mutated")
        req.status = "executed"; req.query_id = query_id; req.evidence_count = int(evidence_count)
        self.audit.append("arc5a_search_executed", {"rid": rid, "qid": query_id, "evidence_count": evidence_count})

    def mark_search_failed(self, rid: str, reason: str) -> None:
        req = self.requirement(rid)
        req.status = "failed"; req.failure = reason
        self.audit.append("arc5a_search_failed", {"rid": rid, "reason": reason})

    # ------------------------------- evidence correlation
    def screen_evidence(self, decision: ScreeningDecision) -> str:
        decision.validate()
        if decision.evidence_id not in self.arc.evidence:
            raise KeyError("unknown evidence")
        self.screening[decision.evidence_id] = decision
        item = self.arc.evidence[decision.evidence_id]
        item.state = "screened_in" if decision.include else "screened_out"
        item.exclusion_reason = "" if decision.include else decision.reason
        self.audit.append("arc5a_evidence_screened", asdict(decision))
        return decision.sid

    def add_lineage(self, profile: EvidenceLineageProfile) -> str:
        profile.validate()
        if profile.evidence_id not in self.arc.evidence:
            raise KeyError("unknown evidence")
        self.lineages[profile.evidence_id] = profile
        self.audit.append("arc5a_lineage_added", asdict(profile))
        return profile.lid

    def independence_clusters(self, evidence_ids: Optional[Sequence[str]] = None) -> Tuple[Tuple[str, ...], ...]:
        ids = list(evidence_ids or [eid for eid, e in self.arc.evidence.items() if e.state == "screened_in"])
        parent = {eid: eid for eid in ids}
        def find(x: str) -> str:
            while parent[x] != x:
                parent[x] = parent[parent[x]]; x = parent[x]
            return x
        def union(a: str, b: str) -> None:
            ra, rb = find(a), find(b)
            if ra != rb: parent[rb] = ra
        roots = {}
        unknown = []
        for eid in ids:
            profile = self.lineages.get(eid)
            values = profile.roots() if profile else ()
            if not values:
                unknown.append(eid)
            for root in values:
                roots.setdefault(root, []).append(eid)
        for members in roots.values():
            for other in members[1:]: union(members[0], other)
        if len(unknown) > 1:
            for other in unknown[1:]: union(unknown[0], other)
        groups: Dict[str, List[str]] = {}
        for eid in ids: groups.setdefault(find(eid), []).append(eid)
        return tuple(tuple(sorted(v)) for v in sorted(groups.values(), key=lambda x: tuple(sorted(x))))

    # ------------------------------- dual decomposition
    def add_decomposition(self, row: DecompositionPass) -> str:
        if self.current_stage != "expose":
            raise RuntimeError("decomposition may only occur in expose stage")
        row.validate(); self.decompositions[row.did] = row
        self.audit.append("arc5a_decomposition_added", asdict(row)); return row.did

    def add_decomposition_disagreement(self, row: DecompositionDisagreement) -> str:
        row.validate()
        modes = {self.decompositions[row.goal_pass_id].mode, self.decompositions[row.failure_pass_id].mode}
        if modes != {"goal_backward", "failure_forward"}:
            raise ValueError("disagreement must compare opposing decomposition modes")
        self.decomposition_disagreements[row.xid] = row
        self.audit.append("arc5a_decomposition_disagreement", asdict(row)); return row.xid

    # ------------------------------- arena and Pareto reduction
    def add_candidate(self, candidate: ArenaCandidate) -> str:
        if self.current_stage != "arena":
            raise RuntimeError("candidates may only be added in arena stage")
        candidate.validate()
        if any(c.role == candidate.role and c.state not in {"killed"} for c in self.candidates.values()):
            raise ValueError(f"active {candidate.role} candidate already exists")
        self.candidates[candidate.cid] = candidate
        self.audit.append("arc5a_candidate_added", asdict(candidate)); return candidate.cid

    def add_pareto_dimension(self, dimension: ParetoDimension) -> str:
        dimension.validate()
        if any(d.name == dimension.name for d in self.pareto_dimensions.values()):
            raise ValueError("duplicate Pareto dimension")
        self.pareto_dimensions[dimension.did] = dimension
        self.audit.append("arc5a_pareto_dimension_added", asdict(dimension)); return dimension.did

    def add_pareto_assessment(self, assessment: ParetoAssessment) -> str:
        assessment.validate()
        if assessment.candidate_id not in self.candidates:
            raise KeyError("unknown candidate")
        names = {d.name for d in self.pareto_dimensions.values()}
        if set(assessment.values) != names:
            raise ValueError("assessment must cover every frozen Pareto dimension")
        self.pareto_assessments[assessment.candidate_id] = assessment
        self.audit.append("arc5a_pareto_assessment_added", asdict(assessment)); return assessment.aid

    def compute_pareto_frontier(self) -> dict:
        dimensions = {d.name: d.direction for d in self.pareto_dimensions.values()}
        if not dimensions:
            raise RuntimeError("no Pareto dimensions")
        active = [c for c in self.candidates.values() if c.state not in {"killed"}]
        if any(c.cid not in self.pareto_assessments for c in active):
            raise RuntimeError("every active candidate requires an assessment")
        dominated = set()
        for a in active:
            av = self.pareto_assessments[a.cid].values
            for b in active:
                if a.cid == b.cid: continue
                bv = self.pareto_assessments[b.cid].values
                no_worse = True; strictly_better = False
                for name, direction in dimensions.items():
                    if direction == "max":
                        no_worse &= float(bv[name]) >= float(av[name])
                        strictly_better |= float(bv[name]) > float(av[name])
                    else:
                        no_worse &= float(bv[name]) <= float(av[name])
                        strictly_better |= float(bv[name]) < float(av[name])
                if no_worse and strictly_better:
                    dominated.add(a.cid); break
        frontier = []
        for c in active:
            c.state = "dominated" if c.cid in dominated else "frontier"
            if c.state == "frontier": frontier.append(c.cid)
        self.audit.append("arc5a_pareto_computed", {"frontier": frontier, "dominated": sorted(dominated)})
        return {"frontier": tuple(sorted(frontier)), "dominated": tuple(sorted(dominated))}

    def add_saturation_wave(self, row: DecisionSaturationWave) -> str:
        row.validate(); self.saturation_waves[row.sid] = row
        self.audit.append("arc5a_saturation_wave", asdict(row)); return row.sid

    def decision_saturated(self) -> bool:
        rows = sorted(self.saturation_waves.values(), key=lambda x: (x.wave, x.created_at))
        return len(rows) >= 2 and not rows[-1].changed_decision_space and not rows[-2].changed_decision_space

    # ------------------------------- dual-authored tests and contact
    @staticmethod
    def _test_definition(test: TestObligation) -> dict:
        return {
            "tid": test.tid, "target_type": test.target_type, "target_id": test.target_id,
            "question": test.question, "method": test.method,
            "outcome_if_a": test.outcome_if_a, "outcome_if_b": test.outcome_if_b,
            "contact_type": test.contact_type, "independence_group": test.independence_group,
            "expected_information_gain": test.expected_information_gain,
            "downstream_impact": test.downstream_impact, "contact_quality": test.contact_quality,
            "cost": dict(test.cost), "reversible": test.reversible,
            "public_surface": test.public_surface, "evidence_ids": list(test.evidence_ids),
        }

    def add_test(self, test: TestObligation) -> str:
        if self.test_plan_digest:
            raise RuntimeError("test plan is frozen")
        if self.current_stage != "arena":
            raise RuntimeError("tests may only be authored in arena stage")
        test.validate()
        if test.target_id in self.candidates:
            self.arc.tests[test.tid] = test
            self.arc.audit.append("arc5a_candidate_test_added", asdict(test))
            return test.tid
        return self.arc.add_test(test)

    def pair_tests(self, pair: AdversarialTestPair) -> str:
        pair.validate()
        if pair.candidate_id not in self.candidates:
            raise KeyError("unknown candidate")
        if pair.champion_test_id not in self.arc.tests or pair.adversarial_test_id not in self.arc.tests:
            raise KeyError("test pair references unknown test")
        self.test_pairs[pair.candidate_id] = pair
        self.audit.append("arc5a_test_pair_added", asdict(pair)); return pair.pid

    def test_plan_material(self) -> list[dict]:
        rows = []
        for cid in sorted(self.test_pairs):
            p = self.test_pairs[cid]
            rows.append({
                "pair": asdict(p),
                "champion": self._test_definition(self.arc.tests[p.champion_test_id]),
                "adversarial": self._test_definition(self.arc.tests[p.adversarial_test_id]),
            })
        return rows

    def freeze_tests(self, actor: str) -> str:
        gate = self.arena_gate()
        if not gate.passed:
            raise RuntimeError("arena gate has not passed: " + "; ".join(gate.reasons))
        if not self.decision_saturated():
            raise RuntimeError("decision space has not reached saturation")
        if self.test_plan_digest:
            if not self.verify_test_plan():
                raise RuntimeError("frozen test plan was mutated")
            return self.test_plan_digest
        self.test_plan_digest = _digest(self.test_plan_material())
        self.test_plan_frozen_by = actor; self.test_plan_frozen_at = time.time()
        self.audit.append("arc5a_tests_frozen", {"actor": actor, "digest": self.test_plan_digest})
        return self.test_plan_digest

    def verify_test_plan(self) -> bool:
        return bool(self.test_plan_digest) and _digest(self.test_plan_material()) == self.test_plan_digest

    def record_contact(self, row: ContactRecord, *, failure_layer: str = "") -> Optional[str]:
        row.validate()
        if self.current_stage != "contact" or not self.verify_test_plan():
            raise RuntimeError("contact requires approved contact stage and valid frozen tests")
        pair = self.test_pairs.get(row.candidate_id)
        if not pair:
            raise KeyError("candidate has no test pair")
        expected = pair.champion_test_id if row.kind == "champion" else pair.adversarial_test_id
        if row.test_id != expected:
            raise ValueError("contact kind does not match paired test")
        self.contacts[row.rid] = row
        test = self.arc.tests[row.test_id]
        test.state = row.state; test.observed = row.observed; test.evidence_ids = row.evidence_ids
        self.audit.append("arc5a_contact_recorded", asdict(row))
        if row.state == "failed" and failure_layer:
            return self.reopen_for_failure(failure_layer, row.observed)
        self.update_candidate_state(row.candidate_id)
        return None

    def update_candidate_state(self, candidate_id: str) -> str:
        c = self.candidates[candidate_id]
        pair = self.test_pairs[candidate_id]
        records = {r.kind: r for r in self.contacts.values() if r.candidate_id == candidate_id}
        if set(records) != {"champion", "adversarial"}:
            c.state = "unresolved"; return c.state
        champion, attack = records["champion"], records["adversarial"]
        if champion.state == "passed" and attack.state == "passed":
            c.state = "surviving"
        elif champion.state == "failed" or attack.state == "failed":
            c.state = "killed"
        else:
            c.state = "unresolved"
        return c.state

    def reopen_for_failure(self, layer: str, reason: str) -> str:
        stage = self.FAILURE_STAGE.get(layer, "contact")
        self.current_stage = stage
        # Cancel downstream queue and invalidate products; preserve history.
        order = {s: i for i, s in enumerate(STAGES)}
        for w in self.work_queue.values():
            if order.get(w.stage, 99) >= order[stage] and w.state in {"queued", "active", "blocked"}:
                w.state = "cancelled"
        if order[stage] <= order["arena"]:
            self.invalidated_ids.update(self.candidates)
            self.invalidated_ids.update(self.pareto_assessments)
            self.invalidated_ids.update(self.test_pairs)
            self.test_plan_digest = ""; self.test_plan_frozen_by = ""; self.test_plan_frozen_at = 0.0
        self.enqueue(stage, f"rework after {layer} failure: {reason}", priority=100.0)
        self.audit.append("arc5a_stage_reopened", {"stage": stage, "layer": layer, "reason": reason})
        return stage

    # ------------------------------- gates and human queue
    def coverage_gate(self, lane: str) -> StageGate:
        plan = self.search_plans[lane]
        reasons = []
        if not plan.verify(): reasons.append("plan is not frozen or digest-valid")
        planned = list(plan.requirements.values())
        if not planned: reasons.append("empty plan")
        pending = [x.rid for x in planned if x.status == "planned"]
        failed = [x.rid for x in planned if x.status == "failed"]
        if pending: reasons.append(f"{len(pending)} searches remain unexecuted")
        if failed: reasons.append(f"{len(failed)} searches failed")
        evidence_ids = []
        for req in planned:
            if req.query_id:
                evidence_ids.extend(e.eid for e in self.arc.evidence.values()
                                    if e.query_id == req.query_id and e.state == "screened_in")
        clusters = self.independence_clusters(evidence_ids)
        if len(clusters) < self.envelope.min_independent_groups:
            reasons.append(f"only {len(clusters)} independent causal lineages")
        waves = {x.wave for x in planned if x.evidence_count > 0}
        if len(waves) < self.envelope.min_search_waves:
            reasons.append(f"only {len(waves)} evidence-bearing waves")
        categories = {x.category for x in planned if x.status == "executed"}
        return StageGate(lane, not reasons, tuple(reasons), {
            "requirements": len(planned), "evidence": len(evidence_ids),
            "independent_lineages": len(clusters), "waves": sorted(waves),
            "categories": sorted(categories),
        })

    def contract_gate(self) -> StageGate:
        reasons = []
        if not self.verify_contracts(): reasons.append("constructive/hostile contracts not frozen or mutated")
        if self.hostile.author.strip().lower() == self.contract_frozen_by.strip().lower():
            reasons.append("hostile interpretation must be independently authored from freeze authority")
        return StageGate("contract", not reasons, tuple(reasons), {
            "contract_digest": self.contract_digest,
            "hostile_author": self.hostile.author,
            "freeze_actor": self.contract_frozen_by,
        })

    def concrete_gate(self) -> StageGate:
        gates = [self.coverage_gate("concrete_constructive"), self.coverage_gate("concrete_destructive")]
        reasons = [f"{g.stage}: {r}" for g in gates for r in g.reasons]
        authors = {req.author.strip().lower() for lane in ("concrete_constructive", "concrete_destructive")
                   for req in self.search_plans[lane].requirements.values()}
        if len(authors) < 2: reasons.append("constructive and destructive field models lack independent authorship")
        return StageGate("concrete", not reasons, tuple(reasons), {"lanes": [asdict(g) for g in gates]})

    def expose_gate(self) -> StageGate:
        reasons = []
        modes = {d.mode for d in self.decompositions.values() if d.did not in self.invalidated_ids}
        if modes != {"goal_backward", "failure_forward"}: reasons.append("both decomposition modes are required")
        authors = {d.author.strip().lower() for d in self.decompositions.values() if d.did not in self.invalidated_ids}
        if len(authors) < 2: reasons.append("decomposition modes require independent authors")
        if not self.decomposition_disagreements: reasons.append("at least one decomposition disagreement is required")
        return StageGate("expose", not reasons, tuple(reasons), {
            "modes": sorted(modes), "authors": sorted(authors),
            "disagreements": len(self.decomposition_disagreements),
        })

    def abstract_gate(self) -> StageGate:
        gates = [self.coverage_gate("abstract_function"), self.coverage_gate("abstract_counterfactual")]
        reasons = [f"{g.stage}: {r}" for g in gates for r in g.reasons]
        lanes = {r.lane for r in self.abstraction_registrations.values()}
        if lanes != {"abstract_function", "abstract_counterfactual"}:
            reasons.append("two independently authored abstraction lattices are required")
        authors = {r.independent_author.strip().lower() for r in self.abstraction_registrations.values()}
        if len(authors) < 2: reasons.append("abstraction lattices lack independent authorship")
        return StageGate("abstract", not reasons, tuple(reasons), {
            "lanes": [asdict(g) for g in gates], "registrations": len(self.abstraction_registrations),
        })

    def arena_gate(self) -> StageGate:
        reasons = []
        active = [c for c in self.candidates.values() if c.cid not in self.invalidated_ids]
        roles = {c.role for c in active}
        missing = ROLES - roles
        if missing: reasons.append("missing strongest-selection roles: " + ", ".join(sorted(missing)))
        if len(active) != len(roles): reasons.append("arena contains duplicate active roles")
        if len(self.pareto_dimensions) < 5: reasons.append("at least five independent Pareto dimensions are required")
        missing_assessments = [c.cid for c in active if c.cid not in self.pareto_assessments]
        if missing_assessments: reasons.append("all candidates require Pareto assessment")
        missing_pairs = [c.cid for c in active if c.cid not in self.test_pairs]
        if missing_pairs: reasons.append("all candidates require champion/adversarial tests")
        if not self.decision_saturated(): reasons.append("decision saturation requires two unchanged waves")
        return StageGate("arena", not reasons, tuple(reasons), {
            "roles": sorted(roles), "dimensions": len(self.pareto_dimensions),
            "assessments": len(self.pareto_assessments), "pairs": len(self.test_pairs),
            "decision_saturated": self.decision_saturated(),
        })

    def contact_gate(self) -> StageGate:
        reasons = []
        if not self.verify_test_plan(): reasons.append("test plan is not frozen or was mutated")
        active = [c for c in self.candidates.values() if c.cid not in self.invalidated_ids]
        for c in active:
            kinds = {r.kind for r in self.contacts.values() if r.candidate_id == c.cid}
            if kinds != {"champion", "adversarial"}:
                reasons.append(f"candidate {c.cid} lacks both contact types")
        survivors = [c.cid for c in active if c.state == "surviving"]
        unresolved = [c.cid for c in active if c.state in {"candidate", "frontier", "unresolved"}]
        if unresolved: reasons.append(f"{len(unresolved)} candidates remain unresolved")
        return StageGate("contact", not reasons, tuple(reasons), {
            "contacts": len(self.contacts), "survivors": survivors,
            "killed": [c.cid for c in active if c.state == "killed"],
        })

    def stage_gate(self, stage: str) -> StageGate:
        return {
            "contract": self.contract_gate,
            "concrete": self.concrete_gate,
            "expose": self.expose_gate,
            "abstract": self.abstract_gate,
            "arena": self.arena_gate,
            "contact": self.contact_gate,
            "complete": self.contact_gate,
        }[stage]()

    def approve(self, stage: str, decision: str, actor: str, rationale: str) -> AdversarialApprovalRecord:
        if stage != self.current_stage:
            raise RuntimeError(f"cannot approve {stage} while at {self.current_stage}")
        if decision not in {"approve", "hold", "reopen", "reject"}:
            raise ValueError("invalid approval decision")
        record = AdversarialApprovalRecord(stage, decision, actor, rationale, _digest(asdict(self.stage_gate(stage))))
        record.validate(); self.approvals.append(record)
        if decision == "approve":
            gate = self.stage_gate(stage)
            if not gate.passed:
                raise RuntimeError("stage gate has not passed: " + "; ".join(gate.reasons))
            next_stage = STAGES[min(STAGES.index(stage) + 1, len(STAGES) - 1)]
            self._complete_stage_items(stage); self.current_stage = next_stage
            if next_stage != "complete": self.enqueue(next_stage, f"perform {next_stage} stage", priority=90.0)
        elif decision in {"reopen", "reject"}:
            self.reopen_for_failure(stage if stage != "contract" else "goal", rationale)
        self.audit.append("arc5a_human_decision", asdict(record)); return record

    def enqueue(self, stage: str, reason: str, *, priority: float = 1.0) -> str:
        item = AdversarialWorkItem(stage, reason, priority=priority); item.validate(); self.work_queue[item.wid] = item
        return item.wid

    def _complete_stage_items(self, stage: str) -> None:
        for w in self.work_queue.values():
            if w.stage == stage and w.state in {"queued", "active", "blocked"}: w.state = "done"

    def next_work(self) -> Optional[AdversarialWorkItem]:
        rows = [w for w in self.work_queue.values() if w.state == "queued"]
        return sorted(rows, key=lambda x: (-x.priority, x.created_at))[0] if rows else None

    # ------------------------------- persistence and status
    def process_posiwid(self) -> dict:
        frontier = [c.cid for c in self.candidates.values() if c.state in {"frontier", "surviving"}]
        return {
            "arc_id": self.arc.arc_id,
            "revision": self.revision,
            "current_stage": self.current_stage,
            "search_lanes": {lane: {
                "requirements": len(plan.requirements), "frozen": plan.frozen,
                "digest_valid": plan.verify() if plan.frozen else False,
                "executed": sum(1 for x in plan.requirements.values() if x.status == "executed"),
            } for lane, plan in self.search_plans.items()},
            "decompositions": {mode: sum(1 for d in self.decompositions.values() if d.mode == mode)
                               for mode in ("goal_backward", "failure_forward")},
            "abstraction_lattices": {lane: sum(1 for r in self.abstraction_registrations.values() if r.lane == lane)
                                     for lane in ("abstract_function", "abstract_counterfactual")},
            "arena_roles": {role: sum(1 for c in self.candidates.values() if c.role == role)
                            for role in sorted(ROLES)},
            "pareto_frontier": frontier,
            "decision_saturated": self.decision_saturated(),
            "test_plan_frozen": bool(self.test_plan_digest),
            "contacts": len(self.contacts),
            "next_work": asdict(self.next_work()) if self.next_work() else None,
            "contract_valid": self.verify_contracts(),
            "audit_valid": self.audit.verify().get("valid", False),
        }

    def status(self) -> dict:
        return {
            "process": self.process_posiwid(),
            "gates": [asdict(self.stage_gate(s)) for s in STAGES],
            "approvals": [asdict(x) for x in self.approvals],
            "search_plans": {lane: {
                "frozen": p.frozen, "digest_valid": p.verify() if p.frozen else False,
                "requirements": [asdict(x) for x in p.requirements.values()],
            } for lane, p in self.search_plans.items()},
            "decomposition_disagreements": [asdict(x) for x in self.decomposition_disagreements.values()],
            "candidates": [asdict(x) for x in self.candidates.values()],
            "saturation": [asdict(x) for x in self.saturation_waves.values()],
            "contacts": [asdict(x) for x in self.contacts.values()],
        }

    def to_dict(self) -> dict:
        return {
            "arc": self.arc.to_dict(), "envelope": asdict(self.envelope),
            "eligibility": asdict(self.eligibility), "hostile": asdict(self.hostile),
            "revision": self.revision, "current_stage": self.current_stage,
            "contract_digest": self.contract_digest, "contract_frozen_by": self.contract_frozen_by,
            "contract_frozen_at": self.contract_frozen_at,
            "search_plans": {lane: {
                "lane": p.lane, "requirements": [asdict(x) for x in p.requirements.values()],
                "frozen_digest": p.frozen_digest, "frozen_at": p.frozen_at, "frozen_by": p.frozen_by,
            } for lane, p in self.search_plans.items()},
            "screening": [asdict(x) for x in self.screening.values()],
            "lineages": [asdict(x) for x in self.lineages.values()],
            "decompositions": [asdict(x) for x in self.decompositions.values()],
            "decomposition_disagreements": [asdict(x) for x in self.decomposition_disagreements.values()],
            "abstraction_registrations": [asdict(x) for x in self.abstraction_registrations.values()],
            "candidates": [asdict(x) for x in self.candidates.values()],
            "pareto_dimensions": [asdict(x) for x in self.pareto_dimensions.values()],
            "pareto_assessments": [asdict(x) for x in self.pareto_assessments.values()],
            "test_pairs": [asdict(x) for x in self.test_pairs.values()],
            "saturation_waves": [asdict(x) for x in self.saturation_waves.values()],
            "contacts": [asdict(x) for x in self.contacts.values()],
            "approvals": [asdict(x) for x in self.approvals],
            "work_queue": [asdict(x) for x in self.work_queue.values()],
            "superseded_ids": sorted(self.superseded_ids), "invalidated_ids": sorted(self.invalidated_ids),
            "test_plan_digest": self.test_plan_digest, "test_plan_frozen_by": self.test_plan_frozen_by,
            "test_plan_frozen_at": self.test_plan_frozen_at, "audit": self.audit.to_dict(),
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "ARC5AAdversarialKernel":
        eraw = dict(raw["envelope"])
        for key in ("domain_families", "concrete_polarities", "abstract_polarities", "required_followup_categories"):
            eraw[key] = tuple(eraw.get(key, ()))
        eligibility_raw = dict(raw["eligibility"])
        for key in ("inclusion_rules", "exclusion_rules", "source_classes", "languages"):
            eligibility_raw[key] = tuple(eligibility_raw.get(key, ()))
        hraw = dict(raw["hostile"])
        for key in ("target_may_be_unreal", "alternative_goals", "impossibility_or_unnecessity",
                    "whole_system_harms", "simpler_problem_substitutes", "disconfirming_observations"):
            hraw[key] = tuple(hraw.get(key, ()))
        obj = cls(DiscoveryArc.from_dict(raw["arc"]), SearchEnvelope(**eraw),
                  EligibilityContract(**eligibility_raw), HostileInterpretation(**hraw))
        obj.revision = int(raw.get("revision", 1)); obj.current_stage = str(raw.get("current_stage", "contract"))
        obj.contract_digest = str(raw.get("contract_digest", "")); obj.contract_frozen_by = str(raw.get("contract_frozen_by", "")); obj.contract_frozen_at = float(raw.get("contract_frozen_at", 0.0))
        obj.search_plans = {}
        for lane, prow in dict(raw.get("search_plans", {})).items():
            p = LaneSearchPlan(str(prow.get("lane", lane)))
            for row in prow.get("requirements", []):
                x = LaneSearchRequirement(**dict(row)); p.requirements[x.rid] = x
            p.frozen_digest = str(prow.get("frozen_digest", "")); p.frozen_at = float(prow.get("frozen_at", 0.0)); p.frozen_by = str(prow.get("frozen_by", "")); obj.search_plans[str(lane)] = p
        for lane in LANES: obj.search_plans.setdefault(lane, LaneSearchPlan(lane))
        obj.screening = {}
        for row in raw.get("screening", []):
            d = dict(row); d["criteria"] = tuple(d.get("criteria", ())); x = ScreeningDecision(**d); obj.screening[x.evidence_id] = x
        obj.lineages = {}
        for row in raw.get("lineages", []):
            d = dict(row)
            for key in ("study_ids", "dataset_ids", "model_families", "institutions", "author_groups", "funding_sources", "raw_source_ids", "other_roots"): d[key] = tuple(d.get(key, ()))
            x = EvidenceLineageProfile(**d); obj.lineages[x.evidence_id] = x
        for attr, cls_, tuple_keys, key_attr in (
            ("decompositions", DecompositionPass, ("starting_observations", "causal_steps", "interfaces", "hidden_resources_or_authority", "predicted_failure_propagation", "evidence_ids"), "did"),
            ("decomposition_disagreements", DecompositionDisagreement, (), "xid"),
            ("abstraction_registrations", AbstractionRegistration, ("excluded_framings",), "reg_id"),
            ("candidates", ArenaCandidate, ("mechanism_ids", "composition", "local_posiwid", "whole_posiwid", "assumptions", "resource_relocations", "failure_modes", "security_authority_consequences", "support_evidence_ids", "attack_evidence_ids"), "cid"),
            ("pareto_dimensions", ParetoDimension, (), "did"),
            ("pareto_assessments", ParetoAssessment, ("evidence_ids",), "candidate_id"),
            ("test_pairs", AdversarialTestPair, (), "candidate_id"),
            ("saturation_waves", DecisionSaturationWave, ("evidence_ids",), "sid"),
            ("contacts", ContactRecord, ("evidence_ids",), "rid"),
        ):
            mapping = {}
            for row in raw.get(attr, []):
                d = dict(row)
                for key in tuple_keys: d[key] = tuple(d.get(key, ()))
                x = cls_(**d); mapping[getattr(x, key_attr)] = x
            setattr(obj, attr, mapping)
        obj.approvals = [AdversarialApprovalRecord(**dict(x)) for x in raw.get("approvals", [])]
        obj.work_queue = {}
        for row in raw.get("work_queue", []):
            d = dict(row); d["blocked_by"] = tuple(d.get("blocked_by", ())); x = AdversarialWorkItem(**d); obj.work_queue[x.wid] = x
        obj.superseded_ids = set(raw.get("superseded_ids", ())); obj.invalidated_ids = set(raw.get("invalidated_ids", ()))
        obj.test_plan_digest = str(raw.get("test_plan_digest", "")); obj.test_plan_frozen_by = str(raw.get("test_plan_frozen_by", "")); obj.test_plan_frozen_at = float(raw.get("test_plan_frozen_at", 0.0))
        obj.audit = EventLog.from_dict(raw.get("audit", {}))
        return obj

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True, default=str))

    @classmethod
    def load(cls, path: str | Path) -> "ARC5AAdversarialKernel":
        return cls.from_dict(json.loads(Path(path).read_text()))

    def verify(self) -> dict:
        errors = []
        if self.contract_digest and not self.verify_contracts(): errors.append("contract digest mismatch")
        for lane, plan in self.search_plans.items():
            if plan.frozen and not plan.verify(): errors.append(f"{lane} search digest mismatch")
        if self.test_plan_digest and not self.verify_test_plan(): errors.append("test plan digest mismatch")
        aa = self.arc.audit.verify(); ka = self.audit.verify()
        if not aa.get("valid", False): errors.append("arc audit invalid")
        if not ka.get("valid", False): errors.append("kernel audit invalid")
        return {"valid": not errors, "errors": errors, "arc_audit": aa, "kernel_audit": ka,
                "revision": self.revision, "invalidated_ids": len(self.invalidated_ids)}

    def requirement(self, rid: str) -> LaneSearchRequirement:
        for plan in self.search_plans.values():
            if rid in plan.requirements: return plan.requirements[rid]
        raise KeyError("unknown search requirement")
