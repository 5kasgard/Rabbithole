"""Dependency-aware invalidation, revalidation, and blast-radius accounting."""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Tuple


def _id(prefix: str = "DEP") -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


@dataclass
class DependencyEdge:
    source: str
    target: str
    relation: str
    reversible: bool = True
    edge_id: str = field(default_factory=_id)


@dataclass
class Invalidation:
    root: str
    affected: Tuple[str, ...]
    reason: str
    actor: str = ""
    created_at: float = field(default_factory=time.time)
    invalidation_id: str = field(default_factory=lambda: _id("INV"))


class DependencyField:
    def __init__(self):
        self.edges: Dict[str, DependencyEdge] = {}
        self.invalid_roots: Dict[str, str] = {}
        self.history: list[Invalidation] = []

    def add(self, edge: DependencyEdge) -> str:
        if not edge.source or not edge.target or edge.source == edge.target:
            raise ValueError("dependency endpoints must be distinct and non-empty")
        self.edges[edge.edge_id] = edge
        return edge.edge_id

    def descendants(self, root: str) -> Tuple[str, ...]:
        out: set[str] = set()
        frontier = [root]
        while frontier:
            source = frontier.pop()
            for edge in self.edges.values():
                if edge.source == source and edge.target not in out:
                    out.add(edge.target)
                    frontier.append(edge.target)
        return tuple(sorted(out))

    def invalid_items(self) -> Tuple[str, ...]:
        affected = set()
        for root in self.invalid_roots:
            affected.add(root)
            affected.update(self.descendants(root))
        return tuple(sorted(affected))

    @property
    def invalid(self) -> set[str]:
        return set(self.invalid_items())

    def invalidate(self, root: str, reason: str, actor: str = "") -> Invalidation:
        if not reason.strip():
            raise ValueError("invalidation reason is required")
        self.invalid_roots[root] = reason
        affected = (root,) + self.descendants(root)
        rec = Invalidation(root, tuple(dict.fromkeys(affected)), reason, actor)
        self.history.append(rec)
        return rec

    def restore(self, root: str) -> Tuple[str, ...]:
        self.invalid_roots.pop(root, None)
        return self.invalid_items()

    def to_dict(self) -> dict:
        return {"edges": [asdict(e) for e in self.edges.values()],
                "invalid_roots": dict(self.invalid_roots),
                "history": [asdict(x) for x in self.history]}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "DependencyField":
        obj = cls()
        for row in raw.get("edges", []):
            obj.add(DependencyEdge(**dict(row)))
        obj.invalid_roots = {str(k): str(v) for k, v in dict(raw.get("invalid_roots", {})).items()}
        for row in raw.get("history", []):
            d = dict(row); d["affected"] = tuple(d.get("affected", ()))
            obj.history.append(Invalidation(**d))
        return obj
