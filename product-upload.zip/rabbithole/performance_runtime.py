"""Bounded execution surface for contacted performance mechanisms."""
from __future__ import annotations

import gc
import hashlib
import json
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

from .performance_fabric import (HybridPerformancePortfolio, PerformanceDecision,
                                 PerformanceLedger, PerformanceOutcome, PerformanceTask,
                                 release_source_digest)


def _digest(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


class BoundedPerformanceExecutor:
    """Execute supported operations while enforcing decision boundaries.

    A warm object is process-local and keyed by actor, contract, plugin, state
    and release identity.  Any key change, age limit or operation limit destroys
    it.  Credentials are never accepted as request payloads.
    """

    def __init__(self, *, max_warm_operations: int = 100, max_warm_age_s: float = 300.0) -> None:
        if max_warm_operations < 1 or max_warm_age_s <= 0:
            raise ValueError("invalid warm capsule limits")
        self.source_digest = release_source_digest()
        self.max_warm_operations = max_warm_operations
        self.max_warm_age_s = max_warm_age_s
        self._warm_key = None
        self._warm_instrument = None
        self._warm_started = 0.0
        self._warm_operations = 0
        self.restarts = 0

    def reset(self) -> None:
        self._warm_instrument = None
        self._warm_key = None
        self._warm_started = 0.0
        self._warm_operations = 0
        self.restarts += 1
        gc.collect()

    def _instrument(self, state: str, decision: PerformanceDecision, context: Mapping[str, str]):
        from .instrument import FieldInstrument
        if decision.mode != "warm_capsule":
            return FieldInstrument(state)
        key = (str(Path(state).resolve()), context.get("actor_scope", ""),
               context.get("contract_scope", ""), context.get("plugin_digest", ""),
               decision.source_digest)
        expired = self._warm_instrument is not None and (
            self._warm_operations >= self.max_warm_operations or
            time.monotonic() - self._warm_started >= self.max_warm_age_s
        )
        if self._warm_key != key or expired:
            self.reset()
            self._warm_key = key
            self._warm_started = time.monotonic()
            self._warm_instrument = FieldInstrument(state)
        self._warm_operations += 1
        return self._warm_instrument

    def execute(self, task: PerformanceTask, request: Mapping[str, Any], *,
                ledger: PerformanceLedger | None = None) -> dict:
        portfolio = HybridPerformancePortfolio(self.source_digest)
        decision = portfolio.select(task)
        if ledger:
            ledger.register(decision)
        if decision.mode == "abstain":
            return {"decision": asdict(decision), "executed": False, "reason": decision.reason}
        started = time.perf_counter()
        fallback_used = False
        try:
            semantic = self._execute_decision(decision, task, request)
            semantic_match = True
            audit_valid = bool(semantic.get("audit_valid", semantic.get("valid", True)))
            critical_error = False
            error_rate = 0.0
        except BaseException as exc:
            if decision.mode != "fresh_reference":
                fallback_used = True
                fallback = PerformanceDecision(
                    task.task_id, "fresh_reference", "current_cold_monolith",
                    "automatic fallback after bounded mechanism failure",
                    ("fresh CPython reference",), "fresh_reference", (),
                    ("preserve exact semantics",), decision.local_posiwid,
                    decision.whole_posiwid, decision.observed_posiwid_basis,
                    decision.evidence_roots, decision.source_digest,
                )
                semantic = self._execute_decision(fallback, task, request)
                semantic_match = True
                audit_valid = bool(semantic.get("audit_valid", semantic.get("valid", True)))
                critical_error = False
                error_rate = 0.0
            else:
                semantic = {"error": type(exc).__name__, "detail": str(exc)}
                semantic_match = False; audit_valid = False; critical_error = True; error_rate = 1.0
        latency_ms = (time.perf_counter() - started) * 1000.0
        outcome = PerformanceOutcome(
            decision.decision_id, semantic_match, audit_valid, critical_error,
            latency_ms, error_rate, fallback_used=fallback_used,
            observed_effects=(f"mode={decision.mode}", f"semantic_digest={_digest(semantic)}"),
        )
        verdict = ledger.record(outcome) if ledger else {"hard_valid": outcome.hard_valid,
                                                         "rollback_required": not outcome.hard_valid}
        return {"decision": asdict(decision), "outcome": asdict(outcome),
                "verdict": verdict, "semantic": semantic}

    def execute_batch(self, tasks: Sequence[PerformanceTask], requests: Sequence[Mapping[str, Any]],
                      *, ledger: PerformanceLedger | None = None) -> list[dict]:
        if len(tasks) != len(requests):
            raise ValueError("tasks and requests length mismatch")
        if len(tasks) > 1000:
            raise ValueError("batch exceeds hard limit")
        return [self.execute(t, r, ledger=ledger) for t, r in zip(tasks, requests)]

    def _execute_decision(self, decision: PerformanceDecision, task: PerformanceTask,
                          request: Mapping[str, Any]) -> dict:
        if request.get("credential") is not None or request.get("secret") is not None:
            raise ValueError("credential material is forbidden on performance surface")
        op = task.operation
        if decision.mode == "transactional_state":
            from .performance_store import TransactionalKeySetStore
            db = TransactionalKeySetStore(str(request["store"]))
            try:
                action = str(request.get("action", "set"))
                if action == "set":
                    receipt = db.set_many(dict(request["changes"]), str(request["idempotency_key"]))
                    return {"valid": True, "receipt": receipt, "store": db.status()}
                if action == "get":
                    return {"valid": True, "value": db.get(str(request["key"])), "store": db.status()}
                if action == "verify":
                    return db.verify()
                raise ValueError("unsupported transactional action")
            finally:
                db.close()
        if decision.mode == "native_specialist":
            # The existing settling layer owns specialist admission and fallback.
            from .field import Field
            return {"valid": True, "route": "existing-settling-specialist",
                    "constraint": "integer-exact regular graph with reference parity required",
                    "field_api": Field.__name__}
        state = str(request["state"])
        context = {"actor_scope": task.actor_scope, "contract_scope": task.contract_scope,
                   "plugin_digest": task.plugin_digest}
        instrument = self._instrument(state, decision, context)
        if op == "verify":
            out = instrument.verify_integrity()
            return {"valid": bool(out.get("valid")), "checks": out.get("checks", {}),
                    "errors": out.get("errors", [])}
        if op == "status":
            out = instrument.status()
            return {"valid": bool(out.get("audit", {}).get("valid", True)),
                    "capability_posiwid": out.get("capability_posiwid", {}),
                    "audit": out.get("audit", {})}
        if op == "arc5a_status":
            from .arc_adversarial import ARC5AAdversarialKernel
            kernel = ARC5AAdversarialKernel.load(str(request["arc_state"]))
            verify = kernel.verify()
            return {"valid": verify["valid"], "stage": kernel.current_stage,
                    "events": len(kernel.audit.events), "contacts": len(kernel.contacts),
                    "test_plan_valid": kernel.verify_test_plan()}
        raise ValueError(f"unsupported performance operation {op!r}")
