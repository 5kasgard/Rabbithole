"""Thin typed contract waist for The Field.

The waist is deliberately not a universal ontology.  It is an append-only,
content-addressed envelope shared by heterogeneous representations and organs.
It preserves the information needed to route, verify, invalidate, audit, and
replay objects without pretending that all domain semantics share one model.
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Optional, Sequence, Tuple


def _canon(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, default=str).encode("utf-8")


def _id(prefix: str = "OBJ") -> str:
    return f"{prefix}{uuid.uuid4().hex[:14]}"


OBJECT_TYPES = {
    "artifact", "representation", "carving", "observation", "claim",
    "hypothesis", "model", "goal", "constraint", "mapping",
    "transformation", "verification_contract", "test", "result",
    "decision", "action", "resource", "amendment", "revocation", "report",
}
STATUSES = {
    "proposed", "active", "supported", "falsified", "inconclusive",
    "untestable", "stale", "superseded", "revoked", "rejected", "failed",
}


@dataclass(frozen=True)
class ContractObject:
    logical_id: str
    version: int
    object_type: str
    payload: Mapping[str, object]
    scope: Mapping[str, object] = field(default_factory=dict)
    representation: str = ""
    uncertainty: Mapping[str, object] = field(default_factory=dict)
    dependency_ids: Tuple[str, ...] = ()
    alternative_ids: Tuple[str, ...] = ()
    independence_group: str = ""
    verification_contract: str = ""
    status: str = "proposed"
    authority_ceiling: float = 0.0
    applicability: Mapping[str, object] = field(default_factory=dict)
    permissions: Tuple[str, ...] = ()
    resource: Mapping[str, object] = field(default_factory=dict)
    valid_from: Optional[float] = None
    valid_to: Optional[float] = None
    created_at: float = field(default_factory=time.time)
    parent_digest: str = ""
    digest: str = ""

    def material(self) -> dict:
        d = asdict(self)
        d.pop("digest", None)
        return d

    def sealed(self) -> "ContractObject":
        if self.object_type not in OBJECT_TYPES:
            raise ValueError(f"unsupported object type {self.object_type!r}")
        if self.status not in STATUSES:
            raise ValueError(f"unsupported status {self.status!r}")
        if self.version < 1:
            raise ValueError("version must be positive")
        if not 0.0 <= self.authority_ceiling <= 1.0:
            raise ValueError("authority ceiling must be in [0,1]")
        if self.valid_from is not None and self.valid_to is not None and self.valid_to < self.valid_from:
            raise ValueError("valid_to precedes valid_from")
        digest = hashlib.sha256(_canon(self.material())).hexdigest()
        return ContractObject(**(self.material() | {"digest": digest}))

    def verify(self) -> bool:
        if not self.digest:
            return False
        return hashlib.sha256(_canon(self.material())).hexdigest() == self.digest


@dataclass(frozen=True)
class DependencyLink:
    source_id: str
    target_id: str
    relation: str
    created_at: float = field(default_factory=time.time)
    link_id: str = field(default_factory=lambda: _id("LNK"))


class ContractStore:
    """Append-only logical-object versions plus dependency invalidation.

    ``logical_id`` is stable across versions.  Nothing is overwritten; a new
    version or revocation is appended.  Dependencies refer to logical IDs so a
    retraction can identify every derived object.  This store proves integrity
    and derivation only, never truth.
    """

    def __init__(self):
        self.versions: Dict[str, list[ContractObject]] = {}
        self.links: Dict[str, DependencyLink] = {}

    def append(self, object_type: str, payload: Mapping[str, object], *,
               logical_id: str = "", scope: Optional[Mapping[str, object]] = None,
               representation: str = "", uncertainty: Optional[Mapping[str, object]] = None,
               dependency_ids: Sequence[str] = (), alternative_ids: Sequence[str] = (),
               independence_group: str = "", verification_contract: str = "",
               status: str = "proposed", authority_ceiling: float = 0.0,
               applicability: Optional[Mapping[str, object]] = None,
               permissions: Sequence[str] = (), resource: Optional[Mapping[str, object]] = None,
               valid_from: Optional[float] = None, valid_to: Optional[float] = None) -> ContractObject:
        lid = logical_id or _id("OBJ")
        history = self.versions.setdefault(lid, [])
        parent = history[-1].digest if history else ""
        obj = ContractObject(
            logical_id=lid, version=len(history) + 1, object_type=object_type,
            payload=dict(payload), scope=dict(scope or {}), representation=representation,
            uncertainty=dict(uncertainty or {}), dependency_ids=tuple(dependency_ids),
            alternative_ids=tuple(alternative_ids), independence_group=independence_group,
            verification_contract=verification_contract, status=status,
            authority_ceiling=authority_ceiling, applicability=dict(applicability or {}),
            permissions=tuple(permissions), resource=dict(resource or {}),
            valid_from=valid_from, valid_to=valid_to, parent_digest=parent,
        ).sealed()
        history.append(obj)
        for dep in dependency_ids:
            link = DependencyLink(str(dep), lid, "derived_from")
            self.links[link.link_id] = link
        return obj

    def current(self, logical_id: str) -> ContractObject:
        return self.versions[logical_id][-1]

    def history(self, logical_id: str) -> Tuple[ContractObject, ...]:
        return tuple(self.versions.get(logical_id, ()))

    def descendants(self, logical_id: str) -> Tuple[str, ...]:
        out: set[str] = set()
        frontier = [logical_id]
        while frontier:
            root = frontier.pop()
            for link in self.links.values():
                if link.source_id == root and link.target_id not in out:
                    out.add(link.target_id)
                    frontier.append(link.target_id)
        return tuple(sorted(out))

    def revoke(self, logical_id: str, reason: str, *, actor: str = "") -> Tuple[ContractObject, ...]:
        affected = (logical_id,) + self.descendants(logical_id)
        appended = []
        for lid in affected:
            if lid not in self.versions:
                continue
            current = self.current(lid)
            if current.status == "revoked":
                appended.append(current)
                continue
            appended.append(self.append(
                current.object_type,
                dict(current.payload) | {"revocation_reason": reason, "revoked_by": actor},
                logical_id=lid, scope=current.scope, representation=current.representation,
                uncertainty=current.uncertainty, dependency_ids=current.dependency_ids,
                alternative_ids=current.alternative_ids,
                independence_group=current.independence_group,
                verification_contract=current.verification_contract,
                status="revoked", authority_ceiling=0.0,
                applicability=current.applicability, permissions=current.permissions,
                resource=current.resource, valid_from=current.valid_from,
                valid_to=time.time(),
            ))
        return tuple(appended)

    def verify(self) -> dict:
        errors = []
        objects = 0
        for lid, history in self.versions.items():
            parent = ""
            for expected_version, obj in enumerate(history, 1):
                objects += 1
                if obj.logical_id != lid:
                    errors.append(f"{lid}: logical id mismatch")
                if obj.version != expected_version:
                    errors.append(f"{lid}: non-contiguous version {obj.version}")
                if obj.parent_digest != parent:
                    errors.append(f"{lid}: parent digest mismatch at version {obj.version}")
                if not obj.verify():
                    errors.append(f"{lid}: digest mismatch at version {obj.version}")
                parent = obj.digest
        for link in self.links.values():
            if link.target_id not in self.versions:
                errors.append(f"dependency target absent: {link.target_id}")
        return {"valid": not errors, "objects": objects, "logical_objects": len(self.versions),
                "links": len(self.links), "errors": errors}

    def to_dict(self) -> dict:
        return {
            "versions": {lid: [asdict(x) for x in history] for lid, history in self.versions.items()},
            "links": [asdict(x) for x in self.links.values()],
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "ContractStore":
        obj = cls()
        for lid, rows in dict(raw.get("versions", {})).items():
            history = []
            for row in rows:
                d = dict(row)
                for key in ("dependency_ids", "alternative_ids", "permissions"):
                    d[key] = tuple(d.get(key, ()))
                history.append(ContractObject(**d))
            obj.versions[str(lid)] = history
        for row in raw.get("links", []):
            link = DependencyLink(**dict(row))
            obj.links[link.link_id] = link
        return obj
