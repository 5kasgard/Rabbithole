# Consolidated ARC Lineage

## First ARC

The first ARC identified the carving/placement joint, the need to separate placement from disagreement, the value of physical vetoes over source consensus, and the thin-waist pattern seen in TCP/IP, currency, containers, genomes and alphabets.

Core procedure:

```text
Expose → invariant-check → adversarial split → smallest real test
```

## ARC-5

Expanded the procedure into a persistent human-gated state machine with frozen contracts, concrete and abstract search, mechanism reduction, preregistered contact and upstream reopening on failure.

## ARC-5A

Added independent constructive/destructive lanes, goal-backward and failure-forward decompositions, dual abstraction lattices, a five-role arena, Pareto preservation, independently authored demonstration and attempted-kill tests, and saturation waves.

## Process-against-process ARC

Rejected a universal discovery process and retained a task-proportionate portfolio.

## Substrate ARC

Rejected stack preference and retained CPython authority with bounded specialists and reversible migration slices.

## Performance ARC

Found repeated fixed control-plane work, selected bounded hybrid acceleration, and preserved homogeneous authority boundaries.

## Lineage-and-vision ARC

Compared Rx0 through v0.17, reverse-POSIWID against the full vision, reconstructed the first ARC and TCP/IP-like objective, tested an experimental protocol and bounded outward loop, and concluded that the epistemic spine is strong while the outward organism and standard remain incomplete.

## Current use rule

Use ARC only when the decision is genuinely open, high-risk, ill-structured or vulnerable to framing capture. Use direct engineering, formal checking or a minimal scientific loop for bounded deterministic work. The process must never become an excuse to avoid the smallest real external test.
