"""Persistent resident/scheduler/supervisor runtime for bounded outward work.

This module recovers the valid functions of the pre-Rx0 active scheduler,
resident, executive, supervisor and telemetry lineages while applying the
current Field invariants: no self-authored authority, objective-scoped work,
leases, explicit budgets, deterministic persistence, abstention, and exact
replay.  It is a tick-driven runtime, not a claim of autonomous utility.
"""
from __future__ import annotations

import hashlib
import heapq
import json
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping

from .wal import EventLog


def _atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n").encode()
    tmp = path.with_name(path.name + f".tmp-{uuid.uuid4().hex[:8]}")
    with tmp.open("wb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    tmp.replace(path)
    path.with_suffix(path.suffix + ".sha256").write_text(hashlib.sha256(data).hexdigest() + "\n")


def _read_verified(path: Path) -> dict[str, Any]:
    data = path.read_bytes()
    digest = path.with_suffix(path.suffix + ".sha256").read_text().strip()
    if hashlib.sha256(data).hexdigest() != digest:
        raise ValueError("resident runtime state digest mismatch")
    raw = json.loads(data)
    if not isinstance(raw, dict):
        raise ValueError("resident runtime state must be an object")
    return raw


@dataclass(frozen=True)
class RuntimePolicy:
    max_attempts: int = 3
    lease_seconds: float = 30.0
    max_tasks_per_tick: int = 1
    max_wall_seconds_per_tick: float = 10.0
    retry_backoff_seconds: float = 1.0
    require_frozen_objective: bool = True

    def validate(self) -> None:
        if self.max_attempts < 1 or self.max_tasks_per_tick < 1:
            raise ValueError("attempt and tick limits must be positive")
        if self.lease_seconds <= 0 or self.max_wall_seconds_per_tick <= 0:
            raise ValueError("runtime time bounds must be positive")
        if self.retry_backoff_seconds < 0:
            raise ValueError("retry backoff cannot be negative")


@dataclass(order=True)
class ScheduledWork:
    sort_key: tuple[float, int, str] = field(init=False, repr=False)
    not_before: float
    priority: int
    work_id: str
    objective_id: str
    operation: str
    payload: Mapping[str, Any]
    actor: str
    authority_scope: tuple[str, ...] = ()
    dependencies: tuple[str, ...] = ()
    attempts: int = 0
    state: str = "queued"  # queued | leased | completed | failed | abstained | blocked
    lease_owner: str = ""
    lease_expires_at: float = 0.0
    last_error: str = ""
    result: Mapping[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        object.__setattr__(self, "sort_key", (float(self.not_before), -int(self.priority), self.work_id))
        if not self.work_id or not self.objective_id or not self.operation or not self.actor:
            raise ValueError("work identity, objective, operation and actor are required")
        if self.state not in {"queued", "leased", "completed", "failed", "abstained", "blocked"}:
            raise ValueError("invalid work state")

    def refresh_sort(self) -> None:
        self.sort_key = (float(self.not_before), -int(self.priority), self.work_id)


@dataclass(frozen=True)
class HandlerResult:
    state: str  # completed | failed | abstained | blocked | retry
    output: Mapping[str, Any] = field(default_factory=dict)
    reason: str = ""
    resource: Mapping[str, float] = field(default_factory=dict)
    authority_granted: bool = False

    def validate(self) -> None:
        if self.state not in {"completed", "failed", "abstained", "blocked", "retry"}:
            raise ValueError("invalid handler result")
        if self.authority_granted:
            raise ValueError("runtime handlers cannot self-grant authority")


Handler = Callable[[ScheduledWork], HandlerResult]


class ResidentRuntime:
    """Durable, lease-based scheduler with deterministic tick semantics.

    The runtime is deliberately single-writer. Concurrency is expected behind
    scoped adapters; scheduling authority remains serialized and replayable.
    """

    def __init__(self, state_dir: str | Path, *, policy: RuntimePolicy | None = None):
        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.policy = policy or RuntimePolicy()
        self.policy.validate()
        self.work: dict[str, ScheduledWork] = {}
        self.completed_ids: set[str] = set()
        self.handlers: dict[str, Handler] = {}
        self.audit = EventLog()
        self.resource_totals: dict[str, float] = {}
        self.created_at = time.time()
        self.last_tick_at = 0.0
        self.supervisor_generation = 1
        self.audit.append("resident_runtime_initialized", {
            "policy": asdict(self.policy),
            "external_utility_established": False,
        })

    def register_handler(self, operation: str, handler: Handler) -> None:
        if not operation or operation in self.handlers:
            raise ValueError("operation must be unique and non-empty")
        self.handlers[operation] = handler
        self.audit.append("resident_handler_registered", {"operation": operation})

    def submit(self, work: ScheduledWork) -> None:
        if work.work_id in self.work:
            raise ValueError("duplicate work id")
        if self.policy.require_frozen_objective and not work.objective_id:
            raise ValueError("frozen objective id required")
        self.work[work.work_id] = work
        self.audit.append("resident_work_submitted", {
            "work_id": work.work_id,
            "objective_id": work.objective_id,
            "operation": work.operation,
            "dependencies": list(work.dependencies),
            "authority_scope": list(work.authority_scope),
        })
        self.save()

    def _recover_expired_leases(self, now: float) -> None:
        for row in self.work.values():
            if row.state == "leased" and row.lease_expires_at <= now:
                row.state = "queued"
                row.lease_owner = ""
                row.lease_expires_at = 0.0
                row.last_error = "lease expired; safely requeued"
                row.updated_at = now
                row.refresh_sort()
                self.audit.append("resident_lease_expired", {"work_id": row.work_id})

    def _eligible(self, now: float) -> list[ScheduledWork]:
        rows: list[ScheduledWork] = []
        for row in self.work.values():
            if row.state != "queued" or row.not_before > now:
                continue
            missing = [dep for dep in row.dependencies if dep not in self.completed_ids]
            if missing:
                continue
            heapq.heappush(rows, row)
        return rows

    def _add_resource(self, resource: Mapping[str, float]) -> None:
        for key, value in resource.items():
            self.resource_totals[str(key)] = self.resource_totals.get(str(key), 0.0) + float(value)

    def tick(self, *, worker_id: str = "resident", now: float | None = None) -> list[dict[str, Any]]:
        now = time.time() if now is None else float(now)
        self._recover_expired_leases(now)
        started = time.perf_counter()
        receipts: list[dict[str, Any]] = []
        queue = self._eligible(now)
        while queue and len(receipts) < self.policy.max_tasks_per_tick:
            if time.perf_counter() - started >= self.policy.max_wall_seconds_per_tick:
                break
            row = heapq.heappop(queue)
            handler = self.handlers.get(row.operation)
            if handler is None:
                row.state = "blocked"
                row.last_error = "no registered handler"
                row.updated_at = now
                result = HandlerResult("blocked", reason=row.last_error)
            else:
                row.state = "leased"
                row.lease_owner = worker_id
                row.lease_expires_at = now + self.policy.lease_seconds
                row.attempts += 1
                row.updated_at = now
                self.audit.append("resident_work_leased", {
                    "work_id": row.work_id,
                    "worker_id": worker_id,
                    "attempt": row.attempts,
                })
                try:
                    result = handler(row)
                    result.validate()
                except Exception as exc:  # unexpected exceptions are recorded and reclassified, never swallowed
                    result = HandlerResult("retry", reason=f"handler exception: {type(exc).__name__}: {exc}")

                self._add_resource(result.resource)
                row.result = dict(result.output)
                row.last_error = result.reason
                if result.state == "retry" and row.attempts < self.policy.max_attempts:
                    row.state = "queued"
                    row.not_before = now + self.policy.retry_backoff_seconds * row.attempts
                    row.lease_owner = ""
                    row.lease_expires_at = 0.0
                elif result.state == "retry":
                    row.state = "failed"
                    row.last_error = result.reason or "retry limit exhausted"
                else:
                    row.state = result.state
                if row.state == "completed":
                    self.completed_ids.add(row.work_id)
                row.updated_at = time.time()
                row.refresh_sort()

            receipt = {
                "work_id": row.work_id,
                "objective_id": row.objective_id,
                "operation": row.operation,
                "state": row.state,
                "attempts": row.attempts,
                "result": dict(row.result),
                "reason": row.last_error,
                "external_utility_established": False,
            }
            receipts.append(receipt)
            self.audit.append("resident_work_resolved", receipt)
            # Completion may make dependent work eligible within the same bounded tick.
            if len(receipts) < self.policy.max_tasks_per_tick:
                queue = self._eligible(now)

        self.last_tick_at = time.time()
        self.save()
        return receipts

    def supervise(self, *, now: float | None = None) -> dict[str, Any]:
        now = time.time() if now is None else float(now)
        self._recover_expired_leases(now)
        stalled = [row.work_id for row in self.work.values() if row.state == "leased" and row.lease_expires_at <= now]
        failed = [row.work_id for row in self.work.values() if row.state == "failed"]
        blocked = [row.work_id for row in self.work.values() if row.state == "blocked"]
        report = {
            "valid": self.audit.verify().get("valid", False),
            "generation": self.supervisor_generation,
            "queued": sum(row.state == "queued" for row in self.work.values()),
            "leased": sum(row.state == "leased" for row in self.work.values()),
            "completed": len(self.completed_ids),
            "failed": failed,
            "blocked": blocked,
            "stalled": stalled,
            "resource_totals": dict(self.resource_totals),
            "external_claims_closed": False,
        }
        self.audit.append("resident_supervisor_report", report)
        self.save()
        return report

    def restart_generation(self, reason: str) -> None:
        self.supervisor_generation += 1
        for row in self.work.values():
            if row.state == "leased":
                row.state = "queued"
                row.lease_owner = ""
                row.lease_expires_at = 0.0
                row.last_error = f"supervisor restart: {reason}"
                row.refresh_sort()
        self.audit.append("resident_supervisor_restart", {
            "generation": self.supervisor_generation,
            "reason": reason,
        })
        self.save()

    def telemetry(self) -> dict[str, Any]:
        total = max(1, len(self.work))
        unresolved = sum(row.state in {"queued", "leased", "blocked"} for row in self.work.values())
        failed = sum(row.state == "failed" for row in self.work.values())
        return {
            "schema": "field.resident-telemetry/1",
            "work_total": len(self.work),
            "completion_rate": len(self.completed_ids) / total,
            "unresolved_rate": unresolved / total,
            "failure_rate": failed / total,
            "queue_depth": sum(row.state == "queued" for row in self.work.values()),
            "leased": sum(row.state == "leased" for row in self.work.values()),
            "resource_totals": dict(self.resource_totals),
            "audit_valid": self.audit.verify().get("valid", False),
            "note": "operational health only; not semantic quality or external utility",
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "field.resident-runtime-state/1",
            "policy": asdict(self.policy),
            "created_at": self.created_at,
            "last_tick_at": self.last_tick_at,
            "supervisor_generation": self.supervisor_generation,
            "work": [asdict(row) for row in sorted(self.work.values(), key=lambda r: r.work_id)],
            "completed_ids": sorted(self.completed_ids),
            "resource_totals": dict(self.resource_totals),
            "audit": self.audit.to_dict(),
            "external_claims": {
                "72_hour_operation": "blocked_not_elapsed",
                "14_day_operation": "blocked_not_elapsed",
                "independent_utility": "blocked_no_independent_evaluator",
            },
        }

    def save(self) -> None:
        _atomic_json(self.state_dir / "resident_runtime.json", self.to_dict())

    @classmethod
    def load(cls, state_dir: str | Path) -> "ResidentRuntime":
        state_dir = Path(state_dir)
        raw = _read_verified(state_dir / "resident_runtime.json")
        runtime = cls.__new__(cls)
        runtime.state_dir = state_dir
        runtime.policy = RuntimePolicy(**dict(raw["policy"]))
        runtime.policy.validate()
        runtime.work = {}
        for item in raw.get("work", []):
            row = dict(item)
            row.pop("sort_key", None)
            row["authority_scope"] = tuple(row.get("authority_scope", ()))
            row["dependencies"] = tuple(row.get("dependencies", ()))
            work = ScheduledWork(**row)
            runtime.work[work.work_id] = work
        runtime.completed_ids = set(raw.get("completed_ids", ()))
        runtime.handlers = {}
        runtime.audit = EventLog.from_dict(raw.get("audit", {}))
        runtime.resource_totals = {str(k): float(v) for k, v in raw.get("resource_totals", {}).items()}
        runtime.created_at = float(raw.get("created_at", time.time()))
        runtime.last_tick_at = float(raw.get("last_tick_at", 0.0))
        runtime.supervisor_generation = int(raw.get("supervisor_generation", 1))
        return runtime

    def verify_integrity(self) -> dict[str, Any]:
        errors: list[str] = []
        path = self.state_dir / "resident_runtime.json"
        if path.exists():
            try:
                _read_verified(path)
            except Exception as exc:
                errors.append(str(exc))
        audit = self.audit.verify()
        if not audit.get("valid"):
            errors.append(f"audit invalid: {audit}")
        for row in self.work.values():
            if row.state == "completed" and row.work_id not in self.completed_ids:
                errors.append(f"completed set missing {row.work_id}")
            if row.work_id in row.dependencies:
                errors.append(f"self dependency: {row.work_id}")
        return {
            "valid": not errors,
            "work_count": len(self.work),
            "completed": len(self.completed_ids),
            "external_claims_closed": False,
            "errors": errors,
        }
