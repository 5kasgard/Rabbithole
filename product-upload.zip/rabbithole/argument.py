"""Non-numeric disagreement and argument graph.

Numeric observations can be fused in the Field belief layer.  Abstract claims
cannot safely be forced into the same Gaussian/value machinery.  This module
keeps claims, evidence and attack/support relations explicit, collapses
correlated evidence by independence group, and reports dialectical status
without pretending that a graph score is truth.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from .wal import EventLog


RELATIONS = {"supports", "attacks", "depends_on", "refines", "contradicts", "undercuts"}
CLAIM_STATES = {"proposed", "supported", "contested", "defeated", "unresolved", "withdrawn"}


@dataclass
class ArgumentClaim:
    statement: str
    claim_class: str
    scope: Mapping[str, object] = field(default_factory=dict)
    author: str = ""
    state: str = "proposed"
    created_at: float = field(default_factory=time.time)
    cid: str = field(default_factory=lambda: f"ARG{uuid.uuid4().hex[:12]}")


@dataclass
class ArgumentEvidence:
    claim_id: str
    relation: str
    source_id: str
    independence_group: str
    contact_type: str
    quality: float
    tested: bool
    summary: str
    artifact_ids: Tuple[str, ...] = ()
    active: bool = True
    created_at: float = field(default_factory=time.time)
    eid: str = field(default_factory=lambda: f"AEV{uuid.uuid4().hex[:12]}")

    def validate(self) -> None:
        if self.relation not in {"supports", "attacks", "undercuts"}:
            raise ValueError("evidence relation must support, attack, or undercut")
        if not (0 <= self.quality <= 1):
            raise ValueError("evidence quality must be in [0,1]")
        if not self.independence_group:
            raise ValueError("evidence requires an independence group")


@dataclass
class ClaimRelation:
    source_claim: str
    target_claim: str
    relation: str
    scope: Mapping[str, object] = field(default_factory=dict)
    active: bool = True
    rid: str = field(default_factory=lambda: f"REL{uuid.uuid4().hex[:12]}")

    def validate(self) -> None:
        if self.relation not in RELATIONS:
            raise ValueError(f"unknown claim relation {self.relation!r}")
        if self.source_claim == self.target_claim:
            raise ValueError("self-relations are not admitted")


@dataclass
class DialecticalReport:
    claim_id: str
    state: str
    independent_support_groups: int
    independent_attack_groups: int
    support_quality: float
    attack_quality: float
    unresolved_dependencies: Tuple[str, ...]
    live_contradictions: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    note: str


class ArgumentGraph:
    def __init__(self):
        self.claims: Dict[str, ArgumentClaim] = {}
        self.evidence: Dict[str, ArgumentEvidence] = {}
        self.relations: Dict[str, ClaimRelation] = {}
        self.audit = EventLog()

    def add_claim(self, claim: ArgumentClaim) -> str:
        if claim.state not in CLAIM_STATES:
            raise ValueError(f"unknown claim state {claim.state!r}")
        if not claim.statement.strip() or not claim.claim_class.strip():
            raise ValueError("claim statement and class are required")
        self.claims[claim.cid] = claim
        self.audit.append("argument_claim_added", asdict(claim))
        return claim.cid

    def add_evidence(self, evidence: ArgumentEvidence) -> str:
        evidence.validate()
        if evidence.claim_id not in self.claims:
            raise KeyError(evidence.claim_id)
        self.evidence[evidence.eid] = evidence
        self.audit.append("argument_evidence_added", asdict(evidence))
        self._refresh(evidence.claim_id)
        return evidence.eid

    def relate(self, relation: ClaimRelation) -> str:
        relation.validate()
        if relation.source_claim not in self.claims or relation.target_claim not in self.claims:
            raise KeyError("claim relation references unknown claim")
        self.relations[relation.rid] = relation
        self.audit.append("argument_relation_added", asdict(relation))
        self._refresh(relation.source_claim)
        self._refresh(relation.target_claim)
        return relation.rid

    def retract_evidence(self, eid: str, reason: str) -> None:
        ev = self.evidence[eid]
        ev.active = False
        self.audit.append("argument_evidence_retracted", {"eid": eid, "reason": reason})
        self._refresh(ev.claim_id)

    def retract_relation(self, rid: str, reason: str) -> None:
        rel = self.relations[rid]
        rel.active = False
        self.audit.append("argument_relation_retracted", {"rid": rid, "reason": reason})
        self._refresh(rel.source_claim)
        self._refresh(rel.target_claim)

    def withdraw_claim(self, cid: str, reason: str) -> None:
        self.claims[cid].state = "withdrawn"
        self.audit.append("argument_claim_withdrawn", {"cid": cid, "reason": reason})

    @staticmethod
    def _group_quality(items: Iterable[ArgumentEvidence]) -> Dict[str, float]:
        """One correlated family contributes at most its strongest tested contact."""
        groups: Dict[str, float] = {}
        for ev in items:
            if not ev.active or not ev.tested:
                continue
            groups[ev.independence_group] = max(groups.get(ev.independence_group, 0.0), ev.quality)
        return groups

    def report(self, cid: str) -> DialecticalReport:
        if cid not in self.claims:
            raise KeyError(cid)
        claim = self.claims[cid]
        own = [e for e in self.evidence.values() if e.claim_id == cid and e.active]
        supports = self._group_quality(e for e in own if e.relation == "supports")
        attacks = self._group_quality(e for e in own if e.relation in {"attacks", "undercuts"})
        contradictions = []
        dependencies = []
        for rel in self.relations.values():
            if not rel.active:
                continue
            if rel.target_claim == cid and rel.relation in {"contradicts", "attacks", "undercuts"}:
                source = self.claims[rel.source_claim]
                if source.state in {"supported", "contested", "unresolved"}:
                    contradictions.append(source.cid)
            if rel.source_claim == cid and rel.relation == "depends_on":
                target = self.claims[rel.target_claim]
                if target.state != "supported":
                    dependencies.append(target.cid)
        sq, aq = sum(supports.values()), sum(attacks.values())
        if claim.state == "withdrawn":
            state, note = "withdrawn", "claim was explicitly withdrawn"
        elif dependencies:
            state, note = "unresolved", "one or more dependencies are not supported"
        elif (attacks or contradictions) and supports:
            state, note = "contested", "independent support and opposition remain live"
        elif attacks or contradictions:
            state, note = "defeated", "live opposition exists without independent tested support"
        elif supports:
            state, note = "supported", "at least one independent tested support group exists"
        else:
            state, note = "unresolved", "no independent tested support or attack"
        claim.state = state
        return DialecticalReport(
            cid, state, len(supports), len(attacks), sq, aq,
            tuple(sorted(dependencies)), tuple(sorted(contradictions)),
            tuple(sorted(e.eid for e in own)), note,
        )

    def _refresh(self, cid: str) -> None:
        if cid in self.claims and self.claims[cid].state != "withdrawn":
            self.report(cid)

    def posiwid(self) -> dict:
        reports = [self.report(cid) for cid in self.claims]
        return {
            "claims": len(self.claims), "evidence": len(self.evidence),
            "relations": len(self.relations),
            "states": {s: sum(r.state == s for r in reports) for s in CLAIM_STATES},
            "independence_groups": len({e.independence_group for e in self.evidence.values()
                                        if e.active}),
            "audit_valid": self.audit.verify().get("valid", False),
        }

    def to_dict(self) -> dict:
        return {
            "claims": [asdict(x) for x in self.claims.values()],
            "evidence": [asdict(x) for x in self.evidence.values()],
            "relations": [asdict(x) for x in self.relations.values()],
            "audit": self.audit.to_dict(),
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "ArgumentGraph":
        g = cls()
        g.claims = {x["cid"]: ArgumentClaim(**x) for x in raw.get("claims", [])}
        g.evidence = {}
        for x in raw.get("evidence", []):
            d = dict(x); d["artifact_ids"] = tuple(d.get("artifact_ids", ()))
            g.evidence[d["eid"]] = ArgumentEvidence(**d)
        g.relations = {x["rid"]: ClaimRelation(**x) for x in raw.get("relations", [])}
        g.audit = EventLog.from_dict(raw.get("audit", {}))
        return g
