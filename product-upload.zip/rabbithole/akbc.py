"""AKBC intake and placement waist for The Field.

This module is deliberately narrower than the vision and stronger than the
previous demo.  It implements one end-to-end invariant:

    independent carvings remain provenance-bearing observations;
    identity is a reversible hypothesis; only observations of the same
    particular measurand are projected onto one field variable; testimony has
    zero authority until a registered external test touches it.

The implementation separates three levels that must not be collapsed:

* QuantityKind  -- what kind of property it is (energy, torque, density, ...)
* Measurand     -- the particular property of a particular subject/scope
* Observation   -- one source's reported value for that measurand

Similarity retrieves candidates.  It never authorizes a merge.  Automatic
acceptance requires structural identity: compatible dimension, matching known
quantity kind, compatible algebraic character, and shared non-conflicting scope.
Ambiguous cases remain separate and emit an identity hypothesis/test target.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import time
import uuid
from dataclasses import asdict, dataclass, field as dc_field
from difflib import SequenceMatcher
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from .core import Dim, UNITS, unit as unit_lookup
from .field import Field
from .tether import GroundingTest, RealityHarness, SourceLedger, Verdict
from .wal import EventLog
from .routing import HeterogeneousRouter

ALGEBRAIC_TYPES = {"unknown", "scalar", "vector", "pseudovector", "tensor", "set", "symbolic"}
HYPOTHESIS_STATES = {"proposed", "accepted", "rejected", "unresolved", "retracted"}


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:10]}"


def _norm(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", (text or "").lower()))


def _tokens(text: str) -> set[str]:
    return set(_norm(text).split())


def _semantic_similarity(a: str, b: str) -> float:
    """Cheap candidate retrieval only; never merge authority."""
    na, nb = _norm(a), _norm(b)
    if not na or not nb:
        return 0.0
    ta, tb = _tokens(a), _tokens(b)
    jac = len(ta & tb) / len(ta | tb) if ta | tb else 0.0
    seq = SequenceMatcher(None, na, nb).ratio()
    return 0.55 * seq + 0.45 * jac


def _jaccard(a: Sequence[str], b: Sequence[str]) -> Optional[float]:
    sa, sb = set(a), set(b)
    if not sa or not sb:
        return None
    return len(sa & sb) / len(sa | sb)


@dataclass(frozen=True)
class Scope:
    """Identity-bearing qualifiers for a particular measurand.

    Keys are intentionally generic: sample_id, device_id, location, component,
    state, time_window, jurisdiction, dataset, etc.  The domain adapter decides
    which qualifiers are identity-bearing by putting them here.  Conflicting
    values for the same key are a hard non-identity signal.
    """

    items: Tuple[Tuple[str, str], ...] = ()

    @staticmethod
    def from_mapping(mapping: Optional[Mapping[str, object]]) -> "Scope":
        if not mapping:
            return Scope()
        return Scope(tuple(sorted((str(k), str(v)) for k, v in mapping.items()
                                  if v is not None and str(v) != "")))

    def as_dict(self) -> Dict[str, str]:
        return dict(self.items)

    def compare(self, other: "Scope") -> Tuple[str, float, str]:
        a, b = self.as_dict(), other.as_dict()
        conflicts = sorted(k for k in a.keys() & b.keys() if a[k] != b[k])
        if conflicts:
            detail = ", ".join(f"{k}: {a[k]!r} != {b[k]!r}" for k in conflicts)
            return "fail", 0.0, detail
        shared = a.keys() & b.keys()
        if not shared:
            return "unknown", 0.0, "no shared identity-bearing scope"
        union = a.keys() | b.keys()
        return "pass", len(shared) / max(1, len(union)), \
            f"shared scope: {', '.join(sorted(shared))}"


@dataclass
class QuantityKind:
    kid: str
    label: str
    unit: str
    dim: Dim
    algebraic_type: str = "unknown"
    phenomenon: str = ""
    operational_tags: Tuple[str, ...] = ()
    aliases: set[str] = dc_field(default_factory=set)
    provisional: bool = False

    def __post_init__(self) -> None:
        if self.algebraic_type not in ALGEBRAIC_TYPES:
            raise ValueError(f"unknown algebraic type {self.algebraic_type!r}")
        self.aliases.add(_norm(self.label))


@dataclass
class SourceReceipt:
    rid: str
    source: str
    locator: str
    retrieved_at: float
    media_type: str
    content_sha256: str
    snapshot: str = ""
    extractor: str = "structured-input"
    extraction_version: str = "0.6.0"

    def verify(self) -> bool:
        if not self.snapshot:
            return self.content_sha256 == ""
        return hashlib.sha256(self.snapshot.encode()).hexdigest() == self.content_sha256


@dataclass
class Carving:
    label: str
    unit: str
    value: Optional[float] = None
    sigma: Optional[float] = None
    source: str = "unknown"
    citation: str = ""
    confidence: float = 0.5
    kind_id: str = ""
    kind_label: str = ""
    algebraic_type: str = "unknown"
    phenomenon: str = ""
    operational_tags: Tuple[str, ...] = ()
    scope: Mapping[str, object] = dc_field(default_factory=dict)
    relations: Tuple[str, ...] = ()
    contact: str = "human"
    independence_key: str = ""
    source_locator: str = ""
    source_snapshot: str = ""
    media_type: str = "text/plain"
    extractor: str = "structured-input"
    extraction_version: str = "0.6.0"
    cid: str = dc_field(default_factory=lambda: _id("K"))

    def validate(self) -> None:
        if not self.label.strip():
            raise ValueError("carving label must not be empty")
        if self.unit not in UNITS:
            raise KeyError(f"unknown unit {self.unit!r}")
        if self.algebraic_type not in ALGEBRAIC_TYPES:
            raise ValueError(f"unknown algebraic type {self.algebraic_type!r}")
        if not (0.0 <= float(self.confidence) <= 1.0):
            raise ValueError("confidence must be in [0, 1]")
        if self.value is not None and not math.isfinite(float(self.value)):
            raise ValueError("observation value must be finite")
        if self.value is not None:
            if self.sigma is None or not math.isfinite(float(self.sigma)) or float(self.sigma) <= 0:
                raise ValueError("valued carvings require finite sigma > 0")


@dataclass
class Observation:
    oid: str
    carving_id: str
    label: str
    unit: str
    value: Optional[float]
    sigma: Optional[float]
    source: str
    citation: str
    confidence: float
    kind_id: str
    algebraic_type: str
    phenomenon: str
    operational_tags: Tuple[str, ...]
    scope: Scope
    relations: Tuple[str, ...]
    contact: str
    independence_key: str
    local_measurand_id: str
    receipt_id: str = ""
    grounding_author: str = ""
    grounding_kind: str = ""
    grounding_quality: float = 0.0
    grounding_status: str = "untested"  # untested|passed|failed|untestable
    test_count: int = 0
    last_grounded_at: float = 0.0
    grounding_history: List[dict] = dc_field(default_factory=list)


@dataclass
class Measurand:
    mid: str
    label: str
    kind_id: str
    unit: str
    dim: Dim
    algebraic_type: str
    phenomenon: str
    scope: Scope
    operational_tags: Tuple[str, ...] = ()
    relation_tags: Tuple[str, ...] = ()
    aliases: set[str] = dc_field(default_factory=set)
    observation_ids: List[str] = dc_field(default_factory=list)
    provisional: bool = True

    def __post_init__(self) -> None:
        self.aliases.add(_norm(self.label))


@dataclass
class Probe:
    name: str
    outcome: str  # pass|fail|unknown
    weight: float
    detail: str
    hard: bool = False


@dataclass
class IdentityHypothesis:
    hid: str
    observation_id: str
    source_measurand_id: str
    target_measurand_id: str
    score: float
    status: str
    probes: List[Probe]
    created_at: float
    decided_at: float = 0.0
    decided_by: str = ""
    test_history: List[dict] = dc_field(default_factory=list)


@dataclass
class PlacementDecision:
    action: str  # accepted_existing|new|unresolved|rejected_unit|rejected
    observation_id: str
    local_measurand_id: str
    canonical_measurand_id: str
    reason: str
    hypotheses: List[str] = dc_field(default_factory=list)
    route: List[str] = dc_field(default_factory=list)


@dataclass
class ConstraintProposal:
    pid: str
    spec: dict
    proposer: str
    status: str  # proposed|approved|rejected
    dimensional_status: str
    reason: str
    basis: str = ""
    source: str = ""
    created_at: float = dc_field(default_factory=time.time)


class KindRegistry:
    """Thin, accreting quantity-kind registry.

    It is not the world ontology.  It stores only distinctions the running
    system has needed, with optional domain seed packs.  Aliases retrieve a
    known kind; matching dimension alone never does.
    """

    def __init__(self):
        self.kinds: Dict[str, QuantityKind] = {}
        self.alias_to_kind: Dict[str, str] = {}

    def register(self, kid: str, label: str, unit: str,
                 algebraic_type: str = "unknown", phenomenon: str = "",
                 operational_tags: Iterable[str] = (), aliases: Iterable[str] = (),
                 provisional: bool = False) -> QuantityKind:
        dim, _ = unit_lookup(unit)
        q = QuantityKind(kid, label, unit, dim, algebraic_type, phenomenon,
                         tuple(sorted(set(operational_tags))),
                         set(_norm(x) for x in aliases), provisional)
        self.kinds[kid] = q
        for alias in q.aliases | {_norm(label), _norm(kid)}:
            if alias:
                self.alias_to_kind[alias] = kid
        return q

    def resolve(self, kind_id: str = "", label: str = "") -> Optional[QuantityKind]:
        if kind_id and kind_id in self.kinds:
            return self.kinds[kind_id]
        kid = self.alias_to_kind.get(_norm(label)) if label else None
        return self.kinds.get(kid) if kid else None

    def ensure_provisional(self, carving: Carving) -> QuantityKind:
        known = self.resolve(carving.kind_id, carving.kind_label or carving.label)
        if known:
            return known
        dim, _ = unit_lookup(carving.unit)
        kid = carving.kind_id or f"provisional:{_norm(carving.kind_label or carving.label).replace(' ', '_')}"
        if kid in self.kinds:
            return self.kinds[kid]
        return self.register(kid, carving.kind_label or carving.label, carving.unit,
                             carving.algebraic_type, carving.phenomenon,
                             carving.operational_tags, provisional=True)


def metrology_seed() -> KindRegistry:
    """Small testable seed pack, not a claim of complete ontology."""
    r = KindRegistry()
    r.register("mass_density", "mass density", "kg/m^3", "scalar", "material property",
               ("mass_per_volume", "additive_mass_over_volume"),
               aliases=("density", "volumic mass", "rho"))
    r.register("energy", "energy", "J", "scalar", "energetic state or transfer",
               ("scalar", "work_equivalent", "additive_same_kind"))
    r.register("torque", "torque", "N*m", "pseudovector", "rotational moment",
               ("cross_product_r_force", "rotation_generator"),
               aliases=("moment of force",))
    r.register("frequency", "frequency", "Hz", "scalar", "periodic event rate",
               ("reciprocal_period", "cycle_count_rate"), aliases=("cycle rate",))
    r.register("activity", "radionuclide activity", "Bq", "scalar", "radioactive decay rate",
               ("decay_count_rate",), aliases=("radioactivity", "decay activity"))
    r.register("speed", "speed", "m/s", "scalar", "magnitude of motion",
               ("path_length_rate", "velocity_magnitude"))
    r.register("velocity", "velocity", "m/s", "vector", "directed motion",
               ("position_derivative", "direction_bearing"))
    r.register("thermodynamic_temperature", "thermodynamic temperature", "K", "scalar",
               "thermal state", ("zeroth_law_state",), aliases=("temperature",))
    r.register("heat_capacity", "heat capacity", "J/K", "scalar", "thermal response",
               ("energy_change_per_temperature_change",))
    r.register("entropy", "entropy", "J/K", "scalar", "thermodynamic state",
               ("state_function", "heat_over_temperature_reversible",))
    return r


class FieldSystem:
    """A vertical AKBC slice joined to the RabbitHole constraint kernel."""

    def __init__(self, name: str = "field-system", kinds: Optional[KindRegistry] = None,
                 harness: Optional[RealityHarness] = None):
        self.name = name
        self.kinds = kinds or KindRegistry()
        self.harness = harness or RealityHarness()
        self.ledger = SourceLedger()
        self.audit = EventLog()
        self.router = HeterogeneousRouter()
        self.receipts: Dict[str, SourceReceipt] = {}
        self.observations: Dict[str, Observation] = {}
        self.measurands: Dict[str, Measurand] = {}
        self.hypotheses: Dict[str, IdentityHypothesis] = {}
        self.constraint_proposals: Dict[str, ConstraintProposal] = {}
        self.approved_specs: List[dict] = []  # {spec, basis, source}
        self._canonical_parent: Dict[str, str] = {}
        self.field = Field(name)
        self._evidence_for_observation: Dict[str, str] = {}
        self._projection_fids: Dict[str, str] = {}
        self.metrics = {"carvings": 0, "accepted": 0, "new": 0,
                        "unresolved": 0, "rejected": 0,
                        "grounded": 0, "identity_tests": 0}

    # ------------------------------------------------------------------ identity
    def canonical(self, mid: str) -> str:
        parent = self._canonical_parent.get(mid, mid)
        if parent != mid:
            self._canonical_parent[mid] = self.canonical(parent)
        return self._canonical_parent.get(mid, mid)

    def _recompute_canonical(self) -> None:
        """Rebuild the canonical view from accepted identity edges.

        Union-find is treated as a projection, never the source of truth.  The
        accepted hypothesis graph is the truth-bearing state, so retracting one
        edge can split a previously joined component without relying on an
        irreversible union history.  Directed source->target order preserves
        the older/existing target as the canonical representative.
        """
        parent = {mid: mid for mid in self.measurands}

        def find(mid: str) -> str:
            cur = parent.get(mid, mid)
            if cur != mid:
                parent[mid] = find(cur)
            return parent.get(mid, mid)

        for h in sorted(self.hypotheses.values(), key=lambda x: (x.created_at, x.hid)):
            if h.status != "accepted":
                continue
            rs, rt = find(h.source_measurand_id), find(h.target_measurand_id)
            if rs != rt:
                parent[rs] = rt
        for mid in list(parent):
            parent[mid] = find(mid)
        self._canonical_parent = parent

    def _join(self, child: str, target: str) -> None:
        # Compatibility shim: accepted hypotheses, not this call, own identity.
        self._recompute_canonical()

    def _split(self, child: str) -> None:
        self._recompute_canonical()

    def _kind_for(self, carving: Carving) -> QuantityKind:
        return self.kinds.ensure_provisional(carving)

    def _evaluate(self, obs: Observation, candidate: Measurand) -> IdentityHypothesis:
        probes: List[Probe] = []
        odim, _ = unit_lookup(obs.unit)
        dim_ok = odim == candidate.dim
        probes.append(Probe("dimension", "pass" if dim_ok else "fail", 1.0,
                            f"incoming {odim}; candidate {candidate.dim}", hard=True))

        if obs.kind_id and candidate.kind_id:
            kind_ok = obs.kind_id == candidate.kind_id
            probes.append(Probe("quantity_kind", "pass" if kind_ok else "fail", 0.30,
                                f"{obs.kind_id!r} vs {candidate.kind_id!r}", hard=not kind_ok))
        else:
            probes.append(Probe("quantity_kind", "unknown", 0.30,
                                "one or both quantity kinds are provisional"))

        oa, ca = obs.algebraic_type, candidate.algebraic_type
        if oa != "unknown" and ca != "unknown":
            alg_ok = oa == ca
            probes.append(Probe("algebraic_character", "pass" if alg_ok else "fail", 0.18,
                                f"{oa} vs {ca}", hard=not alg_ok))
        else:
            probes.append(Probe("algebraic_character", "unknown", 0.18,
                                f"{oa} vs {ca}"))

        if obs.phenomenon and candidate.phenomenon:
            phen_ok = _norm(obs.phenomenon) == _norm(candidate.phenomenon)
            probes.append(Probe("phenomenon", "pass" if phen_ok else "fail", 0.12,
                                f"{obs.phenomenon!r} vs {candidate.phenomenon!r}",
                                hard=not phen_ok))
        else:
            probes.append(Probe("phenomenon", "unknown", 0.12,
                                "phenomenon identity incomplete"))

        scope_out, scope_score, scope_detail = obs.scope.compare(candidate.scope)
        probes.append(Probe("measurand_scope", scope_out, 0.28, scope_detail,
                            hard=scope_out == "fail"))

        op = _jaccard(obs.operational_tags, candidate.operational_tags)
        if op is None:
            probes.append(Probe("operational_signature", "unknown", 0.17,
                                "operational tags incomplete"))
        else:
            probes.append(Probe("operational_signature", "pass" if op > 0 else "fail", 0.17,
                                f"tag Jaccard={op:.3f}"))

        rel = _jaccard(obs.relations, candidate.relation_tags)
        if rel is None:
            probes.append(Probe("graph_neighbourhood", "unknown", 0.10,
                                "relation neighbourhood incomplete"))
        else:
            probes.append(Probe("graph_neighbourhood", "pass" if rel > 0 else "fail", 0.10,
                                f"relation Jaccard={rel:.3f}"))

        sem = max([_semantic_similarity(obs.label, candidate.label)] +
                  [_semantic_similarity(obs.label, a) for a in candidate.aliases])
        probes.append(Probe("semantic_candidate", "pass" if sem >= 0.55 else "unknown", 0.08,
                            f"retrieval similarity={sem:.3f}"))

        hard_fail = any(p.hard and p.outcome == "fail" for p in probes)
        known = [p for p in probes if not p.hard and p.outcome != "unknown"]
        numerator = sum(p.weight * (1.0 if p.outcome == "pass" else 0.0) for p in known)
        denominator = sum(p.weight for p in known) or 1.0
        score = 0.0 if hard_fail else numerator / denominator

        # Similarity never authorizes identity.  Automatic acceptance requires
        # same known kind plus positive scope contact; everything else remains a
        # falsifiable hypothesis.
        kind_pass = any(p.name == "quantity_kind" and p.outcome == "pass" for p in probes)
        scope_pass = any(p.name == "measurand_scope" and p.outcome == "pass" for p in probes)
        if hard_fail:
            status = "rejected"
        elif kind_pass and scope_pass and score >= 0.80:
            status = "proposed"  # final selection/margin gate happens across candidates
        else:
            status = "unresolved"

        return IdentityHypothesis(_id("H"), obs.oid, obs.local_measurand_id,
                                  candidate.mid, score, status, probes, time.time())

    def ingest(self, carving: Carving) -> PlacementDecision:
        """Admit a carving transactionally as an untested observation.

        The caller cannot assert that it is tested.  Authority can move only via
        ground_observation(), which runs a registered RealityHarness executor.
        """
        self.metrics["carvings"] += 1
        try:
            carving.validate()
        except KeyError as e:
            self.metrics["rejected"] += 1
            oid = _id("O")
            self.audit.append("carving_rejected", {"oid": oid, "cid": carving.cid,
                                                    "reason": str(e), "label": carving.label})
            return PlacementDecision("rejected_unit", oid, "", "", str(e))

        kind = self._kind_for(carving)
        mid = _id("M")
        rid = _id("R")
        digest = (hashlib.sha256(carving.source_snapshot.encode()).hexdigest()
                  if carving.source_snapshot else "")
        receipt = SourceReceipt(
            rid=rid, source=carving.source,
            locator=carving.source_locator or carving.citation,
            retrieved_at=time.time(), media_type=carving.media_type,
            content_sha256=digest, snapshot=carving.source_snapshot,
            extractor=carving.extractor, extraction_version=carving.extraction_version,
        )
        self.receipts[rid] = receipt
        obs = Observation(
            oid=_id("O"), carving_id=carving.cid, label=carving.label, unit=carving.unit,
            value=None if carving.value is None else float(carving.value),
            sigma=None if carving.sigma is None else float(carving.sigma),
            source=carving.source, citation=carving.citation,
            confidence=float(carving.confidence), kind_id=kind.kid,
            algebraic_type=carving.algebraic_type if carving.algebraic_type != "unknown"
                           else kind.algebraic_type,
            phenomenon=carving.phenomenon or kind.phenomenon,
            operational_tags=tuple(sorted(set(carving.operational_tags or kind.operational_tags))),
            scope=Scope.from_mapping(carving.scope), relations=tuple(sorted(set(carving.relations))),
            contact=carving.contact,
            independence_key=carving.independence_key or carving.source,
            local_measurand_id=mid, receipt_id=rid,
        )
        provisional = Measurand(mid, carving.label, kind.kid, carving.unit, kind.dim,
                                obs.algebraic_type, obs.phenomenon, obs.scope,
                                obs.operational_tags, obs.relations, provisional=True)
        provisional.observation_ids.append(obs.oid)
        self.observations[obs.oid] = obs
        self.measurands[mid] = provisional
        self._canonical_parent[mid] = mid

        # Compare against canonical roots only. Accepted local carvings remain
        # in history, but must not reappear as duplicate candidates and create
        # insertion-order ambiguity for later observations.
        candidates = [m for m in self.measurands.values()
                      if m.mid != mid and self.canonical(m.mid) == m.mid]
        hypotheses = [self._evaluate(obs, c) for c in candidates]
        for h in hypotheses:
            self.hypotheses[h.hid] = h

        viable = sorted((h for h in hypotheses if h.status == "proposed"),
                        key=lambda h: h.score, reverse=True)
        accepted: Optional[IdentityHypothesis] = None
        if viable:
            best = viable[0]
            runner = viable[1].score if len(viable) > 1 else 0.0
            if best.score >= 0.80 and best.score - runner >= 0.15:
                best.status = "accepted"
                best.decided_at = time.time()
                best.decided_by = "deterministic structural gate"
                self._join(mid, best.target_measurand_id)
                accepted = best

        unresolved = [h for h in hypotheses if h.status == "unresolved"]
        if accepted:
            action, canonical_mid = "accepted_existing", self.canonical(mid)
            self.metrics["accepted"] += 1
            reason = (f"structural identity accepted at score {accepted.score:.3f}; "
                      "observations remain separate, canonical projection shared")
        elif unresolved or viable:
            action, canonical_mid = "unresolved", mid
            self.metrics["unresolved"] += 1
            reason = "candidate identity lacks decisive structural evidence; kept separate"
        else:
            action, canonical_mid = "new", mid
            self.metrics["new"] += 1
            reason = "no viable existing measurand; created a provisional distinct node"

        self.audit.append("carving_ingested", {
            "oid": obs.oid, "cid": carving.cid, "local_mid": mid,
            "canonical_mid": canonical_mid, "action": action,
            "source": carving.source, "receipt_id": rid,
            "source_digest": digest, "hypotheses": [h.hid for h in hypotheses],
        })
        self.rebuild_field()
        return PlacementDecision(action, obs.oid, mid, canonical_mid, reason,
                                 [h.hid for h in hypotheses],
                                 ["dimension", "quantity_kind", "algebraic_character",
                                  "phenomenon", "measurand_scope", "operational_signature",
                                  "graph_neighbourhood", "semantic_candidate",
                                  "identity_disagreement_if_unresolved"])

    # ------------------------------------------------------------------ grounding
    def ground_observation(self, oid: str, test: GroundingTest) -> Verdict:
        obs = self.observations[oid]
        verdict = self.harness.run(test)
        effective = verdict.result
        detail = verdict.reason
        if verdict.result == "pass" and verdict.value is not None and obs.value is not None:
            # A measurement executor returned an independent value.  It decides
            # whether the reported observation survived contact.
            incoming_dim, incoming_scale = unit_lookup(obs.unit)
            measured_unit = verdict.unit or obs.unit
            measured_dim, measured_scale = unit_lookup(measured_unit)
            if measured_dim != incoming_dim:
                effective = "untestable"
                detail = (f"measurement unit {measured_unit!r} incompatible with "
                          f"observation unit {obs.unit!r}")
                verdict = Verdict("untestable", verdict.contact, verdict.kind,
                                  verdict.author, reason=detail, unit=measured_unit,
                                  quality=0.0)
            claimed_si = obs.value * incoming_scale
            sigma_si = obs.sigma * incoming_scale if obs.sigma is not None else 0.0
            measured_si = verdict.value * measured_scale if verdict.value is not None else math.nan
            measured_sigma_si = (verdict.sigma or 0.0) * measured_scale
            if effective == "pass":
                tolerance = 2.0 * math.sqrt(sigma_si ** 2 + measured_sigma_si ** 2)
                effective = "pass" if abs(claimed_si - measured_si) <= tolerance else "fail"
                detail = (f"measurement {verdict.value} ± {verdict.sigma} {measured_unit}; "
                          f"claim delta={abs(claimed_si-measured_si):.6g} SI; "
                          f"2σ tolerance={tolerance:.6g}")
                verdict = Verdict(effective, verdict.contact, verdict.kind, verdict.author,
                                  value=verdict.value, sigma=verdict.sigma,
                                  reason=detail, unit=measured_unit,
                                  quality=verdict.quality if effective == "pass" else 0.0)

        if effective == "pass":
            obs.test_count += 1
            obs.last_grounded_at = time.time()
            obs.grounding_status = "passed"
            obs.contact = verdict.contact
            obs.grounding_author = verdict.author
            obs.grounding_kind = verdict.kind
            obs.grounding_quality = verdict.quality
            self.metrics["grounded"] += 1
        elif effective == "fail":
            obs.grounding_status = "failed"
            obs.grounding_quality = 0.0
        else:
            obs.grounding_status = "untestable"
            obs.grounding_quality = 0.0
        record = {"result": effective, "kind": verdict.kind, "contact": verdict.contact,
                  "contact_quality": obs.grounding_quality,
                  "author": verdict.author, "reason": detail, "ts": time.time()}
        obs.grounding_history.append(record)
        self.ledger.record(obs.source, oid, effective, author=verdict.author,
                           note=f"{verdict.kind}/{verdict.contact}: {detail}")
        self.audit.append("observation_test", {"oid": oid, **record})
        self.rebuild_field()
        return verdict

    def test_identity(self, hid: str, test: GroundingTest,
                      min_quality: float = 0.75) -> Verdict:
        h = self.hypotheses[hid]
        hard_fails = [p for p in h.probes if p.hard and p.outcome == "fail"]
        if hard_fails:
            reason = ("identity test refused: hard invariant failure(s): " +
                      "; ".join(f"{p.name}: {p.detail}" for p in hard_fails))
            self.audit.append("identity_test_refused", {"hid": hid, "reason": reason})
            return Verdict("fail", "model", "identity_gate", test.author, reason=reason)
        if not math.isfinite(float(min_quality)) or not (0.0 <= min_quality <= 1.0):
            raise ValueError("min_quality must be in [0,1]")
        verdict = self.harness.run(test)
        self.metrics["identity_tests"] += 1
        sufficient = verdict.result == "pass" and verdict.quality >= min_quality
        record = {"result": verdict.result, "kind": verdict.kind,
                  "contact": verdict.contact, "contact_quality": verdict.quality,
                  "minimum_quality": min_quality, "sufficient": sufficient,
                  "author": verdict.author, "reason": verdict.reason, "ts": time.time()}
        h.test_history.append(record)
        if sufficient:
            h.status = "accepted"
            h.decided_at = time.time()
            h.decided_by = (f"registered test {verdict.kind}/{verdict.contact} "
                            f"quality={verdict.quality:.3f}")
            self._join(h.source_measurand_id, h.target_measurand_id)
        elif verdict.result == "pass":
            # A low-contact or workflow-level pass is evidence, not identity.
            h.status = "unresolved"
            h.decided_by = (f"insufficient contact quality {verdict.quality:.3f} "
                            f"< {min_quality:.3f}")
        elif verdict.result == "fail":
            h.status = "rejected"
            h.decided_at = time.time()
            h.decided_by = f"registered test {verdict.kind}/{verdict.contact}"
            self._split(h.source_measurand_id)
        else:
            h.status = "unresolved"
        self.audit.append("identity_test", {"hid": hid, **record, "status": h.status})
        self.rebuild_field()
        return verdict

    def retract_identity(self, hid: str, reason: str) -> None:
        h = self.hypotheses[hid]
        h.status = "retracted"
        h.decided_at = time.time()
        h.decided_by = reason
        self._split(h.source_measurand_id)
        self.audit.append("identity_retracted", {"hid": hid, "reason": reason})
        self.rebuild_field()

    # ------------------------------------------------------------------ field projection
    def _canonical_groups(self) -> Dict[str, List[Measurand]]:
        groups: Dict[str, List[Measurand]] = {}
        for m in self.measurands.values():
            groups.setdefault(self.canonical(m.mid), []).append(m)
        return groups

    def rebuild_field(self) -> Field:
        """Rebuild the constraint projection from immutable observations.

        Rebuilding rather than destructively moving nodes makes identity merges
        reversible and prevents historical provenance from being overwritten.
        """
        new = Field(self.name)
        self._evidence_for_observation = {}
        self._projection_fids = {}
        groups = self._canonical_groups()
        for root, members in groups.items():
            canonical = self.measurands[root]
            new.var(root, canonical.unit, note=(
                f"measurand: {canonical.label}; kind={canonical.kind_id}; "
                f"scope={canonical.scope.as_dict()}"))
        for obs in self.observations.values():
            if obs.value is None:
                continue
            root = self.canonical(obs.local_measurand_id)
            target = self.measurands[root]
            incoming_scale = unit_lookup(obs.unit)[1]
            value_target = obs.value * incoming_scale / unit_lookup(target.unit)[1]
            sigma_target = obs.sigma * incoming_scale / unit_lookup(target.unit)[1]
            tested = obs.grounding_status == "passed" and obs.test_count > 0
            eid = new.add_evidence(
                root, value_target, sigma_target, obs.source, obs.confidence,
                grounded_at=obs.last_grounded_at or None, tested=tested,
                contact=obs.contact, author=obs.grounding_author or obs.source,
                independence_key=obs.independence_key,
                contact_quality=obs.grounding_quality if tested else 1.0,
                statement=(f"{obs.label} = {obs.value} ± {obs.sigma} {obs.unit}; "
                           f"citation={obs.citation or 'none'}; observation={obs.oid}; "
                           f"receipt={obs.receipt_id}"),
            )
            if obs.grounding_status == "failed":
                new.evidence[eid].prov.confidence = 0.0
            self._evidence_for_observation[obs.oid] = eid
        # Only explicitly approved model specs become structural factors.
        if self.approved_specs:
            from .bridge import ingest
            for approved in self.approved_specs:
                # Older persisted snapshots may contain bare specs.
                if "spec" in approved:
                    spec = approved["spec"]
                    source = f"{approved.get('basis', 'declared_model')}: {approved.get('source', 'unknown')}"
                else:
                    spec, source = approved, "legacy declared model"
                ingest(spec, new, mode="declared", source=source,
                       authority_class=approved.get("basis", "declared_model") if "spec" in approved else "declared_model")
        self.field = new
        return new

    # ------------------------------------------------------------------ constraint proposals
    def propose_constraints(self, spec: dict, proposer: str = "unknown") -> ConstraintProposal:
        """Dimension-check a proposed model without granting structural authority."""
        from .bridge import validate_spec
        pid = _id("P")
        try:
            validate_spec(spec, self.field)
            status, reason = "valid", "dimensionally and structurally admissible proposal"
        except Exception as exc:
            status, reason = "invalid", f"{type(exc).__name__}: {exc}"
        p = ConstraintProposal(pid, json.loads(json.dumps(spec)), proposer, "proposed",
                               status, reason)
        self.constraint_proposals[pid] = p
        self.audit.append("constraint_proposed", asdict(p))
        return p

    def approve_constraints(self, pid: str, basis: str, source: str,
                            test: Optional[GroundingTest] = None,
                            min_invariant_quality: float = 0.90) -> ConstraintProposal:
        """Promote a model only through an explicit authority class.

        `definition` and `convention` are scoped declarations, not discoveries.
        `verified_invariant` requires a registered passing test.  An LLM or source
        name alone is never a valid basis.
        """
        p = self.constraint_proposals[pid]
        if p.dimensional_status != "valid":
            raise ValueError("cannot approve an invalid proposal")
        allowed = {"definition", "convention", "declared_model", "verified_invariant"}
        if basis not in allowed:
            raise ValueError(f"unknown promotion basis {basis!r}")
        verifier = None
        if basis == "verified_invariant":
            if not math.isfinite(float(min_invariant_quality)) or not (0.0 <= min_invariant_quality <= 1.0):
                raise ValueError("min_invariant_quality must be in [0,1]")
            if test is None:
                raise PermissionError("verified_invariant requires a registered test")
            verdict = self.harness.run(test)
            verifier = {"result": verdict.result, "kind": verdict.kind,
                        "contact": verdict.contact, "quality": verdict.quality,
                        "author": verdict.author, "reason": verdict.reason,
                        "minimum_quality": min_invariant_quality}
            if verdict.result != "pass":
                raise PermissionError(f"invariant test did not pass: {verdict.result}")
            if verdict.quality < min_invariant_quality:
                raise PermissionError(
                    f"invariant contact quality {verdict.quality:.3f} is below "
                    f"required {min_invariant_quality:.3f}")
        p.status, p.basis, p.source = "approved", basis, source
        self.approved_specs.append({"spec": p.spec, "basis": basis, "source": source,
                                    "verifier": verifier})
        self.audit.append("constraint_approved", {"pid": pid, "basis": basis,
                                                  "source": source, "verifier": verifier})
        self.rebuild_field()
        return p

    # ------------------------------------------------------------------ allocation/routing
    def allocate(self, top_k: int = 5) -> List[dict]:
        """Rank the next reality contacts by expected resolution per cost.

        This is a transparent one-step approximation, not a claim of optimal
        Bayesian design.  Identity tests receive impact proportional to the
        number of observations they could compose; observation tests receive
        impact from field degree and live disagreement.  Cost is explicit.
        """
        tasks: List[dict] = []
        group_sizes = {root: sum(len(m.observation_ids) for m in ms)
                       for root, ms in self._canonical_groups().items()}
        for h in self.hypotheses.values():
            if h.status not in {"unresolved", "proposed"}:
                continue
            p = min(0.99, max(0.01, h.score if h.score else 0.5))
            entropy_proxy = 4.0 * p * (1.0 - p)
            impact = 1.0 + group_sizes.get(self.canonical(h.target_measurand_id), 1)
            cost = 3.0  # identity generally needs richer context or an external lookup
            tasks.append({"type": "identity", "target": h.hid,
                          "score": entropy_proxy * impact / cost,
                          "why": "unresolved co-reference blocks composition",
                          "cost": cost})
        for obs in self.observations.values():
            if obs.value is None or obs.grounding_status == "passed":
                continue
            root = self.canonical(obs.local_measurand_id)
            degree = len(self.field._adj.get(root, []))
            belief = self.field.belief(root)
            disagreement = 1.5 if belief.contested else 1.0
            source_unc = self.ledger.trust(obs.source)["uncertainty"]
            impact = 1.0 + degree + group_sizes.get(root, 1)
            cost = 1.0 if obs.contact in {"direct", "instrument"} else 2.0
            tasks.append({"type": "observation", "target": obs.oid,
                          "score": disagreement * (0.5 + source_unc) * impact / cost,
                          "why": "untested claim supports a live measurand",
                          "cost": cost})
        tasks.sort(key=lambda x: (-x["score"], x["type"], x["target"]))
        return tasks[:top_k]

    def route(self, task: Mapping[str, object]) -> dict:
        """Heterogeneous POSIWID routing: use the cheapest mechanism that can decide."""
        typ = task.get("type")
        if typ == "identity":
            h = self.hypotheses[str(task["target"])]
            hard_unknown = [p.name for p in h.probes if p.outcome == "unknown" and
                            p.name in {"quantity_kind", "algebraic_character",
                                      "phenomenon", "measurand_scope",
                                      "operational_signature"}]
            if hard_unknown:
                return {"mechanism": "context_forager_or_registered_oracle",
                        "substrate": "I/O + CPU validation",
                        "reason": "missing structural identity probes: " + ", ".join(hard_unknown)}
            return {"mechanism": "deterministic_identity_gate", "substrate": "CPU",
                    "reason": "all structural probes are present; no semantic model needed"}
        if typ == "observation":
            obs = self.observations[str(task["target"])]
            return {"mechanism": "registered_measurement_or_source_check",
                    "substrate": "external contact",
                    "reason": f"{obs.source} assertion has zero authority until test survival"}
        return {"mechanism": "refuse_unknown_task", "substrate": "none",
                "reason": f"no routing contract for {typ!r}"}

    def project_beliefs(self, mids: Optional[Iterable[str]] = None,
                        k_sigma: float = 2.0,
                        allow_contested: bool = False) -> dict:
        """Make grounded beliefs calculable without pretending they are laws.

        Projection is explicit, reversible, and scoped to the current working
        field.  It is the bridge between weighted tested evidence and hard
        interval propagation.  Rebuilding the field removes every projection.
        """
        for fid in list(self._projection_fids.values()):
            self.field.release(fid)
        self._projection_fids = {}
        targets = list(mids) if mids is not None else list(self._canonical_groups())
        result = {"projected": {}, "refused": {}}
        for mid in targets:
            root = self.canonical(mid)
            if root not in self.field.variables or root in self._projection_fids:
                continue
            try:
                fid = self.field.project_belief(root, k_sigma=k_sigma,
                                                allow_contested=allow_contested,
                                                source="AKBC grounded-belief projection")
                self._projection_fids[root] = fid
                result["projected"][root] = fid
                self.audit.append("belief_projected", {"mid": root, "fid": fid,
                                  "k_sigma": k_sigma, "allow_contested": allow_contested})
            except ValueError as exc:
                result["refused"][root] = str(exc)
                self.audit.append("belief_projection_refused", {"mid": root,
                                  "reason": str(exc)})
        return result

    def settle(self, need_event_trace: bool = False,
               use_grounded_beliefs: bool = False,
               k_sigma: float = 2.0):
        """Settle through the heterogeneous router and record the actual route.

        Grounded evidence is soft by default.  ``use_grounded_beliefs=True``
        explicitly projects it as a reversible working interval before solving.
        """
        projection = None
        if use_grounded_beliefs:
            projection = self.project_beliefs(k_sigma=k_sigma)
        report, route = self.router.settle(self.field, need_event_trace=need_event_trace)
        self.audit.append("routed_settle", {
            "mechanism": route.mechanism, "substrate": route.substrate,
            "reason": route.reason, "elapsed_ms": route.elapsed_ms,
            "status": report.status, "projection": projection,
        })
        return report, route

    # ------------------------------------------------------------------ reports/persistence
    def disagreement(self, mid: str) -> dict:
        root = self.canonical(mid)
        b = self.field.belief(root)
        identity = [h for h in self.hypotheses.values()
                    if self.canonical(h.target_measurand_id) == root and
                    h.status in {"unresolved", "proposed"}]
        return {
            "measurand": root,
            "identity_disagreement": [h.hid for h in identity],
            "value_disagreement": bool(b.contested),
            "belief": {"mean": b.mean, "sigma": b.sigma,
                       "contributions": b.contributions,
                       "test": None if b.test is None else b.test.reason},
        }

    def verify_receipts(self) -> dict:
        broken = [rid for rid, receipt in self.receipts.items() if not receipt.verify()]
        return {"valid": not broken, "receipts": len(self.receipts),
                "snapshots": sum(bool(r.snapshot) for r in self.receipts.values()),
                "broken": broken}

    def receipt_for_observation(self, oid: str) -> Optional[SourceReceipt]:
        rid = self.observations[oid].receipt_id
        return self.receipts.get(rid)

    def posiwid(self) -> dict:
        """Report what the running system actually did, not what it is named."""
        groups = self._canonical_groups()
        grounded = sum(o.grounding_status == "passed" for o in self.observations.values())
        unresolved = sum(h.status in {"unresolved", "proposed"} for h in self.hypotheses.values())
        return {
            "observed_effects": {
                "carvings_retained": len(self.observations),
                "source_receipts_retained": len(self.receipts),
                "source_snapshots_retained": sum(bool(r.snapshot) for r in self.receipts.values()),
                "local_measurands_retained": len(self.measurands),
                "canonical_views": len(groups),
                "accepted_identity_hypotheses": sum(h.status == "accepted" for h in self.hypotheses.values()),
                "rejected_identity_hypotheses": sum(h.status == "rejected" for h in self.hypotheses.values()),
                "unresolved_identity_hypotheses": unresolved,
                "grounded_observations": grounded,
                "untested_observations": sum(o.grounding_status == "untested" for o in self.observations.values()),
                "field_evidence_records": len(self.field.evidence),
                "audit_events": len(self.audit.events),
                "routing_events": len(self.router.history),
                "active_belief_projections": len(self._projection_fids),
            },
            "next_tests": self.allocate(),
            "routing_efficiency": self.router.efficiency(),
            "audit_valid": self.audit.verify(),
            "receipt_integrity": self.verify_receipts(),
        }

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "receipts": [asdict(r) for r in self.receipts.values()],
            "kinds": [{**asdict(k), "dim": [str(x) for x in k.dim.exps],
                       "aliases": sorted(k.aliases)} for k in self.kinds.kinds.values()],
            "observations": [asdict(o) for o in self.observations.values()],
            "measurands": [{**asdict(m), "dim": [str(x) for x in m.dim.exps],
                            "aliases": sorted(m.aliases)} for m in self.measurands.values()],
            "hypotheses": [asdict(h) for h in self.hypotheses.values()],
            "parents": dict(self._canonical_parent),
            "constraint_proposals": [asdict(p) for p in self.constraint_proposals.values()],
            "approved_specs": self.approved_specs,
            "ledger": self.ledger.to_dict(),
            "audit": self.audit.to_dict(),
            "metrics": dict(self.metrics),
        }

    @classmethod
    def from_dict(cls, data: dict, harness: Optional[RealityHarness] = None) -> "FieldSystem":
        kinds = KindRegistry()
        for raw in data.get("kinds", []):
            kinds.register(raw["kid"], raw["label"], raw["unit"],
                           raw.get("algebraic_type", "unknown"),
                           raw.get("phenomenon", ""),
                           raw.get("operational_tags", ()),
                           raw.get("aliases", ()),
                           raw.get("provisional", False))
        system = cls(data.get("name", "field-system"), kinds=kinds, harness=harness)
        for raw in data.get("receipts", []):
            receipt = SourceReceipt(**raw)
            system.receipts[receipt.rid] = receipt
        for raw in data.get("observations", []):
            r = dict(raw)
            scope = r.get("scope", {})
            if isinstance(scope, dict) and "items" in scope:
                r["scope"] = Scope(tuple(tuple(x) for x in scope["items"]))
            else:
                r["scope"] = Scope.from_mapping(scope)
            r["operational_tags"] = tuple(r.get("operational_tags", ()))
            r["relations"] = tuple(r.get("relations", ()))
            system.observations[r["oid"]] = Observation(**r)
        for raw in data.get("measurands", []):
            r = dict(raw)
            r.pop("dim", None)
            scope = r.get("scope", {})
            if isinstance(scope, dict) and "items" in scope:
                r["scope"] = Scope(tuple(tuple(x) for x in scope["items"]))
            else:
                r["scope"] = Scope.from_mapping(scope)
            r["dim"] = unit_lookup(r["unit"])[0]
            r["operational_tags"] = tuple(r.get("operational_tags", ()))
            r["relation_tags"] = tuple(r.get("relation_tags", ()))
            r["aliases"] = set(r.get("aliases", ()))
            system.measurands[r["mid"]] = Measurand(**r)
        for raw in data.get("hypotheses", []):
            r = dict(raw)
            r["probes"] = [Probe(**p) for p in r.get("probes", [])]
            system.hypotheses[r["hid"]] = IdentityHypothesis(**r)
        for raw in data.get("constraint_proposals", []):
            system.constraint_proposals[raw["pid"]] = ConstraintProposal(**raw)
        if system.hypotheses:
            system._recompute_canonical()
        else:
            system._canonical_parent = dict(data.get("parents", {}))
            for mid in system.measurands:
                system._canonical_parent.setdefault(mid, mid)
        system.approved_specs = list(data.get("approved_specs", []))
        system.ledger = SourceLedger.from_dict(data.get("ledger", {}))
        system.audit = EventLog.from_dict(data.get("audit", {}))
        system.metrics.update(data.get("metrics", {}))
        system.rebuild_field()
        return system

    @classmethod
    def load(cls, path: str, harness: Optional[RealityHarness] = None) -> "FieldSystem":
        with open(path) as fh:
            return cls.from_dict(json.load(fh), harness=harness)

    def save(self, path: str) -> None:
        self.audit.snapshot(self.to_dict())
        with open(path, "w") as fh:
            json.dump(self.to_dict(), fh, indent=2)
