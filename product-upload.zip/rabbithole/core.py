"""RabbitHole core: interval arithmetic + dimensional algebra.

The two primitives everything else stands on:

  Interval  — the shape of what is still permitted for a variable.
              Propagation only ever SHRINKS intervals (pruning, never
              generation). Sound: no consistent value is ever removed.

  Dim       — a vector of exponents over base dimensions. Dimensional
              consistency is the first universal wall: constraints that
              don't dimension-check are rejected at registration,
              before any number moves.

Zero dependencies. Python stdlib only.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from fractions import Fraction
from typing import Callable

INF = math.inf

# ---------------------------------------------------------------------------
# Interval arithmetic (with careful infinity handling)
# ---------------------------------------------------------------------------



class Interval:
    """Closed interval with outward-rounded binary floating-point arithmetic.

    The inputs are IEEE-754 floats. Each arithmetic result encloses the exact
    real result of operating on those floats. Exact operations (for example,
    integer addition) are not needlessly widened; inexact operations are moved
    one representable float outward. This is a small but real enclosure
    guarantee, not the previous tolerance-only approximation.
    """

    __slots__ = ("lo", "hi")

    def __init__(self, lo: float, hi: float):
        self.lo = float(lo)
        self.hi = float(hi)

    def __eq__(self, other) -> bool:
        return isinstance(other, Interval) and self.lo == other.lo and self.hi == other.hi

    def __hash__(self) -> int:
        return hash((self.lo, self.hi))

    @staticmethod
    def full() -> "Interval":
        return Interval(-INF, INF)

    @staticmethod
    def empty() -> "Interval":
        return Interval(1.0, -1.0)

    @staticmethod
    def point(x: float) -> "Interval":
        if not math.isfinite(float(x)):
            raise ValueError("interval point must be finite")
        return Interval(float(x), float(x))

    def is_empty(self) -> bool:
        return self.lo > self.hi

    def is_point(self, tol: float = 0.0) -> bool:
        return not self.is_empty() and (self.hi - self.lo) <= tol

    def contains(self, x: float) -> bool:
        return (not self.is_empty()) and self.lo <= x <= self.hi

    def width(self) -> float:
        if self.is_empty():
            return 0.0
        return self.hi - self.lo

    def mid(self) -> float:
        if self.is_empty():
            return math.nan
        if math.isinf(self.lo) and math.isinf(self.hi):
            return 0.0
        if math.isinf(self.lo):
            return self.hi
        if math.isinf(self.hi):
            return self.lo
        return 0.5 * (self.lo + self.hi)

    def intersect(self, other: "Interval") -> "Interval":
        if self.is_empty() or other.is_empty():
            return Interval.empty()
        lo, hi = max(self.lo, other.lo), min(self.hi, other.hi)
        return Interval(lo, hi) if lo <= hi else Interval.empty()

    def hull(self, other: "Interval") -> "Interval":
        if self.is_empty():
            return other
        if other.is_empty():
            return self
        return Interval(min(self.lo, other.lo), max(self.hi, other.hi))

    def __add__(self, other: "Interval") -> "Interval":
        if self.is_empty() or other.is_empty():
            return Interval.empty()
        return Interval(_bin_down(self.lo, other.lo, "add"),
                        _bin_up(self.hi, other.hi, "add"))

    def __sub__(self, other: "Interval") -> "Interval":
        if self.is_empty() or other.is_empty():
            return Interval.empty()
        return Interval(_bin_down(self.lo, other.hi, "sub"),
                        _bin_up(self.hi, other.lo, "sub"))

    def __neg__(self) -> "Interval":
        if self.is_empty():
            return self
        return Interval(-self.hi, -self.lo)

    def scale(self, k: float) -> "Interval":
        if self.is_empty():
            return self
        if not math.isfinite(k):
            raise ValueError("interval scale must be finite")
        if k >= 0:
            return Interval(_bin_down(self.lo, k, "mul"),
                            _bin_up(self.hi, k, "mul"))
        return Interval(_bin_down(self.hi, k, "mul"),
                        _bin_up(self.lo, k, "mul"))

    def __mul__(self, other: "Interval") -> "Interval":
        if self.is_empty() or other.is_empty():
            return Interval.empty()
        lows, highs = [], []
        for a in (self.lo, self.hi):
            for b in (other.lo, other.hi):
                lows.append(_bin_down(a, b, "mul"))
                highs.append(_bin_up(a, b, "mul"))
        return Interval(min(lows), max(highs))

    def __truediv__(self, other: "Interval") -> "Interval":
        """If the divisor may be zero, no safe narrowing is possible."""
        if self.is_empty() or other.is_empty():
            return Interval.empty()
        if other.lo <= 0.0 <= other.hi:
            return Interval.full()
        rec = Interval(_bin_down(1.0, other.hi, "div"),
                       _bin_up(1.0, other.lo, "div"))
        return self * rec

    def power(self, n: int) -> "Interval":
        if self.is_empty():
            return self
        if n < 1:
            raise ValueError("interval power requires positive integer")
        if n == 1:
            return self
        if n % 2 == 1:
            return Interval(_pow_down(self.lo, n), _pow_up(self.hi, n))
        if self.lo >= 0:
            return Interval(_pow_down(self.lo, n), _pow_up(self.hi, n))
        if self.hi <= 0:
            return Interval(_pow_down(self.hi, n), _pow_up(self.lo, n))
        return Interval(0.0, max(_pow_up(self.lo, n), _pow_up(self.hi, n)))

    def root_branches(self, n: int) -> "list[Interval]":
        if self.is_empty():
            return []
        if n < 1:
            raise ValueError("root requires positive integer")
        if n % 2 == 1:
            return [Interval(_root_down(self.lo, n), _root_up(self.hi, n))]
        if self.hi < 0:
            return []
        lo = max(self.lo, 0.0)
        r_lo, r_hi = _root_down(lo, n), _root_up(self.hi, n)
        return [Interval(r_lo, r_hi), Interval(-r_hi, -r_lo)]

    def __repr__(self) -> str:
        if self.is_empty():
            return "∅"
        if self.is_point():
            return f"{{{_fmt(self.lo)}}}"
        return f"[{_fmt(self.lo)}, {_fmt(self.hi)}]"


def _fraction(x: float) -> Fraction:
    return Fraction.from_float(float(x))


def _raw_binary(a: float, b: float, op: str) -> float:
    if op == "add":
        return a + b
    if op == "sub":
        return a - b
    if op == "mul":
        if a == 0.0 or b == 0.0:
            return 0.0
        return a * b
    if op == "div":
        return a / b
    raise ValueError(op)


def _exact_binary(a: float, b: float, op: str) -> Fraction:
    fa, fb = _fraction(a), _fraction(b)
    if op == "add":
        return fa + fb
    if op == "sub":
        return fa - fb
    if op == "mul":
        return fa * fb
    if op == "div":
        return fa / fb
    raise ValueError(op)


def _bin_round(a: float, b: float, op: str, upward: bool) -> float:
    # Handle interval conventions and infinities before exact rational checks.
    if op == "mul" and (a == 0.0 or b == 0.0):
        return 0.0
    try:
        r = _raw_binary(a, b, op)
    except OverflowError:
        sign = -1.0 if ((a < 0) ^ (b < 0)) else 1.0
        return math.copysign(INF, sign)
    if not (math.isfinite(a) and math.isfinite(b) and math.isfinite(r)):
        return r
    # Hot-path exactness: propagation graphs commonly use small integral
    # coefficients and bounds. Their +, -, and modest products are exactly
    # representable in binary64, so avoid Fraction allocation entirely.
    if a.is_integer() and b.is_integer() and abs(a) < 2**26 and abs(b) < 2**26:
        if op in {"add", "sub"}:
            return r
        if op == "mul" and abs(a * b) < 2**53:
            return r
        if op == "div" and b != 0 and r.as_integer_ratio()[1] & (r.as_integer_ratio()[1] - 1) == 0:
            if _fraction(r) == _fraction(a) / _fraction(b):
                return r
    exact = _exact_binary(a, b, op)
    fr = _fraction(r)
    if upward and fr < exact:
        return math.nextafter(r, INF)
    if not upward and fr > exact:
        return math.nextafter(r, -INF)
    return r


def _bin_down(a: float, b: float, op: str) -> float:
    return _bin_round(a, b, op, False)


def _bin_up(a: float, b: float, op: str) -> float:
    return _bin_round(a, b, op, True)


def _pow_round(x: float, n: int, upward: bool) -> float:
    if math.isinf(x):
        return INF if (x > 0 or n % 2 == 0) else -INF
    try:
        r = x ** n
    except OverflowError:
        return -INF if (x < 0 and n % 2 == 1) else INF
    if not math.isfinite(r):
        return r
    exact = _fraction(x) ** n
    fr = _fraction(r)
    if upward and fr < exact:
        return math.nextafter(r, INF)
    if not upward and fr > exact:
        return math.nextafter(r, -INF)
    return r


def _pow_down(x: float, n: int) -> float:
    return _pow_round(x, n, False)


def _pow_up(x: float, n: int) -> float:
    return _pow_round(x, n, True)


def _root_raw(x: float, n: int) -> float:
    if math.isinf(x):
        return math.copysign(INF, x)
    return math.copysign(abs(x) ** (1.0 / n), x)


def _root_round(x: float, n: int, upward: bool) -> float:
    """Directed enclosure for an integer root of a binary64 endpoint.

    ``libm`` root estimates are not assumed correctly rounded.  We verify the
    candidate using exact rational exponentiation of the candidate float and
    move outward until its nth power is on the required side of the exact input
    float.  This is slower than one ``nextafter`` but runs only on root factors
    and makes the Python oracle's enclosure claim real.
    """
    r = _root_raw(x, n)
    if not math.isfinite(r) or r == 0.0:
        return r
    target = _fraction(x)
    direction = INF if upward else -INF
    for _ in range(10_000):  # defensive cap; ordinary libm is within a few ulps
        powered = _fraction(r) ** n
        if (upward and powered >= target) or (not upward and powered <= target):
            return r
        nxt = math.nextafter(r, direction)
        if nxt == r:
            return r
        r = nxt
    raise ArithmeticError("unable to outward-round interval root")


def _root_down(x: float, n: int) -> float:
    return _root_round(x, n, False)


def _root_up(x: float, n: int) -> float:
    return _root_round(x, n, True)


def _fmt(x: float) -> str:
    if math.isinf(x):
        return "∞" if x > 0 else "-∞"
    if x == int(x) and abs(x) < 1e15:
        return str(int(x))
    return f"{x:.6g}"


# ---------------------------------------------------------------------------
# Dimensional algebra
# ---------------------------------------------------------------------------

# SI base dimensions + currency ($) + count (#) so the same wall that guards
# physics also guards economics and inventory. Exponents are Fractions so
# square roots of dimensions (e.g. sqrt(m^2/s^2) -> m/s) stay exact.
BASE = ("kg", "m", "s", "A", "K", "mol", "cd", "$", "#")


@dataclass(frozen=True)
class Dim:
    exps: tuple  # tuple[Fraction, ...] length == len(BASE)

    @staticmethod
    def none() -> "Dim":
        return Dim(tuple(Fraction(0) for _ in BASE))

    @staticmethod
    def base(symbol: str) -> "Dim":
        i = BASE.index(symbol)
        return Dim(tuple(Fraction(1 if j == i else 0) for j in range(len(BASE))))

    def __mul__(self, other: "Dim") -> "Dim":
        return Dim(tuple(a + b for a, b in zip(self.exps, other.exps)))

    def __truediv__(self, other: "Dim") -> "Dim":
        return Dim(tuple(a - b for a, b in zip(self.exps, other.exps)))

    def power(self, k) -> "Dim":
        k = Fraction(k)
        return Dim(tuple(a * k for a in self.exps))

    def is_none(self) -> bool:
        return all(e == 0 for e in self.exps)

    def __repr__(self) -> str:
        if self.is_none():
            return "1"
        num, den = [], []
        for sym, e in zip(BASE, self.exps):
            if e == 0:
                continue
            part = sym if abs(e) == 1 else f"{sym}^{abs(e)}"
            (num if e > 0 else den).append(part)
        s = "·".join(num) if num else "1"
        if den:
            s += "/" + "·".join(den)
        return s


# ---------------------------------------------------------------------------
# Units: a small, real registry. A unit is a Dim plus a scale to coherent SI.
# ---------------------------------------------------------------------------

_D1 = Dim.none()
_KG, _M, _S = Dim.base("kg"), Dim.base("m"), Dim.base("s")
_A, _K, _MOL, _CD = Dim.base("A"), Dim.base("K"), Dim.base("mol"), Dim.base("cd")
_USD, _CNT = Dim.base("$"), Dim.base("#")

_N = _KG * _M / (_S * _S)
_J = _N * _M
_W = _J / _S
_PA = _N / (_M * _M)
_V = _W / _A
_OHM = _V / _A

UNITS: dict = {
    "": (_D1, 1.0),
    "1": (_D1, 1.0),
    "m": (_M, 1.0),
    "km": (_M, 1e3),
    "cm": (_M, 1e-2),
    "mm": (_M, 1e-3),
    "s": (_S, 1.0),
    "min": (_S, 60.0),
    "h": (_S, 3600.0),
    "day": (_S, 86400.0),
    "kg": (_KG, 1.0),
    "g": (_KG, 1e-3),
    "t": (_KG, 1e3),
    "K": (_K, 1.0),
    "A": (_A, 1.0),
    "mol": (_MOL, 1.0),
    "cd": (_CD, 1.0),
    "N": (_N, 1.0),
    "J": (_J, 1.0),
    "N*m": (_J, 1.0),
    "N·m": (_J, 1.0),
    "kJ": (_J, 1e3),
    "kWh": (_J, 3.6e6),
    "W": (_W, 1.0),
    "kW": (_W, 1e3),
    "Pa": (_PA, 1.0),
    "Hz": (_D1 / _S, 1.0),
    "Bq": (_D1 / _S, 1.0),
    "1/s": (_D1 / _S, 1.0),
    "s^-1": (_D1 / _S, 1.0),
    "rad/s": (_D1 / _S, 1.0),
    "V": (_V, 1.0),
    "ohm": (_OHM, 1.0),
    "m/s": (_M / _S, 1.0),
    "km/h": (_M / _S, 1000.0 / 3600.0),
    "m/s^2": (_M / (_S * _S), 1.0),
    "m^2/s^2": ((_M / _S) * (_M / _S), 1.0),
    "J*s": (_J * _S, 1.0),
    "C": (_A * _S, 1.0),
    "1/mol": (_D1 / _MOL, 1.0),
    "m^2": (_M * _M, 1.0),
    "m^3": (_M * _M * _M, 1.0),
    "kg/m^3": (_KG / (_M * _M * _M), 1.0),
    "g/cm^3": (_KG / (_M * _M * _M), 1000.0),
    "$": (_USD, 1.0),
    "k$": (_USD, 1e3),
    "item": (_CNT, 1.0),
    "$/item": (_USD / _CNT, 1.0),
    "item/s": (_CNT / _S, 1.0),
    "item/day": (_CNT / _S, 1.0 / 86400.0),
    "$/s": (_USD / _S, 1.0),
    "$/day": (_USD / _S, 1.0 / 86400.0),
    "J/K": (_J / _K, 1.0),
}


def unit(name: str):
    """Look up a unit -> (Dim, scale-to-SI). Raises KeyError for unknown."""
    return UNITS[name]