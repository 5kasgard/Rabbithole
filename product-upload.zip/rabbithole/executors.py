"""Small auditable external-contact executors.

These executors do not decide their own epistemic status.  The harness fixes the
contact type and quality at registration.  They only return reproducible outputs.
"""
from __future__ import annotations
import json, urllib.parse, urllib.request
from dataclasses import dataclass
from typing import Mapping
from .acquisition import AcquisitionEngine, FetchPolicy
from .tether import Measurement

@dataclass
class HTTPJSONMeasurement:
    acquisition: AcquisitionEngine
    policy: FetchPolicy = FetchPolicy(allowed_schemes=("https",))
    def __call__(self,spec:Mapping[str,object]):
        locator=str(spec["locator"]); path=str(spec.get("json_path","value")); sigma_path=str(spec.get("sigma_path","sigma")); unit_path=str(spec.get("unit_path","unit"))
        parsed=self.acquisition.acquire(locator,self.policy)
        obj=json.loads(parsed.text)
        def get(p):
            cur=obj
            for key in p.split('.'):
                if key: cur=cur[int(key)] if isinstance(cur,list) else cur[key]
            return cur
        return Measurement(float(get(path)),float(get(sigma_path)),str(get(unit_path)) if unit_path else "")

@dataclass
class FileHashPredicate:
    acquisition: AcquisitionEngine
    policy: FetchPolicy = FetchPolicy(allowed_schemes=("file","https"))
    def __call__(self,spec:Mapping[str,object]):
        parsed=self.acquisition.acquire(str(spec["locator"]),self.policy)
        return parsed.artifact.content_sha256 == str(spec["expected_sha256"])
