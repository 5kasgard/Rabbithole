"""Deterministic front-door goal and ambiguity gate.

This does not infer a user's values.  It identifies when a request lacks the
minimum target, authority, success condition, or risk information required to
proceed safely.  An LLM may later propose a richer contract, but it cannot
bypass this gate.
"""
from __future__ import annotations

import re
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Mapping, Sequence, Tuple


def _id() -> str:
    return f"GOL{uuid.uuid4().hex[:12]}"


@dataclass
class GoalRequest:
    text: str
    success_conditions: Tuple[str, ...] = ()
    constraints: Tuple[str, ...] = ()
    stakeholders: Tuple[str, ...] = ()
    risk_tier: str = "low"  # low|medium|high|critical
    irreversible: bool = False
    requested_actions: Tuple[str, ...] = ()
    authorized_by: str = ""
    context: Mapping[str, object] = field(default_factory=dict)
    request_id: str = field(default_factory=_id)


@dataclass
class GoalDecision:
    request_id: str
    state: str  # ready|clarification_required|refused
    target: str
    clarifications: Tuple[str, ...]
    assumptions: Tuple[str, ...]
    contradictions: Tuple[str, ...]
    authority_owner: str
    reason: str
    created_at: float = field(default_factory=time.time)


class GoalGate:
    PRONOUN_ONLY = re.compile(r"(?i)^\s*(do|delete|change|fix|send|move|buy|approve|run)\s+(it|that|this|them)\b")
    DESTRUCTIVE = re.compile(r"(?i)\b(delete|destroy|terminate|publish|send|purchase|transfer|execute|deploy|approve)\b")

    def evaluate(self, req: GoalRequest) -> GoalDecision:
        text = req.text.strip()
        if not text:
            return GoalDecision(req.request_id, "refused", "", (), (), (), "",
                                "empty request has no testable target")
        if req.risk_tier not in {"low", "medium", "high", "critical"}:
            raise ValueError("invalid risk tier")
        clarifications, assumptions, contradictions = [], [], []
        if self.PRONOUN_ONLY.search(text):
            clarifications.append("identify the target object or system")
        if not req.success_conditions:
            clarifications.append("state an observable success condition")
        if req.irreversible or (req.risk_tier in {"high", "critical"} and self.DESTRUCTIVE.search(text)):
            if not req.authorized_by:
                clarifications.append("identify the accountable authority for the irreversible or high-stakes decision")
            if not req.requested_actions:
                clarifications.append("state the exact action boundary and what must remain untouched")
        # Detect direct textual constraint contradictions of the form "must X" and "must not X".
        normalized = {re.sub(r"\s+", " ", c.strip().lower()) for c in req.constraints}
        for c in list(normalized):
            if c.startswith("must ") and "must not " + c[5:] in normalized:
                contradictions.append(f"both required and forbidden: {c[5:]}")
            if c.startswith("must not ") and "must " + c[9:] in normalized:
                contradictions.append(f"both required and forbidden: {c[9:]}")
        if contradictions:
            return GoalDecision(req.request_id, "clarification_required", text,
                                tuple(clarifications), tuple(assumptions), tuple(sorted(set(contradictions))),
                                req.authorized_by, "goal constraints are internally inconsistent")
        if clarifications:
            return GoalDecision(req.request_id, "clarification_required", text,
                                tuple(dict.fromkeys(clarifications)), tuple(assumptions), (),
                                req.authorized_by, "request is underspecified for its consequences")
        return GoalDecision(req.request_id, "ready", text, (), tuple(assumptions), (),
                            req.authorized_by, "minimum behavioral contract is explicit")
