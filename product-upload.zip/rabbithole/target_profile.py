"""Versioned cross-domain target profiles without identity collapse.

A profile is a view over attributable artifacts, claims, actions, relations and
outcomes. It does not fuse rival identity hypotheses or grant source claims
truth. Every update is versioned, provenance-addressed and revocable.
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Mapping


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _id(prefix: str, payload: Any) -> str:
    return f"{prefix}{hashlib.sha256(_canonical(payload)).hexdigest()[:16]}"


@dataclass(frozen=True)
class ProfileAssertion:
    assertion_id: str
    category: str
    statement: str
    value: Any
    source_ids: tuple[str, ...]
    identity_hypothesis_id: str
    observed_at: float | None = None
    valid_from: float | None = None
    valid_to: float | None = None
    confidence: float = 0.0
    status: str = "proposed"  # proposed | supported | falsified | contested | revoked
    authority_ceiling: float = 0.0
    legal_basis: str = ""
    access_scope: tuple[str, ...] = ()
    dependencies: tuple[str, ...] = ()
    created_at: float = field(default_factory=time.time)

    def validate(self) -> None:
        if not self.assertion_id or not self.category or not self.statement:
            raise ValueError("assertion identity, category and statement are required")
        if not self.source_ids:
            raise ValueError("profile assertions require at least one source")
        if not self.identity_hypothesis_id:
            raise ValueError("identity hypothesis is required")
        if self.status not in {"proposed", "supported", "falsified", "contested", "revoked"}:
            raise ValueError("invalid assertion status")
        if not 0.0 <= self.confidence <= 1.0 or not 0.0 <= self.authority_ceiling <= 1.0:
            raise ValueError("confidence and authority ceiling must be in [0,1]")
        if self.status == "proposed" and self.authority_ceiling > 0:
            raise ValueError("untested profile assertion cannot carry authority")


@dataclass(frozen=True)
class IdentityHypothesis:
    hypothesis_id: str
    target_type: str
    labels: tuple[str, ...]
    source_ids: tuple[str, ...]
    status: str = "unresolved"  # unresolved | supported | rejected | superseded
    confidence: float = 0.0
    opposition: tuple[str, ...] = ()
    created_at: float = field(default_factory=time.time)

    def validate(self) -> None:
        if not self.hypothesis_id or not self.target_type or not self.labels or not self.source_ids:
            raise ValueError("identity hypothesis is incomplete")
        if self.status not in {"unresolved", "supported", "rejected", "superseded"}:
            raise ValueError("invalid identity status")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("identity confidence must be in [0,1]")


class TargetProfile:
    def __init__(self, profile_id: str, canonical_label: str, *, owner: str, privacy_policy: str):
        if not profile_id or not canonical_label or not owner or not privacy_policy:
            raise ValueError("profile identity, owner and privacy policy are required")
        self.profile_id = profile_id
        self.canonical_label = canonical_label
        self.owner = owner
        self.privacy_policy = privacy_policy
        self.identities: dict[str, IdentityHypothesis] = {}
        self.assertions: dict[str, ProfileAssertion] = {}
        self.revocations: list[dict[str, Any]] = []
        self.versions: list[dict[str, Any]] = []
        self.created_at = time.time()
        self._commit("profile_created", {"label": canonical_label})

    def _commit(self, event: str, payload: Mapping[str, Any]) -> str:
        previous = self.versions[-1]["digest"] if self.versions else "0" * 64
        row = {
            "version": len(self.versions) + 1,
            "event": event,
            "payload": dict(payload),
            "previous": previous,
            "recorded_at": time.time(),
        }
        digest = hashlib.sha256(_canonical(row)).hexdigest()
        row["digest"] = digest
        self.versions.append(row)
        return digest

    def add_identity(self, hypothesis: IdentityHypothesis) -> str:
        hypothesis.validate()
        if hypothesis.hypothesis_id in self.identities:
            raise ValueError("duplicate identity hypothesis")
        self.identities[hypothesis.hypothesis_id] = hypothesis
        return self._commit("identity_added", asdict(hypothesis))

    def add_assertion(self, assertion: ProfileAssertion) -> str:
        assertion.validate()
        if assertion.assertion_id in self.assertions:
            raise ValueError("duplicate assertion")
        if assertion.identity_hypothesis_id not in self.identities:
            raise ValueError("unknown identity hypothesis")
        unknown = [dep for dep in assertion.dependencies if dep not in self.assertions]
        if unknown:
            raise ValueError(f"unknown assertion dependencies: {unknown}")
        self.assertions[assertion.assertion_id] = assertion
        return self._commit("assertion_added", asdict(assertion))

    def propose_assertion(self, *, category: str, statement: str, value: Any,
                          source_ids: tuple[str, ...], identity_hypothesis_id: str,
                          dependencies: tuple[str, ...] = (), legal_basis: str = "",
                          access_scope: tuple[str, ...] = ()) -> ProfileAssertion:
        payload = {
            "profile_id": self.profile_id,
            "category": category,
            "statement": statement,
            "value": value,
            "source_ids": source_ids,
            "identity_hypothesis_id": identity_hypothesis_id,
            "dependencies": dependencies,
        }
        row = ProfileAssertion(
            assertion_id=_id("PA", payload), category=category, statement=statement,
            value=value, source_ids=source_ids,
            identity_hypothesis_id=identity_hypothesis_id,
            dependencies=dependencies, legal_basis=legal_basis,
            access_scope=access_scope,
        )
        self.add_assertion(row)
        return row

    def revoke(self, assertion_id: str, *, actor: str, reason: str) -> list[str]:
        if assertion_id not in self.assertions:
            raise KeyError(assertion_id)
        revoked: list[str] = []
        frontier = [assertion_id]
        while frontier:
            current = frontier.pop()
            if current in revoked:
                continue
            revoked.append(current)
            frontier.extend(
                aid for aid, row in self.assertions.items()
                if current in row.dependencies and aid not in revoked
            )
        record = {"assertion_ids": revoked, "actor": actor, "reason": reason, "recorded_at": time.time()}
        self.revocations.append(record)
        self._commit("assertions_revoked", record)
        return revoked

    def view(self, *, include_proposed: bool = True, access_scope: set[str] | None = None) -> dict[str, Any]:
        revoked = {aid for row in self.revocations for aid in row["assertion_ids"]}
        rows = []
        for aid, assertion in self.assertions.items():
            if aid in revoked:
                continue
            if not include_proposed and assertion.status == "proposed":
                continue
            if assertion.access_scope and access_scope is not None and not set(assertion.access_scope).issubset(access_scope):
                continue
            rows.append(asdict(assertion))
        return {
            "schema": "field.target-profile/1",
            "profile_id": self.profile_id,
            "canonical_label": self.canonical_label,
            "owner": self.owner,
            "privacy_policy": self.privacy_policy,
            "identity_hypotheses": [asdict(row) for row in self.identities.values()],
            "assertions": rows,
            "revocations": list(self.revocations),
            "version": len(self.versions),
            "version_digest": self.versions[-1]["digest"],
            "semantic_authority_granted_by_profile": False,
        }

    def verify(self) -> dict[str, Any]:
        errors: list[str] = []
        previous = "0" * 64
        for expected, row in enumerate(self.versions, start=1):
            base = {k: v for k, v in row.items() if k != "digest"}
            if row.get("version") != expected or row.get("previous") != previous:
                errors.append(f"version chain error at {expected}")
            digest = hashlib.sha256(_canonical(base)).hexdigest()
            if digest != row.get("digest"):
                errors.append(f"version digest mismatch at {expected}")
            previous = str(row.get("digest"))
        for row in self.identities.values():
            try: row.validate()
            except Exception as exc: errors.append(str(exc))
        for row in self.assertions.values():
            try: row.validate()
            except Exception as exc: errors.append(str(exc))
        return {
            "valid": not errors,
            "identity_hypotheses": len(self.identities),
            "assertions": len(self.assertions),
            "versions": len(self.versions),
            "external_identity_quality_established": False,
            "errors": errors,
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "canonical_label": self.canonical_label,
            "owner": self.owner,
            "privacy_policy": self.privacy_policy,
            "created_at": self.created_at,
            "identities": [asdict(row) for row in self.identities.values()],
            "assertions": [asdict(row) for row in self.assertions.values()],
            "revocations": self.revocations,
            "versions": self.versions,
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "TargetProfile":
        obj = cls.__new__(cls)
        obj.profile_id = str(raw["profile_id"])
        obj.canonical_label = str(raw["canonical_label"])
        obj.owner = str(raw["owner"])
        obj.privacy_policy = str(raw["privacy_policy"])
        obj.created_at = float(raw.get("created_at", time.time()))
        obj.identities = {}
        for row in raw.get("identities", []):
            item = dict(row); item["labels"] = tuple(item.get("labels", ())); item["source_ids"] = tuple(item.get("source_ids", ())); item["opposition"] = tuple(item.get("opposition", ()))
            hyp = IdentityHypothesis(**item); obj.identities[hyp.hypothesis_id] = hyp
        obj.assertions = {}
        for row in raw.get("assertions", []):
            item = dict(row); item["source_ids"] = tuple(item.get("source_ids", ())); item["access_scope"] = tuple(item.get("access_scope", ())); item["dependencies"] = tuple(item.get("dependencies", ()))
            assertion = ProfileAssertion(**item); obj.assertions[assertion.assertion_id] = assertion
        obj.revocations = list(raw.get("revocations", []))
        obj.versions = list(raw.get("versions", []))
        return obj
