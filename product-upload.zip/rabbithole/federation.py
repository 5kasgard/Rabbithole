"""Content-addressed append-only exchange without consensus laundering.

Transport convergence and integrity are separated from semantic agreement.
Divergent versions are retained as conflicts; last-write-wins is never used for
knowledge or authority-bearing objects.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Tuple


def _canon(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")


@dataclass
class FederationBundle:
    producer: str
    events: Tuple[Mapping[str, object], ...]
    parent_digests: Tuple[str, ...] = ()
    sequence: int = 0
    created_at: float = field(default_factory=time.time)
    digest: str = ""
    signature: str = ""

    def material(self) -> dict:
        return {"producer": self.producer, "events": self.events,
                "parent_digests": self.parent_digests, "sequence": self.sequence,
                "created_at": self.created_at}

    def seal(self, key: bytes = b"") -> "FederationBundle":
        self.digest = hashlib.sha256(_canon(self.material())).hexdigest()
        self.signature = hmac.new(key, self.digest.encode(), hashlib.sha256).hexdigest() if key else ""
        return self

    def verify(self, key: bytes = b"") -> bool:
        digest = hashlib.sha256(_canon(self.material())).hexdigest()
        if not hmac.compare_digest(digest, self.digest):
            return False
        return not key or hmac.compare_digest(
            hmac.new(key, digest.encode(), hashlib.sha256).hexdigest(), self.signature)


@dataclass
class ObjectVersion:
    object_id: str
    producer: str
    bundle_digest: str
    payload: Mapping[str, object]
    payload_digest: str
    sequence: int
    created_at: float


@dataclass
class MergeConflict:
    object_id: str
    local_digest: str
    remote_digest: str
    local_producer: str
    remote_producer: str
    reason: str
    created_at: float = field(default_factory=time.time)


class FederationLedger:
    def __init__(self):
        self.bundles: Dict[str, FederationBundle] = {}
        self.versions: Dict[str, list[ObjectVersion]] = {}
        self.conflicts: list[MergeConflict] = []
        self.last_sequence: Dict[str, int] = {}

    @property
    def objects(self) -> Dict[str, Mapping[str, object]]:
        # Compatibility view: first accepted version only.  Callers needing
        # current semantic resolution must inspect versions/conflicts.
        return {oid: rows[0].payload for oid, rows in self.versions.items() if rows}

    def import_bundle(self, bundle: FederationBundle, key: bytes = b"") -> dict:
        if not bundle.verify(key):
            raise ValueError("bundle integrity or signature failed")
        if bundle.digest in self.bundles:
            return {"duplicate": True, "accepted": 0, "conflicts": 0, "gaps": 0}
        expected = self.last_sequence.get(bundle.producer, -1) + 1
        gaps = 0
        if bundle.sequence != expected:
            gaps = 1
        missing_parents = [x for x in bundle.parent_digests if x not in self.bundles]
        if missing_parents:
            raise ValueError(f"bundle parents are missing: {missing_parents}")
        accepted = 0
        before = len(self.conflicts)
        for event in bundle.events:
            oid = str(event.get("object_id", ""))
            payload = event.get("payload")
            if not oid or not isinstance(payload, Mapping):
                self.conflicts.append(MergeConflict(oid, "", "", "", bundle.producer,
                                                    "malformed event"))
                continue
            pd = hashlib.sha256(_canon(payload)).hexdigest()
            version = ObjectVersion(oid, bundle.producer, bundle.digest, dict(payload), pd,
                                    bundle.sequence, bundle.created_at)
            rows = self.versions.setdefault(oid, [])
            if any(x.payload_digest == pd for x in rows):
                continue
            if rows:
                self.conflicts.append(MergeConflict(
                    oid, rows[-1].payload_digest, pd, rows[-1].producer,
                    bundle.producer, "divergent semantic object; retained without overwrite"))
            rows.append(version)
            accepted += 1
        self.bundles[bundle.digest] = bundle
        self.last_sequence[bundle.producer] = max(bundle.sequence, self.last_sequence.get(bundle.producer, -1))
        return {"duplicate": False, "accepted": accepted,
                "conflicts": len(self.conflicts) - before, "gaps": gaps}

    def to_dict(self) -> dict:
        return {"bundles": [asdict(x) for x in self.bundles.values()],
                "versions": {k: [asdict(x) for x in v] for k, v in self.versions.items()},
                "conflicts": [asdict(x) for x in self.conflicts],
                "last_sequence": dict(self.last_sequence)}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "FederationLedger":
        obj = cls()
        for row in raw.get("bundles", []):
            d = dict(row); d["events"] = tuple(d.get("events", ())); d["parent_digests"] = tuple(d.get("parent_digests", ()))
            b = FederationBundle(**d); obj.bundles[b.digest] = b
        for oid, rows in dict(raw.get("versions", {})).items():
            obj.versions[str(oid)] = [ObjectVersion(**dict(x)) for x in rows]
        obj.conflicts = [MergeConflict(**dict(x)) for x in raw.get("conflicts", [])]
        obj.last_sequence = {str(k): int(v) for k, v in dict(raw.get("last_sequence", {})).items()}
        return obj
