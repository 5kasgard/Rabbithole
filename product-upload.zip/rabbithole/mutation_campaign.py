"""Requirement-specific architectural mutations and survivor review."""
from __future__ import annotations
import contextlib,time,uuid
from dataclasses import asdict,dataclass,field
from typing import Callable,Dict,Mapping,Optional,Sequence,Tuple
from .organs import OrganRegistry
from .wal import EventLog

def _id(p):return f"{p}{uuid.uuid4().hex[:12]}"
@dataclass
class MutationOperator:
    mutation_id:str;capability:str;target:str;operator_type:str;expected_failure:str;requirement_id:str;enabled:bool=True
@dataclass
class MutationExecution:
    mutation_id:str;baseline_passed:bool;mutant_passed:bool;expected_failure_observed:bool;baseline_digest:str;mutant_digest:str;error:str="";state:str="executed";execution_id:str=field(default_factory=lambda:_id("MEX"));created_at:float=field(default_factory=time.time)
    @property
    def killed(self):return self.baseline_passed and not self.mutant_passed and self.expected_failure_observed
class MutationCampaign:
    def __init__(self):self.operators:Dict[str,MutationOperator]={};self.executions:Dict[str,MutationExecution]={};self.survivor_queue:list[dict]=[];self.audit=EventLog()
    def register(self,m:MutationOperator):self.operators[m.mutation_id]=m;self.audit.append("mutation_registered",asdict(m))
    @staticmethod
    def _digest(x):
        import hashlib,json
        return hashlib.sha256(json.dumps(x,sort_keys=True,default=str).encode()).hexdigest()
    def run_organ(self,mutation_id:str,organs:OrganRegistry,invoke:Callable[[],object],observe:Callable[[object],Mapping[str,object]])->MutationExecution:
        m=self.operators[mutation_id]
        try:b=invoke();bo=dict(observe(b));bp=bool(bo.get("passed",False));bd=self._digest(b)
        except Exception as exc:
            e=MutationExecution(mutation_id,False,False,False,"","",f"baseline: {type(exc).__name__}: {exc}");self.executions[e.execution_id]=e;return e
        mutant_passed=False;expected=False;md="";err=""
        try:
            with organs.disabled(m.target,"stage4c mutation"):
                x=invoke();xo=dict(observe(x));mutant_passed=bool(xo.get("passed",False));md=self._digest(x);expected=str(xo.get("failure",""))==m.expected_failure
        except Exception as exc:
            err=f"{type(exc).__name__}: {exc}";expected=m.expected_failure in err or m.target in err
        e=MutationExecution(mutation_id,bp,mutant_passed,expected,bd,md,err);self.executions[e.execution_id]=e
        if not e.killed:self.survivor_queue.append({"execution_id":e.execution_id,"mutation_id":mutation_id,"target":m.target,"classification":"unreviewed"})
        self.audit.append("mutation_executed",asdict(e)|{"killed":e.killed});return e
    def classify_survivor(self,execution_id:str,classification:str,reviewer:str,rationale:str):
        allowed={"equivalent_mutant","test_gap","requirement_gap","decorative_target","invalid_mutation"}
        if classification not in allowed:raise ValueError(classification)
        row=next(x for x in self.survivor_queue if x["execution_id"]==execution_id);row.update({"classification":classification,"reviewer":reviewer,"rationale":rationale,"reviewed_at":time.time()});self.audit.append("mutation_survivor_classified",dict(row));return row
    def coverage(self,required_capabilities:Sequence[str])->dict:
        by={c:[m for m in self.operators.values() if m.capability==c and m.enabled] for c in required_capabilities};executed={self.operators[e.mutation_id].capability for e in self.executions.values() if e.killed};unreviewed=[x for x in self.survivor_queue if x.get("classification")=="unreviewed"]
        return {"required_capabilities":list(required_capabilities),"missing_operators":sorted(c for c,x in by.items() if not x),"killed_capabilities":sorted(executed),"unkilled_capabilities":sorted(set(required_capabilities)-executed),"unreviewed_survivors":unreviewed,"passed":not [c for c,x in by.items() if not x] and not (set(required_capabilities)-executed) and not unreviewed}
    def to_dict(self):return {"operators":[asdict(x) for x in self.operators.values()],"executions":[asdict(x) for x in self.executions.values()],"survivor_queue":self.survivor_queue,"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw):
        o=cls()
        for r in raw.get("operators",[]):m=MutationOperator(**dict(r));o.operators[m.mutation_id]=m
        for r in raw.get("executions",[]):e=MutationExecution(**dict(r));o.executions[e.execution_id]=e
        o.survivor_queue=list(raw.get("survivor_queue",[]));o.audit=EventLog.from_dict(raw.get("audit",{}));return o
