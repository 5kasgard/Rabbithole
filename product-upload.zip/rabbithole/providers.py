"""Provider contracts, policy receipts, study grouping, and offline replay."""
from __future__ import annotations

import hashlib
import json
import re
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Callable, Dict, Mapping, Optional, Sequence, Tuple

from .search import ContentStore, SearchProvider, SearchResult
from .wal import EventLog


def _id(prefix: str) -> str: return f"{prefix}{uuid.uuid4().hex[:12]}"

def _norm(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", text.lower()))

@dataclass
class ProviderPolicy:
    provider_id: str
    provider_type: str
    source_classes: Tuple[str, ...]
    license_policy: str
    credential_scope: str = ""
    network_required: bool = False
    terms_url: str = ""
    max_results: int = 100
    enabled: bool = True
    policy_id: str = field(default_factory=lambda: _id("PVP"))

@dataclass
class RetrievalReceipt:
    provider_id: str
    query: str
    route: str
    result_digests: Tuple[str, ...]
    locators: Tuple[str, ...]
    source_classes: Tuple[str, ...]
    provider_metadata: Mapping[str, object]
    retrieved_at: float = field(default_factory=time.time)
    receipt_id: str = field(default_factory=lambda: _id("RET"))

@dataclass
class StudyGroup:
    group_id: str
    result_digests: Tuple[str, ...]
    canonical_key: str
    grouping_basis: str
    independence_group: str

class ProviderRegistry:
    def __init__(self, content: ContentStore):
        self.content = content
        self.policies: Dict[str, ProviderPolicy] = {}
        self.providers: Dict[str, SearchProvider] = {}
        self.receipts: Dict[str, RetrievalReceipt] = {}
        self.results: Dict[str, dict] = {}
        self.audit = EventLog()

    def register(self, policy: ProviderPolicy, provider: Optional[SearchProvider] = None) -> None:
        if not policy.provider_id or not policy.source_classes or not policy.license_policy:
            raise ValueError("provider id, source classes and license policy are required")
        self.policies[policy.provider_id] = policy
        if provider is not None:
            self.providers[policy.provider_id] = provider
        self.audit.append("provider_registered", asdict(policy) | {"runtime_attached": provider is not None})

    def attach(self, provider_id: str, provider: SearchProvider) -> None:
        if provider_id not in self.policies: raise KeyError(provider_id)
        self.providers[provider_id] = provider
        self.audit.append("provider_attached", {"provider_id": provider_id, "provider_name": getattr(provider, "name", type(provider).__name__)})

    def retrieve(self, provider_id: str, query: str, *, limit: int = 20, route: str = "concrete") -> tuple[RetrievalReceipt, tuple[SearchResult, ...]]:
        policy = self.policies[provider_id]
        if not policy.enabled: raise RuntimeError("provider disabled")
        if provider_id not in self.providers: raise RuntimeError("provider deployment is not attached")
        rows = tuple(self.providers[provider_id].search(query, limit=min(limit, policy.max_results)))
        digests=[]; locators=[]; classes=[]
        for row in rows:
            digest=self.content.put(row.snapshot, {"provider_id":provider_id,"query":query,"locator":row.locator,
                                                  "license_policy":policy.license_policy,"route":route})
            digests.append(digest); locators.append(row.locator); classes.append(row.source_type)
            self.results[digest] = {"result": asdict(row), "provider_id": provider_id, "query": query,
                                    "content_sha256": digest, "policy_id": policy.policy_id}
        receipt=RetrievalReceipt(provider_id,query,route,tuple(digests),tuple(locators),tuple(classes),
                                 {"policy_id":policy.policy_id,"provider_type":policy.provider_type,
                                  "license_policy":policy.license_policy,"network_required":policy.network_required})
        self.receipts[receipt.receipt_id]=receipt
        self.audit.append("provider_retrieval",asdict(receipt))
        return receipt, rows

    @staticmethod
    def _canonical_key(row: Mapping[str, object]) -> tuple[str,str]:
        result=dict(row.get("result", row))
        meta=dict(result.get("provider_metadata", {}))
        for key in ("doi","DOI","pmid","arxiv_id","study_id","dataset_id"):
            value=str(meta.get(key,"")) or str(result.get(key,""))
            if value: return f"{key}:{value.lower().strip()}", key
        title=_norm(str(result.get("title","")))
        authors="|".join(sorted(_norm(str(x)) for x in result.get("authors", ())))
        year=str(result.get("published_at", ""))[:4]
        return f"title:{title}|authors:{authors}|year:{year}", "normalized bibliographic identity"

    def group_studies(self, digests: Sequence[str]) -> tuple[StudyGroup, ...]:
        buckets: Dict[str,list[str]]={}; bases={}
        for digest in digests:
            key,basis=self._canonical_key(self.results[digest]); buckets.setdefault(key,[]).append(digest); bases[key]=basis
        groups=[]
        for key, ds in sorted(buckets.items()):
            independence=sorted({str(self.results[d]["result"].get("independence_group", "unknown")) for d in ds})
            group=StudyGroup(_id("STU"),tuple(sorted(ds)),key,bases[key],"|".join(independence))
            groups.append(group)
        self.audit.append("studies_grouped", {"groups":[asdict(x) for x in groups]})
        return tuple(groups)

    def replay(self, receipt_id: str) -> dict:
        receipt=self.receipts[receipt_id]; invalid=[]
        for digest in receipt.result_digests:
            try: self.content.get(digest)
            except Exception as exc: invalid.append({"digest":digest,"error":f"{type(exc).__name__}: {exc}"})
        return {"receipt":asdict(receipt),"valid":not invalid,"invalid":invalid,
                "groups":[asdict(x) for x in self.group_studies(receipt.result_digests)]}

    def verify(self)->dict:
        missing=[rid for rid,r in self.receipts.items() if any(d not in self.results for d in r.result_digests)]
        return {"valid":not missing and self.audit.verify().get("valid",False),"missing_results":missing,
                "providers":len(self.policies),"receipts":len(self.receipts)}

    def to_dict(self)->dict:
        return {"policies":[asdict(x) for x in self.policies.values()],"receipts":[asdict(x) for x in self.receipts.values()],
                "results":self.results,"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls, content:ContentStore, raw:Mapping[str,object])->"ProviderRegistry":
        obj=cls(content)
        for row in raw.get("policies",[]):
            d=dict(row);d["source_classes"]=tuple(d.get("source_classes",()));p=ProviderPolicy(**d);obj.policies[p.provider_id]=p
        for row in raw.get("receipts",[]):
            d=dict(row)
            for k in ("result_digests","locators","source_classes"):d[k]=tuple(d.get(k,()))
            r=RetrievalReceipt(**d);obj.receipts[r.receipt_id]=r
        obj.results=dict(raw.get("results",{}));obj.audit=EventLog.from_dict(raw.get("audit",{}));return obj
