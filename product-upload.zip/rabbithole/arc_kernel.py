"""Human-gated ARC-5 process kernel.

This module turns the improved subtractive-discovery method into an executable,
persistent process.  It does not decide truth and it does not silently advance
stages.  Search expands the candidate field; screening, contrastive cases,
mechanism reduction and pre-registered contact progressively remove what fails.

The kernel adds the controls missing from the earlier one-pass ARC controller:

* separately frozen concrete and abstraction search plans;
* explicit eligibility and screening decisions;
* multi-root evidence-lineage correlation rather than one trust label;
* causal transfer / anti-analogy records;
* contrastive mechanism-case matrices;
* immutable test definitions before contact;
* human approvals and a persistent work queue;
* recursive failure localization and stage reopening;
* append-only amendments instead of silent goal or criterion changes.
"""
from __future__ import annotations

import hashlib
import json
import math
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

from .discovery import DiscoveryArc, POSIWIDContract, SearchQuery, TestObligation
from .process import SearchEnvelope, StageGate
from .wal import EventLog


def _id(prefix: str) -> str:
    return f"{prefix}{uuid.uuid4().hex[:14]}"


def _canon(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, default=str).encode("utf-8")


def _digest(value: object) -> str:
    return hashlib.sha256(_canon(value)).hexdigest()


STAGE_ORDER = ("contract", "concrete", "expose", "abstract", "reduce", "contact", "complete")
TRACKS = {"concrete", "abstract"}
WORK_STATES = {"queued", "active", "blocked", "done", "cancelled"}
APPROVAL_DECISIONS = {"approve", "hold", "reopen", "reject"}
TRANSFER_STATES = {"candidate", "supported", "rejected", "unresolved"}
PRESENCE = {"present", "absent", "unknown"}
OUTCOMES = {"success", "failure", "mixed", "unknown"}


@dataclass(frozen=True)
class EligibilityContract:
    """Predeclared eligibility boundary for evidence screening."""

    inclusion_rules: Tuple[str, ...]
    exclusion_rules: Tuple[str, ...]
    source_classes: Tuple[str, ...] = ()
    date_boundary: str = ""
    languages: Tuple[str, ...] = ()
    scope: str = ""
    eid: str = field(default_factory=lambda: _id("ELG"))

    def validate(self) -> None:
        if not self.inclusion_rules:
            raise ValueError("eligibility requires at least one inclusion rule")
        if not self.exclusion_rules:
            raise ValueError("eligibility requires at least one exclusion rule")


@dataclass
class SearchRequirement:
    track: str
    text: str
    polarity: str
    category: str
    wave: int
    domain_family: str = ""
    parent_requirement_id: str = ""
    abstraction_id: str = ""
    rationale: str = ""
    status: str = "planned"  # planned|executed|failed|cancelled
    query_id: str = ""
    evidence_count: int = 0
    failure: str = ""
    rid: str = field(default_factory=lambda: _id("SRQ"))

    def validate(self) -> None:
        if self.track not in TRACKS:
            raise ValueError("search track must be concrete or abstract")
        if not self.text.strip():
            raise ValueError("search requirement text is required")
        if self.wave < 0:
            raise ValueError("search wave cannot be negative")
        if self.status not in {"planned", "executed", "failed", "cancelled"}:
            raise ValueError("invalid search requirement status")

    def definition(self) -> dict:
        return {
            "rid": self.rid, "track": self.track, "text": self.text,
            "polarity": self.polarity, "category": self.category,
            "wave": self.wave, "domain_family": self.domain_family,
            "parent_requirement_id": self.parent_requirement_id,
            "abstraction_id": self.abstraction_id, "rationale": self.rationale,
        }


@dataclass
class SearchTrackPlan:
    track: str
    requirements: Dict[str, SearchRequirement] = field(default_factory=dict)
    frozen_digest: str = ""
    frozen_at: float = 0.0
    frozen_by: str = ""

    @property
    def frozen(self) -> bool:
        return bool(self.frozen_digest)

    def add(self, requirement: SearchRequirement) -> str:
        if self.frozen:
            raise RuntimeError(f"{self.track} search plan is frozen")
        requirement.validate()
        if requirement.track != self.track:
            raise ValueError("requirement belongs to another search track")
        if requirement.rid in self.requirements:
            raise ValueError("duplicate search requirement id")
        self.requirements[requirement.rid] = requirement
        return requirement.rid

    def material(self) -> list[dict]:
        return [self.requirements[k].definition() for k in sorted(self.requirements)]

    def freeze(self, actor: str) -> str:
        if self.frozen:
            if not self.verify():
                raise RuntimeError(f"frozen {self.track} search plan was mutated")
            return self.frozen_digest
        if not actor.strip():
            raise ValueError("freezing a search plan requires an accountable actor")
        if not self.requirements:
            raise ValueError("cannot freeze an empty search plan")
        self.frozen_digest = _digest(self.material())
        self.frozen_at = time.time()
        self.frozen_by = actor
        return self.frozen_digest

    def verify(self) -> bool:
        return bool(self.frozen_digest) and _digest(self.material()) == self.frozen_digest


@dataclass(frozen=True)
class ScreeningDecision:
    evidence_id: str
    include: bool
    criteria: Tuple[str, ...]
    reason: str
    reviewer: str
    created_at: float = field(default_factory=time.time)
    sid: str = field(default_factory=lambda: _id("SCR"))

    def validate(self) -> None:
        if not self.reviewer.strip() or not self.reason.strip():
            raise ValueError("screening requires reviewer and reason")
        if not self.criteria:
            raise ValueError("screening must cite eligibility criteria")


@dataclass(frozen=True)
class EvidenceLineageProfile:
    """Independent causal roots that can correlate apparently distinct reports.

    Empty fields are not interpreted as independence.  Evidence without any
    declared root is conservatively placed in one unresolved lineage cluster.
    """

    evidence_id: str
    study_ids: Tuple[str, ...] = ()
    dataset_ids: Tuple[str, ...] = ()
    model_families: Tuple[str, ...] = ()
    institutions: Tuple[str, ...] = ()
    author_groups: Tuple[str, ...] = ()
    funding_sources: Tuple[str, ...] = ()
    raw_source_ids: Tuple[str, ...] = ()
    other_roots: Tuple[str, ...] = ()
    basis: str = ""
    reviewer: str = ""
    created_at: float = field(default_factory=time.time)
    lid: str = field(default_factory=lambda: _id("LIN"))

    def roots(self) -> Tuple[str, ...]:
        rows: List[str] = []
        for prefix, values in (
            ("study", self.study_ids), ("dataset", self.dataset_ids),
            ("model", self.model_families), ("institution", self.institutions),
            ("authors", self.author_groups), ("funding", self.funding_sources),
            ("raw", self.raw_source_ids), ("other", self.other_roots),
        ):
            rows.extend(f"{prefix}:{str(v).strip().lower()}" for v in values if str(v).strip())
        return tuple(sorted(set(rows)))

    def validate(self) -> None:
        if not self.reviewer.strip() or not self.basis.strip():
            raise ValueError("lineage profile requires reviewer and basis")


@dataclass(frozen=True)
class TransferCase:
    abstraction_id: str
    source_domain: str
    source_case: str
    target_function: str
    retained_causal_structure: Tuple[str, ...]
    retained_constraints: Tuple[str, ...]
    contextual_mismatches: Tuple[str, ...]
    anti_analogy: Tuple[str, ...]
    translation_prediction: Tuple[str, ...]
    falsifier: str
    evidence_ids: Tuple[str, ...]
    state: str = "candidate"
    reviewer: str = ""
    tid: str = field(default_factory=lambda: _id("TRN"))

    def validate(self) -> None:
        if self.state not in TRANSFER_STATES:
            raise ValueError("invalid transfer state")
        if not self.retained_causal_structure or not self.falsifier:
            raise ValueError("transfer requires causal structure and falsifier")
        if not self.contextual_mismatches or not self.anti_analogy:
            raise ValueError("transfer must record mismatches and anti-analogy")
        if not self.evidence_ids:
            raise ValueError("transfer must cite evidence")


@dataclass(frozen=True)
class MechanismCaseAssessment:
    mechanism_id: str
    example_id: str
    mechanism_presence: str
    outcome: str
    causal_role: str
    confounders: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    reviewer: str
    created_at: float = field(default_factory=time.time)
    aid: str = field(default_factory=lambda: _id("MCA"))

    def validate(self) -> None:
        if self.mechanism_presence not in PRESENCE:
            raise ValueError("invalid mechanism presence")
        if self.outcome not in OUTCOMES:
            raise ValueError("invalid case outcome")
        if not self.reviewer.strip() or not self.causal_role.strip():
            raise ValueError("assessment requires reviewer and causal role")
        if not self.evidence_ids:
            raise ValueError("assessment must cite evidence")


@dataclass(frozen=True)
class MechanismInference:
    mechanism_id: str
    necessary_status: str
    sufficient_status: str
    success_with: Tuple[str, ...]
    success_without: Tuple[str, ...]
    failure_with: Tuple[str, ...]
    failure_without: Tuple[str, ...]
    unresolved: Tuple[str, ...]
    conclusion: str
    created_at: float = field(default_factory=time.time)
    iid: str = field(default_factory=lambda: _id("INF"))


@dataclass(frozen=True)
class ApprovalRecord:
    stage: str
    decision: str
    actor: str
    rationale: str
    gate_digest: str
    created_at: float = field(default_factory=time.time)
    approval_id: str = field(default_factory=lambda: _id("APR"))

    def validate(self) -> None:
        if self.stage not in STAGE_ORDER:
            raise ValueError("invalid approval stage")
        if self.decision not in APPROVAL_DECISIONS:
            raise ValueError("invalid approval decision")
        if not self.actor.strip() or not self.rationale.strip():
            raise ValueError("approval requires actor and rationale")


@dataclass
class WorkItem:
    stage: str
    reason: str
    source_id: str = ""
    priority: float = 1.0
    state: str = "queued"
    blocked_by: Tuple[str, ...] = ()
    created_at: float = field(default_factory=time.time)
    wid: str = field(default_factory=lambda: _id("WRK"))

    def validate(self) -> None:
        if self.stage not in STAGE_ORDER:
            raise ValueError("invalid work-item stage")
        if self.state not in WORK_STATES:
            raise ValueError("invalid work-item state")
        if not math.isfinite(self.priority) or self.priority < 0:
            raise ValueError("work-item priority must be finite and non-negative")


@dataclass(frozen=True)
class FailureDiagnosis:
    test_id: str
    observed_state: str
    failure_layer: str
    reopened_stage: str
    hypotheses: Tuple[str, ...]
    evidence_ids: Tuple[str, ...]
    created_at: float = field(default_factory=time.time)
    diagnosis_id: str = field(default_factory=lambda: _id("DIA"))


@dataclass(frozen=True)
class ArcAmendment:
    from_revision: int
    to_revision: int
    reopen_stage: str
    reason: str
    changes: Mapping[str, object]
    actor: str
    approval_ref: str
    superseded_ids: Tuple[str, ...]
    created_at: float = field(default_factory=time.time)
    amendment_id: str = field(default_factory=lambda: _id("AMD"))


class ARC5Kernel:
    """Persistent, human-gated controller around one :class:`DiscoveryArc`."""

    FAILURE_STAGE = {
        "goal": "contract", "intent": "contract", "criteria": "contract",
        "search": "concrete", "coverage": "concrete", "evidence": "concrete",
        "screening": "concrete", "independence": "concrete",
        "decomposition": "expose", "interface": "expose",
        "abstraction": "abstract", "analogy": "abstract", "translation": "abstract",
        "mechanism": "reduce", "composition": "reduce", "substrate": "reduce",
        "representation": "reduce", "model": "reduce",
        "implementation": "contact", "integration": "contact", "verifier": "contact",
        "instrument": "contact", "test": "contact", "unknown": "contact",
    }

    def __init__(self, arc: DiscoveryArc, envelope: SearchEnvelope,
                 eligibility: EligibilityContract):
        arc.contract.validate(); envelope.validate(); eligibility.validate()
        self.arc = arc
        self.envelope = envelope
        self.eligibility = eligibility
        self.revision = 1
        self.current_stage = "contract"
        self.contract_digest = ""
        self.contract_frozen_at = 0.0
        self.contract_frozen_by = ""
        self.search_plans: Dict[str, SearchTrackPlan] = {
            "concrete": SearchTrackPlan("concrete"),
            "abstract": SearchTrackPlan("abstract"),
        }
        self.screening: Dict[str, ScreeningDecision] = {}
        self.lineages: Dict[str, EvidenceLineageProfile] = {}
        self.transfers: Dict[str, TransferCase] = {}
        self.case_assessments: Dict[str, MechanismCaseAssessment] = {}
        self.inferences: Dict[str, MechanismInference] = {}
        self.approvals: List[ApprovalRecord] = []
        self.work_queue: Dict[str, WorkItem] = {}
        self.diagnoses: Dict[str, FailureDiagnosis] = {}
        self.amendments: List[ArcAmendment] = []
        self.superseded_ids: set[str] = set()
        self.invalidated_ids: set[str] = set()
        self.test_plan_digest = ""
        self.test_plan_frozen_at = 0.0
        self.test_plan_frozen_by = ""
        self.audit = EventLog()
        self.enqueue("contract", "freeze the dual-POSIWID and eligibility contract", priority=100.0)
        self.audit.append("arc5_kernel_created", {
            "arc_id": arc.arc_id, "revision": self.revision,
            "envelope": asdict(envelope), "eligibility": asdict(eligibility),
        })

    def _active(self, mapping: Mapping[str, object]) -> list[object]:
        return [value for key, value in mapping.items()
                if key not in self.superseded_ids and key not in self.invalidated_ids]

    # --------------------------------------------------------- lifecycle/freeze
    def freeze_contract(self, actor: str) -> str:
        if self.contract_digest:
            if _digest(asdict(self.arc.contract)) != self.contract_digest:
                raise RuntimeError("frozen contract was mutated")
            return self.contract_digest
        if not actor.strip():
            raise ValueError("contract freeze requires an accountable actor")
        self.arc.contract.validate()
        self.contract_digest = _digest(asdict(self.arc.contract))
        self.contract_frozen_at = time.time()
        self.contract_frozen_by = actor
        # Freezing establishes immutability but does not advance the human gate.
        # Only an explicit approval may move the arc into concrete search.
        self.audit.append("contract_frozen", {"digest": self.contract_digest, "actor": actor})
        return self.contract_digest

    def verify_contract(self) -> bool:
        return bool(self.contract_digest) and _digest(asdict(self.arc.contract)) == self.contract_digest

    def add_search_requirement(self, requirement: SearchRequirement) -> str:
        if not self.verify_contract():
            raise RuntimeError("freeze the contract before planning searches")
        rid = self.search_plans[requirement.track].add(requirement)
        self.audit.append("search_requirement_added", asdict(requirement))
        return rid

    def seed_concrete_plan(self) -> Tuple[str, ...]:
        plan = self.search_plans["concrete"]
        if plan.frozen:
            raise RuntimeError("concrete plan is already frozen")
        target = self.arc.contract.target
        current = "; ".join(self.arc.contract.local_current + self.arc.contract.whole_current)
        goal = "; ".join(self.arc.contract.local_goal + self.arc.contract.whole_goal)
        rows = (
            (f"{target} mechanisms existing systems empirical evaluation", "for", "solution"),
            (f"{target} failures limitations negative results", "failure", "failure"),
            (f"alternatives to {target} critique counterexample", "against", "alternative"),
            (f"{target} impossibility lower bounds boundary conditions", "boundary", "boundary"),
            (f"systems with observed current effect: {current}", "neutral", "current-posiwid"),
            (f"systems producing observable goal effect: {goal}", "for", "goal-posiwid"),
        )
        ids = []
        for text, polarity, category in rows:
            ids.append(self.add_search_requirement(SearchRequirement(
                "concrete", text, polarity, category, 0,
                domain_family="concrete-problem", rationale="deterministic contrastive seed")))
        return tuple(ids)

    def seed_followup_plan(self, track: str, wave: int) -> Tuple[str, ...]:
        if track not in TRACKS:
            raise ValueError("invalid search track")
        plan = self.search_plans[track]
        if plan.frozen:
            raise RuntimeError(f"{track} plan is frozen; amend/reopen before adding a wave")
        if wave < 1:
            raise ValueError("follow-up wave must be positive")
        roots = [r for r in plan.requirements.values() if r.wave == wave - 1]
        if not roots:
            raise RuntimeError("follow-up wave has no parent requirements")
        root = sorted(roots, key=lambda x: x.rid)[0]
        target = self.arc.contract.target
        templates = {
            "replication": (f"independent replication evidence for {target}", "for" if track == "concrete" else "analogue"),
            "contradiction": (f"evidence contradicting claimed mechanisms for {target}", "against" if track == "concrete" else "counterexample"),
            "boundary": (f"where mechanisms for {target} fail scale context limits", "boundary"),
            "hidden_assumption": (f"hidden assumptions dependencies external work in {target} mechanisms", "failure" if track == "concrete" else "anti_analogue"),
            "alternative": (f"substitute mechanisms achieving the same observable effect as {target}", "against" if track == "concrete" else "analogue"),
        }
        ids = []
        for category, (text, polarity) in templates.items():
            ids.append(self.add_search_requirement(SearchRequirement(
                track, text, polarity, category, wave,
                domain_family=root.domain_family, parent_requirement_id=root.rid,
                rationale="deterministic compounding search")))
        return tuple(ids)

    def seed_abstract_plan(self) -> Tuple[str, ...]:
        plan = self.search_plans["abstract"]
        if plan.frozen:
            raise RuntimeError("abstract plan is already frozen")
        active_abstractions = self._active(self.arc.abstractions)
        if not active_abstractions:
            raise RuntimeError("no active abstraction lattice exists")
        ids: List[str] = []
        max_queries = self.envelope.max_queries - len(self.arc.queries)
        templates = {
            "analogue": "{domain} systems that {function} causal mechanisms empirical",
            "anti_analogue": "{domain} apparent analogies for {function} that fail causal transfer",
            "counterexample": "{domain} successful systems without {function} counterexample",
            "boundary": "{domain} {function} scale limits boundary conditions",
        }
        for abstraction in sorted(active_abstractions, key=lambda a: (a.level, a.aid)):
            function = abstraction.retained_function
            for domain in self.envelope.domain_families:
                for polarity in self.envelope.abstract_polarities:
                    if len(ids) >= max_queries:
                        return tuple(ids)
                    template = templates.get(polarity, "{domain} {function} {polarity}")
                    ids.append(self.add_search_requirement(SearchRequirement(
                        "abstract", template.format(domain=domain, function=function, polarity=polarity),
                        polarity, "abstraction-instance", 0, domain_family=domain,
                        abstraction_id=abstraction.aid,
                        rationale="function-preserving abstraction search")))
        return tuple(ids)

    def freeze_search_plan(self, track: str, actor: str) -> str:
        plan = self.search_plans[track]
        digest = plan.freeze(actor)
        self.audit.append("search_plan_frozen", {"track": track, "digest": digest, "actor": actor})
        return digest

    def mark_search_executed(self, requirement_id: str, query_id: str, evidence_count: int) -> None:
        req = self._requirement(requirement_id)
        plan = self.search_plans[req.track]
        if not plan.verify():
            raise RuntimeError("search plan definition changed after freeze")
        if query_id not in self.arc.queries:
            raise KeyError("executed query is not recorded in the arc")
        req.status = "executed"; req.query_id = query_id; req.evidence_count = int(evidence_count)
        self.audit.append("search_requirement_executed", {
            "requirement_id": requirement_id, "query_id": query_id,
            "evidence_count": evidence_count,
        })

    def mark_search_failed(self, requirement_id: str, reason: str) -> None:
        req = self._requirement(requirement_id)
        req.status = "failed"; req.failure = reason
        self.audit.append("search_requirement_failed", {"requirement_id": requirement_id, "reason": reason})

    # ----------------------------------------------------- screening/independence
    def screen_evidence(self, decision: ScreeningDecision) -> str:
        decision.validate()
        if decision.evidence_id not in self.arc.evidence:
            raise KeyError("unknown evidence id")
        if decision.evidence_id in self.screening:
            raise RuntimeError("evidence already has a screening decision; amend instead")
        self.screening[decision.evidence_id] = decision
        self.arc.screen(decision.evidence_id, decision.include, decision.reason)
        self.audit.append("evidence_screened", asdict(decision))
        return decision.sid

    def add_lineage(self, profile: EvidenceLineageProfile) -> str:
        profile.validate()
        if profile.evidence_id not in self.arc.evidence:
            raise KeyError("unknown evidence id")
        if profile.evidence_id in self.lineages:
            raise RuntimeError("evidence lineage already declared; amend instead")
        self.lineages[profile.evidence_id] = profile
        self.audit.append("evidence_lineage_declared", asdict(profile))
        return profile.lid

    def independence_clusters(self, evidence_ids: Optional[Sequence[str]] = None) -> Tuple[Tuple[str, ...], ...]:
        ids = list(evidence_ids or [eid for eid, d in self.screening.items() if d.include])
        ids = [eid for eid in ids if eid in self.arc.evidence]
        parent = {eid: eid for eid in ids}

        def find(x: str) -> str:
            while parent[x] != x:
                parent[x] = parent[parent[x]]; x = parent[x]
            return x

        def union(a: str, b: str) -> None:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[rb] = ra

        by_root: Dict[str, List[str]] = {}
        unknown: List[str] = []
        for eid in ids:
            profile = self.lineages.get(eid)
            roots = profile.roots() if profile else ()
            if not roots:
                unknown.append(eid)
            for root in roots:
                by_root.setdefault(root, []).append(eid)
        for group in by_root.values():
            for eid in group[1:]:
                union(group[0], eid)
        # Undeclared lineage is one conservative unresolved cluster.
        for eid in unknown[1:]:
            union(unknown[0], eid)
        clusters: Dict[str, List[str]] = {}
        for eid in ids:
            clusters.setdefault(find(eid), []).append(eid)
        return tuple(tuple(sorted(v)) for v in sorted(clusters.values(), key=lambda x: tuple(sorted(x))))

    # ----------------------------------------------------------- transfer/reduce
    def add_transfer(self, transfer: TransferCase) -> str:
        transfer.validate()
        if transfer.abstraction_id not in self.arc.abstractions:
            raise KeyError("unknown abstraction id")
        for eid in transfer.evidence_ids:
            if eid not in self.arc.evidence:
                raise KeyError(f"unknown transfer evidence {eid}")
        self.transfers[transfer.tid] = transfer
        self.audit.append("abstraction_transfer_added", asdict(transfer))
        return transfer.tid

    def add_case_assessment(self, assessment: MechanismCaseAssessment) -> str:
        assessment.validate()
        if assessment.mechanism_id not in self.arc.mechanisms:
            raise KeyError("unknown mechanism id")
        if assessment.example_id not in self.arc.examples:
            raise KeyError("unknown example id")
        for eid in assessment.evidence_ids:
            if eid not in self.arc.evidence:
                raise KeyError(f"unknown assessment evidence {eid}")
        self.case_assessments[assessment.aid] = assessment
        self.audit.append("mechanism_case_assessed", asdict(assessment))
        return assessment.aid

    def infer_mechanism(self, mechanism_id: str) -> MechanismInference:
        if mechanism_id not in self.arc.mechanisms:
            raise KeyError("unknown mechanism id")
        rows = [x for x in self.case_assessments.values() if x.mechanism_id == mechanism_id]
        success_with = tuple(x.example_id for x in rows if x.outcome == "success" and x.mechanism_presence == "present")
        success_without = tuple(x.example_id for x in rows if x.outcome == "success" and x.mechanism_presence == "absent")
        failure_with = tuple(x.example_id for x in rows if x.outcome == "failure" and x.mechanism_presence == "present")
        failure_without = tuple(x.example_id for x in rows if x.outcome == "failure" and x.mechanism_presence == "absent")
        unresolved = tuple(x.example_id for x in rows if x.outcome in {"mixed", "unknown"} or x.mechanism_presence == "unknown")
        necessary = "not_necessary" if success_without else (
            "conditional" if success_with and failure_without else "unknown")
        sufficient = "not_sufficient" if failure_with else (
            "conditional" if success_with else "unknown")
        if not rows:
            conclusion = "no contrastive cases recorded"
        elif success_without and failure_with:
            conclusion = "neither necessary nor sufficient in the observed contexts"
        elif success_without:
            conclusion = "not necessary in at least one observed context"
        elif failure_with:
            conclusion = "not sufficient in at least one observed context"
        else:
            conclusion = "survives current cases only conditionally; absence of counterexample is not proof"
        inference = MechanismInference(mechanism_id, necessary, sufficient,
                                       success_with, success_without, failure_with,
                                       failure_without, unresolved, conclusion)
        self.inferences[inference.iid] = inference
        mechanism = self.arc.mechanisms[mechanism_id]
        mechanism.necessary_status = necessary
        mechanism.sufficient_status = sufficient
        mechanism.state = "unresolved" if rows else "candidate"
        self.arc.audit.append("mechanism_contrastive_inference", asdict(inference))
        self.audit.append("mechanism_contrastive_inference", asdict(inference))
        return inference

    # ---------------------------------------------------------- test plan/contact
    @staticmethod
    def _test_definition(test: TestObligation) -> dict:
        return {
            "tid": test.tid, "target_type": test.target_type, "target_id": test.target_id,
            "question": test.question, "method": test.method,
            "outcome_if_a": test.outcome_if_a, "outcome_if_b": test.outcome_if_b,
            "contact_type": test.contact_type,
            "independence_group": test.independence_group,
            "expected_information_gain": test.expected_information_gain,
            "downstream_impact": test.downstream_impact,
            "contact_quality": test.contact_quality, "cost": dict(test.cost),
            "reversible": test.reversible, "public_surface": test.public_surface,
        }

    def test_plan_material(self) -> list[dict]:
        return [self._test_definition(self.arc.tests[k]) for k in sorted(self.arc.tests)
                if k not in self.superseded_ids and k not in self.invalidated_ids]

    def freeze_tests(self, actor: str) -> str:
        if self.test_plan_digest:
            if not self.verify_test_plan():
                raise RuntimeError("frozen test plan was mutated")
            return self.test_plan_digest
        if not actor.strip():
            raise ValueError("test-plan freeze requires an accountable actor")
        gate = self.reduction_gate()
        if not gate.passed:
            raise RuntimeError("reduction gate failed: " + "; ".join(gate.reasons))
        if not self.test_plan_material():
            raise ValueError("cannot freeze an empty active test plan")
        self.test_plan_digest = _digest(self.test_plan_material())
        self.test_plan_frozen_at = time.time()
        self.test_plan_frozen_by = actor
        # Freezing preregisters the tests.  Contact remains inaccessible until a
        # human explicitly approves the reduction stage.
        self.audit.append("test_plan_frozen", {"digest": self.test_plan_digest, "actor": actor})
        return self.test_plan_digest

    def verify_test_plan(self) -> bool:
        return bool(self.test_plan_digest) and _digest(self.test_plan_material()) == self.test_plan_digest

    def record_contact(self, test_id: str, state: str, observed: str, *,
                       result: str = "", failure_layer: str = "",
                       evidence_ids: Sequence[str] = ()) -> Optional[FailureDiagnosis]:
        if not self.verify_test_plan():
            raise RuntimeError("tests were not frozen or definitions changed after freeze")
        if test_id in self.superseded_ids:
            raise RuntimeError("cannot record contact against a superseded test")
        self.arc.record_test(test_id, state, observed, result=result,
                             failure_layer=failure_layer, evidence_ids=evidence_ids)
        self.audit.append("contact_recorded", {
            "test_id": test_id, "state": state, "observed": observed,
            "result": result, "failure_layer": failure_layer,
            "evidence_ids": list(evidence_ids),
        })
        if state in {"failed", "inconclusive", "unrunnable"}:
            return self.diagnose_failure(test_id, state, failure_layer or "unknown",
                                         observed, evidence_ids)
        return None

    def _invalidate_downstream_for_stage(self, stage: str) -> Tuple[str, ...]:
        """Mark products that depend on a failed stage as unusable, without deletion."""
        index = STAGE_ORDER.index(stage)
        invalidated: set[str] = set()
        if index <= STAGE_ORDER.index("concrete"):
            invalidated.update(self.arc.distinctions)
        if index <= STAGE_ORDER.index("expose"):
            invalidated.update(self.arc.abstractions)
            invalidated.update(self.transfers)
        if index <= STAGE_ORDER.index("abstract"):
            invalidated.update(self.arc.examples)
            invalidated.update(self.arc.mechanisms)
            invalidated.update(self.arc.systems)
            invalidated.update(self.case_assessments)
            invalidated.update(self.inferences)
        if index <= STAGE_ORDER.index("reduce"):
            invalidated.update(self.arc.tests)
            self.test_plan_digest = ""
            self.test_plan_frozen_at = 0.0
            self.test_plan_frozen_by = ""
        self.invalidated_ids.update(invalidated)
        # Downstream work was derived from assumptions that no longer hold.
        for item in self.work_queue.values():
            if (STAGE_ORDER.index(item.stage) > index and
                    item.state in {"queued", "active", "blocked"}):
                item.state = "cancelled"
        return tuple(sorted(invalidated))

    def diagnose_failure(self, test_id: str, state: str, failure_layer: str,
                         observed: str, evidence_ids: Sequence[str] = ()) -> FailureDiagnosis:
        normalized = failure_layer.strip().lower().replace("-", "_")
        reopened = self.FAILURE_STAGE.get(normalized, "contact")
        hypotheses = {
            "contract": ("goal or success criterion is incomplete", "normative authority is missing"),
            "concrete": ("candidate field is biased or incomplete", "evidence independence is overstated"),
            "expose": ("the problem decomposition collapsed independently failing functions",),
            "abstract": ("the abstraction removed a causal constraint", "the analogy does not transfer"),
            "reduce": ("the selected mechanism is contextual or redundant", "the composition or substrate is wrong"),
            "contact": ("implementation or integration is defective", "the verifier/contact is invalid or unavailable"),
        }[reopened]
        diagnosis = FailureDiagnosis(test_id, state, failure_layer, reopened,
                                     tuple(hypotheses), tuple(evidence_ids))
        self.diagnoses[diagnosis.diagnosis_id] = diagnosis
        invalidated = self._invalidate_downstream_for_stage(reopened)
        self.enqueue(reopened, f"contact {test_id} requires rework: {observed}",
                     source_id=diagnosis.diagnosis_id, priority=80.0)
        # A failed contact causally reopens the implicated stage regardless of
        # the caller's prior cursor.  History is retained; downstream products
        # are invalidated and must be rebuilt behind human approval.
        self.current_stage = reopened
        self.audit.append("failure_diagnosed", asdict(diagnosis) | {"invalidated_ids": invalidated})
        return diagnosis

    # --------------------------------------------------------- gates/approvals
    def coverage_gate(self, track: str) -> StageGate:
        plan = self.search_plans[track]
        reasons: List[str] = []
        if not plan.verify():
            reasons.append(f"{track} search plan is not frozen or was mutated")
        requirements = list(plan.requirements.values())
        incomplete = [r.rid for r in requirements if r.status not in {"executed", "cancelled"}]
        if incomplete:
            reasons.append(f"{len(incomplete)} search requirements are incomplete")
        query_ids = {r.query_id for r in requirements if r.query_id}
        included = [e for eid, e in self.arc.evidence.items()
                    if e.query_id in query_ids and self.screening.get(eid) and self.screening[eid].include]
        unscreened = [eid for eid, e in self.arc.evidence.items()
                      if e.query_id in query_ids and eid not in self.screening]
        if unscreened:
            reasons.append(f"{len(unscreened)} retrieved evidence items are unscreened")
        polarities = {e.polarity for e in included}
        required = set(self.envelope.concrete_polarities if track == "concrete"
                       else self.envelope.abstract_polarities)
        missing = required - polarities
        if missing:
            reasons.append("missing included polarities: " + ", ".join(sorted(missing)))
        waves = {self.arc.queries[e.query_id].wave for e in included}
        if len(waves) < self.envelope.min_search_waves:
            reasons.append(f"only {len(waves)} evidence-bearing waves")
        categories = {r.category for r in requirements if r.wave > 0 and r.status == "executed"}
        missing_followups = set(self.envelope.required_followup_categories) - categories
        if self.envelope.min_search_waves > 1 and missing_followups:
            reasons.append("missing follow-up categories: " + ", ".join(sorted(missing_followups)))
        clusters = self.independence_clusters([e.eid for e in included])
        if len(clusters) < self.envelope.min_independent_groups:
            reasons.append(f"only {len(clusters)} evidence-lineage clusters")
        # Domain coverage is a property of the predeclared search requirement.
        # Provider metadata may describe the repository rather than the analogue
        # family being tested (for example, a local lineage corpus).
        domains = {r.domain_family for r in requirements
                   if r.domain_family and r.status == "executed" and r.evidence_count > 0}
        if track == "abstract":
            absent = set(self.envelope.domain_families) - domains
            if absent:
                reasons.append("uncovered abstract domain families: " + ", ".join(sorted(absent)))
        return StageGate(track, not reasons, tuple(reasons), {
            "requirements": len(requirements), "included_evidence": len(included),
            "unscreened": len(unscreened), "polarities": sorted(polarities),
            "waves": sorted(waves), "followup_categories": sorted(categories),
            "independence_clusters": len(clusters), "domains": sorted(domains),
        })

    def exposure_gate(self) -> StageGate:
        reasons = []
        distinctions = self._active(self.arc.distinctions)
        if not distinctions:
            reasons.append("no active functional distinctions")
        for d in distinctions:
            if not d.functions or not d.evidence_ids:
                reasons.append(f"distinction {d.did} lacks functions or evidence")
            if not d.interfaces and not d.failure_propagation:
                reasons.append(f"distinction {d.did} does not expose an interface or failure propagation")
        return StageGate("expose", not reasons, tuple(reasons), {
            "distinctions": len(distinctions),
            "interfaces": sum(len(d.interfaces) for d in distinctions),
        })

    def abstraction_gate(self) -> StageGate:
        reasons = list(self.coverage_gate("abstract").reasons)
        abstractions = self._active(self.arc.abstractions)
        transfers = self._active(self.transfers)
        levels = {a.level for a in abstractions}
        if len(levels) < 2:
            reasons.append("fewer than two abstraction levels")
        if not transfers:
            reasons.append("no active causal transfer or anti-analogy records")
        for t in transfers:
            if t.state == "candidate":
                reasons.append(f"transfer {t.tid} remains unscreened")
        return StageGate("abstract", not reasons, tuple(reasons), {
            "levels": sorted(levels), "transfers": len(transfers),
            "rejected_transfers": sum(t.state == "rejected" for t in transfers),
        })

    def reduction_gate(self) -> StageGate:
        reasons = []
        mechanisms = self._active(self.arc.mechanisms)
        systems = self._active(self.arc.systems)
        tests = self._active(self.arc.tests)
        assessments = self._active(self.case_assessments)
        if not mechanisms:
            reasons.append("no active mechanism hypotheses")
        for m in mechanisms:
            rows = [x for x in assessments if x.mechanism_id == m.mid]
            if not rows:
                reasons.append(f"mechanism {m.mid} has no contrastive case matrix")
            if not m.work_relocated_to or not m.falsifier:
                reasons.append(f"mechanism {m.mid} lacks work-relocation or falsifier")
            if not m.local_posiwid_effect or not m.whole_posiwid_effect:
                reasons.append(f"mechanism {m.mid} lacks dual POSIWID effect")
        if len(systems) < 2:
            reasons.append("fewer than two active competing system hypotheses")
        if not tests:
            reasons.append("no active discriminating tests")
        return StageGate("reduce", not reasons, tuple(reasons), {
            "mechanisms": len(mechanisms), "systems": len(systems),
            "case_assessments": len(assessments), "tests": len(tests),
        })

    def stage_gate(self, stage: str) -> StageGate:
        if stage == "contract":
            reasons = [] if self.verify_contract() else ["contract is not frozen or was mutated"]
            return StageGate("contract", not reasons, tuple(reasons), {"digest": self.contract_digest})
        if stage == "concrete": return self.coverage_gate("concrete")
        if stage == "expose": return self.exposure_gate()
        if stage == "abstract": return self.abstraction_gate()
        if stage == "reduce":
            base = self.reduction_gate()
            reasons = list(base.reasons)
            if not self.verify_test_plan():
                reasons.append("test plan is not frozen or was mutated")
            observations = dict(base.observations)
            observations["test_plan_frozen"] = self.verify_test_plan()
            return StageGate("reduce", not reasons, tuple(reasons), observations)
        if stage == "contact":
            reasons = [] if self.verify_test_plan() else ["test plan is not frozen or was mutated"]
            pending = [t.tid for t in self._active(self.arc.tests)
                       if t.state in {"proposed", "scheduled"}]
            if pending: reasons.append(f"{len(pending)} frozen tests have no contact result")
            return StageGate("contact", not reasons, tuple(reasons), {"pending": pending})
        if stage == "complete":
            contact = self.stage_gate("contact")
            return StageGate("complete", contact.passed, contact.reasons, contact.observations)
        raise ValueError("unknown stage")

    def approve(self, stage: str, decision: str, actor: str, rationale: str) -> ApprovalRecord:
        gate = self.stage_gate(stage)
        record = ApprovalRecord(stage, decision, actor, rationale,
                                _digest(asdict(gate)))
        record.validate()
        if decision == "approve" and not gate.passed:
            raise RuntimeError("cannot approve a failed stage gate: " + "; ".join(gate.reasons))
        self.approvals.append(record)
        if decision == "approve":
            idx = STAGE_ORDER.index(stage)
            self._complete_stage_items(stage)
            if idx + 1 < len(STAGE_ORDER):
                nxt = STAGE_ORDER[idx + 1]
                self.current_stage = nxt
                self.enqueue(nxt, f"human-approved transition from {stage}", source_id=record.approval_id,
                             priority=max(1.0, 70.0 - idx * 10.0))
        elif decision == "reopen":
            self.current_stage = stage
            self.enqueue(stage, rationale, source_id=record.approval_id, priority=90.0)
        elif decision in {"hold", "reject"}:
            self.current_stage = stage
        self.audit.append("stage_approval", asdict(record))
        return record

    # ------------------------------------------------------------- queue/amend
    def enqueue(self, stage: str, reason: str, *, source_id: str = "", priority: float = 1.0,
                blocked_by: Sequence[str] = ()) -> str:
        item = WorkItem(stage, reason, source_id, float(priority), "queued", tuple(blocked_by))
        item.validate(); self.work_queue[item.wid] = item
        self.audit.append("work_enqueued", asdict(item))
        return item.wid

    def next_work(self) -> Optional[WorkItem]:
        candidates = [w for w in self.work_queue.values() if w.state == "queued" and
                      all(self.work_queue.get(x) and self.work_queue[x].state == "done" for x in w.blocked_by)]
        return sorted(candidates, key=lambda w: (-w.priority, w.created_at, w.wid))[0] if candidates else None

    def set_work_state(self, work_id: str, state: str) -> None:
        if state not in WORK_STATES:
            raise ValueError("invalid work state")
        item = self.work_queue[work_id]; item.state = state
        self.audit.append("work_state_changed", {"work_id": work_id, "state": state})

    def _complete_stage_items(self, stage: str) -> None:
        for item in self.work_queue.values():
            if item.stage == stage and item.state in {"queued", "active"}:
                item.state = "done"

    def amend(self, reopen_stage: str, reason: str, changes: Mapping[str, object], *,
              actor: str, approval_ref: str) -> ArcAmendment:
        if reopen_stage not in STAGE_ORDER[:-1]:
            raise ValueError("amendment must reopen a real process stage")
        if not actor.strip() or not approval_ref.strip() or not reason.strip():
            raise ValueError("amendment requires actor, approval reference and reason")
        old_revision = self.revision; self.revision += 1
        index = STAGE_ORDER.index(reopen_stage)
        superseded: List[str] = []

        def supersede(mapping: Mapping[str, object]) -> None:
            superseded.extend(k for k in mapping if k not in self.superseded_ids)

        if index == STAGE_ORDER.index("contract"):
            if "contract" in changes:
                raw = dict(changes["contract"])
                for key in ("local_current", "local_goal", "whole_current", "whole_goal",
                            "constraints", "anti_goals", "success_observations", "failure_observations"):
                    raw[key] = tuple(raw.get(key, ()))
                raw["resource_budget"] = dict(raw.get("resource_budget", {}))
                self.arc.contract = POSIWIDContract(**raw)
            if "eligibility" in changes:
                raw = dict(changes["eligibility"])
                for key in ("inclusion_rules", "exclusion_rules", "source_classes", "languages"):
                    raw[key] = tuple(raw.get(key, ()))
                self.eligibility = EligibilityContract(**raw); self.eligibility.validate()
            if "envelope" in changes:
                raw = dict(changes["envelope"])
                for key in ("domain_families", "concrete_polarities", "abstract_polarities",
                            "required_followup_categories"):
                    raw[key] = tuple(raw.get(key, ()))
                self.envelope = SearchEnvelope(**raw); self.envelope.validate()
            self.contract_digest = ""; self.contract_frozen_at = 0.0; self.contract_frozen_by = ""

        if index <= STAGE_ORDER.index("concrete"):
            supersede(self.arc.queries); supersede(self.arc.evidence)
            self.search_plans["concrete"] = SearchTrackPlan("concrete")
            self.screening = {}; self.lineages = {}
        if index <= STAGE_ORDER.index("expose"):
            supersede(self.arc.distinctions)
        if index <= STAGE_ORDER.index("abstract"):
            supersede(self.arc.abstractions); supersede(self.transfers)
            self.search_plans["abstract"] = SearchTrackPlan("abstract")
            self.transfers = {}
        if index <= STAGE_ORDER.index("reduce"):
            supersede(self.arc.examples); supersede(self.arc.mechanisms)
            supersede(self.arc.systems); supersede(self.arc.tests)
            supersede(self.case_assessments); supersede(self.inferences)
            self.case_assessments = {}; self.inferences = {}
            for m in self.arc.mechanisms.values():
                if m.mid in superseded and m.state not in {"falsified", "superseded"}:
                    m.state = "superseded"
            self.test_plan_digest = ""; self.test_plan_frozen_at = 0.0; self.test_plan_frozen_by = ""
        elif index <= STAGE_ORDER.index("contact"):
            supersede(self.arc.tests)
            self.test_plan_digest = ""; self.test_plan_frozen_at = 0.0; self.test_plan_frozen_by = ""

        self.superseded_ids.update(superseded)
        self.invalidated_ids.difference_update(superseded)
        amendment = ArcAmendment(old_revision, self.revision, reopen_stage, reason,
                                 dict(changes), actor, approval_ref, tuple(sorted(set(superseded))))
        self.amendments.append(amendment)
        self.current_stage = reopen_stage
        self.enqueue(reopen_stage, f"amendment {amendment.amendment_id}: {reason}",
                     source_id=amendment.amendment_id, priority=100.0)
        self.audit.append("arc_amended", asdict(amendment))
        return amendment

    # -------------------------------------------------------------- reporting
    def process_posiwid(self) -> dict:
        included = [eid for eid, d in self.screening.items() if d.include]
        active_mechanisms = self._active(self.arc.mechanisms)
        all_mechanisms = list(self.arc.mechanisms.values())
        eliminated = sum(m.mid in self.superseded_ids or m.mid in self.invalidated_ids
                         or m.state in {"falsified", "superseded"}
                         for m in all_mechanisms)
        contacts = [t for t in self._active(self.arc.tests) if t.state not in {"proposed", "scheduled"}]
        return {
            "arc_id": self.arc.arc_id, "revision": self.revision,
            "current_stage": self.current_stage,
            "candidate_field_expansion": {
                "queries": len(self.arc.queries), "retrieved_evidence": len(self.arc.evidence),
                "screened_in": len(included),
                "independence_clusters": len(self.independence_clusters(included)),
                "abstraction_levels": len({a.level for a in self._active(self.arc.abstractions)}),
                "transfer_cases": len(self._active(self.transfers)),
            },
            "subtractive_reduction": {
                "mechanisms_total": len(all_mechanisms), "mechanisms_eliminated": eliminated,
                "mechanisms_remaining": len(active_mechanisms),
                "competing_systems": len(self._active(self.arc.systems)),
                "case_assessments": len(self._active(self.case_assessments)),
                "tests_frozen": bool(self.test_plan_digest),
                "contacts_recorded": len(contacts),
                "stage_reopenings": len(self.amendments) + len(self.diagnoses),
                "invalidated_products": len(self.invalidated_ids),
            },
            "queue": [asdict(w) for w in sorted(self.work_queue.values(),
                                                key=lambda x: (-x.priority, x.created_at))
                      if w.state in {"queued", "active", "blocked"}],
            "next_work": asdict(self.next_work()) if self.next_work() else None,
            "contract_valid": self.verify_contract(),
            "test_plan_valid": self.verify_test_plan() if self.test_plan_digest else False,
            "audit_valid": self.audit.verify(),
        }

    def status(self) -> dict:
        return {
            "process": self.process_posiwid(),
            "gates": [asdict(self.stage_gate(stage)) for stage in STAGE_ORDER],
            "approvals": [asdict(x) for x in self.approvals],
            "amendments": [asdict(x) for x in self.amendments],
            "diagnoses": [asdict(x) for x in self.diagnoses.values()],
            "search_plans": {
                k: {"frozen": p.frozen, "digest_valid": p.verify() if p.frozen else False,
                    "requirements": [asdict(x) for x in p.requirements.values()]}
                for k, p in self.search_plans.items()
            },
        }

    # ------------------------------------------------------------ persistence
    def to_dict(self) -> dict:
        return {
            "arc": self.arc.to_dict(), "envelope": asdict(self.envelope),
            "eligibility": asdict(self.eligibility), "revision": self.revision,
            "current_stage": self.current_stage, "contract_digest": self.contract_digest,
            "contract_frozen_at": self.contract_frozen_at,
            "contract_frozen_by": self.contract_frozen_by,
            "search_plans": {
                k: {"track": p.track,
                    "requirements": [asdict(x) for x in p.requirements.values()],
                    "frozen_digest": p.frozen_digest, "frozen_at": p.frozen_at,
                    "frozen_by": p.frozen_by}
                for k, p in self.search_plans.items()},
            "screening": [asdict(x) for x in self.screening.values()],
            "lineages": [asdict(x) for x in self.lineages.values()],
            "transfers": [asdict(x) for x in self.transfers.values()],
            "case_assessments": [asdict(x) for x in self.case_assessments.values()],
            "inferences": [asdict(x) for x in self.inferences.values()],
            "approvals": [asdict(x) for x in self.approvals],
            "work_queue": [asdict(x) for x in self.work_queue.values()],
            "diagnoses": [asdict(x) for x in self.diagnoses.values()],
            "amendments": [asdict(x) for x in self.amendments],
            "superseded_ids": sorted(self.superseded_ids),
            "invalidated_ids": sorted(self.invalidated_ids),
            "test_plan_digest": self.test_plan_digest,
            "test_plan_frozen_at": self.test_plan_frozen_at,
            "test_plan_frozen_by": self.test_plan_frozen_by,
            "audit": self.audit.to_dict(),
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "ARC5Kernel":
        eraw = dict(raw["envelope"])
        for key in ("domain_families", "concrete_polarities", "abstract_polarities",
                    "required_followup_categories"):
            eraw[key] = tuple(eraw.get(key, ()))
        eligibility_raw = dict(raw["eligibility"])
        for key in ("inclusion_rules", "exclusion_rules", "source_classes", "languages"):
            eligibility_raw[key] = tuple(eligibility_raw.get(key, ()))
        obj = cls(DiscoveryArc.from_dict(raw["arc"]), SearchEnvelope(**eraw),
                  EligibilityContract(**eligibility_raw))
        obj.revision = int(raw.get("revision", 1)); obj.current_stage = str(raw.get("current_stage", "contract"))
        obj.contract_digest = str(raw.get("contract_digest", "")); obj.contract_frozen_at = float(raw.get("contract_frozen_at", 0.0)); obj.contract_frozen_by = str(raw.get("contract_frozen_by", ""))
        obj.search_plans = {}
        for track, prow in dict(raw.get("search_plans", {})).items():
            p = SearchTrackPlan(str(prow.get("track", track)))
            for row in prow.get("requirements", []):
                req = SearchRequirement(**dict(row)); p.requirements[req.rid] = req
            p.frozen_digest = str(prow.get("frozen_digest", "")); p.frozen_at = float(prow.get("frozen_at", 0.0)); p.frozen_by = str(prow.get("frozen_by", ""))
            obj.search_plans[str(track)] = p
        for track in TRACKS:
            obj.search_plans.setdefault(track, SearchTrackPlan(track))
        obj.screening = {}
        for row in raw.get("screening", []):
            d = dict(row); d["criteria"] = tuple(d.get("criteria", ())); x = ScreeningDecision(**d); obj.screening[x.evidence_id] = x
        obj.lineages = {}
        for row in raw.get("lineages", []):
            d = dict(row)
            for key in ("study_ids", "dataset_ids", "model_families", "institutions", "author_groups", "funding_sources", "raw_source_ids", "other_roots"):
                d[key] = tuple(d.get(key, ()))
            x = EvidenceLineageProfile(**d); obj.lineages[x.evidence_id] = x
        obj.transfers = {}
        for row in raw.get("transfers", []):
            d = dict(row)
            for key in ("retained_causal_structure", "retained_constraints", "contextual_mismatches", "anti_analogy", "translation_prediction", "evidence_ids"):
                d[key] = tuple(d.get(key, ()))
            x = TransferCase(**d); obj.transfers[x.tid] = x
        obj.case_assessments = {}
        for row in raw.get("case_assessments", []):
            d = dict(row)
            for key in ("confounders", "evidence_ids"): d[key] = tuple(d.get(key, ()))
            x = MechanismCaseAssessment(**d); obj.case_assessments[x.aid] = x
        obj.inferences = {}
        for row in raw.get("inferences", []):
            d = dict(row)
            for key in ("success_with", "success_without", "failure_with", "failure_without", "unresolved"): d[key] = tuple(d.get(key, ()))
            x = MechanismInference(**d); obj.inferences[x.iid] = x
        obj.approvals = [ApprovalRecord(**dict(x)) for x in raw.get("approvals", [])]
        obj.work_queue = {}
        for row in raw.get("work_queue", []):
            d = dict(row); d["blocked_by"] = tuple(d.get("blocked_by", ())); x = WorkItem(**d); obj.work_queue[x.wid] = x
        obj.diagnoses = {}
        for row in raw.get("diagnoses", []):
            d = dict(row); d["hypotheses"] = tuple(d.get("hypotheses", ())); d["evidence_ids"] = tuple(d.get("evidence_ids", ())); x = FailureDiagnosis(**d); obj.diagnoses[x.diagnosis_id] = x
        obj.amendments = []
        for row in raw.get("amendments", []):
            d = dict(row); d["superseded_ids"] = tuple(d.get("superseded_ids", ())); obj.amendments.append(ArcAmendment(**d))
        obj.superseded_ids = set(raw.get("superseded_ids", ()))
        obj.invalidated_ids = set(raw.get("invalidated_ids", ()))
        obj.test_plan_digest = str(raw.get("test_plan_digest", "")); obj.test_plan_frozen_at = float(raw.get("test_plan_frozen_at", 0.0)); obj.test_plan_frozen_by = str(raw.get("test_plan_frozen_by", ""))
        obj.audit = EventLog.from_dict(raw.get("audit", {}))
        return obj

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True, default=str))

    @classmethod
    def load(cls, path: str | Path) -> "ARC5Kernel":
        return cls.from_dict(json.loads(Path(path).read_text()))

    def verify(self) -> dict:
        errors = []
        if self.contract_digest and not self.verify_contract(): errors.append("contract digest mismatch")
        for track, plan in self.search_plans.items():
            if plan.frozen and not plan.verify(): errors.append(f"{track} search-plan digest mismatch")
        if self.test_plan_digest and not self.verify_test_plan(): errors.append("test-plan digest mismatch")
        arc_audit = self.arc.audit.verify(); kernel_audit = self.audit.verify()
        if not arc_audit.get("valid", False): errors.append("arc audit invalid")
        if not kernel_audit.get("valid", False): errors.append("kernel audit invalid")
        return {"valid": not errors, "errors": errors,
                "arc_audit": arc_audit, "kernel_audit": kernel_audit,
                "revision": self.revision, "invalidated_ids": len(self.invalidated_ids)}

    def _requirement(self, requirement_id: str) -> SearchRequirement:
        for plan in self.search_plans.values():
            if requirement_id in plan.requirements:
                return plan.requirements[requirement_id]
        raise KeyError("unknown search requirement")
