"""Restricted transactional key-set state slice for performance experiments."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from pathlib import Path
from typing import Mapping


def _canon(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def _digest(value: object) -> str:
    return hashlib.sha256(_canon(value).encode()).hexdigest()


class TransactionalKeySetStore:
    """SQLite WAL/FULL store for idempotent key-set mutations only.

    It is not a replacement for FieldInstrument.runtime.json.  The API rejects
    deletes, increments and opaque object mutation because those algebras were
    not part of the qualifying contact.
    """

    SCHEMA_VERSION = 1

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path, timeout=10.0, isolation_level=None)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS events(
              seq INTEGER PRIMARY KEY AUTOINCREMENT,
              idempotency_key TEXT NOT NULL UNIQUE,
              payload_json TEXT NOT NULL,
              payload_sha256 TEXT NOT NULL,
              committed_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS materialized(
              key TEXT PRIMARY KEY,
              value_json TEXT NOT NULL,
              value_sha256 TEXT NOT NULL,
              last_seq INTEGER NOT NULL REFERENCES events(seq)
            );
            CREATE INDEX IF NOT EXISTS idx_materialized_last_seq ON materialized(last_seq);
            """
        )
        self.db.execute("INSERT OR IGNORE INTO metadata(key,value) VALUES('schema_version',?)",
                        (str(self.SCHEMA_VERSION),))

    def close(self) -> None:
        self.db.close()

    def set_many(self, changes: Mapping[str, object], idempotency_key: str) -> dict:
        if not idempotency_key.strip() or not changes:
            raise ValueError("set_many requires changes and idempotency key")
        if any(not isinstance(k, str) or not k for k in changes):
            raise ValueError("keys must be non-empty strings")
        payload = {k: changes[k] for k in sorted(changes)}
        payload_json = _canon(payload); payload_sha = _digest(payload)
        self.db.execute("BEGIN IMMEDIATE")
        try:
            prior = self.db.execute(
                "SELECT seq,payload_sha256 FROM events WHERE idempotency_key=?",
                (idempotency_key,),
            ).fetchone()
            if prior:
                if prior[1] != payload_sha:
                    raise ValueError("idempotency key reused with different payload")
                self.db.execute("COMMIT")
                return {"seq": prior[0], "duplicate": True, "payload_sha256": payload_sha}
            cur = self.db.execute(
                "INSERT INTO events(idempotency_key,payload_json,payload_sha256,committed_at) VALUES(?,?,?,?)",
                (idempotency_key, payload_json, payload_sha, time.time()),
            )
            seq = int(cur.lastrowid)
            for key, value in payload.items():
                value_json = _canon(value); value_sha = hashlib.sha256(value_json.encode()).hexdigest()
                self.db.execute(
                    "INSERT INTO materialized(key,value_json,value_sha256,last_seq) VALUES(?,?,?,?) "
                    "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,"
                    "value_sha256=excluded.value_sha256,last_seq=excluded.last_seq",
                    (key, value_json, value_sha, seq),
                )
            self.db.execute("COMMIT")
            return {"seq": seq, "duplicate": False, "payload_sha256": payload_sha}
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def get(self, key: str):
        row = self.db.execute("SELECT value_json FROM materialized WHERE key=?", (key,)).fetchone()
        return None if row is None else json.loads(row[0])

    def export_state(self) -> dict:
        return {key: json.loads(value) for key, value in self.db.execute(
            "SELECT key,value_json FROM materialized ORDER BY key")}

    def verify(self) -> dict:
        rebuilt = {}
        broken = []
        events = 0
        for seq, payload_json, payload_sha in self.db.execute(
                "SELECT seq,payload_json,payload_sha256 FROM events ORDER BY seq"):
            events += 1
            try:
                payload = json.loads(payload_json)
            except json.JSONDecodeError:
                broken.append({"seq": seq, "reason": "invalid event JSON"}); continue
            if _digest(payload) != payload_sha:
                broken.append({"seq": seq, "reason": "event digest mismatch"}); continue
            rebuilt.update(payload)
        actual = self.export_state()
        if rebuilt != actual:
            broken.append({"reason": "event/materialized state mismatch"})
        return {"valid": not broken, "events": events, "keys": len(actual),
                "state_sha256": _digest(actual), "broken": broken,
                "scope": "idempotent key-set process-crash semantics; not physical power-loss certification"}

    def status(self) -> dict:
        page_count = int(self.db.execute("PRAGMA page_count").fetchone()[0])
        page_size = int(self.db.execute("PRAGMA page_size").fetchone()[0])
        return {"path": str(self.path), "journal_mode": self.db.execute("PRAGMA journal_mode").fetchone()[0],
                "synchronous": int(self.db.execute("PRAGMA synchronous").fetchone()[0]),
                "events": int(self.db.execute("SELECT COUNT(*) FROM events").fetchone()[0]),
                "keys": int(self.db.execute("SELECT COUNT(*) FROM materialized").fetchone()[0]),
                "application_db_bytes": page_count * page_size, "verify": self.verify()}
