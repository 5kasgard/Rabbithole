"""Runtime organ registry and architectural mutation gates.

An organ is not live because a file exists or a unit test imports it.  It is live
only when a public capability traverses it, its effects are recorded, and
removing it causes the representative capability to fail in the predicted way.

The registry therefore supplies:

* explicit dependencies and authority effects;
* enable/disable controls for deletion testing;
* per-request runtime traces;
* capability coverage and decorative-organ detection;
* mutation gates that compare baseline and disabled behaviour.
"""
from __future__ import annotations

import contextlib
import copy
import os
import resource
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Callable, Dict, Iterable, Iterator, List, Mapping, Optional, Sequence, Tuple

from .wal import EventLog


class OrganUnavailable(RuntimeError):
    def __init__(self, organ: str, reason: str):
        super().__init__(f"organ {organ!r} unavailable: {reason}")
        self.organ = organ
        self.reason = reason


@dataclass
class OrganSpec:
    name: str
    function: str
    observed_effects: Tuple[str, ...]
    dependencies: Tuple[str, ...] = ()
    public_capabilities: Tuple[str, ...] = ()
    authority_effect: str = "none"
    failure_signature: str = ""
    substrate: str = ""
    enabled: bool = True
    status: str = "registered"  # registered|live|partial|deferred|failed
    oid: str = field(default_factory=lambda: f"ORG{uuid.uuid4().hex[:12]}")

    def validate(self) -> None:
        if not self.name.strip() or not self.function.strip():
            raise ValueError("organ name and function are required")
        if not self.observed_effects:
            raise ValueError("organ requires at least one observable effect")
        if self.name in self.dependencies:
            raise ValueError("organ cannot depend on itself")


@dataclass
class OrganTrace:
    request_id: str
    organ: str
    capability: str
    operation: str
    started_at: float
    ended_at: float
    outcome: str
    effects: Tuple[str, ...] = ()
    error: str = ""
    authority_effect: str = "none"


@dataclass
class MutationResult:
    organ: str
    capability: str
    baseline_ok: bool
    disabled_ok: bool
    expected_failure_observed: bool
    baseline_effect: object
    disabled_effect: object
    reason: str

    @property
    def load_bearing(self) -> bool:
        return self.baseline_ok and not self.disabled_ok and self.expected_failure_observed


class OrganRegistry:
    def __init__(self):
        self.specs: Dict[str, OrganSpec] = {}
        self.traces: List[OrganTrace] = []
        self.audit = EventLog()
        self.resource_hook = None

    def register(self, spec: OrganSpec) -> None:
        spec.validate()
        if spec.name in self.specs:
            raise ValueError(f"organ {spec.name!r} already registered")
        self.specs[spec.name] = spec
        self._validate_graph()
        self.audit.append("organ_registered", asdict(spec))

    def _validate_graph(self) -> None:
        # Unknown dependencies may be registered later, but cycles among known
        # organs are rejected because they make deletion diagnosis ambiguous.
        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(name: str) -> None:
            if name in visited:
                return
            if name in visiting:
                raise ValueError(f"organ dependency cycle involving {name!r}")
            visiting.add(name)
            for dep in self.specs[name].dependencies:
                if dep in self.specs:
                    visit(dep)
            visiting.remove(name)
            visited.add(name)

        for name in self.specs:
            visit(name)

    def require(self, organ: str, capability: str = "") -> OrganSpec:
        if organ not in self.specs:
            raise OrganUnavailable(organ, "not registered")
        spec = self.specs[organ]
        if not spec.enabled:
            raise OrganUnavailable(organ, "disabled by mutation or policy")
        missing = [d for d in spec.dependencies
                   if d not in self.specs or not self.specs[d].enabled]
        if missing:
            raise OrganUnavailable(organ, f"disabled/missing dependencies: {', '.join(missing)}")
        if capability and spec.public_capabilities and capability not in spec.public_capabilities:
            raise OrganUnavailable(organ, f"does not serve capability {capability!r}")
        return spec

    @contextlib.contextmanager
    def operation(self, request_id: str, organ: str, capability: str,
                  operation: str) -> Iterator[OrganSpec]:
        spec = self.require(organ, capability)
        start = time.time(); cpu0 = time.process_time()
        ru0 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        def _io():
            try:
                values = {}
                with open("/proc/self/io", "r", encoding="utf-8") as fh:
                    for line in fh:
                        key, value = line.split(":", 1); values[key.strip()] = int(value.strip())
                return int(values.get("read_bytes", 0)), int(values.get("write_bytes", 0))
            except Exception:
                return 0, 0
        r0, w0 = _io()
        outcome, error = "passed", ""
        effects: Tuple[str, ...] = ()
        try:
            yield spec
            effects = spec.observed_effects
            spec.status = "live"
        except Exception as exc:
            outcome, error = "failed", f"{type(exc).__name__}: {exc}"
            spec.status = "failed"
            raise
        finally:
            end = time.time(); cpu1 = time.process_time(); r1, w1 = _io()
            trace = OrganTrace(request_id, organ, capability, operation,
                               start, end, outcome, effects, error,
                               spec.authority_effect)
            self.traces.append(trace)
            self.audit.append("organ_invoked", asdict(trace))
            if self.resource_hook is not None:
                peak = int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
                if os.name == "posix" and peak < 10_000_000:
                    peak *= 1024
                self.resource_hook({
                    "request_id": request_id, "capability": capability, "operation": operation,
                    "organ": organ, "wall_seconds": max(0.0, end-start),
                    "cpu_seconds": max(0.0, cpu1-cpu0), "peak_rss_bytes": peak,
                    "read_bytes": max(0, r1-r0), "write_bytes": max(0, w1-w0),
                    "unknown_dimensions": ("monetary_cost", "energy_joules", "human_seconds",
                                           "external_experiment_cost", "irreversible_risk"),
                    "metadata": {"outcome": outcome, "error": error},
                    "started_at": start, "ended_at": end,
                })

    def enable(self, organ: str, enabled: bool = True, reason: str = "") -> None:
        spec = self.specs[organ]
        spec.enabled = bool(enabled)
        self.audit.append("organ_state_changed", {
            "organ": organ, "enabled": spec.enabled, "reason": reason,
        })

    @contextlib.contextmanager
    def disabled(self, organ: str, reason: str = "mutation test") -> Iterator[None]:
        old = self.specs[organ].enabled
        self.enable(organ, False, reason)
        try:
            yield
        finally:
            self.enable(organ, old, "restore after mutation")

    def mutation_test(self, organ: str, capability: str,
                      invoke: Callable[[], object],
                      *, failure_predicate: Optional[Callable[[BaseException], bool]] = None,
                      equivalence: Optional[Callable[[object, object], bool]] = None) -> MutationResult:
        """Disable one organ and rerun a public capability.

        A passing baseline plus the predicted disabled failure establishes that
        the organ is load-bearing for this capability.  A changed result without
        the declared failure signature remains a diagnosis failure, not success.
        """
        try:
            baseline = invoke()
            baseline_ok = True
        except Exception as exc:
            return MutationResult(organ, capability, False, False, False,
                                  f"{type(exc).__name__}: {exc}", None,
                                  "baseline capability failed")
        disabled_ok = True
        disabled_effect: object = None
        expected = False
        with self.disabled(organ):
            try:
                disabled_effect = invoke()
            except BaseException as exc:
                disabled_ok = False
                disabled_effect = f"{type(exc).__name__}: {exc}"
                if failure_predicate is not None:
                    expected = bool(failure_predicate(exc))
                else:
                    expected = isinstance(exc, OrganUnavailable) and (
                        exc.organ == organ
                        or organ in {x.strip() for x in exc.reason.partition(":")[2].split(",") if x.strip()}
                    )
        if disabled_ok:
            same = equivalence(baseline, disabled_effect) if equivalence else baseline == disabled_effect
            reason = ("organ is decorative for this capability" if same else
                      "organ changes behaviour but does not fail with a declared signature")
        elif expected:
            reason = "predicted capability failure observed"
        else:
            reason = "disabled run failed, but not in the predicted way"
        result = MutationResult(organ, capability, baseline_ok, disabled_ok, expected,
                                baseline, disabled_effect, reason)
        self.audit.append("organ_mutation_test", asdict(result) | {"load_bearing": result.load_bearing})
        return result

    def coverage(self, capability: Optional[str] = None) -> dict:
        specs = [s for s in self.specs.values()
                 if capability is None or capability in s.public_capabilities]
        invoked = {t.organ for t in self.traces
                   if capability is None or t.capability == capability}
        uninvoked = sorted(s.name for s in specs if s.name not in invoked)
        failed = sorted({t.organ for t in self.traces if t.outcome == "failed"
                         and (capability is None or t.capability == capability)})
        return {
            "capability": capability,
            "registered": len(specs),
            "invoked": len(invoked & {s.name for s in specs}),
            "uninvoked": uninvoked,
            "failed": failed,
            "audit_valid": self.audit.verify().get("valid", False),
        }

    def dependency_path(self, capability: str) -> dict:
        roots = [s.name for s in self.specs.values() if capability in s.public_capabilities]
        reachable: set[str] = set()

        def walk(name: str) -> None:
            if name in reachable or name not in self.specs:
                return
            reachable.add(name)
            for dep in self.specs[name].dependencies:
                walk(dep)

        for root in roots:
            walk(root)
        missing = sorted({d for n in reachable for d in self.specs[n].dependencies
                          if d not in self.specs})
        disabled = sorted(n for n in reachable if not self.specs[n].enabled)
        return {"capability": capability, "roots": roots,
                "reachable_organs": sorted(reachable),
                "missing_dependencies": missing, "disabled": disabled,
                "complete": bool(roots) and not missing and not disabled}

    def to_dict(self) -> dict:
        return {
            "specs": [asdict(x) for x in self.specs.values()],
            "traces": [asdict(x) for x in self.traces],
            "audit": self.audit.to_dict(),
        }

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "OrganRegistry":
        reg = cls()
        reg.specs = {}
        for x in raw.get("specs", []):
            d = dict(x)
            for key in ("observed_effects", "dependencies", "public_capabilities"):
                d[key] = tuple(d.get(key, ()))
            reg.specs[d["name"]] = OrganSpec(**d)
        reg.traces = []
        for x in raw.get("traces", []):
            d = dict(x)
            d["effects"] = tuple(d.get("effects", ()))
            reg.traces.append(OrganTrace(**d))
        reg.audit = EventLog.from_dict(raw.get("audit", {}))
        reg._validate_graph()
        return reg
