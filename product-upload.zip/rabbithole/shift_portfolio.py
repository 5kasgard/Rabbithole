"""Declared distribution-shift monitor portfolios with scoped responses."""
from __future__ import annotations
import math,time,uuid
from collections import Counter
from dataclasses import asdict,dataclass,field
from typing import Dict,Mapping,Sequence,Tuple
from .wal import EventLog

def _id(p):return f"{p}{uuid.uuid4().hex[:12]}"
@dataclass
class ShiftContract:
    monitor_id:str;feature:str;family:str;threshold:float;response:str;applicability:Mapping[str,object];enabled:bool=True
@dataclass
class ShiftBaseline:
    monitor_id:str;statistics:Mapping[str,object];n:int;created_at:float=field(default_factory=time.time);baseline_id:str=field(default_factory=lambda:_id("SHB"))
@dataclass
class ShiftResult:
    monitor_id:str;baseline_id:str;detected:bool;score:float;state:str;response:str;outside_claim:bool=False;result_id:str=field(default_factory=lambda:_id("SHR"))
class ShiftPortfolio:
    FAMILIES={"mean_z","variance_ratio","category_novelty","missingness"}
    def __init__(self):self.contracts:Dict[str,ShiftContract]={};self.baselines:Dict[str,ShiftBaseline]={};self.audit=EventLog()
    def register(self,c:ShiftContract):
        if c.family not in self.FAMILIES:raise ValueError("undeclared monitor family")
        self.contracts[c.monitor_id]=c;self.audit.append("shift_monitor_registered",asdict(c))
    def fit(self,monitor_id:str,values:Sequence[object])->ShiftBaseline:
        c=self.contracts[monitor_id];xs=list(values)
        if len(xs)<2:raise ValueError("baseline requires at least two values")
        if c.family in {"mean_z","variance_ratio"}:
            nums=[float(x) for x in xs if x is not None];mean=sum(nums)/len(nums);var=sum((x-mean)**2 for x in nums)/max(1,len(nums)-1);stats={"mean":mean,"std":max(math.sqrt(var),1e-12),"variance":var,"missing":1-len(nums)/len(xs)}
        elif c.family=="category_novelty":stats={"categories":sorted({str(x) for x in xs if x is not None}),"missing":sum(x is None for x in xs)/len(xs)}
        else:stats={"missing":sum(x is None for x in xs)/len(xs)}
        b=ShiftBaseline(monitor_id,stats,len(xs));self.baselines[b.baseline_id]=b;self.audit.append("shift_baseline_fitted",asdict(b));return b
    def evaluate(self,baseline_id:str,values:Sequence[object],*,observed_family:str="")->ShiftResult:
        b=self.baselines[baseline_id];c=self.contracts[b.monitor_id]
        if observed_family and observed_family!=c.family:
            r=ShiftResult(c.monitor_id,baseline_id,False,0.,"outside_declared_shift_family","abstain_and_re-ground",True);self.audit.append("shift_outside_claim",asdict(r));return r
        xs=list(values)
        if not xs:raise ValueError("observations required")
        if c.family=="mean_z":
            nums=[float(x) for x in xs if x is not None];score=abs(sum(nums)/len(nums)-float(b.statistics["mean"]))/float(b.statistics["std"])
        elif c.family=="variance_ratio":
            nums=[float(x) for x in xs if x is not None];mean=sum(nums)/len(nums);var=sum((x-mean)**2 for x in nums)/max(1,len(nums)-1);base=max(float(b.statistics["variance"]),1e-12);score=max(var/base,base/max(var,1e-12))
        elif c.family=="category_novelty":
            known=set(b.statistics["categories"]);score=sum(str(x) not in known for x in xs if x is not None)/max(1,sum(x is not None for x in xs))
        else:score=abs(sum(x is None for x in xs)/len(xs)-float(b.statistics["missing"]))
        detected=score>c.threshold;r=ShiftResult(c.monitor_id,baseline_id,detected,score,"declared_shift_detected" if detected else "within_declared_regime",c.response if detected else "continue_with_scope")
        self.audit.append("shift_evaluated",asdict(r));return r
    def to_dict(self):return {"contracts":[asdict(x) for x in self.contracts.values()],"baselines":[asdict(x) for x in self.baselines.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw):
        o=cls()
        for r in raw.get("contracts",[]):c=ShiftContract(**dict(r));o.contracts[c.monitor_id]=c
        for r in raw.get("baselines",[]):b=ShiftBaseline(**dict(r));o.baselines[b.baseline_id]=b
        o.audit=EventLog.from_dict(raw.get("audit",{}));return o
