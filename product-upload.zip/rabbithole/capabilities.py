"""Scoped, revocable object capabilities for faculty and executor actions.

Recovered from the lineage because the running system now has real tool seams.
Capabilities control *permission to act*, not epistemic authority: a permitted
executor can still return an untestable or failed verdict, and a capability does
not make its output true.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
from typing import Optional


class CapabilityError(Exception):
    pass


class CapabilityIssuer:
    def __init__(self, secret: Optional[bytes] = None):
        self._secret = secret or os.urandom(32)
        self._revoked: set[str] = set()
        self.audit: list[dict] = []

    def _body(self, grant: dict) -> bytes:
        keys = ("cap_id", "action", "resource", "holder", "expires", "constraints", "parent")
        return json.dumps({k: grant.get(k) for k in keys}, sort_keys=True,
                          separators=(",", ":")).encode()

    def _sign(self, grant: dict) -> str:
        return hmac.new(self._secret, self._body(grant), hashlib.sha256).hexdigest()

    def mint(self, action: str, resource: str, holder: str,
             expires: Optional[float] = None, constraints: Optional[dict] = None,
             parent: Optional[str] = None) -> dict:
        grant = {
            "cap_id": hashlib.sha256(os.urandom(16)).hexdigest()[:16],
            "action": str(action), "resource": str(resource), "holder": str(holder),
            "expires": expires, "constraints": constraints or {}, "parent": parent,
        }
        grant["sig"] = self._sign(grant)
        self.audit.append({"op": "mint", "cap_id": grant["cap_id"], "action": action,
                           "resource": resource, "holder": holder, "ts": time.time()})
        return grant

    def check(self, grant: Optional[dict], action: str, resource: str,
              holder: Optional[str] = None) -> bool:
        try:
            if not grant or "sig" not in grant:
                return self._deny(grant, "malformed")
            if grant.get("cap_id") in self._revoked:
                return self._deny(grant, "revoked")
            exp = grant.get("expires")
            if exp is not None and time.time() > float(exp):
                return self._deny(grant, "expired")
            if not hmac.compare_digest(str(grant["sig"]), self._sign(grant)):
                return self._deny(grant, "forged or tampered")
            if grant.get("action") != action or grant.get("resource") != resource:
                return self._deny(grant, "out of scope")
            if holder is not None and grant.get("holder") != holder:
                return self._deny(grant, "wrong holder")
            self.audit.append({"op": "check", "cap_id": grant["cap_id"],
                               "result": "allow", "ts": time.time()})
            return True
        except Exception as exc:
            return self._deny(grant, f"error: {exc}")

    def _deny(self, grant: Optional[dict], reason: str) -> bool:
        self.audit.append({"op": "check", "cap_id": (grant or {}).get("cap_id"),
                           "result": "deny", "reason": reason, "ts": time.time()})
        return False

    def revoke(self, grant: dict) -> None:
        cid = str(grant.get("cap_id"))
        self._revoked.add(cid)
        self.audit.append({"op": "revoke", "cap_id": cid, "ts": time.time()})

    def attenuate(self, grant: dict, holder: Optional[str] = None,
                  action: Optional[str] = None, resource: Optional[str] = None,
                  expires: Optional[float] = None) -> dict:
        if not self.check(grant, grant.get("action"), grant.get("resource")):
            raise CapabilityError("cannot attenuate an invalid capability")
        new_action = action or grant["action"]
        new_resource = resource or grant["resource"]
        if new_action != grant["action"] or new_resource != grant["resource"]:
            allowed = {tuple(x) for x in grant.get("constraints", {}).get("sub_scopes", [])}
            if (new_action, new_resource) not in allowed:
                raise CapabilityError("attenuation cannot broaden or invent scope")
        old_exp = grant.get("expires")
        if old_exp is not None and expires is not None and expires > old_exp:
            raise CapabilityError("attenuation cannot extend expiry")
        new_exp = old_exp if expires is None else expires
        return self.mint(new_action, new_resource, holder or grant["holder"],
                         new_exp, parent=grant["cap_id"])
