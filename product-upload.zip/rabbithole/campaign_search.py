"""Opposition-aware multi-route search campaign controller."""
from __future__ import annotations

import math
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Sequence, Tuple

from .providers import ProviderRegistry
from .wal import EventLog


def _id(prefix:str)->str:return f"{prefix}{uuid.uuid4().hex[:12]}"

@dataclass(frozen=True)
class CampaignQuery:
    text:str
    polarity:str  # for|against|failure|boundary|analogue|anti-analogue|snowball
    source_class:str
    provider_ids:Tuple[str,...]
    limit:int=20
    qid:str=field(default_factory=lambda:_id("QRY"))

@dataclass
class RouteResult:
    query_id:str
    provider_id:str
    receipt_id:str
    result_digests:Tuple[str,...]
    new_content:int
    new_studies:int
    error:str=""

@dataclass
class SearchCampaign:
    name:str
    required_polarities:Tuple[str,...]
    required_source_classes:Tuple[str,...]
    queries:Tuple[CampaignQuery,...]
    reviewer_required:bool=False
    campaign_id:str=field(default_factory=lambda:_id("SRC"))
    state:str="planned"
    route_results:Tuple[RouteResult,...]=()
    reviewer_decision:Mapping[str,object]=field(default_factory=dict)
    created_at:float=field(default_factory=time.time)

class SearchCampaignController:
    def __init__(self):
        self.campaigns:Dict[str,SearchCampaign]={}
        self.audit=EventLog()

    def register(self,campaign:SearchCampaign)->str:
        if not campaign.queries: raise ValueError("search campaign requires queries")
        polarities={q.polarity for q in campaign.queries};classes={q.source_class for q in campaign.queries}
        missing_p=set(campaign.required_polarities)-polarities;missing_c=set(campaign.required_source_classes)-classes
        if missing_p or missing_c: raise ValueError(f"coverage plan incomplete: polarities={sorted(missing_p)}, classes={sorted(missing_c)}")
        self.campaigns[campaign.campaign_id]=campaign;self.audit.append("search_campaign_registered",asdict(campaign));return campaign.campaign_id

    def execute(self,campaign_id:str,providers:ProviderRegistry)->dict:
        c=self.campaigns[campaign_id]
        if c.state not in {"planned","failed"}: raise ValueError("campaign already executed")
        seen_content=set();seen_study_keys=set();rows=[];novelty=[]
        for q in c.queries:
            for pid in q.provider_ids:
                try:
                    receipt,_=providers.retrieve(pid,q.text,limit=q.limit,route=q.polarity)
                    groups=providers.group_studies(receipt.result_digests)
                    new_content=len(set(receipt.result_digests)-seen_content)
                    keys={g.canonical_key for g in groups};new_studies=len(keys-seen_study_keys)
                    seen_content.update(receipt.result_digests);seen_study_keys.update(keys)
                    rr=RouteResult(q.qid,pid,receipt.receipt_id,receipt.result_digests,new_content,new_studies)
                except Exception as exc:
                    rr=RouteResult(q.qid,pid,"",(),0,0,f"{type(exc).__name__}: {exc}")
                rows.append(rr);novelty.append({"step":len(rows),"new_content":rr.new_content,"new_studies":rr.new_studies,
                                                "cumulative_content":len(seen_content),"cumulative_studies":len(seen_study_keys)})
        c.route_results=tuple(rows);c.state="executed" if any(not r.error for r in rows) else "failed"
        result=self.coverage(campaign_id)|{"novelty_curve":novelty}
        self.audit.append("search_campaign_executed",{"campaign_id":campaign_id,"result":result})
        return result

    def review(self,campaign_id:str,*,reviewer:str,decision:str,rationale:str)->dict:
        if decision not in {"accept","revise","reject"}:raise ValueError(decision)
        c=self.campaigns[campaign_id];c.reviewer_decision={"reviewer":reviewer,"decision":decision,"rationale":rationale,"at":time.time()}
        self.audit.append("search_campaign_reviewed",{"campaign_id":campaign_id,**c.reviewer_decision});return dict(c.reviewer_decision)

    def coverage(self,campaign_id:str)->dict:
        c=self.campaigns[campaign_id];executed_q={r.query_id for r in c.route_results if not r.error}
        qmap={q.qid:q for q in c.queries};pol={qmap[x].polarity for x in executed_q};classes={qmap[x].source_class for x in executed_q}
        missing_p=sorted(set(c.required_polarities)-pol);missing_c=sorted(set(c.required_source_classes)-classes)
        errors=[asdict(r) for r in c.route_results if r.error]
        plateau=False
        successes=[r for r in c.route_results if not r.error]
        if len(successes)>=3: plateau=all(r.new_studies==0 for r in successes[-3:])
        review_ok=not c.reviewer_required or c.reviewer_decision.get("decision")=="accept"
        return {"campaign_id":campaign_id,"state":c.state,"missing_polarities":missing_p,"missing_source_classes":missing_c,
                "routes":len(c.route_results),"successful_routes":len(successes),"errors":errors,"novelty_plateau":plateau,
                "review_required":c.reviewer_required,"review":dict(c.reviewer_decision),
                "coverage_passed":not missing_p and not missing_c and bool(successes) and review_ok}

    def compare_baselines(self,campaign_id:str,relevant_study_keys:Sequence[str],providers:ProviderRegistry)->dict:
        c=self.campaigns[campaign_id];target=set(relevant_study_keys)
        route_sets=[]
        for r in c.route_results:
            if r.error:continue
            route_sets.append({g.canonical_key for g in providers.group_studies(r.result_digests)})
        combined=set().union(*route_sets) if route_sets else set();single=max((len(x&target) for x in route_sets),default=0)
        cheap_first=len(route_sets[0]&target) if route_sets else 0
        return {"target":len(target),"campaign_recall":len(combined&target)/max(1,len(target)),
                "best_single_recall":single/max(1,len(target)),"cheap_first_recall":cheap_first/max(1,len(target)),
                "campaign_improves":len(combined&target)>single}

    def to_dict(self)->dict:return {"campaigns":[asdict(x) for x in self.campaigns.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw:Mapping[str,object])->"SearchCampaignController":
        obj=cls()
        for row in raw.get("campaigns",[]):
            d=dict(row);d["required_polarities"]=tuple(d.get("required_polarities",()));d["required_source_classes"]=tuple(d.get("required_source_classes",()))
            d["queries"]=tuple(CampaignQuery(**({**q,"provider_ids":tuple(q.get("provider_ids",()))})) for q in d.get("queries",()))
            d["route_results"]=tuple(RouteResult(**({**r,"result_digests":tuple(r.get("result_digests",()))})) for r in d.get("route_results",()))
            c=SearchCampaign(**d);obj.campaigns[c.campaign_id]=c
        obj.audit=EventLog.from_dict(raw.get("audit",{}));return obj
