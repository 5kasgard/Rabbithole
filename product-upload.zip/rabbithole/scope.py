"""Applicability and scope contracts for models, laws, and mechanisms.

A model can be internally consistent and still be the wrong model for the
situation.  This registry makes applicability explicit before a model is allowed
to constrain a task.  Unknown scope is not silently treated as a match.
"""
from __future__ import annotations

import math
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Dict, Mapping, Sequence, Tuple

from .wal import EventLog


@dataclass
class ScopeCondition:
    key: str
    operator: str  # eq|in|range|present|absent
    value: object = None
    reason: str = ""

    def evaluate(self, context: Mapping[str, object]) -> Tuple[str, str]:
        if self.operator == "present":
            return ("pass", self.reason) if self.key in context else ("unknown", f"missing {self.key}")
        if self.operator == "absent":
            return ("pass", self.reason) if self.key not in context else ("fail", f"{self.key} must be absent")
        if self.key not in context:
            return "unknown", f"missing {self.key}"
        observed = context[self.key]
        if self.operator == "eq":
            return ("pass", self.reason) if observed == self.value else ("fail", f"{self.key} != {self.value!r}")
        if self.operator == "in":
            values = tuple(self.value or ())
            return ("pass", self.reason) if observed in values else ("fail", f"{self.key} outside allowed set")
        if self.operator == "range":
            lo, hi = self.value
            try:
                x = float(observed)
                ok = math.isfinite(x) and float(lo) <= x <= float(hi)
            except Exception:
                ok = False
            return ("pass", self.reason) if ok else ("fail", f"{self.key} outside [{lo}, {hi}]")
        raise ValueError(f"unknown scope operator {self.operator!r}")


@dataclass
class ModelContract:
    model_id: str
    statement: str
    input_classes: Tuple[str, ...]
    output_classes: Tuple[str, ...]
    conditions: Tuple[ScopeCondition, ...]
    assumptions: Tuple[str, ...]
    known_failure_modes: Tuple[str, ...]
    verification_evidence: Tuple[str, ...] = ()
    contact_quality: float = 0.0
    authority_ceiling: float = 0.0
    valid_from: float = field(default_factory=time.time)
    valid_until: float = 0.0
    status: str = "declared"  # declared|tested|invalidated

    def validate(self) -> None:
        if not self.model_id or not self.statement:
            raise ValueError("model id and statement are required")
        if not 0 <= self.contact_quality <= 1 or not 0 <= self.authority_ceiling <= 1:
            raise ValueError("quality and authority must be in [0,1]")
        if self.status not in {"declared", "tested", "invalidated"}:
            raise ValueError("invalid model status")


@dataclass
class ApplicabilityDecision:
    model_id: str
    state: str  # applicable|inapplicable|unresolved|invalidated
    passed: Tuple[str, ...]
    failed: Tuple[str, ...]
    unknown: Tuple[str, ...]
    authority_ceiling: float
    context: Mapping[str, object]
    created_at: float = field(default_factory=time.time)
    did: str = field(default_factory=lambda: f"APP{uuid.uuid4().hex[:12]}")


class ModelRegistry:
    def __init__(self):
        self.models: Dict[str, ModelContract] = {}
        self.decisions: Dict[str, ApplicabilityDecision] = {}
        self.audit = EventLog()

    def register(self, model: ModelContract) -> None:
        model.validate()
        if model.model_id in self.models:
            raise ValueError(f"model {model.model_id!r} already registered")
        self.models[model.model_id] = model
        self.audit.append("model_registered", asdict(model))

    def invalidate(self, model_id: str, reason: str) -> None:
        model = self.models[model_id]
        model.status = "invalidated"
        self.audit.append("model_invalidated", {"model_id": model_id, "reason": reason})

    def evaluate(self, model_id: str, context: Mapping[str, object], *, now: float | None = None) -> ApplicabilityDecision:
        model = self.models[model_id]
        now = time.time() if now is None else float(now)
        if model.status == "invalidated" or (model.valid_until and now > model.valid_until):
            decision = ApplicabilityDecision(model_id, "invalidated", (), (), (), 0.0, dict(context))
        else:
            passed, failed, unknown = [], [], []
            for condition in model.conditions:
                state, reason = condition.evaluate(context)
                label = f"{condition.key}:{condition.operator}:{reason}"
                (passed if state == "pass" else failed if state == "fail" else unknown).append(label)
            state = "inapplicable" if failed else "unresolved" if unknown else "applicable"
            ceiling = model.authority_ceiling if state == "applicable" else 0.0
            decision = ApplicabilityDecision(model_id, state, tuple(passed), tuple(failed),
                                              tuple(unknown), ceiling, dict(context))
        self.decisions[decision.did] = decision
        self.audit.append("model_applicability_evaluated", asdict(decision))
        return decision

    def require_applicable(self, model_id: str, context: Mapping[str, object]) -> ApplicabilityDecision:
        decision = self.evaluate(model_id, context)
        if decision.state != "applicable":
            raise ValueError(f"model {model_id!r} is {decision.state}: failed={decision.failed}, unknown={decision.unknown}")
        return decision

    def to_dict(self) -> dict:
        return {"models": [asdict(x) for x in self.models.values()],
                "decisions": [asdict(x) for x in self.decisions.values()],
                "audit": self.audit.to_dict()}

    @classmethod
    def from_dict(cls, raw: Mapping[str, object]) -> "ModelRegistry":
        reg = cls()
        for x in raw.get("models", []):
            d = dict(x)
            for key in ("input_classes", "output_classes", "assumptions", "known_failure_modes", "verification_evidence"):
                d[key] = tuple(d.get(key, ()))
            d["conditions"] = tuple(ScopeCondition(**c) for c in d.get("conditions", ()))
            model = ModelContract(**d)
            reg.models[model.model_id] = model
        for x in raw.get("decisions", []):
            d = dict(x)
            for key in ("passed", "failed", "unknown"):
                d[key] = tuple(d.get(key, ()))
            decision = ApplicabilityDecision(**d)
            reg.decisions[decision.did] = decision
        reg.audit = EventLog.from_dict(raw.get("audit", {}))
        return reg
