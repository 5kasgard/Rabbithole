"""Scoped whole-system assurance profiles; never a terminal universal certificate."""
from __future__ import annotations
import time,uuid
from dataclasses import asdict,dataclass,field
from typing import Dict,Mapping,Sequence,Tuple
from .wal import EventLog

def _id(p):return f"{p}{uuid.uuid4().hex[:12]}"
@dataclass
class ScenarioProfile:
    profile_id:str;name:str;scope:Mapping[str,object];required_capabilities:Tuple[str,...];required_external_contacts:Tuple[str,...];success_observations:Tuple[str,...];failure_observations:Tuple[str,...];resource_limits:Mapping[str,float]=field(default_factory=dict);version:str="1"
@dataclass
class ScenarioRun:
    profile_id:str;release_commitment_id:str;capability_results:Mapping[str,str];external_contacts:Tuple[str,...];mutation_case_ids:Tuple[str,...];resource_totals:Mapping[str,object];observations:Tuple[str,...];state:str;limitations:Tuple[str,...];run_id:str=field(default_factory=lambda:_id("SCR"));created_at:float=field(default_factory=time.time)
class ScenarioAssurance:
    def __init__(self):self.profiles:Dict[str,ScenarioProfile]={};self.runs:Dict[str,ScenarioRun]={};self.audit=EventLog()
    def register(self,p:ScenarioProfile):
        if not p.required_capabilities or not p.success_observations:raise ValueError("scenario profile requires capabilities and observations")
        self.profiles[p.profile_id]=p;self.audit.append("scenario_profile_registered",asdict(p))
    def record(self,profile_id:str,release_commitment_id:str,capability_results:Mapping[str,str],external_contacts:Sequence[str],mutation_case_ids:Sequence[str],resource_totals:Mapping[str,object],observations:Sequence[str],limitations:Sequence[str]=())->ScenarioRun:
        p=self.profiles[profile_id];missing_caps=[c for c in p.required_capabilities if capability_results.get(c)!="passed"];missing_contacts=[c for c in p.required_external_contacts if c not in external_contacts];missing_obs=[x for x in p.success_observations if x not in observations];bad=[x for x in p.failure_observations if x in observations]
        limit_breaches=[]
        for k,v in p.resource_limits.items():
            actual=resource_totals.get(k)
            if actual is None or float(actual)>float(v):limit_breaches.append(k)
        state="passed_scoped_profile" if not(missing_caps or missing_contacts or missing_obs or bad or limit_breaches or limitations) else "partial_or_failed"
        lim=tuple(limitations)+tuple(f"missing capability:{x}" for x in missing_caps)+tuple(f"missing contact:{x}" for x in missing_contacts)+tuple(f"missing observation:{x}" for x in missing_obs)+tuple(f"failure observed:{x}" for x in bad)+tuple(f"resource limit:{x}" for x in limit_breaches)
        r=ScenarioRun(profile_id,release_commitment_id,dict(capability_results),tuple(external_contacts),tuple(mutation_case_ids),dict(resource_totals),tuple(observations),state,lim);self.runs[r.run_id]=r;self.audit.append("scenario_run_recorded",asdict(r));return r
    def assurance_graph(self)->dict:
        return {"profiles":[asdict(x) for x in self.profiles.values()],"runs":[asdict(x) for x in self.runs.values()],"universal_completion_claim":False,"terminal_certificate":False,"maintained_scoped_evidence":True}
    def to_dict(self):return {"profiles":[asdict(x) for x in self.profiles.values()],"runs":[asdict(x) for x in self.runs.values()],"audit":self.audit.to_dict()}
    @classmethod
    def from_dict(cls,raw):
        o=cls()
        for r in raw.get("profiles",[]):
            d=dict(r)
            for k in ("required_capabilities","required_external_contacts","success_observations","failure_observations"):d[k]=tuple(d.get(k,()))
            p=ScenarioProfile(**d);o.profiles[p.profile_id]=p
        for r in raw.get("runs",[]):
            d=dict(r)
            for k in ("external_contacts","mutation_case_ids","observations","limitations"):d[k]=tuple(d.get(k,()))
            x=ScenarioRun(**d);o.runs[x.run_id]=x
        o.audit=EventLog.from_dict(raw.get("audit",{}));return o
