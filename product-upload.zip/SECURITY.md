# Security

Do not disclose credentials or sensitive subject data in public issues. Report security-sensitive findings privately to the repository owner.

External actions must remain capability-scoped, reversible where declared, budgeted, monitored and attributable. A clean local test is not external validation.
