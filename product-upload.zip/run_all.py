"""Fast source-bound replay for The Field master candidate 0.18.0rc3."""
from __future__ import annotations

import json
from pathlib import Path

from rabbithole.master_registry import MasterRegistry, master_source_digest, master_test_digest


def main() -> int:
    root = Path(__file__).resolve().parent
    receipt_path = root / "artifacts" / "master_acceptance.json"
    registry = MasterRegistry(root).verify()
    if not receipt_path.is_file():
        valid = bool(
            registry.get("valid") is True
            and registry.get("distribution_scope") == "wheel_runtime"
            and registry.get("full_history_embedded") is False
            and registry.get("external_claims_closed") is False
        )
        output = {
            "passed": valid,
            "release": "0.18.0rc3",
            "distribution_scope": "wheel_runtime",
            "full_archive_acceptance": "requires the full master ZIP",
            "authority_bundle_digest": registry.get("master_source_digest"),
            "external_validation": "blocked",
            "canonical_v018_promotion": "not_authorized",
            "mode": "installed-wheel runtime self-check",
        }
        print(json.dumps(output, indent=2))
        return 0 if valid else 1
    receipt = json.loads(receipt_path.read_text())
    valid = bool(
        receipt.get("passed") is True
        and receipt.get("release") == "0.18.0rc3"
        and receipt.get("master_source_digest") == master_source_digest(root)
        and receipt.get("master_test_digest") == master_test_digest(root)
        and receipt.get("external_validation") == "blocked"
        and receipt.get("canonical_v018_promotion") == "not_authorized"
        and receipt.get("check_count") == receipt.get("passed_count")
        and all(check.get("passed") for check in receipt.get("checks", []))
        and registry.get("valid") is True
        and registry.get("external_claims_closed") is False
    )
    output = {
        "passed": valid,
        "release": "0.18.0rc3",
        "checks": f"{receipt.get('passed_count', 0)}/{receipt.get('check_count', 0)}",
        "master_source_digest": master_source_digest(root),
        "external_validation": "blocked",
        "canonical_v018_promotion": "not_authorized",
        "mode": "source-bound master receipt replay",
    }
    print(json.dumps(output, indent=2))
    return 0 if valid else 1


if __name__ == "__main__":
    raise SystemExit(main())
