"""Normal front door for The Field master candidate.

This CLI deliberately exposes a small operating surface while preserving the
advanced `field` CLI for expert and archival workflows.
"""
from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

from rabbithole.interchange import graph_validate, make_envelope, parse_json, seal, validate_shape
from rabbithole.master_registry import MasterRegistry
from rabbithole.outward_loop import ExternalObjective, FileIntegrityProfile, OutwardLoopEngine


def _json(value: str) -> Any:
    stripped = value.lstrip()
    if stripped.startswith(("{", "[")):
        return json.loads(value)
    return json.loads(Path(value).read_text())


def _dump(value: Any, output: str | None = None) -> None:
    def default(obj: Any) -> Any:
        if dataclasses.is_dataclass(obj):
            return dataclasses.asdict(obj)
        return str(obj)
    text = json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, default=default) + "\n"
    if output:
        Path(output).write_text(text)
    else:
        print(text, end="")


def _objective(raw: dict[str, Any]) -> ExternalObjective:
    data = dict(raw)
    data["success_conditions"] = tuple(data.get("success_conditions", ()))
    data["allowed_actions"] = tuple(data.get("allowed_actions", ()))
    return ExternalObjective(**data)


def _profile(config: dict[str, Any], base_dir: Path | None = None) -> FileIntegrityProfile:
    raw = dict(config.get("profile", {}))
    if raw.get("kind") != "file-integrity":
        raise ValueError("only the contacted file-integrity profile is built into the master candidate")
    def resolve(value: str) -> Path:
        path = Path(value)
        return path if path.is_absolute() or base_dir is None else (base_dir / path).resolve()
    return FileIntegrityProfile(resolve(raw["source"]), raw["expected_sha256"], resolve(raw["output"]))


def _load_engine(config_path: str, state: str) -> OutwardLoopEngine:
    config = _json(config_path)
    base_dir = Path(config_path).resolve().parent if Path(config_path).exists() else Path.cwd()
    profile = _profile(config, base_dir)
    return OutwardLoopEngine.load(
        state,
        acquire=profile.acquire,
        verify=profile.verify,
        act=profile.act,
        monitor=profile.monitor,
        replan=profile.replan,
    )


def cmd_status(args: argparse.Namespace) -> int:
    out = MasterRegistry(args.root).status()
    _dump(out)
    return 0 if out["verification"]["valid"] else 1


def cmd_verify(args: argparse.Namespace) -> int:
    out = MasterRegistry(args.root).verify()
    _dump(out)
    return 0 if out["valid"] else 1



def cmd_registry(args: argparse.Namespace) -> int:
    registry = MasterRegistry(args.root)
    key = args.registry.replace("-", "_")
    mapping = {
        "origin_reuse": "origin_reuse",
        "gaps": "gap_closure",
        "blind_spots": "blind_spots",
        "changelog": "changelog",
        "propagation": "implementation_propagation",
        "requirements": "requirements",
        "components": "components",
        "capabilities": "capabilities",
        "decisions": "decisions",
        "standards": "standards",
    }
    if key not in mapping:
        raise ValueError("unknown registry")
    _dump(registry.data[mapping[key]])
    return 0


def cmd_fip_seal(args: argparse.Namespace) -> int:
    raw = _json(args.input)
    if args.profile:
        payload = raw if isinstance(raw, dict) else {"value": raw}
        out = make_envelope(
            profile=args.profile,
            identity=args.identity,
            payload=payload,
            dependencies=tuple(args.dependency or ()),
            authority_ceiling=args.authority_ceiling,
            issuer=args.issuer,
            scopes=tuple(args.scope or ()),
        )
    else:
        out = seal(raw)
    _dump(out, args.output)
    return 0


def cmd_fip_verify(args: argparse.Namespace) -> int:
    raw_text = Path(args.input).read_text() if Path(args.input).exists() else args.input
    obj = parse_json(raw_text)
    out = validate_shape(obj)
    out["canonical_sha256"] = hashlib.sha256(
        __import__("rabbithole.interchange", fromlist=["canonical_bytes"]).canonical_bytes(obj)
    ).hexdigest()
    _dump(out)
    return 0


def cmd_fip_batch(args: argparse.Namespace) -> int:
    raw = _json(args.input)
    if not isinstance(raw, list):
        raise ValueError("batch input must be a JSON array")
    out = graph_validate(raw)
    _dump(out)
    return 0


def cmd_phase_init(args: argparse.Namespace) -> int:
    config = _json(args.config)
    objective = _objective(dict(config["objective"]))
    base_dir = Path(args.config).resolve().parent if Path(args.config).exists() else Path.cwd()
    profile = _profile(config, base_dir)
    engine = OutwardLoopEngine(
        args.state,
        objective,
        acquire=profile.acquire,
        verify=profile.verify,
        act=profile.act,
        monitor=profile.monitor,
        replan=profile.replan,
    )
    engine.save()
    _dump({"initialized": True, "state": str(args.state), "integrity": engine.verify_integrity()})
    return 0


def cmd_phase_step(args: argparse.Namespace) -> int:
    engine = _load_engine(args.config, args.state)
    receipt = engine.step()
    _dump({"receipt": receipt, "integrity": engine.verify_integrity()})
    return 0 if engine.verify_integrity()["valid"] else 1


def cmd_phase_run(args: argparse.Namespace) -> int:
    engine = _load_engine(args.config, args.state)
    receipts = engine.run(max_cycles=args.cycles, max_seconds=args.seconds)
    out = {
        "receipts": receipts,
        "integrity": engine.verify_integrity(),
        "external_claims_closed": False,
    }
    _dump(out)
    return 0 if out["integrity"]["valid"] else 1


def cmd_phase_status(args: argparse.Namespace) -> int:
    state = Path(args.state)
    raw = (state / "outward_loop_state.json").read_bytes()
    expected = (state / "outward_loop_state.sha256").read_text().strip()
    observed = hashlib.sha256(raw).hexdigest()
    payload = json.loads(raw)
    out = {
        "valid": expected == observed,
        "digest": observed,
        "cycles": len(payload.get("cycles", [])),
        "stopped": payload.get("stopped", False),
        "stop_reason": payload.get("stop_reason", ""),
        "resource_used": payload.get("resource_used", {}),
        "external_claims": payload.get("external_claims", {}),
    }
    _dump(out)
    return 0 if out["valid"] else 1


def cmd_frontdoor(args: argparse.Namespace) -> int:
    mapping = {
        "observe": ["status", args.state],
        "verify": ["verify", args.state],
        "research": ["investigate", *args.rest, args.state],
        "reason": ["inquire", *args.rest, args.state],
        "act": ["task", *args.rest, args.state],
        "validate": ["validation-status", args.state, *args.rest],
        "optimize": ["performance-status", *args.rest],
        "administer": ["organism", *args.rest, args.state],
    }
    command = [sys.executable, str(Path(__file__).with_name("field_cli.py")), *mapping[args.intent]]
    return subprocess.call(command)


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="The Field current master candidate")
    p.add_argument("--root", default=str(Path(__file__).parent))
    sub = p.add_subparsers(dest="command", required=True)

    status = sub.add_parser("status", help="show current master, promotion and external-boundary status")
    status.set_defaults(func=cmd_status)
    verify = sub.add_parser("verify", help="verify current master registries, documents and history")
    verify.set_defaults(func=cmd_verify)
    reg = sub.add_parser("registry", help="show one current master registry")
    reg.add_argument("registry", choices=("origin-reuse", "gaps", "blind-spots", "changelog", "propagation", "requirements", "components", "capabilities", "decisions", "standards"))
    reg.set_defaults(func=cmd_registry)

    fs = sub.add_parser("fip-seal", help="seal or construct an experimental FIP object")
    fs.add_argument("input"); fs.add_argument("--output")
    fs.add_argument("--profile"); fs.add_argument("--identity", default="")
    fs.add_argument("--dependency", action="append", default=[])
    fs.add_argument("--scope", action="append", default=[])
    fs.add_argument("--authority-ceiling", type=int, default=0)
    fs.add_argument("--issuer", default="")
    fs.set_defaults(func=cmd_fip_seal)
    fv = sub.add_parser("fip-verify", help="verify one experimental FIP object")
    fv.add_argument("input"); fv.set_defaults(func=cmd_fip_verify)
    fb = sub.add_parser("fip-batch", help="verify FIP dependency and revocation graph")
    fb.add_argument("input"); fb.set_defaults(func=cmd_fip_batch)

    pi = sub.add_parser("phase-init", help="initialize a bounded outward-loop profile")
    pi.add_argument("config"); pi.add_argument("state"); pi.set_defaults(func=cmd_phase_init)
    ps = sub.add_parser("phase-step", help="execute one acquire-test-act-monitor-replan cycle")
    ps.add_argument("config"); ps.add_argument("state"); ps.set_defaults(func=cmd_phase_step)
    pr = sub.add_parser("phase-run", help="run a bounded number of outward-loop cycles")
    pr.add_argument("config"); pr.add_argument("state"); pr.add_argument("--cycles", type=int, default=1)
    pr.add_argument("--seconds", type=float); pr.set_defaults(func=cmd_phase_run)
    pst = sub.add_parser("phase-status", help="inspect persisted outward-loop state without advancing it")
    pst.add_argument("state"); pst.set_defaults(func=cmd_phase_status)

    fd = sub.add_parser("frontdoor", help="route one normal intent to the existing advanced CLI")
    fd.add_argument("intent", choices=("observe", "verify", "research", "reason", "act", "validate", "optimize", "administer"))
    fd.add_argument("state"); fd.add_argument("rest", nargs=argparse.REMAINDER); fd.set_defaults(func=cmd_frontdoor)
    return p


def main() -> int:
    try:
        args = parser().parse_args()
        return int(args.func(args) or 0)
    except (ValueError, KeyError, TypeError, RuntimeError, OSError) as exc:
        print(f"error: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    import os
    code = main()
    sys.stdout.flush(); sys.stderr.flush()
    os._exit(code)
