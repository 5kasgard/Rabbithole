# The Field

The Field is a truth-grounded computational substrate for bounded reasoning, evidence, coordination and externally consequential action. This repository is the **product source**, not the complete development vault.

The current published runtime is **0.18.0rc3**, the most complete internally supported master in the preserved lineage. It remains a release candidate: external slow-clock validation and independent evaluation are still open.

## Design rule

> Heterogeneous by bounded function; homogeneous at authority boundaries.

The system combines deterministic constraints, provenance, epistemic state, revocation, capability-scoped execution, resident operation, whole-subject profiles, experimental interchange and explicit utility/resource accounting. Internal work is not automatically counted as real-world progress.

## Repository scope

Included here:

- the complete Python runtime and command surfaces;
- current machine-readable master registries;
- authoritative architecture, constitution and conformance documents;
- examples and experimental FIP implementations;
- a fast public test suite;
- a consolidated changelog and Stage 6 external-contact obligations.

Excluded from Git:

- nested historical release archives;
- raw reconstruction and ARC campaign state;
- generated acceptance artifacts and benchmark corpora;
- compiled binaries, wheels, caches and runtime state.

The immutable full lineage vault is a separate archival distribution. `history/MASTER_LINEAGE_INDEX.json` preserves its content identities without pretending the bytes are embedded here.

## Install

```bash
python -m pip install .
```

Python 3.10 or later is required.

## Main commands

```bash
field-master status
field-master verify
field --help
field-performance --help
```

Run the public product checks with:

```bash
python scripts/run_product_tests.py
```

## Bounded outward loop

```bash
field-master phase-init examples/master/file_integrity_loop.json ./state/loop
field-master phase-step examples/master/file_integrity_loop.json ./state/loop
field-master phase-status ./state/loop
```

The built-in profile verifies a frozen file digest, performs a reversible effect, monitors it, records audit events and keeps unsupported external utility claims blocked.

## Start reading

1. `docs/GOAL_VISION.md`
2. `docs/CONSTITUTION_v6_0.md`
3. `docs/MASTER_ARCHITECTURE.md`
4. `docs/THE_FIELD_master.md`
5. `docs/KNOWN_LIMITS_AND_EXTERNAL_GATES.md`
6. `CHANGELOG.md`

## Status and honesty boundary

This repository does not claim that:

- FIP is an adopted external standard;
- 72-hour or 14-day live trials have completed;
- independent utility or safety superiority is established;
- the full personal or collective exocortex vision is deployed.

See `docs/stage6/EXTERNAL_CONTACT_OBLIGATIONS.json` for the remaining evidence obligations.

## Licence

No public software licence has been selected yet. Publication of the source does not by itself grant reuse rights.
